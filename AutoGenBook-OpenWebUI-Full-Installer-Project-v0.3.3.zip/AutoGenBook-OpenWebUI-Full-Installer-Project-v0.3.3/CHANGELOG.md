## 0.3.3 — persistent capability downloads

- Replaced the browser-token landing/ticket flow with a stable signed capability URL.
- Bound each capability to Open WebUI file ID, owner, SHA-256 and size.
- Added direct GET/HEAD/Range streaming without browser localStorage or cookies.
- Kept 0.3.2 broker paths as HTTP 410 migration endpoints.
- Forced a non-empty binary preview card to eliminate the `No content` fallback.
- Added regression tests for reload stability, tampering, record replacement and ranged downloads.

## 0.3.2 — authenticated Open WebUI downloads

- Added a same-origin authenticated download broker for persistent AutoGenBook files.
- Replaced user-facing direct `/api/v1/files/<id>/content` links that could return `Not authenticated`.
- Added HMAC download tickets, ownership checks, HEAD/Range/If-Range/ETag support and bounded streaming.
- Added binary-file preview metadata with a durable Download action instead of Open WebUI's `No content` fallback.
- Added idempotent repair of 0.3.1 file records through `výstupy JOB_ID`.
- Removed publication of temporary Companion URLs when native persistence fails.
- Added authenticated-download regression tests and incident documentation.

# Changelog

## 0.3.1 — output parity with standalone AutoGenBook

- Added the default `direct` reviewer parity profile, preserving the canonical standalone system prompt and task contract.
- Removed the default LLM1 prompt-replacement step; `hybrid` may create only a supplemental KB1 addendum and `compliance` remains explicit opt-in.
- Replaced the legacy single-query `k=6` KB2 context with criterion-aware, document-stratified evidence and an auditable evidence manifest.
- Added ordered full-context KB1 handling that cannot erase the academic-quality rubric.
- Propagated cleaned user instructions and the requested output language into the real reviewer prompt.
- Fixed attachment metadata such as an input filename ending in `.pdf` being misread as a PDF-only export request.
- Added `reviewer_parity_manifest.json`, `direct_cli_parity_request.json`, effective prompt snapshots and evidence/quality/conversion reports.
- Added a fail-closed reviewer quality gate with one evidence-preserving repair attempt.
- Requested export failures now fail the job instead of returning `SUCCEEDED` with a missing file.
- PDF export defaults to LuaLaTeX/XeLaTeX before pdfLaTeX and normalizes common Unicode mathematical symbols.
- Fixed direct CLI model overrides being replaced by the global fallback model.
- Added regression tests for prompt preservation, model/command parity, full KB1 context, multi-criterion KB2 coverage, language, attachment parsing and strict exports.


## 0.2.9 — durable Open WebUI artifacts and non-expiring chat links

- Published AutoGenBook outputs are now streamed into the authenticated Open WebUI file store.
- Chat responses and `files` events use stable `/api/v1/files/<id>/content?attachment=true` URLs instead of temporary Companion signatures.
- Large outputs are no longer skipped by the input-attachment size limit; the default persistent-output limit is unlimited.
- Deterministic user-scoped file IDs make `výstupy <job-id>` idempotent and allow migration of completed jobs from older versions.
- Added provider-aware streaming for local, S3, GCS and Azure Open WebUI storage backends.
- Companion fallback links now use a signing key separate from its bearer token.
- Expired fallback links return HTTP 410 with recovery instructions instead of falling through to `Invalid companion token`.
- Added regression tests for multi-megabyte streaming, durable links, duplicate suppression, token rotation and expired signatures.


## 0.2.8 — provider-isolated Open WebUI workers and exact-key preflight

- Fixed a credential-precedence defect where an inherited `OPENROUTER_API_KEY` or role-level endpoint could override the Open WebUI key already validated for the job.
- Detached workers now scrub inherited OpenRouter/OpenAI credentials and base URLs before provider-specific values are injected.
- `AUTOGENBOOK_LLM_API_KEY` and `AUTOGENBOOK_LLM_BASE_URL` are authoritative inside a provider-isolated job.
- Added an exact-worker `/api/models` preflight before AutoGenBook import and KB indexing, so invalid credentials fail immediately rather than after expensive RAG preparation.
- Provider validation and worker preflight now use matching proxy-free transports.
- Added non-secret credential source/fingerprint diagnostics to provider validation, worker logs and request snapshots.
- Interactive replacement of an installer-managed external TXT key now atomically updates that authoritative file instead of storing an ignored lower-priority key.
- Added regression coverage for key precedence, endpoint precedence, environment scrubbing, exact preflight authorization and external TXT rotation.


## 0.2.7 — interactive reviewer KB1 file upload

- Added a visible native file picker to the reviewer KB1 question in Open WebUI.
- The picker accepts PDF, DOCX, PPTX, Markdown and TXT, uploads to the current Open WebUI origin, and returns only Open WebUI file identifiers to the Pipe.
- Added the follow-up command `KB1 <PROJECT_OR_JOB_ID>` so a user can attach KB1 documents in a later chat message.
- Explicitly attached KB1 files bypass filename-role heuristics but still undergo Companion semantic, authentication-page and relevance validation before a reviewer job starts or resumes.
- A valid KB1 added to a draft reviewer project starts a job; a valid KB1 added to a failed/cancelled/interrupted reviewer job resumes it without re-uploading KB2.
- Added regression coverage for the modal upload contract, same-origin endpoint, file ID resolution, project patching, validation and follow-up job creation.


## 0.2.6 — fail-closed relevance KB1 and complete failure diagnostics

- odmítá OAuth/SSO/login, access-gate, příliš krátké a nerelevantní zdroje KB1;
- ověřuje obsah HTML/TXT/PDF/DOCX/PPTX před spuštěním reviewer LLM;
- znovu validuje KB1 přímo v reviewer pipeline a používá pouze přijaté zdroje;
- kompletní ZIP výstup nyní obsahuje `worker.log`, request, progress, stav úlohy a `failure.json`;
- failure metadata se zapisují před vytvořením balíku, takže diagnostika již neskryje vlastní chybu;
- manifest obsahuje verzi Companionu, protokol, stav, exit code a bezpečně redigovanou chybu.

## 0.2.5 — povinná a dohledatelná KB1 pro reviewer, bezpečnější registrace Function

### Změněno

- režim `reviewer` už bez ověřitelné KB1 tiše nepokračuje s obecným promptem;
- KB1 je ve výchozím režimu povinná stejně jako KB2 a musí obsahovat hodnoticí předpis, metodiku, rubric, šablonu posudku nebo explicitní kritéria uživatele;
- Open WebUI Pipe při chybějící nebo nepoužitelné KB1 zastaví start jobu a vyžádá soubor, veřejnou URL, text kritérií nebo kontext pro řízené dohledání;
- kontextové dohledání vyžaduje alespoň jurisdikci/zemi, instituci a typ práce; fakulta a studijní program jsou volitelné upřesňující údaje;
- žádný nalezený zdroj se nepoužije automaticky — uživatel musí kandidátní URL výslovně vybrat;
- obecný posudek bez KB1 je možný pouze explicitní volbou `allow_without_kb1` nebo CLI přepínačem `--reviewer-allow-missing-kb1` a je označen jako neinstitucionální.
- příkaz `pokračuj JOB_ID` při obnově staré reviewer úlohy znovu validuje projekt, případně otevře průvodce KB1 a job nezařadí bez úspěšné validace.

### Přidáno

- endpointy `POST /v1/projects/{project_id}/reviewer/kb1/import` a `POST /v1/projects/{project_id}/reviewer/kb1/discover`;
- bezpečný import veřejného HTTP/HTTPS zdroje s ochranou proti SSRF, validací redirectů, omezením velikosti a provenance sidecarem;
- diagnostické artefakty `reviewer_kb1_diagnostic.json` a `reviewer_kb1_diagnostic.md`;
- chybové kódy `MISSING_REVIEWER_KB1`, `EMPTY_REVIEWER_KB1` a `REVIEWER_KB1_REQUIRED`;
- interaktivní reviewer průvodce s příkazy `URL:`, `TEXT:` a `HLEDAT:`;
- regresní testy chybějící/prázdné KB1, explicitního override, importu textu/URL, SSRF ochrany, discovery payloadu a výběru kandidátů.

### Opraveno

- přímý Open WebUI API klíč se před vytvořením HTTP hlavičky normalizuje a odmítá CR/LF, řídicí znaky a browser JWT;
- automatická registrace Function používá přímé proxy-free HTTP/HTTPS spojení, ověřuje `/api/version` a provádí admin preflight;
- HTTP 400 s nízkoúrovňovou zprávou `Invalid HTTP request received` už neoznačí instalaci Companionu za neúspěšnou; instalátor bezpečně dokončí instalaci a nabídne ruční import Function;
- TXT reference API klíče má prioritu `external_first`, takže ji nepřebije starý per-user/session credential.

## 0.2.4 — Open WebUI API klíč z externího TXT souboru

### Přidáno

- instalační parametr `--webui-api-key-file` / `--api-key-file`;
- bezpečné uložení pouze absolutní cesty k TXT souboru a živé načtení klíče při každé validaci i startu workeru;
- skripty `Configure-OpenWebUI-ApiKeyFile.cmd` a `Clear-OpenWebUI-ApiKeyFile.cmd` pro rotaci nebo odpojení reference bez reinstalace;
- podpora zápisů `sk-…`, `OPENWEBUI_API_KEY=…` a `Authorization: Bearer …`;
- validace UTF-8/UTF-16, přípony `.txt`, jednoho credentialu, délky a řídicích znaků.

## 0.2.3 — trvalá autentizace Open WebUI pro vícedenní úlohy

### Opraveno

- odstraněno použití expirovatelného browser session/JWT tokenu jako credentialu workeru;
- Pipe před startem i obnovením ověřuje trvalý osobní Open WebUI API klíč přes `/api/models`;
- session/JWT token je rozpoznán a odmítnut ještě před síťovým voláním;
- chyby 401 a 403 mají vlastní kódy a akční zprávu s příkazem `pokračuj JOB_ID`;
- worker log už nekončí pouze obecným `exit code 2`, ale uchová konkrétní příčinu autentizace;
- OpenAI-compatible klient rozlišuje 401 a 403 a nepovažuje je za přechodné chyby;
- aktualizační instalace atomicky zachová celý adresář `data`, včetně existujících projektů, checkpointů, tajných údajů a velkých výstupů.

### Přidáno

- endpoint `POST /v1/providers/validate`;
- kontrola dostupnosti zvoleného modelu pro konkrétní API klíč;
- regresní testy session tokenu, neplatného klíče, modelového přístupu, obnovy po 401 a zachování dat při aktualizaci;
- incident report k úloze reviewer, která selhala po úspěšném vytvoření KB2 na expirovaném tokenu.

## 0.2.2 — oprava importu Function v Open WebUI

- odstraněn nekompatibilní frontmatter rozsah `httpx>=0.27,<1`;
- Pipe už nespouští pip při importu, protože používá `httpx` a Pydantic dodávané Open WebUI;
- přidán regresní test parseru frontmatter podle chování Open WebUI;
- audit nyní odmítne každý neplatný nebo čárkou rozbitelný frontmatter requirement;
- integrační bundle a projektové archivy jsou znovu sestaveny deterministicky.

## 0.2.1 — oprava startu Windows instalátoru

### Opraveno

- instalátor přidává `companion\src` a zdroj AutoGenBooku do `PYTHONPATH`;
- automaticky rozpozná dependency-complete rozložení `app/main.py` i zdrojové rozložení `main.py`;
- před detached startem provede importní a `doctor` preflight;
- při pádu procesu zobrazí návratový kód a konec `companion.log` namísto zavádějícího čekání pouze na `bridge.json`;
- stale `bridge.json` se po neúspěšném health checku odstraní;
- Windows proces používá `CREATE_NO_WINDOW` a instalátor korektně uzavírá rodičovský log handle;
- offline runtime se naplní přesným Companion wheelem vytvořeným daným buildem, nikoli historicky připnutou verzí 0.1.0;
- offline release gate nyní skutečně spustí instalátor, ověří autentizovaný `/v1/health` a proces následně ukončí;
- samostatný Windows complete workflow používá kanonický integrační builder a neodkazuje na odstraněné patchovací skripty.

### Přidáno

- regresní test instalace do cesty s mezerami;
- regresní test zdrojového i balíkového rozložení;
- diagnostika chybějících Python závislostí před spuštěním Companionu.

## 0.2.0 — auditovaná Open WebUI integrace

### Přidáno

- dynamický Open WebUI `select` pro LLM model s výchozí hodnotou `e-infra.glm-5`;
- propagace modelu přes job, worker a OpenAI-compatible klient;
- perzistentní progress, heartbeat a samostatný progress endpoint;
- background běh vhodný pro několikadenní úlohy;
- signed download URL, `HEAD`, `ETag`, `Range`, `If-Range`, `206` a `416`;
- auditní skript a deterministický builder integračního bundle;
- kompletní české README s instalací a příklady.

### Opraveno

- FastAPI `422` na dynamicky přidaném progress endpointu;
- rozdíl mezi vývojovým overlay a distribuovaným integračním bundle;
- blokující hashování velkých souborů během průběhu;
- závislost dlouhé úlohy na otevřeném chatovém požadavku;
- riziko použití historického modelu natvrdo místo modelu zvoleného uživatelem;
- neúplný přístup k velkým výsledkům v Open WebUI.

### Změněno

- postupné patchery v2–v5 byly odstraněny;
- jediným kanonickým buildem je `tools/build_openwebui_integration.py`;
- Companion a Pipe mají verzi 0.2.0.

## 0.1.0

- první Companion, Open WebUI Pipe, instalátor a offline build workflow.

## 0.3.1 - 2026-09-18

### Fixed

- Corrected the Open WebUI assistant-file event payload. Generated artifacts now declare `type: file`, use the durable Open WebUI file ID, and appear as native downloadable file cards.
- Added post-registration verification of the Open WebUI database row, owner, metadata size, and local file bytes before any persistent link is published.
- Corrected `url` semantics for Open WebUI `FileItem`/`FileItemModal`; `url` now contains the file ID while `persistent_url` carries the stable content URL.
- Added a fresh, explicitly temporary Companion fallback link when native Open WebUI registration is unavailable instead of returning no usable download.
- Extended the `výstupy <job-id>` path so existing jobs can repair old response attachments without regeneration.

### Tests

- Added a frontend contract regression test for `message.files`.
- Added a real file-content endpoint download test and size/byte verification.
- Added a native-registration-unavailable fallback test.
