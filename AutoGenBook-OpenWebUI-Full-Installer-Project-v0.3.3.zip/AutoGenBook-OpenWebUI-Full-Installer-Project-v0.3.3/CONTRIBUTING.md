# Přispívání

1. Zachovejte kompatibilitu bez forku Open WebUI.
2. Neměňte modelový kontrakt tak, aby call-site default mohl přepsat model uložený v jobu.
3. Dlouhá práce nesmí záviset na otevřeném HTTP požadavku.
4. Velké soubory nikdy nenačítejte celé do paměti.
5. Nepřidávejte API klíče do job payloadu, logu nebo testovacích fixture.
6. Po změně integračních souborů spusťte:

```bash
python tools/build_openwebui_integration.py build
python tools/build_openwebui_integration.py verify
python tools/audit_project.py --project-root . --output-dir audit
```

Pull request musí obsahovat test pro opravenou chybu a aktualizaci README nebo changelogu, pokud mění uživatelský kontrakt.
