@echo off
setlocal
call "%~dp0installer\Install-AutoGenBook.cmd" --configure-only --skip-function --clear-webui-api-key-file
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
