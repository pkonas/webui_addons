@echo off
setlocal
set "KEYFILE=%~1"
if not defined KEYFILE (
  echo Enter the full path to the .txt file containing one persistent Open WebUI API key.
  set /p "KEYFILE=API key TXT file: "
)
if not defined KEYFILE (
  echo No file was selected.
  exit /b 2
)
call "%~dp0installer\Install-AutoGenBook.cmd" --configure-only --skip-function --webui-api-key-file "%KEYFILE%"
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
