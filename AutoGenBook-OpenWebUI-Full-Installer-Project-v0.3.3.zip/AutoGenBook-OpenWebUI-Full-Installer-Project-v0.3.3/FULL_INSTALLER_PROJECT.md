# AutoGenBook Open WebUI — kompletní projekt instalátoru 0.3.3

Tento archiv je úplný projekt použitý pro instalaci, audit a další sestavení integrace AutoGenBook do Open WebUI bez forku hostitelské aplikace.

## Rychlá aktualizace na Windows

Rozbalte celý archiv a spusťte z jeho kořene:

```cmd
Install-AutoGenBook.cmd
```

S persistentním osobním Open WebUI API klíčem uloženým v TXT souboru:

```cmd
Install-AutoGenBook.cmd --webui-api-key-file "C:\Secrets\openwebui-api-key.txt"
```

Instalace do stejného cílového adresáře atomicky zachová `data`: projekty, databázi úloh, KB1/KB2, checkpointy, logy a dosavadní artefakty.

## Důležité změny 0.3.3

- Odstraněna závislost downloadu na browserovém `localStorage`, cookie a bearer hlavičce v novém okně.
- Každý výstup používá stabilní HMAC capability `/api/autogenbook/download/...`.
- Capability je svázaná s Open WebUI file ID, vlastníkem, SHA-256 a velikostí.
- Download podporuje `GET`, `HEAD`, `Range`, `If-Range`, `ETag`, HTTP 206 a 416.
- Binární file modal dostává Markdown popis a tlačítko **Stáhnout**, takže nezobrazuje `No content`.
- Staré endpointy brokeru 0.3.2 vracejí HTTP 410 s pokynem `výstupy JOB_ID`.
- `výstupy <job-id>` opraví i dříve registrované soubory bez nové LLM generace a bez duplicit.
- Dočasné Companion download URL se uživateli nezveřejňují ani jako fallback.
- Zachována je reviewer CLI parity, document-wide evidence, explicitní jazyk/model, quality gate, progress, heartbeat a izolace provider credentialu.

Capability URL je přístupový údaj. Kdo získá úplnou URL, může konkrétní soubor stáhnout. Odkaz je neuhodnutelný a standardně zůstává v soukromé konverzaci, ale nemá být zveřejňován.

## Obsah

- úplný zdroj AutoGenBooku;
- AutoGenBook Companion 0.3.3;
- Open WebUI Pipe Function 0.3.3 bez hostitelského `pip install`;
- instalační a odinstalační skripty;
- persistentní Open WebUI API key TXT reference;
- trvalé Open WebUI výstupy a migrační příkaz `výstupy`;
- perzistentní progress, heartbeat a obnovitelné Companion API downloady;
- reviewer KB1 workflow a diagnostické artefakty;
- Inno Setup projekt a dependency-complete build workflow;
- deterministický integrační bundle;
- testy, README, incident reporty, manifesty a auditní podklady.

Výchozí LLM model je `e-infra.glm-5`.
