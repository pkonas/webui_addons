@echo off
setlocal
call "%~dp0installer\Install-AutoGenBook.cmd" %*
set CODE=%ERRORLEVEL%
endlocal & exit /b %CODE%
