# AutoGenBook pro Open WebUI

AutoGenBook pro Open WebUI je lokální nástroj pro generování rozsáhlých knih, odborných článků, prezentací, vědeckých experimentů, projektových návrhů a recenzních posudků přímo z desktopové aplikace Open WebUI.

Integrace **nemění ani neforkuje Open WebUI**. Skládá se ze dvou částí:

1. **AutoGenBook Pipe Function** běžící uvnitř Open WebUI. Sbírá zadání, přílohy a uživatelské volby, zobrazuje stav a vrací výsledky.
2. **AutoGenBook Companion** běžící jako samostatná lokální služba. Udržuje dlouhotrvající úlohy, spouští izolované workery, ukládá průběh a bezpečně streamuje výstupní soubory.

> **Aktuální auditovaná verze:** 0.3.3  
> **Výchozí LLM model:** `e-infra.glm-5`  
> **Podporované režimy:** `book`, `paper`, `presentation`, `scientist`, `proposal`, `reviewer`

## Obsah

- [Co nástroj řeší](#co-nástroj-řeší)
- [Architektura](#architektura)
- [Požadavky](#požadavky)
- [Instalace](#instalace)
- [První spuštění](#první-spuštění)
- [Volba LLM modelu](#volba-llm-modelu)
- [Práce s dlouhotrvajícími úlohami](#práce-s-dlouhotrvajícími-úlohami)
- [Výstupní soubory a velké downloady](#výstupní-soubory-a-velké-downloady)
- [Příklady použití](#příklady-použití)
- [Reviewer: povinná KB1 a řízené dohledání](#reviewer-povinná-kb1-a-řízené-dohledání)
- [Znalostní báze a přílohy](#znalostní-báze-a-přílohy)
- [Bezpečnost a soukromí](#bezpečnost-a-soukromí)
- [Samostatné CLI](#samostatné-cli)
- [Ekvivalence s přímým CLI AutoGenBooku](#ekvivalence-s-přímým-cli-autogenbooku)
- [Build a reprodukovatelnost](#build-a-reprodukovatelnost)
- [Testování a audit](#testování-a-audit)
- [Řešení problémů](#řešení-problémů)
- [Známá omezení](#známá-omezení)

## Co nástroj řeší

Běžný chat je vhodný pro krátké odpovědi, ale vytvoření knihy nebo rozsáhlé vědecké práce vyžaduje:

- explicitní strukturu dokumentu;
- opakovaná modelová volání;
- lokální nebo webovou rešerši;
- ukládání mezivýsledků;
- obnovu po restartu;
- dlouhodobý průběh a heartbeat;
- bezpečnou práci s přílohami;
- export do více formátů;
- přenos souborů, které mohou mít stovky megabajtů nebo jednotky gigabajtů.

AutoGenBook tyto kroky převádí na trvalou úlohu řízenou Companionem. Zavření chatu neukončí worker a stav lze po návratu znovu načíst.

## Architektura

```text
┌────────────────────────────────────────────────────────────┐
│ Open WebUI Desktop                                         │
│                                                            │
│  uživatel + chat + přílohy                                 │
│                │                                           │
│                ▼                                           │
│  AutoGenBook Pipe Function                                 │
│  ├─ UserValves a výběr LLM                                 │
│  ├─ validace zadání                                        │
│  ├─ status události                                        │
│  ├─ příkazy status/cancel/resume/files                     │
│  └─ trvalá registrace výsledků do Open WebUI              │
└──────────────────────────┬─────────────────────────────────┘
                           │ autentizované HTTP na loopbacku
                           ▼
┌────────────────────────────────────────────────────────────┐
│ AutoGenBook Companion                                      │
│  ├─ FastAPI API                                             │
│  ├─ SQLite databáze projektů a úloh                         │
│  ├─ bezpečné úložiště tajných údajů                         │
│  ├─ perzistentní progress + heartbeat                       │
│  ├─ streamované a obnovitelné downloady                     │
│  └─ samostatný worker proces pro každou úlohu               │
│                         │                                   │
│                         ▼                                   │
│                    AutoGenBook core                         │
│                    RAG / export / audit                     │
└────────────────────────────────────────────────────────────┘
```

Companion standardně poslouchá pouze na `127.0.0.1` a používá náhodný bearer token uložený v lokálním bridge souboru.

## Požadavky

Pro běžné desktopové použití jsou potřeba:

- nainstalovaný Open WebUI Desktop nebo lokální Open WebUI server;
- oprávnění administrátora Open WebUI k importu Function;
- dostatek volného místa pro runtime, modely, znalostní báze a výsledky;
- dostupný LLM model v Open WebUI;
- osobní Open WebUI API klíč, pokud má Companion volat model přes Open WebUI API.

Dependency-complete offline build obsahuje vlastní Python, Python balíky, Pandoc, FFmpeg, TinyTeX, PortAudio, Piper TTS a český hlas. Hostitelská aplikace Open WebUI a samotné lokální LLM váhy nejsou součástí AutoGenBook instalátoru.

## Instalace

### Doporučená instalace z dependency-complete balíku

Distribuční build vytváří samostatný balík pro každou platformu. Balík se musí rozbalit celý; jednotlivé soubory runtime se nesmějí spouštět přímo z archivu. Pro běžnou instalaci na Windows používejte **Complete Offline Installer** nebo **Complete Offline Portable**, nikoli zdrojový archiv `Audited-Project`.

Zdrojový archiv obsahuje instalační kód kvůli reprodukovatelnosti a vývoji. Od verze 0.2.1 umí správně rozpoznat i zdrojové rozložení a přidat `companion\src` do `PYTHONPATH`, ale pokud v archivu není vlastní runtime a wheelhouse, musí mít systémový Python potřebné balíky již nainstalované. To není doporučená cesta pro laika ani plně offline instalace.

#### Linux x64

```bash
tar -xzf AutoGenBook-OpenWebUI-Offline-Installer-linux-x64.tar.gz
cd AutoGenBook-OpenWebUI-linux-x64
chmod +x install.sh
./install.sh
```

#### Windows x64

Spusťte podepsaný EXE instalátor nebo po rozbalení build stagingu:

```text
Install-AutoGenBook.cmd
```

S odkazem na persistentní osobní Open WebUI API klíč uložený v TXT souboru:

```cmd
Install-AutoGenBook.cmd --webui-api-key-file "C:\Secrets\openwebui-api-key.txt"
```

#### macOS

Zdrojový projekt obsahuje platformně nezávislý Python instalátor, ale auditovaná verze 0.3.3 zatím neposkytuje notarizovaný macOS balík. Sestavení musí proběhnout na macOS a následovat podepsání/notarizace vlastníka projektu.

### Co instalátor provede

1. Zkopíruje soukromý runtime do uživatelského datového adresáře.
2. Vytvoří bezpečný bridge soubor s URL a náhodným tokenem.
3. Spustí AutoGenBook Companion na loopback rozhraní.
4. Ověří endpoint `/v1/health`.
5. Vypíše cestu k souboru `autogenbook_pipe.py`.
6. Nevkládá závislosti do Python prostředí Open WebUI.

### Open WebUI API klíč z TXT souboru

Pro několikadenní úlohy je doporučený **osobní Open WebUI API klíč** uložený v samostatném textovém souboru. Instalátoru se předává pouze cesta:

```cmd
Install-AutoGenBook.cmd --webui-api-key-file "C:\Secrets\openwebui-api-key.txt"
```

Při interaktivní instalaci lze stejnou cestu zadat do výzvy. Soubor musí mít příponu `.txt` a právě jednu neprázdnou hodnotu. Podporované zápisy jsou například:

```text
sk-0123456789abcdef
```

```text
OPENWEBUI_API_KEY=sk-0123456789abcdef
```

```text
Authorization: Bearer sk-0123456789abcdef
```

Instalátor:

- ověří UTF-8/UTF-16 text, délku a nepřítomnost řídicích znaků;
- odmítne browser session/JWT token;
- uloží pouze absolutní cestu, nikoli hodnotu klíče;
- nastaví TXT zdroj jako autoritativní (`external_first`), takže jej nepřebije starý per-user token;
- čte soubor znovu při validaci provideru a při každém startu workeru;
- umožní rotaci klíče pouhou změnou jediné hodnoty ve stejném souboru.

TXT soubor ponechte mimo rozbalený instalační adresář a mimo výstupy AutoGenBooku. Na víceuživatelském systému omezte jeho oprávnění pouze na daného uživatele. Soubor se nesmí přikládat ke konverzaci ani zahrnout do zálohy určené třetím osobám.

Konfiguraci lze později změnit bez reinstalace:

```cmd
Configure-OpenWebUI-ApiKeyFile.cmd "C:\Secrets\openwebui-api-key.txt"
```

Odpojení odkazu, aniž by se zdrojový TXT soubor smazal:

```cmd
Clear-OpenWebUI-ApiKeyFile.cmd
```

Přímý parametr nebo maskovaný interaktivní vstup `--admin-api-key` slouží jen k pohodlné **automatické registraci Function**. Přímý klíč se neukládá a nenahrazuje persistentní TXT zdroj pro vícedenní modelová volání. Instalátor normalizuje zápisy `Bearer ...`, `Authorization: Bearer ...`, assignment i obalující uvozovky ještě před vytvořením HTTP hlavičky.

Automatická registrace je volitelná. Pokud admin API není povolené, klíč nemá roli administrátora, endpoint je omezený nebo server vrátí nízkoúrovňovou chybu `Invalid HTTP request received`, instalace Companionu se dokončí a vypíše cestu pro ruční import Pipe. Pouze CI/release test může vynutit fatální chování přepínačem `--require-function-registration`.

### Import Pipe Function do Open WebUI

1. Otevřete **Admin Panel → Functions**.
2. Vytvořte novou Function importem souboru:

   ```text
   integrations/openwebui/autogenbook_pipe.py
   ```

3. Function zkontrolujte, uložte a aktivujte.
4. V seznamu modelů vyberte **AutoGenBook Companion**.

Open WebUI Functions jsou spustitelný serverový Python kód. Importujte pouze soubor z důvěryhodného, auditovaného balíku a ověřte jeho SHA-256.

## První spuštění

Po výběru AutoGenBook modelu napište například:

```text
Vytvoř patnáctisnímkovou prezentaci v češtině pro vedení univerzity
o bezpečném používání AI. Chci PPTX, PDF, citace a poznámky řečníka.
```

Pipe:

1. rozpozná režim;
2. načte přiložené dokumenty;
3. doplní známé parametry;
4. upozorní na chybějící povinné údaje;
5. zobrazí souhrn;
6. po potvrzení vytvoří trvalou úlohu.

Je-li při instalaci nakonfigurován TXT soubor, Companion použije jeho aktuální hodnotu a Pipe se na klíč neptá. Bez TXT reference si Pipe credential vyžádá maskovaným vstupem. Pro Open WebUI provider musí jít o **trvalý osobní API klíč** vytvořený v **Nastavení → Účet → API Keys**. Browser session/JWT token je odmítnut, protože může během několikadenní úlohy expirovat. Klíč se nesmí psát do běžné chatové zprávy.

## Volba LLM modelu

V uživatelských Valve je pole **LLM model** typu `select`. Nabídka se dynamicky skládá z modelů, které jsou dostupné přihlášenému uživateli v Open WebUI.

Výchozí hodnota je:

```text
e-infra.glm-5
```

Zvolený model se uloží do specifikace úlohy a zůstane neměnný po celý její běh. AutoGenBook jej propaguje přes:

```text
Pipe → job payload → SQLite → worker environment → OpenAI-compatible klient
```

Interní AutoGenBook Pipe modely a Arena modely jsou z nabídky odfiltrovány, aby nevznikla rekurze.

### Open WebUI jako provider

Výchozí provider profil používá Open WebUI API:

```text
Base URL: <adresa Open WebUI>/api
Model: hodnota z combo boxu
Credential: reference na bezpečně uložený osobní API klíč
```

Pro lokální Open WebUI API vytvořte osobní klíč v **Nastavení → Účet → API Keys**. Verze 0.2.8 před startem ověří klíč na `/api/models` a zkontroluje, že je zvolený model pro daného uživatele dostupný. Generace následně používá `/api/chat/completions`. Preferovaný instalační režim uchovává klíč ve vámi spravovaném TXT souboru a persistuje pouze jeho absolutní cestu. Bez TXT reference Companion použije systémový keyring, případně lokální soubor s omezenými právy. V projektu a jobu zůstává pouze název secret reference.

### Izolace credentialu a endpointu workeru

Od verze 0.2.8 je každý detached worker providerově izolovaný. Companion před startem odstraní zděděné `OPENROUTER_API_KEY`, `OPENAI_API_KEY` a cizí base URL, poté vloží výhradně klíč a endpoint vybraného jobu. `AUTOGENBOOK_LLM_API_KEY` a `AUTOGENBOOK_LLM_BASE_URL` mají v izolovaném workeru přednost i před historickými per-role override hodnotami.

Ještě před importem AutoGenBooku a před indexací KB worker provede proxy-free kontrolu:

```text
GET <open-webui>/api/models
Authorization: Bearer <exact-job-key>
```

Do diagnostiky se zapisuje pouze zdroj credentialu (`external_text_file` nebo `stored_per_user`) a krátký SHA-256 fingerprint. Klíč se nezapisuje. Fingerprint umožní ověřit, že Companion validoval a worker skutečně použil stejnou hodnotu.

### Jiný OpenAI-compatible provider

Companion lze nakonfigurovat také pro OpenRouter, LM Studio, Ollama gateway nebo firemní OpenAI-compatible endpoint. Model zvolený v AutoGenBook Valve zůstává autoritativní, pokud job výslovně neurčuje specializovaný multimediální model pro obrázky nebo TTS.

## Práce s dlouhotrvajícími úlohami

AutoGenBook může běžet několik hodin nebo dnů. Worker je samostatný proces Companionu; není svázán s jedním otevřeným chatovým požadavkem.

### Průběh

Progress obsahuje:

- stav a aktuální fázi;
- procenta;
- zprávu o posledním kroku;
- `current` a `total`, jsou-li známy;
- zvolený model;
- PID workeru;
- `started_at`, `updated_at` a `heartbeat_at`.

Stav se atomicky zapisuje do `.autogenbook-progress.json`. Heartbeat se obnovuje i v době, kdy aktuální modelové volání neposkytuje dílčí tokenový stream.

### Příkazy v chatu

Nahraďte `JOB_ID` identifikátorem z odpovědi po spuštění:

```text
status JOB_ID
stav JOB_ID
```

Zobrazí aktuální progress a heartbeat.

```text
cancel JOB_ID
zruš JOB_ID
```

Požádá worker o bezpečné ukončení a zachová mezivýsledky.

```text
resume JOB_ID
pokračuj JOB_ID
```

Zařadí přerušenou nebo zrušenou úlohu k pokračování.

```text
files JOB_ID
soubory JOB_ID
```

Trvale zaregistruje publikované výstupy do úložiště Open WebUI a vrátí stabilní odkazy. U úloh vytvořených starší verzí příkaz současně provede migraci; opakované použití je idempotentní a nevytváří duplicity.

### Zavření aplikace

Zavření karty nebo obnovení chatu úlohu nezastaví. Počítač a proces Companionu však musí zůstat spuštěné. Uspání nebo vypnutí počítače přeruší worker; po návratu použijte `resume JOB_ID`, pokud daná pipeline vytvořila použitelný checkpoint.

## Výstupní soubory a velké downloady

Verze 0.3.3 ukládá publikované artefakty do trvalého úložiště Open WebUI a vytváří pro každý soubor podepsanou capability adresu:

```text
/api/autogenbook/download/PODEPSANÁ_CAPABILITY
```

Předchozí cesty selhávaly ze dvou různých důvodů. Přímá navigace na `/api/v1/files/<id>/content?attachment=true` nepřipojovala bearer hlavičku, takže některé desktopové konfigurace vracely `{"detail":"Not authenticated"}`. Broker 0.3.2 se následně pokoušel token znovu získat z `localStorage` nebo cookie v novém okně; Open WebUI Desktop ale může nové okno otevřít v jiném loopback originu či izolovaném storage kontextu, takže `/api/autogenbook/download-ticket` opět vracel 401.

Capability řešení žádný browserový token nepotřebuje. Odkaz:

- neobsahuje osobní Open WebUI API klíč, browserový JWT ani Companion token;
- je HMAC podepsán klíčem odvozeným od stabilního `WEBUI_SECRET_KEY`;
- je svázán s ID Open WebUI souboru, vlastníkem, SHA-256 a velikostí;
- nemá časovou expiraci a funguje po restartu Companionu i Function reloadu;
- zanikne při smazání nebo nahrazení souboru, změně vlastníka/hash/velikosti nebo rotaci `WEBUI_SECRET_KEY`;
- podporuje `GET`, `HEAD`, `Range`, `If-Range`, `ETag`, `206 Partial Content` a `416 Range Not Satisfiable`.

Každý výstup se současně odešle jako nativní Open WebUI assistant-file objekt s `type=file`, `status=uploaded`, stabilním `id`, názvem, MIME typem a velikostí. Binární soubor nemá textový obsah, proto AutoGenBook uloží do `data.content` krátkou Markdown kartu s názvem, velikostí, MIME typem a odkazem **Stáhnout**. Modal tak nezobrazuje matoucí `No content`.

Kopírování z Companionu do Open WebUI probíhá po blocích. Soubor se nenačítá celý do RAM a vstupní Valve `ATTACH_MAX_BYTES` velké výstupy neomezuje. Administrátor může nastavit samostatný `PERSIST_OUTPUT_MAX_BYTES`; výchozí hodnota `0` znamená bez aplikačního limitu. Open WebUI storage, volné místo a operační systém mohou uplatnit vlastní limity.

Pro lokální desktopové úložiště se data zapisují přes dočasný soubor a atomický rename. Implementace podporuje také Open WebUI S3, GCS a Azure storage. Deterministické, uživatelsky oddělené file ID zajistí, že opakovaný příkaz:

```text
výstupy JOB_ID
```

nevytvoří duplicitní kopii. Stejný příkaz opraví i hotové úlohy registrované staršími verzemi: doplní neprázdnou kartu a vytvoří nový capability odkaz, aniž by znovu volal LLM. Původní stará zpráva se zpětně nepřepíše; používejte novou odpověď vytvořenou příkazem `výstupy JOB_ID`.

> **Bezpečnost capability odkazu:** úplná URL je přístupový údaj. Kdokoli, komu ji předáte, může konkrétní soubor stáhnout. Odkaz je kryptograficky neuhodnutelný a standardně se objeví pouze v soukromé konverzaci vlastníka, ale nemá být zveřejňován.

Dočasné Companion download URL slouží pouze interně pro přenos Pipe → Open WebUI. Nezveřejňují se uživateli. Pokud trvalá registrace selže, odpověď uvede chybu místo nebezpečného nebo expirovatelného fallback odkazu.

## Příklady použití

### Kniha pro odbornou veřejnost

```text
Vytvoř českou odbornou knihu „Praktická bezpečnost generativní AI“.
Cílovou skupinou jsou správci IT a vedoucí týmů. Rozsah přibližně 120 stran,
10 kapitol, každá s praktickým checklistem. Použij přiložené normy jako hlavní
zdroje, zapni citační audit a vrať Markdown, DOCX a PDF.
```

Doporučené přílohy: normy, metodiky, firemní politika, odborné články.

### Učebnice s lokální znalostní bází

```text
Napiš učebnici základů strojového učení pro studenty bakalářského programu.
Vycházej pouze z přiložených skript a článků. Každou kapitolu zakonči otázkami,
řešeným příkladem a seznamem pojmů. Výstup: DOCX, PDF a ZIP se zdrojovými soubory.
```

### Odborný článek

```text
Zpracuj anglický research paper pro arXiv o robustním vyhodnocování RAG systémů.
Výzkumné otázky, datasety a naměřené výsledky jsou v přiloženém JSON a CSV.
Použij BibTeX citace, přísný audit tvrzení a vytvoř Markdown, LaTeX, PDF a refs.bib.
```

### Prezentace s poznámkami řečníka

```text
Vytvoř 20minutovou prezentaci pro vedení univerzity o zavádění lokálních LLM.
Potřebuji 14–16 snímků, stručné body, poznámky řečníka, citace a závěrečný plán
na 90 dní. Výstup PPTX a PDF. Negeneruj marketingové obrázky bez informační hodnoty.
```

### Prezentace s audiem a videem

```text
Vytvoř českou výukovou prezentaci o kybernetické hygieně pro nové zaměstnance.
Přidej krátkou naraci pro každý snímek, použij lokální TTS a vyexportuj také WAV
a MP4. Úvodní a závěrečný snímek do videa nezařazuj.
```

Tento režim používá přibalený FFmpeg a může použít český Piper hlas v dependency-complete buildu.

### Projektový návrh s KB1 a KB2

Přílohy pojmenujte nebo přiřaďte do dvou rolí:

- **KB1** – zadávací dokumentace, pravidla výzvy, hodnoticí kritéria;
- **KB2** – popis projektu, tým, rozpočet, předchozí výsledky a technické podklady.

```text
Připrav projektový návrh do přiložené výzvy.
KB1 obsahuje pravidla a povinnou strukturu, KB2 obsahuje podklady projektu.
Text musí být česky, maximálně 30 stran, každá odborná sekce musí mít alespoň
dvě citace. Spusť tři revizní iterace a vrať DOCX, PDF a auditní report.
```

### Recenzní posudek s explicitní KB1

Přiložte nejméně dva zdrojové okruhy:

- **KB1** – oficiální předpis, směrnice, hodnoticí rubric, šablona posudku nebo vlastní explicitní kritéria;
- **KB2** – hodnocená práce a její přílohy.

```text
Vypracuj nezávislý recenzní posudek přiložené disertační práce.
Soubor `kb1_smernice_doktorske_studium.pdf` obsahuje závazná univerzitní
hodnoticí kritéria. Ostatní přílohy tvoří KB2. Odděl zásadní a drobné
připomínky, ověř reprodukovatelnost experimentů, upozorni na chybějící
citace a navrhni otázky k obhajobě.
```

### Recenzní posudek, když hodnoticí předpis nemáte

Reviewer se už nespustí nad samotnou prací bez upozornění. Pipe nabídne tři bezpečné cesty:

```text
URL: https://www.example.edu/official/thesis-evaluation-rules.pdf
```

```text
TEXT: Hodnoť originalitu, správnost metodiky, práci se zdroji, reprodukovatelnost,
      kvalitu výsledků a připravenost k obhajobě. U každé oblasti uveď důkazy z KB2.
```

```text
HLEDAT: země=ČR; instituce=VUT; fakulta=FAST; typ práce=diplomová práce
```

Při `HLEDAT:` musí být uvedena alespoň země/jurisdikce, instituce a typ práce. Pipe nejprve zobrazí ověřené kandidátní URL a použije pouze ty, které uživatel výslovně vybere. Bez dostatečného kontextu se webové dohledání nespustí.

### Scientist režim

```text
Ověř hypotézu, zda kalibrace pravděpodobností zlepší macro-F1 u nevyvážené
klasifikace. Použij přiložený dataset, rozděl data reprodukovatelně, zaznamenej
seed, metriky a grafy. Po experimentu napiš krátký paper a samostatný auditní report.
```

Scientist režim může spouštět lokální kód. Používejte pouze důvěryhodné datasety a šablony a před spuštěním zkontrolujte pracovní adresář.

### Pokračování existující práce

```text
Pokračuj v úloze 0193... a přegeneruj pouze kapitoly, které selhaly při exportu PDF.
Zachovej existující strukturu, citace a úspěšně vytvořené sekce.
```

Použitelnost tohoto scénáře závisí na checkpointech konkrétní pipeline.

## Reviewer: povinná KB1 a řízené dohledání

Reviewer odděluje dvě různé znalostní báze:

| Role | Obsah | Význam |
|---|---|---|
| **KB1** | hodnoticí předpis, směrnice, vyhláška, rubric, metodika, šablona posudku nebo explicitní kritéria | určuje, **podle čeho** se práce hodnotí |
| **KB2** | závěrečná práce, disertace, přílohy, data a další hodnocené materiály | určuje, **co** se hodnotí |

Bez KB1 by model mohl vytvořit obecně přesvědčivý text, který ale neodpovídá pravidlům konkrétní školy, fakulty, programu nebo typu práce. Proto je chování od verze 0.2.7 „fail closed“:

1. chybějící nebo prázdná KB1 zastaví spuštění ještě před prvním LLM voláním;
2. projekt zůstane uložený jako koncept;
3. uživatel dodá soubor, oficiální URL, vlastní text kritérií nebo kontext pro dohledání;
4. Companion KB1 znovu validuje;
5. teprve potom lze job potvrdit a spustit.

### Přímé vložení souboru při otázce na KB1

Když se v chatu objeví dialog **„Chybí hodnoticí předpis (KB1)”**, zadejte:

```text
SOUBOR
```

Open WebUI zobrazí samostatné okno s nativním výběrem souborů. Lze vybrat nejvýše pět
dokumentů ve formátu PDF, DOCX, PPTX, Markdown nebo TXT. Soubory se nejprve nahrají do
úložiště právě přihlášeného uživatele Open WebUI a Pipe je následně streamuje do
reviewer projektu s rolí `kb1`. API klíč ani browserový token se nevrací z dialogu do
projektové specifikace.

Pokud daná verze klienta interaktivní okno nepodporuje nebo uživatel dialog zavře, lze
KB1 doplnit v další zprávě. Přiložte dokument běžným tlačítkem pro přílohy a odešlete:

```text
KB1 <ID_PROJEKTU_NEBO_ÚLOHY>
```

Příklad:

```text
KB1 631131cb-ee9d-4e09-ab1d-0c5fa9640f01
```

U této explicitní operace se nepoužívá odhad role podle názvu souboru: všechny přiložené
dokumenty jsou kandidáty KB1. Stále však musí projít sémantickou kontrolou relevance,
čitelnosti a přístupových/login stránek. Platný dokument doplněný do konceptu spustí
reviewer job; u neúspěšné, zrušené nebo přerušené úlohy se zachovanou KB2 umožní její
pokračování.

### Sémantická kontrola KB1

Pouhá existence souboru nebo jednoho RAG chunku nestačí. Verze 0.2.7 kontroluje obsah
zdroje před prvním LLM voláním a znovu přímo v reviewer pipeline. Odmítá zejména:

- OAuth, SAML, SSO a běžné přihlašovací stránky (`REVIEWER_KB1_AUTH_PAGE`);
- stránky „access denied“, „unauthorized“, 404 a jiné přístupové brány
  (`REVIEWER_KB1_ACCESS_GATE`);
- dokumenty, ze kterých nelze získat text (`REVIEWER_KB1_UNREADABLE`);
- příliš krátké zdroje (`REVIEWER_KB1_TOO_SHORT`);
- texty bez dostatečných znaků hodnoticí směrnice, rubriky nebo kritérií
  (`REVIEWER_KB1_IRRELEVANT`).

Pokud veřejný odkaz přesměruje na `id.*`, `/oauth2/authorize`, `/login` nebo obdobný
identity-provider endpoint, není použit. Je nutný přímo stažitelný veřejný dokument,
případně soubor, který uživatel nahraje, nebo explicitní text kritérií. Pokud bylo vybráno
více zdrojů, reviewer vytvoří RAG pouze z těch, které kontrolou prošly; odmítnuté zdroje
uvede ve varování a v `reviewer_kb1_quality.json`.

### Řízené dohledání veřejného předpisu

Automatické dohledání není slepé. Pipe vyžaduje:

- zemi nebo právní/jurisdikční kontext;
- instituci;
- typ závěrečné práce;
- volitelně fakultu/součást a studijní program.

Companion vyžádá z Open WebUI webové vyhledávání, vrátí omezený seznam kandidátů, technicky ověří jejich veřejné URL a zobrazí provenance. Uživatel musí výběr potvrdit. Soukromé, loopback, link-local a jiné neveřejné adresy se odmítají; redirect se znovu validuje. Nalezený dokument není automaticky považován za právně nebo institucionálně správný — jeho platnost a aktuálnost musí zkontrolovat uživatel.

### Explicitní výjimka

Kompatibilní obecný posudek bez KB1 lze povolit pouze vědomě:

```text
Valve → Reviewer KB1 policy → allow_without_kb1
```

nebo v CLI:

```bash
python main.py --mode reviewer   --kb2-dir ./thesis   --reviewer-allow-missing-kb1   --out-dir ./output/general-review
```

Výsledek je označen diagnostikou `REVIEWER_KB1_EXPLICITLY_WAIVED` a **nesmí být vydáván za posudek splňující konkrétní institucionální předpis**.

## Znalostní báze a přílohy

Podporované vstupy zahrnují zejména:

- PDF;
- DOCX;
- PPTX;
- Markdown;
- TXT;
- JSON struktury;
- ZIP s více dokumenty;
- CSV a další datové soubory pro experimentální režim.

Pipe nikdy nepředává Companionu uživatelem zadanou libovolnou lokální cestu. Soubor nejprve načte přes úložiště Open WebUI a streamuje jej do projektu daného uživatele.

ZIP ingest musí odmítnout absolutní cesty, `../`, symlinky a neúměrně velké rozbalení. Pro citace je vhodnější poskytnout původní dokument než pouze již vytvořené embedding chunky.

## Bezpečnost a soukromí

Implementované zásady:

- Companion poslouchá standardně pouze na loopbacku;
- každý požadavek vyžaduje bearer token;
- projekty a joby jsou vázané na `owner_id`;
- chatové výstupy používají trvalé, uživatelsky autorizované Open WebUI file ID; dočasný API fallback má oddělený signing key, vlastníka a expiraci;
- canonical-path kontrola blokuje path traversal;
- worker se spouští bez `shell=True`;
- API klíče nejsou součástí chatu, job JSON, logu ani výstupního ZIP;
- velké soubory se streamují;
- aktualizace bundle je kontrolována SHA-256;
- Function se musí instalovat pouze z důvěryhodného zdroje.

Externí model nebo webový RAG může zpracovávat odeslaný obsah mimo počítač. Pro citlivé dokumenty použijte lokální model a vypněte webové vyhledávání.

## Samostatné CLI

Open WebUI integrace je hlavní desktopové rozhraní, ale původní CLI zůstává podporované.

```bash
python main.py --help
```

Příklad knihy:

```bash
python main.py \
  --mode book \
  --input examples/book_input.txt \
  --kb-dir ./knowledge \
  --out-dir ./output/book \
  --docx \
  --export-tex
```

Příklad paperu:

```bash
python main.py \
  --mode paper \
  --input examples/paper_input.txt \
  --paper-venue arXiv \
  --citation-style bibtex \
  --audit --audit-mode strict \
  --out-dir ./output/paper
```

Příklad prezentace:

```bash
python main.py \
  --mode presentation \
  --presentation-input examples/presentation_input.txt \
  --presentation-pptx \
  --presentation-tex \
  --presentation-narration \
  --out-dir ./output/presentation
```

Příklad reviewer s povinnou KB1 a KB2:

```bash
python main.py \
  --mode reviewer \
  --kb1-dir ./input/reviewer/kb1 \
  --kb2-dir ./input/reviewer/kb2 \
  --language cs \
  --reviewer-profile direct \
  --reviewer-direct-pdf \
  --reviewer-llm1-model e-infra.glm-5 \
  --reviewer-llm2-model e-infra.glm-5 \
  --out-dir ./output/reviewer
```

Pokud KB1 chybí nebo neobsahuje použitelný dokument, CLI skončí kódem 2 a zapíše diagnostické artefakty místo toho, aby vytvořilo obecný posudek.

Podrobná původní CLI dokumentace je zachována v:

```text
docs/legacy/README_AUTOGENBOOK_CLI_ORIGINAL.md
```


## Ekvivalence s přímým CLI AutoGenBooku

Open WebUI integrace od verze 0.3.1 používá pro obsah stejné core pipeline a stejné prompt soubory jako samostatné CLI. Výchozí reviewer profil `direct` **nepřepisuje** kanonický systémový prompt pomocí LLM1. KB1 je doplňující institucionální kontext a nesmí odstranit hodnocení metodiky, výsledků, původnosti, inovace nebo praktického přínosu.

Každý job ukládá:

```text
direct_cli_parity_request.json
reviewer_prompt1_effective.md
reviewer_prompt2_effective.md
reviewer_evidence_manifest.json
reviewer_parity_manifest.json
reviewer_quality_report.json
reviewer_conversion_report.json
```

`direct_cli_parity_request.json` obsahuje přesný CLI příkaz použitý Companionem, vybraný model, endpoint bez tajného klíče a normalizovanou specifikaci. Pro reprodukci spusťte stejný příkaz nad stejnými vstupními soubory a stejným provider endpointem/model revision.

Strukturální ekvivalence znamená shodné prompty, vstupy, role KB, parametry a exportní/quality pravidla. Bitově totožný text nelze slíbit, pokud provider používá nedeterministické generování nebo se změnila revize modelu pod stejným názvem.

Podrobnosti, metriky původního incidentu a pravidla reprodukce jsou v [docs/OUTPUT_PARITY.md](docs/OUTPUT_PARITY.md) a [forenzním reportu 2026-08-28](docs/incidents/2026-08-28-openwebui-reviewer-output-degradation.md).

## Build a reprodukovatelnost

### Kanonický integrační bundle

Zdroj specifický pro Open WebUI se balí deterministicky:

```bash
python tools/build_openwebui_integration.py build
python tools/build_openwebui_integration.py verify
```

Výsledkem jsou soubory:

```text
integration/openwebui_bundle.partNNN.b64
```

`tools/unpack_openwebui_bundle.py` ověřuje SHA-256 před rozbalením a odmítá nebezpečné členy archivu.

### Dependency-complete installer

Workflow `.github/workflows/build-openwebui-companion.yml`:

1. ověří kanonický bundle;
2. spustí testy;
3. sestaví Companion wheel;
4. vytvoří platformní wheelhouse;
5. přidá samostatný Python runtime;
6. přidá Pandoc, TinyTeX, FFmpeg, PortAudio, Piper a český hlas;
7. provede test s vypnutým přístupem k balíčkovým indexům;
8. vytvoří instalátor a celý Full Build použitý pro jeho reprodukci;
9. velké artefakty rozdělí na ověřitelné části.

Build musí být spuštěn z auditovaného zdroje verze 0.3.3. Starší binární instalátory vytvořené před touto verzí neobsahují opravy modelového selectoru, progress API a velkých downloadů.

## Testování a audit

Lokální audit:

```bash
python tools/audit_project.py --project-root . --output-dir audit
```

Audit kontroluje mimo jiné:

- Python syntaxi;
- Pipe frontmatter a Valve schéma;
- výchozí model `e-infra.glm-5`;
- propagaci modelu do workeru a LLM klienta;
- FastAPI request kontrakt;
- perzistentní progress a heartbeat;
- bearer autorizaci a vlastnictví jobu;
- signed download;
- `HEAD`, `Range`, `If-Range`, `206` a `416`;
- bezpečnost cest;
- velký soubor bez povinného průběžného hashování;
- determinismus integračního bundle;
- povinnou a neprázdnou KB1 v reviewer režimu;
- explicitní souhlas před webovým dohledáním a výběrem kandidáta;
- SSRF ochranu importu veřejné URL;
- přítomnost povinných částí README.
- zachování kanonického reviewer promptu v profilu `direct`;
- odstranění attachment XML před parsováním zadání a exportů;
- evidence pack přes více než legacy šest KB2 chunků a přes všechna kanonická kritéria;
- úplný dokumentově seřazený KB1 kontext;
- explicitní model v reprodukovatelném CLI commandu;
- quality gate a fail-closed požadované exporty.

Auditovaný snapshot 0.3.3 prochází cílenou sadou 81 release-regresních testů zaměřených na trvalé artefakty, Function, instalátor, autentizaci, provider izolaci a Companion služby, dále kompilací zdrojů, validací Pipe, CLI preflightem a deterministickou kontrolou integračního bundle. Zdrojové prostředí nepředstavuje hotový platformní runtime: úplný offline `pip check`, nativní toolchain a startup cílového instalátoru musí znovu projít přiloženým dependency-complete release workflow. Přesný rozsah a omezení jsou popsány v [`docs/AUDIT_SCOPE_0.3.3.md`](docs/AUDIT_SCOPE_0.3.3.md).

## Úplná diagnostika neúspěšného jobu

Od verze 0.2.7 obsahuje `autogenbook_<ID>_complete.zip` také bezpečně redigovanou
provozní diagnostiku:

```text
_autogenbook_companion/companion_manifest.json
_autogenbook_companion/failure.json
_autogenbook_companion/failure.md
_autogenbook_companion/diagnostics/worker.log
_autogenbook_companion/diagnostics/request.json
_autogenbook_companion/diagnostics/progress.json
_autogenbook_companion/diagnostics/job_status.json
```

Failure metadata se zapisují ještě před vytvořením ZIPu. Manifest uvádí verzi Companionu,
protokol, stav, exit code a chybu. Velmi dlouhý `worker.log` může být v ZIPu omezen na
posledních 8 MiB; manifest tuto skutečnost výslovně označí. API klíče se do diagnostiky
nezapisují.

## Řešení problémů

### Companion se nepřipojí

1. Ověřte, že proces běží.
2. Zkontrolujte bridge soubor v datovém adresáři instalace.
3. Otevřete diagnostický log Companionu.
4. Ověřte, že lokální bezpečnostní software neblokuje loopback port.
5. Nespouštějte dvě instalace se stejným datovým adresářem.

Pokud verze 0.2.0 skončí hláškou `Companion did not become healthy` a poslední chybou je chybějící `bridge.json`, proces se ve skutečnosti pravděpodobně nespustil. Nejčastější příčinou bylo chybějící `companion\src` v `PYTHONPATH`; při spuštění ze zdrojového archivu instalátor navíc hledal neexistující `app\main.py`. Použijte balík 0.2.1 nebo novější. Opravený instalátor provede importní preflight, rozpozná obě rozložení a při pádu vypíše konec skutečného `companion.log`.

Opravnou instalaci lze spustit do stejného cílového adresáře. Předchozí obsah se atomicky přesune do sousedního adresáře s příponou `.previous`.

### Combo box obsahuje jen `e-infra.glm-5`

- znovu otevřete nastavení Valve;
- ověřte, že jsou modely dostupné danému uživateli, ne jen administrátorovi;
- zkontrolujte, zda Open WebUI dokončilo načtení modelů;
- ověřte, že používáte Pipe 0.3.3;
- případně restartujte Function cache Open WebUI.

### Model je vybraný, ale job selže s 401

Modelový identifikátor a credential jsou dvě různé věci. Pokud worker hlásí `session has expired` nebo `token is invalid`, byl použit expirovatelný browser session/JWT token nebo zrušený API klíč. Nainstalujte 0.3.3 do stejného adresáře a odešlete:

```text
pokračuj JOB_ID
```

Pipe vyžádá nový trvalý osobní klíč, ověří `/api/models`, dostupnost modelu a znovu zařadí existující job. Aktualizační instalátor zachová celý `data` adresář atomickým přesunem, takže vstupy, checkpointy a částečné výstupy zůstávají dostupné.

### Obnova starší reviewer úlohy po 401 nebo chybějící KB1

Po aktualizaci Function na verzi 0.3.3 lze použít:

```text
pokračuj JOB_ID
```

Pipe nejprve ověří trvalý Open WebUI API klíč a znovu validuje projekt. Pokud reviewer stále nemá použitelnou KB1, otevře průvodce pro soubor, veřejnou URL, explicitní text nebo kontextové dohledání. Job je znovu zařazen až po úspěšné validaci; bez interaktivního doplnění se stav ani data projektu nemění.

### Reviewer hlásí `REVIEWER_KB1_REQUIRED` nebo `MISSING_REVIEWER_KB1`

To znamená, že byla dodána hodnocená práce (KB2), ale chybí použitelný zdroj hodnoticích pravidel (KB1). Nejde o chybu extrakce práce. Vraťte se do AutoGenBook chatu a zvolte jednu z možností:

```text
URL: https://.../official-evaluation-rules.pdf
TEXT: ...explicitní hodnoticí kritéria...
HLEDAT: země=ČR; instituce=...; fakulta=...; typ práce=...
```

U dohledání potvrďte pouze dokument, u něhož souhlasí instituce, součást, typ práce a platnost. Pokud skutečně chcete pouze obecný nezávazný posudek, změňte Valve `Reviewer KB1 policy` na `allow_without_kb1`; výsledný dokument bude označen jako neinstitucionální.

### Reviewer hlásí `REVIEWER_KB1_AUTH_PAGE`

Vybraný odkaz nevedl na veřejný předpis, ale po přesměrování skončil na přihlašovací
stránce (například `id.vut.cz/.../oauth2/authorize`). Přihlášení uživatele v prohlížeči
nelze bezpečně přenášet do několikadenního workeru a login stránka sama neobsahuje
hodnoticí pravidla.

Použijte jednu z možností:

1. stáhněte předpis po přihlášení a nahrajte jeho PDF/DOCX jako KB1;
2. najděte veřejný přímý odkaz bez přihlášení;
3. vložte podrobná explicitní kritéria přes `TEXT:`;
4. opakujte `HLEDAT:` s přesnější institucí/fakultou a potvrďte jiného kandidáta.

Poté použijte `pokračuj JOB_ID`. Starý login zdroj zůstane v auditní historii, ale nebude
použit pro RAG.

### Progress se dlouho nemění

Pokud se mění `heartbeat_at`, worker pravděpodobně stále čeká na dlouhé modelové volání nebo konverzi. Pokud je heartbeat starší než deset minut, zkontrolujte proces a log. Bez ověření nespouštějte stejný job podruhé.

### Souborová karta chybí nebo na ni nelze kliknout

Verze 0.3.0 sice mohla vytvořit databázový záznam souboru, ale do události `files` odesílala backendový `FileModel` bez povinného pole `type=file`. Open WebUI tak položku v odpovědi odfiltrovalo. Aktualizujte Companion i Function na 0.3.3 a odešlete `výstupy JOB_ID`; nová odpověď vytvoří korektní nativní souborové karty bez opakování generování. Podrobnosti jsou v [`docs/incidents/2026-09-18-openwebui-output-download-contract.md`](docs/incidents/2026-09-18-openwebui-output-download-contract.md).

### Odkaz vrací `{"detail":"Not authenticated"}` nebo modal ukazuje `No content`

Verze 0.3.1 používala přímý chráněný Open WebUI endpoint a verze 0.3.2 používala landing stránku s následným ticket requestem. V Open WebUI Desktopu mohlo nové okno postrádat token i session cookie, takže `/api/autogenbook/download-ticket` skončil 401. `No content` byl samostatný fallback prázdného `file.data.content`.

Aktualizujte **Companion i Function** na 0.3.3, restartujte Open WebUI Desktop a odešlete:

```text
výstupy JOB_ID
```

Nová odpověď musí používat adresy začínající:

```text
/api/autogenbook/download/PODEPSANÁ_CAPABILITY
```

Odkaz nevyžaduje browserový token. Modal současně obsahuje skutečnou Markdown kartu s tlačítkem **Stáhnout**. Staré `/api/autogenbook/files/<id>/download` odkazy z verze 0.3.2 vrátí HTTP 410 a pokyn k obnovení výstupů.

### Odkaz na výstup vrací `Invalid companion token`

Tuto chybu vytvářela verze 0.2.8 a starší: text odpovědi používal 24hodinově podepsanou URL Companionu, i když byl menší soubor současně uložen jako Open WebUI File Object. Po expiraci podpisu požadavek propadl do bearer autentizace a prohlížeč zobrazil `Invalid companion token`.

Aktualizujte **Companion i Pipe** na 0.3.3 a v AutoGenBook chatu odešlete:

```text
výstupy JOB_ID
```

Příkaz existující artefakty streamovaně migruje do Open WebUI a vrátí stabilní `/api/autogenbook/download/...` capability odkazy. Starý text zprávy zůstane historicky nezměněný; používejte odkazy z nové odpovědi. Podrobná analýza je v [`docs/incidents/2026-08-27-expiring-companion-download-links.md`](docs/incidents/2026-08-27-expiring-companion-download-links.md).

### Přenos velkého výstupu se přerušil

Zopakujte `výstupy JOB_ID`. Registrace je idempotentní; hotový Open WebUI soubor se znovu nepřenáší a nedokončený dočasný soubor se nepovažuje za výsledek. Pro přímé Companion API zůstává k dispozici HTTP Range fallback, ale chat standardně používá trvalý Open WebUI soubor.


### Reviewer je výrazně kratší nebo horší než přímé CLI

Ověřte, že Companion i Pipe mají verzi 0.3.3 nebo novější a ve Valve je `REVIEWER_PROFILE=direct`. Ve výstupech otevřete `reviewer_parity_manifest.json` a `direct_cli_parity_request.json`.

Varovné znaky staršího běhu:

- `reviewer_prompt1_generated.md` obsahuje kompletní nový systémový prompt místo pouhého addenda;
- log uvádí jen několik KB2 chunků a neobsahuje `[REVIEWER_PARITY]`;
- `language=cs`, ale výsledný posudek je anglicky;
- command obsahuje `--no-md --no-tex` jen proto, že vstupní příloha končí `.pdf`;
- job je `SUCCEEDED`, ale požadovaný export chybí.

V 0.3.1 se takový job buď vytvoří s kanonickým kontraktem, nebo skončí explicitním `REVIEWER_OUTPUT_QUALITY_FAILED` / `REVIEWER_EXPORT_FAILED`. Starý job se obsahově neopraví pouhou migrací artefaktů; spusťte nový reviewer běh nad stejnými KB1/KB2.

### PDF nebo video nevzniklo

Spusťte diagnostiku toolchainu. Zdrojový výstup Markdown/DOCX/PPTX může být hotový, i když selhal následný TeX nebo FFmpeg export. Dependency-complete build musí obsahovat všechny konvertory, ale poškozená šablona nebo neplatný mediální vstup může konverzi stále zastavit.


### Instalátor hlásí `Open WebUI rejected the Function (400): Invalid HTTP request received`

Starší instalační tok považoval automatickou registraci Function za povinnou a předával přímý vstup bez jednotné normalizace. Na počítači s proxy konfigurací navíc mohl obecný HTTP opener změnit cestu požadavku. Nízkou úroveň chyby serveru pak instalátor vydával za neúspěch celé instalace.

Použijte verzi 0.3.3 nebo novější. Instalátor nyní:

- normalizuje přímý klíč a odmítne zalomení řádku, řídicí znaky a JWT;
- používá přímé proxy-free HTTP/HTTPS spojení;
- ověří Open WebUI přes `/api/version`;
- před zápisem Function provede administrátorský preflight `/api/v1/functions/list`;
- rozlišuje create, update a activate endpointy;
- při HTTP 400 bezpečně dokončí instalaci a nabídne ruční import.

Ruční import je plnohodnotný fallback:

```text
Admin Panel → Functions → Import from file
integrations/openwebui/autogenbook_pipe.py
```

Přímý admin klíč můžete zadat jako čistou hodnotu, `Bearer ...`, `Authorization: Bearer ...` nebo assignment. Pro běžný dlouhý běh používejte raději `--webui-api-key-file`; tento osobní klíč nemusí mít oprávnění administrátora k registraci Function.

### Open WebUI odmítne Function kvůli `Invalid requirement: '<1'`

Verze Pipe 0.2.1 obsahovala ve frontmatter zápis `httpx>=0.27,<1`. Open WebUI odděluje
frontmatter závislosti čárkou, takže tento jediný PEP 440 rozsah rozložil na `httpx>=0.27`
a neplatný samostatný argument `<1`. Výsledkem bylo HTTP 400 při vytváření Function.

Použijte Pipe 0.2.2 nebo novější. Pipe už nedeklaruje `httpx` ve frontmatter, protože
`httpx` i Pydantic jsou součástí samotného Open WebUI. Companion a AutoGenBook zůstávají
v odděleném runtime instalátoru. Po aktualizaci stačí Function znovu importovat; Companion
není nutné přeinstalovat.

### Provider projde validací, ale detached worker vrátí 401

Tento stav byl ve verzi 0.2.7 možný, pokud proces zdědil cizí `OPENROUTER_API_KEY` nebo role-level base URL. Aktualizujte Companion i Pipe na 0.2.8. Nová verze izoluje credential a endpoint, provede exact-key preflight před indexací KB a uloží bezpečný fingerprint. Existující job obnovte příkazem:

```text
pokračuj JOB_ID
```

Podrobná analýza je v [`docs/incidents/2026-08-20-openwebui-worker-credential-precedence.md`](docs/incidents/2026-08-20-openwebui-worker-credential-precedence.md).

## Známá omezení

- Délka běhu není omezena, ale notebook nesmí být během generování vypnutý nebo uspaný.
- Obnova pokračuje pouze z checkpointů, které daná pipeline skutečně vytvořila.
- Přesné procento je u některých modelových volání odhad fáze; heartbeat je autoritativnější informace o živosti procesu.
- Lokální LLM váhy nejsou součástí instalátoru.
- Podepsaný/notarizovaný macOS 0.3.3 instalátor musí být vytvořen na infrastruktuře vlastníka projektu.
- Kontextové dohledání KB1 vyžaduje nakonfigurované webové vyhledávání Open WebUI a dostatečný institucionální kontext; nalezený zdroj musí vždy potvrdit uživatel.
- Kvalita a faktická správnost výsledného dokumentu závisí na modelu, zdrojích a zvoleném auditním režimu. Výstupy před publikací vždy odborně zkontrolujte.

## Licence

Projekt je distribuován pod licencí Apache-2.0, není-li u přibalené komponenty uvedeno jinak. Dependency-complete distribuce obsahuje komponenty s vlastními licencemi; Full Build a manifest toolchainu musí tyto licence zachovat.
