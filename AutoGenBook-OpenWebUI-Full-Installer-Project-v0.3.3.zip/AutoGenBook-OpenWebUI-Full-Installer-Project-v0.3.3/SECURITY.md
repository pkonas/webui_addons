# Bezpečnost

Bezpečnostní chyby nepublikujte nejprve jako veřejný exploit. Vlastník projektu má použít soukromé GitHub Security Advisory nebo jiný předem dohodnutý soukromý kanál.

Při hlášení uveďte verzi, operační systém, postižený endpoint nebo soubor, reprodukční kroky a dopad. Neodesílejte skutečné API klíče ani citlivé dokumenty.

## Bezpečnostní model

- Companion má být dostupný pouze na loopbacku.
- Každý API požadavek vyžaduje náhodný bearer token.
- Data jsou oddělena podle normalizovaného `owner_id`.
- Dočasný Companion signed download token je omezen vlastníkem, artefaktem a expirací.
- Trvalý Open WebUI výstup používá neuhodnutelnou HMAC capability svázanou s file ID, vlastníkem, SHA-256 a velikostí; úplná URL je přístupový údaj a nemá se zveřejňovat.
- Cesty jsou kontrolovány po `resolve()` proti spravovanému rootu.
- Subprocessy se nespouštějí přes shell.
- Tajné údaje se ukládají do keyringu nebo do souboru s právy 0600; fallback soubor není kryptograficky šifrovaný.
- Open WebUI Function je spustitelný Python kód a musí být před importem auditována.

## Co nepovažovat za tajný údaj

Job ID ani název výsledného souboru samy o sobě nejsou autentizační prostředek. Dočasný Companion endpoint vyžaduje signed token nebo bearer autorizaci. Trvalý Open WebUI capability odkaz je sám přístupovým údajem; kdo získá jeho úplnou hodnotu, může konkrétní soubor stáhnout až do smazání/nahrazení souboru nebo rotace `WEBUI_SECRET_KEY`.
