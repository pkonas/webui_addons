@echo off
setlocal
call "%~dp0installer\Uninstall-AutoGenBook.cmd" %*
set CODE=%ERRORLEVEL%
endlocal & exit /b %CODE%
