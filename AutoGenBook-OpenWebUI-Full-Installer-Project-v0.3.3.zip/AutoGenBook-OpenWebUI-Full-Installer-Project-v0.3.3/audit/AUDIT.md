# Audit AutoGenBook Open WebUI 0.3.3

- Vygenerováno: `2026-09-18T17:21:09.194380Z`
- Výsledek: **PASS**
- Python: `3.13.5 (main, Jul 15 2026, 20:25:40) [GCC 14.2.0]`
- Kontrol: `24`
- Souborů v inventáři: `407`

## Kontroly

| Kontrola | Stav | Detail |
|---|---:|---|
| Povinné projektové soubory | **PASS** | missing=[] |
| README pokrytí | **PASS** | missing_sections=[]; recognized_examples=8; bytes=47407 |
| Konzistence verze | **PASS** | {"expected": "0.3.3", "pyproject": "0.3.3", "version.py": "0.3.3", "pipe": "0.3.3", "builder": "0.3.3", "installer": "0.3.3", "root": "0.3.3"} |
| Open WebUI frontmatter bez hostitelského pip installu | **PASS** | raw=''; tokens=[]; invalid=[] |
| Open WebUI modelový a long-job kontrakt | **PASS** | missing=[] |
| Trvalá autentizace Open WebUI a obnova po 401 | **PASS** | missing=[] |
| Providerově izolovaný worker a exact-key preflight | **PASS** | missing=[] |
| TXT reference, normalizace přímého klíče a bezpečná registrace Function | **PASS** | missing=[] |
| Reviewer fail-closed KB1, interaktivní soubor, řízené dohledání a SSRF ochrana | **PASS** | missing=[] |
| Reviewer output parity s přímým CLI, quality gate a fail-closed exporty | **PASS** | missing=[]; legacy=[] |
| KB1 file picker: same-origin upload bez návratu credentialu | **PASS** | missing=[]; leaked_secret=False |
| Úplný failure bundle s worker logem a stavem | **PASS** | missing=[] |
| Trvalé Open WebUI výstupy bez expiračního Companion odkazu | **PASS** | missing=[] |
| Trvalá podepsaná capability pro Open WebUI download | **PASS** | missing=[] |
| Progress a obnovitelné downloady | **PASS** | missing=[] |
| Instalátor a dependency-complete startup gate | **PASS** | missing=[] |
| Statická bezpečnost subprocess/loopback | **PASS** | shell_true=[]; public_bind_defaults=[] |
| Odstranění historického patchovacího řetězce | **PASS** | legacy=[] |
| Konzistence nainstalovaných balíků | **PASS** | skipped for source-only builder environment; dependency-complete release workflow owns the offline pip/toolchain gate |
| Deterministický Open WebUI bundle | **PASS** | exit=0; command=/opt/pyvenv/bin/python tools/build_openwebui_integration.py verify |
| Python compileall | **PASS** | exit=0; command=/opt/pyvenv/bin/python -m compileall -q autogenbook companion/src integrations installer build tools |
| Validace Open WebUI Pipe | **PASS** | exit=0; command=/opt/pyvenv/bin/python build/validate_pipe.py integrations/openwebui/autogenbook_pipe.py |
| Start CLI a argparse kontrakt | **PASS** | exit=0; command=/opt/pyvenv/bin/python main.py --help |
| Cílená pytest release-regresní sada | **PASS** | exit=0; command=/opt/pyvenv/bin/python -m pytest -c /dev/null -q tests/test_openwebui_authenticated_downloads.py tests/test_openwebui_persistent_artifacts.py tests/test_openwebui_persistent_auth.py tests/test_openwebui_function_frontmatter.py tests/test_openwebui_integration_v6.py tests/test_provider_credential_isolation.py tests/test_installer_startup.py tests/test_installer_api_key_file.py tests/test_installer_http_registration.py tests/test_reviewer_output_parity.py tests/test_reviewer_kb1_workflow.py |

## Rozsah auditu

Audit ověřuje zdrojový kontrakt, deterministický integrační bundle, Python syntaxi, Open WebUI Pipe, pytest sadu zvolenou pro daný release gate, CLI start, trvalé Open WebUI výstupy, stabilní podepsané capability odkazy nezávislé na browserové autentizaci, vazbu na vlastníka/hash/velikost, HEAD/Range/If-Range streaming, opravu binárního náhledu, bezpečnost dlouhých úloh/downloadů, úplný failure bundle, fail-closed reviewer KB1 workflow a výstupní paritu s přímým CLI: zachování kanonických promptů, odstranění attachment metadata, criterion-aware evidence pack, explicitní model/jazyk, quality gate a fail-closed exporty.

## Omezení auditu

Audit negarantuje faktickou správnost dokumentů generovaných libovolným LLM ani aktuálnost automaticky dohledaného hodnoticího předpisu. Globální pip check zdrojového builderu byl přeskočen kvůli nesouvisejícímu konfliktu MoviePy/Pillow; autoritativní offline pip/toolchain gate provádí platformní dependency-complete workflow. Podepisování Windows instalátoru a notarizace macOS vyžadují certifikáty vlastníka projektu.
