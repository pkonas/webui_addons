from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Tuple, List, Dict

from rag_kb import SUPPORTED_EXTS, KnowledgeBase
from autogenbook.retrieval.kb_citations import build_kb_index
from autogenbook.retrieval.manager import RetrievalManager
from autogenbook.retrieval.types import RetrievalItem
from autogenbook.retrieval.sanitize import sanitize_context_text
from autogenbook.reviewer_kb1_quality import (
    assess_file as assess_reviewer_kb1_file,
    is_metadata_sidecar,
)
from autogenbook.reviewer_parity import (
    DEFAULT_REVIEWER_PROFILE,
    REVIEWER_PROFILES,
    build_kb1_addendum_prompt,
    build_review_repair_messages,
    build_reviewer_evidence_pack,
    clean_user_instructions,
    compose_reviewer_system_prompt,
    compose_reviewer_user_prompt,
    ordered_full_context,
    validate_review_output,
    write_parity_manifest,
)
from openrouter_llm import LLMConfig, OpenRouterLLM
from autogenbook.llm_usage import log_usage, write_run_meta
from autogenbook.pipelines.proposal_pipeline import (
    _convert_with_pandoc,
    _resolve_model_override,
    _resolve_value_override,
)
from autogenbook.prompts.reviewer_loader import load_reviewer_prompts
from autogenbook.prompts.registry import set_prompt_registry
from autogenbook.state import RunContext


def _log(logger: Any, message: str) -> None:
    if logger is not None:
        try:
            logger.info(message)
            return
        except Exception:
            pass
    print(message)


def _dir_has_supported_files(path: Path) -> bool:
    if path is None or not path.exists() or not path.is_dir():
        return False
    for entry in path.rglob("*"):
        if entry.is_file() and entry.suffix.lower() in SUPPORTED_EXTS:
            return True
    return False


def _resolve_dir(raw: Optional[str]) -> Optional[Path]:
    if not raw:
        return None
    return Path(raw).expanduser().resolve()


def _kb_stats(kb: Optional[KnowledgeBase]) -> Tuple[int, int]:
    if kb is None:
        return 0, 0
    chunks = list(getattr(kb, "chunks", []) or [])
    sources = {c.source_path for c in chunks if getattr(c, "source_path", None)}
    return len(chunks), len(sources)


def _kb_item_from_chunk(chunk: Any) -> RetrievalItem:
    source_path = Path(getattr(chunk, "source_path", "") or "")
    return RetrievalItem(
        rid=getattr(chunk, "rid", "") or "",
        kind="kb",
        source=source_path.name,
        loc=getattr(chunk, "loc", "") or "",
        score=0.0,
        cite_key=getattr(chunk, "cite_key", "") or "",
        text=getattr(chunk, "text", "") or "",
        url=None,
        title=source_path.name,
    )


def _collect_kb1_context(
    kb1_retriever: RetrievalManager,
    query_hint: Optional[str] = None,
    *,
    k: int = 8,
) -> Tuple[str, int]:
    if kb1_retriever is None:
        return "(none)", 0

    queries = []
    if query_hint:
        compact_hint = " ".join(query_hint.split())
        if len(compact_hint) > 300:
            compact_hint = compact_hint[:300]
        if compact_hint:
            queries.append(compact_hint)
    queries.extend(
        [
            "requirements norms regulations compliance evaluation criteria mandatory sections",
            "rules policies standards regulations legal ethics GDPR",
            "pozadavky normy predpisy regulace soulad kriteria hodnoceni povinne sekce",
            "pravidla zasady standardy etika gdpr zakon vyhlaska",
        ]
    )

    items: List[RetrievalItem] = []
    seen = set()
    for query in queries:
        retrieved = kb1_retriever.retrieve(
            query, k=min(max(k, 1), 10), allow_web=False, diversify_sources=True
        )
        for item in retrieved:
            key = item.rid or item.cite_key or f"{item.source}:{item.loc}"
            if key in seen:
                continue
            seen.add(key)
            items.append(item)
            if len(items) >= k:
                break
        if len(items) >= k:
            break

    if not items and kb1_retriever.local_kb is not None:
        try:
            kb1_retriever.local_kb._ensure_chunk_ids()
        except Exception:
            pass
        for chunk in kb1_retriever.local_kb.chunks[:k]:
            items.append(_kb_item_from_chunk(chunk))

    context = kb1_retriever.format_context(items) if items else "(none)"
    return context, len(items)


def _collect_pdf_direct_text(
    kb: Optional[KnowledgeBase],
    max_chars: int = 8000,
) -> Tuple[str, int]:
    if kb is None or not getattr(kb, "chunks", None):
        return "", 0
    remaining = max_chars
    blocks: List[str] = []
    pdf_sources: List[str] = []
    current_source: Optional[str] = None
    for chunk in kb.chunks:
        source_path = getattr(chunk, "source_path", "")
        if not source_path or Path(source_path).suffix.lower() != ".pdf":
            continue
        if source_path not in pdf_sources:
            pdf_sources.append(source_path)
        if current_source != source_path:
            current_source = source_path
            header = f"[PDF:{Path(source_path).name}]"
            if len(header) + 1 > remaining:
                break
            blocks.append(header)
            remaining -= len(header) + 1
        text = sanitize_context_text(str(getattr(chunk, "text", "")).strip())
        if not text:
            continue
        if len(text) + 1 > remaining:
            blocks.append(text[:remaining])
            remaining = 0
            break
        blocks.append(text)
        remaining -= len(text) + 1
        if remaining <= 0:
            break
    return "\n".join(blocks).strip(), len(pdf_sources)


def _log_llm_usage(
    out_dir: Path,
    llm: Any,
    label: str,
    usage: Optional[Dict[str, int]] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    if llm is None or not hasattr(llm, "get_last_usage"):
        return
    usage = usage or llm.get_last_usage()
    if not usage:
        return
    if hasattr(llm, "format_usage_line"):
        try:
            print(llm.format_usage_line(usage, label=label))
        except Exception:
            pass
    if isinstance(llm, OpenRouterLLM):
        try:
            log_usage(out_dir, label, llm, usage, extra or {})
        except Exception:
            pass


_REVIEWER_KB_CACHE_BASE: Optional[Path] = None
_REVIEWER_OUT_DIR: Optional[Path] = None
_REVIEWER_FORCE_REBUILD: bool = False
_REVIEWER_LOGGER: Any = None
_REVIEWER_KB1_QUALITY: list[dict[str, Any]] = []


def _configure_reviewer_kb(out_dir: Path, force_rebuild: bool, logger: Any) -> None:
    global _REVIEWER_KB_CACHE_BASE, _REVIEWER_OUT_DIR, _REVIEWER_FORCE_REBUILD, _REVIEWER_LOGGER
    global _REVIEWER_KB1_QUALITY
    _REVIEWER_KB_CACHE_BASE = out_dir / ".kb_cache"
    _REVIEWER_OUT_DIR = out_dir
    _REVIEWER_FORCE_REBUILD = force_rebuild
    _REVIEWER_LOGGER = logger
    _REVIEWER_KB1_QUALITY = []


def _kb_cache_dir(kind: str) -> Path:
    base = _REVIEWER_KB_CACHE_BASE or (Path.cwd() / ".kb_cache")
    return base / f"reviewer_{kind}"


def _write_kb1_quality_report(kb1_dir: Optional[Path], rows: list[dict[str, Any]]) -> None:
    if _REVIEWER_OUT_DIR is None:
        return
    payload = {
        "kb1_dir": str(kb1_dir) if kb1_dir else None,
        "valid": any(bool(row.get("valid")) for row in rows),
        "sources": rows,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    (_REVIEWER_OUT_DIR / "reviewer_kb1_quality.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _primary_kb1_quality_code() -> str:
    priority = {
        "REVIEWER_KB1_AUTH_PAGE": 0,
        "REVIEWER_KB1_ACCESS_GATE": 1,
        "REVIEWER_KB1_UNREADABLE": 2,
        "REVIEWER_KB1_TOO_SHORT": 3,
        "REVIEWER_KB1_IRRELEVANT": 4,
    }
    invalid = [row for row in _REVIEWER_KB1_QUALITY if not row.get("valid")]
    if not invalid:
        return "REVIEWER_KB1_REQUIRED"
    invalid.sort(key=lambda row: priority.get(str(row.get("code")), 99))
    return str(invalid[0].get("code") or "REVIEWER_KB1_REQUIRED")


def _validated_kb1_directory(kb1_dir: Path, valid_paths: list[Path]) -> Path:
    if _REVIEWER_OUT_DIR is None:
        return kb1_dir
    staging = _REVIEWER_OUT_DIR / ".validated_kb1"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)
    for source in valid_paths:
        try:
            relative = source.relative_to(kb1_dir)
        except ValueError:
            relative = Path(source.name)
        target = staging / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(source, target)
        except OSError:
            shutil.copy2(source, target)
    return staging


def build_or_load_kb1(kb1_dir: Optional[Path]) -> Tuple[bool, Optional[RetrievalManager]]:
    global _REVIEWER_KB1_QUALITY
    if kb1_dir is None or not kb1_dir.exists() or not kb1_dir.is_dir():
        _log(
            _REVIEWER_LOGGER,
            "[REVIEWER] KB1 missing; reviewer requires a source unless the user explicitly waives KB1.",
        )
        _REVIEWER_KB1_QUALITY = []
        _write_kb1_quality_report(kb1_dir, [])
        return False, None

    candidates = [
        path
        for path in sorted(kb1_dir.rglob("*"))
        if path.is_file()
        and path.suffix.casefold() in SUPPORTED_EXTS
        and not is_metadata_sidecar(path)
    ]
    reports: list[dict[str, Any]] = []
    valid_paths: list[Path] = []
    for path in candidates:
        report = assess_reviewer_kb1_file(path)
        row = report.to_dict()
        row["path"] = str(path)
        reports.append(row)
        if report.valid:
            valid_paths.append(path)
        else:
            _log(
                _REVIEWER_LOGGER,
                f"[REVIEWER] KB1 source rejected [{report.code}]: {path.name}: {report.message}",
            )

    _REVIEWER_KB1_QUALITY = reports
    _write_kb1_quality_report(kb1_dir, reports)
    if not candidates:
        _log(
            _REVIEWER_LOGGER,
            "[REVIEWER] KB1 missing or empty; no supported content documents were found.",
        )
        return False, None
    if not valid_paths:
        codes = ", ".join(sorted({str(row.get("code")) for row in reports}))
        _log(
            _REVIEWER_LOGGER,
            f"[REVIEWER_KB1_INVALID] No KB1 source passed semantic validation; codes={codes}.",
        )
        return False, None

    validated_dir = _validated_kb1_directory(kb1_dir, valid_paths)
    kb1 = KnowledgeBase.build_from_directory(
        validated_dir,
        cache_dir=_kb_cache_dir("kb1"),
        force_rebuild=_REVIEWER_FORCE_REBUILD,
    )
    chunk_count, source_count = _kb_stats(kb1)
    _log(
        _REVIEWER_LOGGER,
        f"[REVIEWER] KB1 built: {chunk_count} chunks from {source_count} validated sources.",
    )
    if chunk_count == 0:
        _log(
            _REVIEWER_LOGGER,
            "[REVIEWER] KB1 has 0 chunks after semantic validation. Check file formats/content or enable OCR.",
        )
        if _REVIEWER_OUT_DIR is not None:
            (_REVIEWER_OUT_DIR / "kb1_sources.json").write_text(
                json.dumps(build_kb_index(kb1), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        return False, None
    if _REVIEWER_OUT_DIR is not None:
        (_REVIEWER_OUT_DIR / "kb1_sources.json").write_text(
            json.dumps(build_kb_index(kb1), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    retriever = RetrievalManager(local_kb=kb1, enable_web=False)
    return True, retriever


def build_or_load_kb2(kb2_dir: Optional[Path]) -> RetrievalManager:
    if kb2_dir is None or not kb2_dir.exists() or not kb2_dir.is_dir():
        raise FileNotFoundError("--kb2-dir is required and must be an existing directory.")
    if not _dir_has_supported_files(kb2_dir):
        raise ValueError(
            "--kb2-dir contains no supported documents (.pdf/.docx/.pptx/.md/.txt)."
        )
    kb2 = KnowledgeBase.build_from_directory(
        kb2_dir,
        cache_dir=_kb_cache_dir("kb2"),
        force_rebuild=_REVIEWER_FORCE_REBUILD,
    )
    chunk_count, source_count = _kb_stats(kb2)
    _log(
        _REVIEWER_LOGGER,
        f"[REVIEWER] KB2 built: {chunk_count} chunks from {source_count} sources.",
    )
    if chunk_count == 0:
        _log(
            _REVIEWER_LOGGER,
            "[REVIEWER] KB2 has 0 chunks. Check file formats, file content, or enable OCR.",
        )
        raise ValueError("--kb2-dir produced 0 usable chunks; the reviewed document cannot be evaluated.")
    if _REVIEWER_OUT_DIR is not None:
        (_REVIEWER_OUT_DIR / "kb2_sources.json").write_text(
            json.dumps(build_kb_index(kb2), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return RetrievalManager(local_kb=kb2, enable_web=False)


def _llm_chat(
    llm: Any,
    messages: list[dict[str, str]],
    *,
    allow_tools: bool,
    max_tokens: Optional[int],
) -> str:
    """Call the configured client while retaining compatibility with test/custom clients."""

    kwargs: dict[str, Any] = {"allow_tools": allow_tools}
    if max_tokens is not None:
        kwargs["max_tokens"] = int(max_tokens)
    try:
        return str(llm.chat(messages, **kwargs) or "")
    except TypeError as exc:
        # Older custom clients may not expose max_tokens.  Only retry the
        # compatibility signature when that keyword is the problem.
        if "max_tokens" not in str(exc):
            raise
        kwargs.pop("max_tokens", None)
        return str(llm.chat(messages, **kwargs) or "")


def _read_reviewer_instructions(raw_path: Optional[str]) -> str:
    if not raw_path:
        return ""
    path = Path(raw_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Reviewer instructions file not found: {path}")
    if path.stat().st_size > 2_000_000:
        raise ValueError("Reviewer instructions file is unexpectedly large (>2 MB).")
    return clean_user_instructions(path.read_text(encoding="utf-8", errors="replace"))


def resolve_prompt1(
    kb1_available: bool,
    prompt1_default_path: Path,
    architect_prompt_path: Path,
    kb1_retriever: Optional[RetrievalManager],
    model_client: Optional[OpenRouterLLM],
    out_dir: Path,
    *,
    profile: str = DEFAULT_REVIEWER_PROFILE,
    language: str = "",
    kb1_context_max_chars: int = 48000,
    max_tokens: Optional[int] = 32768,
    usage_label: str = "reviewer_llm1",
) -> tuple[str, str, list[str], bool, str]:
    """Resolve the effective reviewer system prompt without replacing the canonical rubric.

    ``direct`` is the parity profile: the exact standalone prompt1_default remains
    the first and authoritative block and no architect LLM is invoked. ``hybrid``
    asks LLM1 only for a KB1 addendum. ``compliance`` retains an opt-in legacy-like
    KB1-centric profile for deployments that explicitly need it.
    """

    profile = str(profile or DEFAULT_REVIEWER_PROFILE).strip().lower()
    if profile not in REVIEWER_PROFILES:
        raise ValueError(f"Unsupported reviewer profile: {profile}")
    base_prompt = prompt1_default_path.read_text(encoding="utf-8-sig")
    kb1_context = "(none)"
    kb1_ids: list[str] = []
    kb1_truncated = False
    addendum = ""

    if kb1_available and kb1_retriever is not None:
        kb1_context, kb1_ids, kb1_truncated = ordered_full_context(
            getattr(kb1_retriever, "local_kb", None),
            max_chars=max(4000, int(kb1_context_max_chars)),
        )
        _log(
            _REVIEWER_LOGGER,
            f"[REVIEWER] Ordered KB1 context: {len(kb1_ids)} chunks, "
            f"{len(kb1_context)} chars, truncated={kb1_truncated}.",
        )

    if profile in {"hybrid", "compliance"} and kb1_available:
        if model_client is None:
            raise RuntimeError(f"Reviewer profile {profile} requires LLM1.")
        if not architect_prompt_path.exists():
            raise FileNotFoundError(f"Architect prompt not found: {architect_prompt_path}")
        architect_prompt = architect_prompt_path.read_text(encoding="utf-8-sig")
        messages, _ = build_kb1_addendum_prompt(
            architect_prompt=architect_prompt,
            kb1_context=kb1_context,
            language=language,
        )
        addendum = _llm_chat(
            model_client,
            messages,
            allow_tools=False,
            max_tokens=max_tokens,
        ).strip()
        _log_llm_usage(out_dir, model_client, usage_label, extra={"stage": "kb1_addendum", "profile": profile})
        if not addendum:
            raise RuntimeError("LLM1 returned an empty KB1 addendum.")
        (out_dir / "reviewer_kb1_addendum_generated.md").write_text(addendum, encoding="utf-8")

    system_prompt = compose_reviewer_system_prompt(
        base_prompt=base_prompt,
        profile=profile,
        kb1_addendum=addendum,
        language=language,
    )
    effective_path = out_dir / "reviewer_prompt1_effective.md"
    effective_path.write_text(system_prompt, encoding="utf-8")
    # Keep the historical filename for tooling that expects it, but make its
    # semantics explicit: it contains only the optional addendum.
    if addendum:
        (out_dir / "reviewer_prompt1_generated.md").write_text(addendum, encoding="utf-8")
    _log(
        _REVIEWER_LOGGER,
        f"[REVIEWER] prompt1 profile={profile}; canonical prompt preserved -> {effective_path}",
    )
    return system_prompt, kb1_context, kb1_ids, kb1_truncated, addendum

def _write_kb1_diagnostic(
    out_dir: Path,
    *,
    kb1_dir: Optional[Path],
    kb2_dir: Optional[Path],
    explicit_override: bool,
) -> None:
    quality_code = _primary_kb1_quality_code()
    payload = {
        "code": (
            "REVIEWER_KB1_EXPLICITLY_WAIVED"
            if explicit_override
            else quality_code
        ),
        "message": (
            "Reviewer mode requires a semantically valid KB1 source containing evaluation rules, an official "
            "regulation, a rubric, or user-supplied criteria. Authentication pages, access gates and unrelated "
            "documents are rejected before any LLM request."
            if not explicit_override
            else "The user explicitly allowed a general review without a verified KB1 source."
        ),
        "kb1_dir": str(kb1_dir) if kb1_dir else None,
        "kb2_dir": str(kb2_dir) if kb2_dir else None,
        "explicit_override": explicit_override,
        "quality_reports": list(_REVIEWER_KB1_QUALITY),
        "recommended_actions": [
            "Attach the institution/faculty regulation, thesis evaluation rubric, or reviewer template as KB1.",
            "Provide an official public URL and let the Open WebUI Pipe import it as KB1.",
            "Provide jurisdiction, institution, faculty and work type and explicitly request context-aware lookup.",
            "Paste explicit evaluation criteria supplied by the user or institution.",
        ],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    json_path = out_dir / "reviewer_kb1_diagnostic.json"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path = out_dir / "reviewer_kb1_diagnostic.md"
    md_path.write_text(
        "# Reviewer KB1 diagnostic\n\n"
        f"**Code:** `{payload['code']}`\n\n"
        f"{payload['message']}\n\n"
        "## Required next step\n\n"
        + "\n".join(f"- {item}" for item in payload["recommended_actions"])
        + "\n",
        encoding="utf-8",
    )



def run_reviewer(args: Any, run_ctx: Optional[RunContext], logger: Any) -> int:
    out_dir = Path(args.out_dir).expanduser().resolve()
    if run_ctx is None:
        run_ctx = RunContext.create(out_dir=out_dir, mode="reviewer")

    out_dir.mkdir(parents=True, exist_ok=True)
    started_at = datetime.now(timezone.utc)
    status = "ok"
    error: Optional[str] = None
    llm1: Any = None
    llm2: Any = None

    def _client_model(client: Any) -> Optional[str]:
        return getattr(getattr(client, "config", None), "model", None) if client is not None else None

    def _client_tokens(client: Any) -> int:
        try:
            return int(client.get_total_tokens()) if client is not None else 0
        except Exception:
            return 0

    def _client_cost(client: Any) -> Optional[float]:
        try:
            value = client.get_total_cost_usd() if client is not None else None
            return None if value is None else float(value)
        except Exception:
            return None

    def _persist_meta() -> None:
        try:
            write_run_meta(
                run_ctx=run_ctx,
                args=args,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc),
                status=status,
                error=error,
                models={"llm1": _client_model(llm1), "llm2": _client_model(llm2)},
                token_totals={"llm1": _client_tokens(llm1), "llm2": _client_tokens(llm2)},
                cost_totals_usd={"llm1": _client_cost(llm1), "llm2": _client_cost(llm2)},
            )
        except Exception as exc:
            _log(logger, f"[REVIEWER] Unable to write run_meta.json: {exc}")

    prompts = load_reviewer_prompts()
    set_prompt_registry("reviewer", prompts)

    kb1_dir = _resolve_dir(getattr(args, "kb1_dir", None))
    kb2_dir = _resolve_dir(getattr(args, "kb2_dir", None))
    profile = str(getattr(args, "reviewer_profile", DEFAULT_REVIEWER_PROFILE) or DEFAULT_REVIEWER_PROFILE).lower()
    language = str(getattr(args, "language", None) or "").strip()
    evidence_max_chars = max(12000, min(int(getattr(args, "reviewer_evidence_max_chars", 60000)), 500000))
    kb1_max_chars = max(4000, min(int(getattr(args, "reviewer_kb1_context_max_chars", 48000)), 300000))
    per_criterion = max(1, min(int(getattr(args, "reviewer_evidence_per_criterion", 6)), 30))
    max_output_tokens = max(2048, min(int(getattr(args, "reviewer_max_output_tokens", 32768)), 131072))
    quality_gate = bool(getattr(args, "reviewer_quality_gate", True))
    direct_pdf = bool(getattr(args, "reviewer_direct_pdf", False))

    if profile not in REVIEWER_PROFILES:
        print(f"Error: unsupported reviewer profile: {profile}", file=sys.stderr)
        return 2

    _configure_reviewer_kb(out_dir, bool(getattr(args, "rebuild_kb", False)), logger)

    try:
        kb2_retriever = build_or_load_kb2(kb2_dir)
    except Exception as exc:
        error = str(exc)
        status = "error"
        print(f"Error: {exc}", file=sys.stderr)
        _persist_meta()
        return 2

    kb1_available, kb1_retriever = build_or_load_kb1(kb1_dir)
    allow_missing_kb1 = bool(getattr(args, "reviewer_allow_missing_kb1", False))
    if kb1_available:
        _log(logger, f"[REVIEWER] KB1 dir: {kb1_dir}")
    elif not allow_missing_kb1:
        _write_kb1_diagnostic(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir, explicit_override=False)
        quality_code = _primary_kb1_quality_code()
        error = f"{quality_code}: reviewer requires a semantically valid KB1"
        status = "error"
        print(
            f"[{quality_code}] Reviewer requires a semantically valid KB1 with explicit evaluation rules, "
            "an official regulation, a rubric, or user-supplied criteria. Attach/provide another KB1 source "
            "or use the guided lookup in the Open WebUI Pipe.",
            file=sys.stderr,
        )
        _persist_meta()
        return 2
    else:
        _write_kb1_diagnostic(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir, explicit_override=True)
        _log(
            logger,
            "[REVIEWER] WARNING: KB1 is missing under an explicit waiver. The result is not an "
            "institutional-compliance review.",
        )

    _log(logger, f"[REVIEWER] KB2 dir: {kb2_dir}")
    _log(logger, f"[REVIEWER] KB2 retriever ready: {kb2_retriever is not None}")
    _log(
        logger,
        f"[REVIEWER_PARITY] profile={profile} language={language or '(auto)'} "
        f"evidence_max_chars={evidence_max_chars} direct_pdf={direct_pdf} quality_gate={quality_gate}",
    )

    prompt_dir = Path(__file__).resolve().parents[2] / "prompts" / "reviewer"
    prompt1_default_path = prompt_dir / "prompt1_default.md"
    architect_prompt_path = prompt_dir / "architect_prompt.md"
    prompt2_path = prompt_dir / "prompt2.md"
    for path, label in (
        (prompt1_default_path, "prompt1_default"),
        (architect_prompt_path, "architect_prompt"),
        (prompt2_path, "prompt2"),
    ):
        if not path.exists():
            error = f"{label} not found: {path}"
            status = "error"
            print(f"Error: {error}", file=sys.stderr)
            _persist_meta()
            return 2

    try:
        user_instructions = _read_reviewer_instructions(getattr(args, "reviewer_instructions", None))
    except Exception as exc:
        error = str(exc)
        status = "error"
        print(f"Error: {exc}", file=sys.stderr)
        _persist_meta()
        return 2

    model_llm1 = _resolve_model_override(args, "reviewer_llm1_model", "AUTOGENBOOK_REVIEWER_LLM1_MODEL")
    model_llm2 = _resolve_model_override(args, "reviewer_llm2_model", "AUTOGENBOOK_REVIEWER_LLM2_MODEL")
    base_llm1 = _resolve_value_override(args, "reviewer_llm1_base_url", "AUTOGENBOOK_REVIEWER_LLM1_BASE_URL")
    base_llm2 = _resolve_value_override(args, "reviewer_llm2_base_url", "AUTOGENBOOK_REVIEWER_LLM2_BASE_URL")

    def _build_config(model_override: Optional[str], base_url_override: Optional[str]) -> Optional[LLMConfig]:
        if model_override or base_url_override or max_output_tokens:
            base = LLMConfig()
            return LLMConfig(
                model=model_override or base.model,
                temperature=base.temperature,
                max_tokens=max_output_tokens,
                input_cost_per_million=base.input_cost_per_million,
                output_cost_per_million=base.output_cost_per_million,
                base_url=base_url_override,
            )
        return None

    try:
        llm2 = OpenRouterLLM(_build_config(model_llm2, base_llm2))
        if profile in {"hybrid", "compliance"} and kb1_available:
            llm1 = OpenRouterLLM(_build_config(model_llm1, base_llm1))
        system_prompt, kb1_context, kb1_ids, kb1_truncated, _kb1_addendum = resolve_prompt1(
            kb1_available,
            prompt1_default_path,
            architect_prompt_path,
            kb1_retriever,
            llm1,
            out_dir,
            profile=profile,
            language=language,
            kb1_context_max_chars=kb1_max_chars,
            max_tokens=max_output_tokens,
        )
    except Exception as exc:
        error = str(exc)
        status = "error"
        print(f"Error: failed to resolve effective reviewer prompt: {exc}", file=sys.stderr)
        _persist_meta()
        return 2

    try:
        canonical_task = prompt2_path.read_text(encoding="utf-8-sig")
        base_prompt = prompt1_default_path.read_text(encoding="utf-8-sig")
        evidence_pack = build_reviewer_evidence_pack(
            kb2_retriever,
            max_chars=evidence_max_chars,
            per_criterion=per_criterion,
            direct_pdf_requested=direct_pdf,
        )
        (out_dir / "reviewer_evidence_pack.md").write_text(evidence_pack.context, encoding="utf-8")
        (out_dir / "reviewer_evidence_manifest.json").write_text(
            json.dumps(evidence_pack.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        user_prompt = compose_reviewer_user_prompt(
            canonical_task=canonical_task,
            user_instructions=user_instructions,
            language=language,
            kb2_pack=evidence_pack,
            kb1_context=kb1_context,
        )
        (out_dir / "reviewer_prompt2_effective.md").write_text(user_prompt, encoding="utf-8")
        _log(
            logger,
            f"[REVIEWER_PARITY] KB2 evidence: {evidence_pack.selected_chunk_count}/"
            f"{evidence_pack.available_chunk_count} chunks, {len(evidence_pack.context)} chars, "
            f"criteria={sum(bool(v) for v in evidence_pack.criterion_ids.values())}/"
            f"{len(evidence_pack.criterion_ids)}.",
        )
    except Exception as exc:
        error = str(exc)
        status = "error"
        print(f"Error: failed to construct reviewer evidence/prompt: {exc}", file=sys.stderr)
        _persist_meta()
        return 2

    repair_attempted = False
    require_default_table = profile != "compliance"
    try:
        review_output = _llm_chat(
            llm2,
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            allow_tools=True,
            max_tokens=max_output_tokens,
        ).strip()
        _log_llm_usage(out_dir, llm2, "reviewer_llm2", extra={"stage": "review", "profile": profile})
        quality = validate_review_output(
            review_output,
            language=language,
            require_default_table=require_default_table,
        )
        if quality_gate and not quality.passed:
            repair_attempted = True
            (out_dir / "reviewer_first_draft.md").write_text(review_output, encoding="utf-8")
            _log(logger, "[REVIEWER_QUALITY] Initial draft failed; requesting one evidence-preserving repair.")
            review_output = _llm_chat(
                llm2,
                build_review_repair_messages(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    previous_output=review_output,
                    quality=quality,
                ),
                allow_tools=False,
                max_tokens=max_output_tokens,
            ).strip()
            _log_llm_usage(
                out_dir,
                llm2,
                "reviewer_llm2_repair",
                extra={"stage": "quality_repair", "profile": profile},
            )
            quality = validate_review_output(
                review_output,
                language=language,
                require_default_table=require_default_table,
            )
    except Exception as exc:
        error = str(exc)
        status = "error"
        print(f"Error: LLM2 reviewer call failed: {exc}", file=sys.stderr)
        _persist_meta()
        return 2

    quality_path = out_dir / "reviewer_quality_report.json"
    quality_path.write_text(
        json.dumps(
            {
                **quality.to_dict(),
                "profile": profile,
                "language": language,
                "repair_attempted": repair_attempted,
                "model": _client_model(llm2),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    write_parity_manifest(
        out_dir / "reviewer_parity_manifest.json",
        profile=profile,
        language=language,
        model=_client_model(llm2),
        user_instructions=user_instructions,
        base_prompt=base_prompt,
        canonical_task=canonical_task,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        kb1_context=kb1_context,
        kb1_ids=kb1_ids,
        kb1_truncated=kb1_truncated,
        kb2_pack=evidence_pack,
        quality=quality,
        repair_attempted=repair_attempted,
    )

    if quality_gate and not quality.passed:
        status = "error"
        error = "REVIEWER_OUTPUT_QUALITY_FAILED: " + "; ".join(quality.defects)
        (out_dir / "review_draft_failed_quality.md").write_text(review_output, encoding="utf-8")
        print(f"Error: {error}", file=sys.stderr)
        _persist_meta()
        return 2

    review_path = out_dir / "review_final.md"
    review_path.write_text(review_output, encoding="utf-8")
    _log(logger, f"[REVIEWER] review_final.md written: {review_path}")

    formats = ["markdown"]
    if not bool(getattr(args, "no_pdf", False)):
        formats.append("pdf")
    if not bool(getattr(args, "no_tex", False)):
        formats.append("tex")
    if bool(getattr(args, "docx", False)):
        formats.append("docx")
    conversion_results = _convert_with_pandoc(
        review_path,
        out_dir,
        formats,
        basename="review_final",
        pdf_engine=str(getattr(args, "reviewer_pdf_engine", "auto") or "auto"),
    )
    (out_dir / "reviewer_conversion_report.json").write_text(
        json.dumps(conversion_results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    failed_exports = [
        fmt for fmt in formats if fmt not in {"markdown", "md"} and not conversion_results.get(fmt, {}).get("success")
    ]
    if failed_exports:
        status = "error"
        error = "REVIEWER_EXPORT_FAILED: " + ", ".join(failed_exports)
        print(
            f"Error: requested reviewer exports were not created: {', '.join(failed_exports)}. "
            "See reviewer_conversion_report.json.",
            file=sys.stderr,
        )
        _persist_meta()
        return 2

    for label, client in (("LLM1", llm1), ("LLM2", llm2)):
        total = _client_tokens(client)
        if total:
            print(f"[TOKENS] {label} total tokens: {total}")
    total_tokens = _client_tokens(llm1) + _client_tokens(llm2)
    if total_tokens:
        print(f"[TOKENS] Celkem spotrebovano tokenu: {total_tokens}")
    known_costs = [value for value in (_client_cost(llm1), _client_cost(llm2)) if value is not None]
    if known_costs:
        print(f"[COST] Celkova cena: ${sum(known_costs):.6f}")

    _persist_meta()
    _log(logger, "[REVIEWER] Reviewer mode completed with the standalone-parity pipeline.")
    return 0
