from __future__ import annotations

import re
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qsl, urlsplit


_AUTH_URL_PARTS = (
    "/oauth/",
    "/oauth2/",
    "/authorize",
    "/login",
    "/log-in",
    "/signin",
    "/sign-in",
    "/sso/",
    "/auth/",
    "/idp/",
    "/shibboleth",
    "/cas/login",
)
_AUTH_QUERY_KEYS = {
    "client_id",
    "redirect_uri",
    "response_type",
    "scope",
    "state",
    "nonce",
    "code_challenge",
    "code_challenge_method",
    "samlrequest",
    "relaystate",
}
_AUTH_HOST_PREFIXES = ("id.", "login.", "signin.", "sso.", "auth.", "accounts.")
_AUTH_TEXT_TERMS = (
    "jednotne prihlaseni",
    "prihlaseni",
    "prihlaste se",
    "prihlasit se",
    "uzivatelske jmeno",
    "heslo",
    "single sign on",
    "single sign-on",
    "sign in",
    "log in",
    "login",
    "identity provider",
    "oauth",
    "password",
    "username",
    "forgot password",
    "session expired",
)
_ACCESS_GATE_TERMS = (
    "access denied",
    "unauthorized",
    "forbidden",
    "not authorized",
    "nemate opravneni",
    "pristup odepren",
    "stranka nenalezena",
    "page not found",
    "javascript is required",
    "cookies are required",
)
_THESIS_TERMS = (
    "zaverecna prace",
    "zaverecnych praci",
    "bakalarska prace",
    "bakalarsky projekt",
    "diplomova prace",
    "disertacni prace",
    "doctoral thesis",
    "master thesis",
    "bachelor thesis",
    "final thesis",
    "final work",
    "thesis",
    "obhajoba",
    "obhajoby",
)
_EVALUATION_TERMS = (
    "hodnoceni",
    "hodnotici",
    "kriteria",
    "kriterium",
    "posudek",
    "posudku",
    "oponent",
    "oponenta",
    "vedouci prace",
    "klasifikace",
    "znamka",
    "smernice",
    "vyhlaska",
    "metodika",
    "rubrika",
    "pravidla",
    "pozadavky",
    "splneni cile",
    "odborna uroven",
    "formalni uroven",
    "kvalita vysledku",
    "prace s literaturou",
    "assessment",
    "evaluation",
    "grading",
    "grade",
    "review rubric",
    "rubric",
    "criteria",
    "regulation",
    "directive",
    "guideline",
    "reviewer report",
)
_INSTITUTION_TERMS = (
    "univerzita",
    "vysoke uceni",
    "vysoka skola",
    "fakulta",
    "rektor",
    "dekan",
    "studijni rad",
    "vnitrni norma",
    "university",
    "faculty",
    "academic senate",
    "study regulations",
)
_METADATA_SIDECAR_SUFFIXES = ("_source.md", "_provenance.md", ".provenance.json")


def normalize_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", str(value or ""))
    normalized = "".join(ch for ch in normalized if not unicodedata.combining(ch))
    normalized = normalized.casefold()
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip()


def _hits(haystack: str, terms: Iterable[str]) -> list[str]:
    return sorted({term for term in terms if normalize_text(term) in haystack})


def is_metadata_sidecar(path: Path | str) -> bool:
    name = Path(path).name.casefold()
    return any(name.endswith(suffix) for suffix in _METADATA_SIDECAR_SUFFIXES)


def authentication_url_reasons(url: str | None) -> list[str]:
    raw = str(url or "").strip()
    if not raw:
        return []
    try:
        parsed = urlsplit(raw)
    except Exception:
        return []
    host = (parsed.hostname or "").casefold()
    path = (parsed.path or "").casefold()
    query_keys = {key.casefold() for key, _value in parse_qsl(parsed.query, keep_blank_values=True)}
    reasons: list[str] = []
    if any(path_part in path for path_part in _AUTH_URL_PARTS):
        reasons.append("URL vede na přihlašovací/autorizační endpoint")
    if len(query_keys & _AUTH_QUERY_KEYS) >= 2:
        reasons.append("URL obsahuje parametry OAuth/SAML přihlášení")
    if host.startswith(_AUTH_HOST_PREFIXES) and (
        query_keys & _AUTH_QUERY_KEYS or any(part in path for part in _AUTH_URL_PARTS)
    ):
        reasons.append("hostname a cesta odpovídají identity provideru")
    return reasons


@dataclass(frozen=True)
class Kb1QualityReport:
    valid: bool
    code: str
    message: str
    score: int
    char_count: int
    word_count: int
    source_name: str = ""
    source_url: str = ""
    title: str = ""
    source_kind: str = "file"
    thesis_hits: list[str] = field(default_factory=list)
    evaluation_hits: list[str] = field(default_factory=list)
    institution_hits: list[str] = field(default_factory=list)
    authentication_hits: list[str] = field(default_factory=list)
    access_gate_hits: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def assess_text(
    text: str,
    *,
    source_name: str = "",
    source_url: str = "",
    title: str = "",
    source_kind: str = "file",
) -> Kb1QualityReport:
    raw = str(text or "")
    compact = normalize_text("\n".join(part for part in (title, source_name, source_url, raw) if part))
    body_compact = normalize_text(raw)
    words = re.findall(r"[a-z0-9]+", body_compact)
    char_count = len(body_compact)
    word_count = len(words)

    thesis_hits = _hits(compact, _THESIS_TERMS)
    evaluation_hits = _hits(compact, _EVALUATION_TERMS)
    institution_hits = _hits(compact, _INSTITUTION_TERMS)
    authentication_hits = _hits(compact, _AUTH_TEXT_TERMS)
    auth_heading_hits = _hits(normalize_text(" ".join((title, source_name))), _AUTH_TEXT_TERMS)
    access_gate_hits = _hits(compact, _ACCESS_GATE_TERMS)
    auth_url_reasons = authentication_url_reasons(source_url)

    reasons: list[str] = []
    score = min(100, (
        min(30, len(evaluation_hits) * 8)
        + min(25, len(thesis_hits) * 10)
        + min(15, len(institution_hits) * 5)
        + (15 if char_count >= 1200 else 8 if char_count >= 500 else 3 if char_count >= 200 else 0)
        + (15 if word_count >= 150 else 8 if word_count >= 60 else 3 if word_count >= 25 else 0)
    ))

    auth_dominant = bool(
        auth_url_reasons
        or (
            authentication_hits
            and (
                len(authentication_hits) >= 2
                and (len(evaluation_hits) < 2 or bool(auth_heading_hits))
            )
        )
    )
    if auth_dominant:
        reasons.extend(auth_url_reasons)
        if authentication_hits:
            reasons.append("obsah je dominantně přihlašovací/SSO stránka")
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_AUTH_PAGE",
            message=(
                "Zdroj KB1 je přihlašovací nebo autorizační stránka, nikoli hodnoticí předpis. "
                "Je nutné dodat veřejně dostupný dokument nebo explicitní kritéria."
            ),
            score=0,
            char_count=char_count,
            word_count=word_count,
            source_name=source_name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            thesis_hits=thesis_hits,
            evaluation_hits=evaluation_hits,
            institution_hits=institution_hits,
            authentication_hits=authentication_hits,
            access_gate_hits=access_gate_hits,
            reasons=reasons,
        )

    if access_gate_hits:
        reasons.append("obsah odpovídá chybové nebo přístupové bráně")
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_ACCESS_GATE",
            message="Zdroj KB1 je chybová/přístupová stránka a neobsahuje použitelná hodnoticí pravidla.",
            score=0,
            char_count=char_count,
            word_count=word_count,
            source_name=source_name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            thesis_hits=thesis_hits,
            evaluation_hits=evaluation_hits,
            institution_hits=institution_hits,
            authentication_hits=authentication_hits,
            access_gate_hits=access_gate_hits,
            reasons=reasons,
        )

    explicit_text = source_kind == "user_text"
    min_chars = 80 if explicit_text else 220
    min_words = 10 if explicit_text else 25
    if char_count < min_chars or word_count < min_words:
        reasons.append(f"zdroj je příliš krátký ({char_count} znaků, {word_count} slov)")
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_TOO_SHORT",
            message=(
                "Zdroj KB1 je příliš krátký na to, aby spolehlivě definoval hodnoticí pravidla. "
                "Dodejte úplný předpis/rubriku nebo podrobnější explicitní kritéria."
            ),
            score=score,
            char_count=char_count,
            word_count=word_count,
            source_name=source_name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            thesis_hits=thesis_hits,
            evaluation_hits=evaluation_hits,
            institution_hits=institution_hits,
            authentication_hits=authentication_hits,
            access_gate_hits=access_gate_hits,
            reasons=reasons,
        )

    topical = bool(thesis_hits and evaluation_hits)
    rubric_like = len(evaluation_hits) >= (2 if explicit_text else 3)
    institution_rule = rubric_like and bool(institution_hits)
    if not (topical or rubric_like or institution_rule):
        reasons.append("obsah neobsahuje dostatek znaků hodnoticí normy/rubriky")
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_IRRELEVANT",
            message=(
                "Zdroj KB1 není dostatečně relevantní k hodnocení závěrečných prací. "
                "Vyžaduje se směrnice, vyhláška, metodika, rubrika, šablona posudku nebo explicitní kritéria."
            ),
            score=score,
            char_count=char_count,
            word_count=word_count,
            source_name=source_name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            thesis_hits=thesis_hits,
            evaluation_hits=evaluation_hits,
            institution_hits=institution_hits,
            authentication_hits=authentication_hits,
            access_gate_hits=access_gate_hits,
            reasons=reasons,
        )

    reasons.append("zdroj obsahuje použitelnou kombinaci hodnoticích a tematických znaků")
    return Kb1QualityReport(
        valid=True,
        code="OK",
        message="Zdroj KB1 prošel kontrolou relevance a není přihlašovací/chybovou stránkou.",
        score=max(score, 55),
        char_count=char_count,
        word_count=word_count,
        source_name=source_name,
        source_url=source_url,
        title=title,
        source_kind=source_kind,
        thesis_hits=thesis_hits,
        evaluation_hits=evaluation_hits,
        institution_hits=institution_hits,
        authentication_hits=authentication_hits,
        access_gate_hits=access_gate_hits,
        reasons=reasons,
    )


def extract_text_from_file(path: Path, *, max_chars: int = 250_000) -> str:
    path = Path(path)
    suffix = path.suffix.casefold()
    if suffix in {".md", ".txt"}:
        try:
            return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
        except OSError:
            return ""
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader  # type: ignore

            reader = PdfReader(str(path))
            parts: list[str] = []
            total = 0
            for page in reader.pages[:40]:
                value = (page.extract_text() or "").strip()
                if not value:
                    continue
                remaining = max_chars - total
                if remaining <= 0:
                    break
                parts.append(value[:remaining])
                total += min(len(value), remaining)
            return "\n".join(parts)
        except Exception:
            return ""
    if suffix == ".docx":
        try:
            from docx import Document  # type: ignore

            document = Document(str(path))
            value = "\n".join(p.text for p in document.paragraphs if p.text and p.text.strip())
            return value[:max_chars]
        except Exception:
            return ""
    if suffix == ".pptx":
        try:
            from pptx import Presentation  # type: ignore

            presentation = Presentation(str(path))
            parts: list[str] = []
            total = 0
            for slide in presentation.slides:
                for shape in slide.shapes:
                    value = str(getattr(shape, "text", "") or "").strip()
                    if not value:
                        continue
                    remaining = max_chars - total
                    if remaining <= 0:
                        return "\n".join(parts)
                    parts.append(value[:remaining])
                    total += min(len(value), remaining)
            return "\n".join(parts)
        except Exception:
            return ""
    return ""


def assess_file(
    path: Path,
    *,
    source_url: str = "",
    title: str = "",
    source_kind: str = "file",
) -> Kb1QualityReport:
    path = Path(path)
    if not path.exists() or not path.is_file():
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_UNREADABLE",
            message="Soubor KB1 neexistuje nebo není běžným souborem.",
            score=0,
            char_count=0,
            word_count=0,
            source_name=path.name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            reasons=["missing or non-file path"],
        )
    if is_metadata_sidecar(path):
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_METADATA_ONLY",
            message="Soubor je pouze provenance/metadata a nemá být použit jako obsah KB1.",
            score=0,
            char_count=0,
            word_count=0,
            source_name=path.name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            reasons=["metadata sidecar"],
        )
    text = extract_text_from_file(path)
    if not text.strip():
        return Kb1QualityReport(
            valid=False,
            code="REVIEWER_KB1_UNREADABLE",
            message="Z dokumentu KB1 se nepodařilo získat žádný text.",
            score=0,
            char_count=0,
            word_count=0,
            source_name=path.name,
            source_url=source_url,
            title=title,
            source_kind=source_kind,
            reasons=["text extraction returned empty content"],
        )
    return assess_text(
        text,
        source_name=path.name,
        source_url=source_url,
        title=title,
        source_kind=source_kind,
    )
