from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from autogenbook.retrieval.sanitize import sanitize_context_text
from autogenbook.retrieval.types import RetrievalItem


DEFAULT_REVIEWER_PROFILE = "direct"
REVIEWER_PROFILES = {"direct", "hybrid", "compliance"}

# These are the seven rows explicitly required by the original/direct reviewer
# prompt pack.  They are used only to gather representative evidence and to
# validate the shape of the generated answer; they are not injected as facts.
DIRECT_REVIEW_CRITERIA: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    (
        "topic_objectives",
        "Description of the topic/problem being addressed and the objectives of the work",
        (
            "téma problém cíl práce zadání motivace účel objectives problem statement",
            "úvod cíle práce řešený problém zadání thesis objectives",
        ),
    ),
    (
        "analysis",
        "Analysis of the topic/problem being addressed",
        (
            "analýza současný stav teoretická východiska rešerše problem analysis state of the art",
            "rozbor problému literatura metody analysis background",
        ),
    ),
    (
        "solutions_conclusions",
        "Proposals for solutions and conclusions",
        (
            "návrh řešení implementace výsledky závěr doporučení solution conclusions results",
            "řešení experiment výsledek diskuse závěr contribution",
        ),
    ),
    (
        "structure_form",
        "Structure and form of the work",
        (
            "struktura práce kapitoly abstrakt klíčová slova literatura přílohy formální úprava",
            "table of contents structure formatting references appendices",
        ),
    ),
    (
        "originality",
        "Originality of the work (topic, proposals and solutions)",
        (
            "původnost vlastní přínos autor návrh originality own contribution",
            "novost samostatnost vlastní řešení originality",
        ),
    ),
    (
        "innovation",
        "Innovation of the work (topic, proposals and solutions)",
        (
            "inovace inovativní nový postup novelty innovation improvements",
            "nový přístup metoda řešení innovation",
        ),
    ),
    (
        "societal_contribution",
        "Contribution of the work to society/application practice",
        (
            "přínos praxe využití aplikace společnost dopad contribution practical application",
            "nasazení využitelnost doporučení impact practice",
        ),
    ),
)

_CZECH_MARKERS = (
    " a ",
    " je ",
    " se ",
    " na ",
    " práce",
    " hodnocení",
    " závěr",
    " cíle",
    " výsled",
    " metod",
    " přínos",
)

_ATTACHMENT_BLOCK_RE = re.compile(r"<attached_files>.*?</attached_files>", re.I | re.S)
_FILE_TAG_RE = re.compile(r"<file\b[^>]*/?>", re.I | re.S)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def clean_user_instructions(value: str | None) -> str:
    """Remove Open WebUI attachment XML while preserving the user's text."""

    text = str(value or "")
    text = _ATTACHMENT_BLOCK_RE.sub("", text)
    text = _FILE_TAG_RE.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def language_instruction(language: str | None) -> str:
    normalized = str(language or "").strip().casefold()
    if normalized.startswith("cs") or normalized in {"cz", "czech", "čeština", "cesky", "česky"}:
        return (
            "Piš celý výsledný posudek česky. Názvy zdrojů a doslovné citace mohou zůstat "
            "v původním jazyce, ale vysvětlení, známky, závěry a doporučení musí být česky."
        )
    if normalized.startswith("sk") or normalized in {"slovak", "slovenčina", "slovensky"}:
        return "Napíš celý výsledný posudok po slovensky."
    if normalized:
        return f"Write the entire final review in language code/name: {language}."
    return "Write the review in the language used by the reviewed work."


def default_reviewer_instruction(language: str | None) -> str:
    normalized = str(language or "").strip().casefold()
    if normalized.startswith("cs") or normalized in {"cz", "czech", "čeština", "česky", "cesky"}:
        return (
            "Vypracuj úplný odborný posudek závěrečné práce podle standardního reviewer promptu "
            "AutoGenBooku. Zohledni obsahovou kvalitu práce i formální požadavky z KB1, u každého "
            "hodnocení uveď konkrétní důkazy z KB2 a jasně rozliš, co nelze z dokumentu ověřit."
        )
    return (
        "Produce the complete thesis review defined by the standard AutoGenBook reviewer prompt. "
        "Use concrete KB2 evidence and treat KB1 as institution-specific formal requirements."
    )


def _chunk_identity(chunk: Any) -> str:
    return str(
        getattr(chunk, "rid", "")
        or getattr(chunk, "cite_key", "")
        or f"{getattr(chunk, 'source_path', '')}:{getattr(chunk, 'loc', '')}"
    )


def _chunk_sort_key(chunk: Any) -> tuple[str, int, int, str]:
    source = str(getattr(chunk, "source_path", "") or "")
    loc = str(getattr(chunk, "loc", "") or "")
    page_match = re.search(r"(?:page|strana)\s*(\d+)", loc, re.I)
    chunk_match = re.search(r"(?:chunk|část)\s*(\d+)", loc, re.I)
    return (
        source.casefold(),
        int(page_match.group(1)) if page_match else 10**9,
        int(chunk_match.group(1)) if chunk_match else 10**9,
        loc.casefold(),
    )


def _to_item(chunk: Any, *, score: float = 0.0) -> RetrievalItem:
    source_path = Path(str(getattr(chunk, "source_path", "") or ""))
    return RetrievalItem(
        rid=str(getattr(chunk, "rid", "") or ""),
        kind="kb",
        source=source_path.name,
        loc=str(getattr(chunk, "loc", "") or ""),
        score=float(score),
        cite_key=str(getattr(chunk, "cite_key", "") or ""),
        text=str(getattr(chunk, "text", "") or ""),
        url=None,
        title=source_path.name,
    )


def _format_item(item: RetrievalItem, *, max_chars: int = 2200) -> str:
    excerpt = sanitize_context_text(str(item.text or "").strip())
    if len(excerpt) > max_chars:
        excerpt = excerpt[:max_chars].rstrip() + " …"
    header = (
        f"[{item.rid or item.cite_key}] source=\"{item.source}\" "
        f"loc=\"{item.loc}\" cite_key=\"{item.cite_key}\""
    )
    return f"{header}\n{excerpt}".strip()


def _fit_blocks(blocks: Iterable[str], max_chars: int) -> tuple[str, int, bool]:
    selected: list[str] = []
    remaining = max(0, int(max_chars))
    total = 0
    truncated = False
    for block in blocks:
        total += 1
        payload = block.strip()
        if not payload:
            continue
        cost = len(payload) + (2 if selected else 0)
        if cost > remaining:
            truncated = True
            continue
        selected.append(payload)
        remaining -= cost
    return "\n\n".join(selected), len(selected), truncated


def ordered_full_context(
    kb: Any,
    *,
    max_chars: int,
    per_chunk_chars: int = 2200,
) -> tuple[str, list[str], bool]:
    """Format KB chunks in document order instead of a single top-k query."""

    chunks = list(getattr(kb, "chunks", []) or [])
    try:
        kb._ensure_chunk_ids()
    except Exception:
        pass
    chunks.sort(key=_chunk_sort_key)
    selected_blocks: list[str] = []
    selected_ids: list[str] = []
    remaining = max(0, int(max_chars))
    for chunk in chunks:
        item = _to_item(chunk)
        block = _format_item(item, max_chars=per_chunk_chars).strip()
        if not block:
            continue
        cost = len(block) + (2 if selected_blocks else 0)
        if cost > remaining:
            continue
        selected_blocks.append(block)
        selected_ids.append(_chunk_identity(chunk))
        remaining -= cost
    return (
        "\n\n".join(selected_blocks) or "(none)",
        selected_ids,
        len(selected_ids) < len(chunks),
    )

def _even_indices(size: int, count: int) -> list[int]:
    if size <= 0 or count <= 0:
        return []
    if count >= size:
        return list(range(size))
    if count == 1:
        return [0]
    return sorted({round(i * (size - 1) / (count - 1)) for i in range(count)})


@dataclass
class ReviewerEvidencePack:
    context: str
    selected_ids: list[str]
    criterion_ids: dict[str, list[str]]
    source_count: int
    available_chunk_count: int
    selected_chunk_count: int
    max_chars: int
    truncated: bool
    direct_pdf_requested: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "selected_ids": self.selected_ids,
            "criterion_ids": self.criterion_ids,
            "source_count": self.source_count,
            "available_chunk_count": self.available_chunk_count,
            "selected_chunk_count": self.selected_chunk_count,
            "max_chars": self.max_chars,
            "truncated": self.truncated,
            "direct_pdf_requested": self.direct_pdf_requested,
            "context_sha256": sha256_text(self.context),
        }


def build_reviewer_evidence_pack(
    retriever: Any,
    *,
    max_chars: int = 60000,
    per_criterion: int = 6,
    anchor_chunks: int = 18,
    direct_pdf_requested: bool = True,
) -> ReviewerEvidencePack:
    """Build a deterministic, criterion-aware evidence pack from the whole KB2.

    The legacy reviewer sent only six BM25 chunks selected by the complete prompt,
    which caused most of a thesis to disappear.  This pack combines document-order
    anchors with criterion-specific retrieval, de-duplicates chunks, and records the
    exact evidence set for parity/audit.
    """

    kb = getattr(retriever, "local_kb", None)
    chunks = list(getattr(kb, "chunks", []) or []) if kb is not None else []
    try:
        kb._ensure_chunk_ids()
    except Exception:
        pass
    chunks.sort(key=_chunk_sort_key)
    chunk_by_id = {_chunk_identity(chunk): chunk for chunk in chunks}
    selected: list[Any] = []
    seen: set[str] = set()
    criterion_ids: dict[str, list[str]] = {}

    def add(chunk: Any, bucket: str | None = None) -> None:
        identity = _chunk_identity(chunk)
        if bucket is not None:
            criterion_ids.setdefault(bucket, [])
            if identity not in criterion_ids[bucket]:
                criterion_ids[bucket].append(identity)
        if identity in seen:
            return
        seen.add(identity)
        selected.append(chunk)

    # Preserve the beginning, ending and evenly distributed parts of every source.
    by_source: dict[str, list[Any]] = {}
    for chunk in chunks:
        by_source.setdefault(str(getattr(chunk, "source_path", "") or ""), []).append(chunk)
    for source_chunks in by_source.values():
        source_chunks.sort(key=_chunk_sort_key)
        for index in _even_indices(len(source_chunks), min(anchor_chunks, len(source_chunks))):
            add(source_chunks[index], "document_anchors")

    # Query every canonical direct-review criterion independently.  This is the
    # key difference from the old single-query/k=6 path.
    for key, _label, queries in DIRECT_REVIEW_CRITERIA:
        criterion_ids.setdefault(key, [])
        for query in queries:
            try:
                rows = retriever.retrieve(
                    query,
                    k=max(1, int(per_criterion)),
                    allow_web=False,
                    diversify_sources=False,
                )
            except Exception:
                rows = []
            for row in rows:
                identity = str(row.rid or row.cite_key or f"{row.source}:{row.loc}")
                chunk = chunk_by_id.get(identity)
                if chunk is None:
                    # Keep retrieval results even when a custom KB implementation does
                    # not expose the original chunk object.
                    pseudo = type("EvidenceChunk", (), {})()
                    pseudo.rid = row.rid
                    pseudo.cite_key = row.cite_key
                    pseudo.source_path = row.source
                    pseudo.loc = row.loc
                    pseudo.text = row.text
                    chunk = pseudo
                    chunk_by_id[identity] = chunk
                add(chunk, key)

    # When direct PDF parity is requested, use remaining budget to increase
    # document-order coverage.  This avoids the legacy "first 8,000 chars only"
    # behaviour while keeping a deterministic context bound.
    if direct_pdf_requested:
        for chunk in chunks:
            add(chunk, "direct_document_context")

    blocks: list[str] = []
    included_ids: list[str] = []
    remaining = max(0, int(max_chars))
    for chunk in selected:
        item = _to_item(chunk)
        block = _format_item(item, max_chars=2200)
        if not block:
            continue
        cost = len(block) + (2 if blocks else 0)
        if cost > remaining:
            continue
        blocks.append(block)
        included_ids.append(_chunk_identity(chunk))
        remaining -= cost

    included_set = set(included_ids)
    criterion_ids = {
        key: [identity for identity in identities if identity in included_set]
        for key, identities in criterion_ids.items()
    }
    source_count = len(
        {
            str(getattr(chunk_by_id[identity], "source_path", "") or "")
            for identity in included_ids
            if identity in chunk_by_id
        }
    )
    index_lines = [
        "CRITERION_TO_EVIDENCE_INDEX:",
        *[
            f"- {key}: {', '.join(ids) if ids else '(no matching chunk selected)'}"
            for key, ids in criterion_ids.items()
        ],
        "",
        "EVIDENCE_CHUNKS:",
    ]
    context = "\n".join(index_lines) + "\n" + "\n\n".join(blocks)
    return ReviewerEvidencePack(
        context=context.strip() or "(none)",
        selected_ids=included_ids,
        criterion_ids=criterion_ids,
        source_count=source_count,
        available_chunk_count=len(chunks),
        selected_chunk_count=len(included_ids),
        max_chars=max_chars,
        truncated=len(included_ids) < len(selected),
        direct_pdf_requested=direct_pdf_requested,
    )


def build_kb1_addendum_prompt(
    *,
    architect_prompt: str,
    kb1_context: str,
    language: str,
) -> tuple[list[dict[str, str]], str]:
    user = (
        "KB1_FULL_CONTEXT_IN_DOCUMENT_ORDER:\n"
        f"{kb1_context}\n\n"
        "OUTPUT_LANGUAGE:\n"
        f"{language_instruction(language)}\n\n"
        "TASK:\n"
        "Extract a concise institution-specific requirements addendum. It supplements, but must not replace, "
        "the canonical AutoGenBook reviewer rubric and output format. Cover every requirement that is actually "
        "present in the supplied context, preserve cite_key values, and state limitations explicitly. Output only "
        "the addendum, without a new role definition.\n"
    )
    return [
        {"role": "system", "content": architect_prompt},
        {"role": "user", "content": user},
    ], user


def compose_reviewer_system_prompt(
    *,
    base_prompt: str,
    profile: str,
    kb1_addendum: str,
    language: str,
) -> str:
    profile = profile if profile in REVIEWER_PROFILES else DEFAULT_REVIEWER_PROFILE
    language_rule = language_instruction(language)
    if profile == "direct":
        # Byte-preserving standalone parity: language, evidence and KB1 are supplied
        # in the user message so the canonical system prompt itself is unchanged.
        return base_prompt.strip()
    if profile == "compliance":
        return (
            f"{kb1_addendum.strip()}\n\n"
            "---\nRUNTIME LANGUAGE REQUIREMENT\n"
            f"{language_rule}\n"
        ).strip()
    addendum = kb1_addendum.strip()
    blocks = [base_prompt.strip()]
    blocks.append(
        "RUNTIME PARITY GUARD:\n"
        "The preceding canonical AutoGenBook reviewer contract and its output rubric remain authoritative. "
        "Institution-specific KB1 rules below supplement formal-compliance checks; they must not erase the "
        "content-quality, methodology, originality, innovation, contribution, evidence, or actionable-feedback "
        "parts required by the canonical contract. When KB1 is silent, do not invent a formal requirement."
    )
    if addendum:
        blocks.append("INSTITUTION-SPECIFIC KB1 ADDENDUM:\n" + addendum)
    blocks.append("RUNTIME LANGUAGE REQUIREMENT:\n" + language_rule)
    return "\n\n---\n\n".join(blocks).strip()


def compose_reviewer_user_prompt(
    *,
    canonical_task: str,
    user_instructions: str,
    language: str,
    kb2_pack: ReviewerEvidencePack,
    kb1_context: str,
) -> str:
    instructions = clean_user_instructions(user_instructions) or default_reviewer_instruction(language)
    return (
        f"{canonical_task.strip()}\n\n"
        "---\nUSER REVIEW INSTRUCTIONS (preserve unless they conflict with evidence/truthfulness):\n"
        f"{instructions}\n\n"
        "OUTPUT LANGUAGE:\n"
        f"{language_instruction(language)}\n\n"
        "KB2 EVIDENCE PACK (criterion-aware and document-stratified):\n"
        f"{kb2_pack.context}\n\n"
        "KB1 FULL CONTEXT (institution-specific formal requirements):\n"
        f"{kb1_context}\n\n"
        "EVIDENCE RULES:\n"
        "- Assess the whole work represented by the evidence pack, not only one retrieved fragment.\n"
        "- Cite or identify concrete KB2 evidence for each score/finding.\n"
        "- Distinguish missing evidence from a negative finding.\n"
        "- Do not let procedural KB1 requirements replace the academic-quality rubric.\n"
        "- Do not invent facts, pages, quotations, sources, or requirements.\n"
    ).strip()


@dataclass
class ReviewQualityResult:
    passed: bool
    defects: list[str] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, "defects": self.defects, "metrics": self.metrics}


def _looks_czech(text: str) -> tuple[bool, float]:
    normalized = " " + re.sub(r"\s+", " ", text.casefold()) + " "
    marker_hits = sum(normalized.count(marker) for marker in _CZECH_MARKERS)
    diacritics = sum(ch in "áčďéěíňóřšťúůýž" for ch in normalized)
    score = marker_hits + min(diacritics / 20.0, 10.0)
    return score >= 4.0, score


def validate_review_output(
    text: str,
    *,
    language: str,
    require_default_table: bool,
) -> ReviewQualityResult:
    value = str(text or "").strip()
    defects: list[str] = []
    metrics: dict[str, Any] = {
        "chars": len(value),
        "words": len(value.split()),
        "table_rows": sum(1 for line in value.splitlines() if line.strip().startswith("|")),
    }
    if len(value) < 1800:
        defects.append("Výstup je příliš krátký pro úplný odborný posudek.")
    if re.search(r"\{[^{}]{2,80}\}|\[[A-Z_ ]*(?:TODO|FILL|PLACEHOLDER)[A-Z_ ]*\]", value, re.I):
        defects.append("Výstup obsahuje nevyplněný placeholder.")
    normalized_language = str(language or "").casefold()
    if normalized_language.startswith("cs") or normalized_language in {"cz", "czech", "čeština", "česky"}:
        czech, score = _looks_czech(value)
        metrics["czech_score"] = score
        if not czech:
            defects.append("Výstup není převážně v požadované češtině.")
    if require_default_table:
        if metrics["table_rows"] < 7:
            defects.append("Chybí úplná markdownová hodnoticí tabulka.")
        marks = re.findall(r"(?<!\d)([0-9])(?:\s*/\s*9)?(?!\d)", value)
        metrics["mark_count"] = len(marks)
        if len(marks) < 5:
            defects.append("Výstup neobsahuje dostatek hodnocení na škále 0–9.")
        criterion_terms = (
            ("cíl", "objective"),
            ("analý", "analysis"),
            ("řešen", "solution"),
            ("struktur", "form"),
            ("původ", "original"),
            ("inovac", "innovation"),
            ("přínos", "contribution"),
        )
        lower = value.casefold()
        covered = sum(1 for alternatives in criterion_terms if any(term in lower for term in alternatives))
        metrics["canonical_criteria_covered"] = covered
        if covered < 6:
            defects.append("Výstup nepokrývá většinu kanonických reviewer kritérií AutoGenBooku.")
    return ReviewQualityResult(passed=not defects, defects=defects, metrics=metrics)


def build_review_repair_messages(
    *,
    system_prompt: str,
    user_prompt: str,
    previous_output: str,
    quality: ReviewQualityResult,
) -> list[dict[str, str]]:
    defects = "\n".join(f"- {item}" for item in quality.defects)
    repair = (
        f"{user_prompt}\n\n"
        "---\nQUALITY-GATE REVISION REQUIRED:\n"
        f"{defects}\n\n"
        "Previous draft:\n"
        "```markdown\n"
        f"{previous_output.strip()}\n"
        "```\n\n"
        "Rewrite the complete final answer. Preserve all well-grounded findings, fix every listed defect, "
        "use only the supplied KB1/KB2 evidence, and return only the final review."
    )
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": repair},
    ]


def write_parity_manifest(
    path: Path,
    *,
    profile: str,
    language: str,
    model: str | None,
    user_instructions: str,
    base_prompt: str,
    canonical_task: str,
    system_prompt: str,
    user_prompt: str,
    kb1_context: str,
    kb1_ids: Sequence[str],
    kb1_truncated: bool,
    kb2_pack: ReviewerEvidencePack,
    quality: ReviewQualityResult | None = None,
    repair_attempted: bool = False,
) -> None:
    payload = {
        "schema_version": 1,
        "profile": profile,
        "language": language,
        "model": model,
        "user_instructions": clean_user_instructions(user_instructions),
        "hashes": {
            "base_prompt_sha256": sha256_text(base_prompt),
            "canonical_task_sha256": sha256_text(canonical_task),
            "system_prompt_sha256": sha256_text(system_prompt),
            "user_prompt_sha256": sha256_text(user_prompt),
            "kb1_context_sha256": sha256_text(kb1_context),
            "user_instructions_sha256": sha256_text(clean_user_instructions(user_instructions)),
        },
        "kb1": {
            "selected_ids": list(kb1_ids),
            "selected_count": len(kb1_ids),
            "truncated": bool(kb1_truncated),
        },
        "kb2": kb2_pack.to_dict(),
        "quality_gate": quality.to_dict() if quality else None,
        "repair_attempted": bool(repair_attempted),
        "parity_statement": (
            "The standalone CLI and Open WebUI Companion execute the same reviewer pipeline and prompt pack. "
            "Equivalent semantic output additionally requires the same underlying model/revision and generation parameters."
        ),
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
