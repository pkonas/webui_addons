# AutoGenBook Companion

Authenticated local FastAPI service used by the Open WebUI AutoGenBook Pipe. It manages projects, uploads, durable SQLite jobs, isolated worker processes, cancellation/resume and artifact downloads.
