"""AutoGenBook Companion service for Open WebUI."""

from .version import __version__

__all__ = ["__version__"]
