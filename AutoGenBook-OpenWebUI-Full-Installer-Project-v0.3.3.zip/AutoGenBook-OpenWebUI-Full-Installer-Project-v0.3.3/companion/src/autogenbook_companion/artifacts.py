from __future__ import annotations

import json
import mimetypes
import shutil
import time
import zipfile
from pathlib import Path
from typing import Any

from .database import Database
from .models import ArtifactRole
from .security import safe_filename, sha256_file
from .version import PROTOCOL_VERSION, __version__

_PRIMARY_EXTENSIONS = {".docx", ".pdf", ".pptx", ".md", ".tex", ".mp4"}
_SKIP_PARTS = {".kb_cache", ".validated_kb1", "__pycache__", ".git", ".venv"}
_MAX_BUNDLED_WORKER_LOG_BYTES = 64 * 1024 * 1024
_WORKER_LOG_TAIL_BYTES = 8 * 1024 * 1024


def infer_role(path: Path) -> ArtifactRole:
    name = path.name.lower()
    if name.endswith("_complete.zip") or name == "complete_bundle.zip":
        return ArtifactRole.bundle
    if path.suffix.lower() in _PRIMARY_EXTENSIONS and not any(
        token in name for token in ("section", "slide_", "structure_graph", "audit_report", "run_meta")
    ):
        return ArtifactRole.primary
    if any(
        token in name
        for token in (
            "log",
            "audit",
            "diagnostic",
            "failure",
            "progress",
            "request",
            "quality",
            "run_meta",
            "structure_graph",
            "usage",
        )
    ):
        return ArtifactRole.diagnostic
    return ArtifactRole.support


class ArtifactCollector:
    def __init__(self, database: Database, max_hash_bytes: int = 64 * 1024 * 1024) -> None:
        self.database = database
        self.max_hash_bytes = max(0, int(max_hash_bytes))

    @staticmethod
    def _include(path: Path, out_dir: Path) -> bool:
        relative = path.relative_to(out_dir)
        if any(part in _SKIP_PARTS for part in relative.parts):
            return False
        if path.name.startswith(".") and path.name not in {".gitkeep"}:
            return False
        return path.is_file()

    @staticmethod
    def _copy_file(source: Path, target: Path) -> dict[str, Any] | None:
        if not source.exists() or not source.is_file():
            return None
        target.parent.mkdir(parents=True, exist_ok=True)
        size = source.stat().st_size
        if source.name.casefold() == "worker.log" and size > _MAX_BUNDLED_WORKER_LOG_BYTES:
            with source.open("rb") as stream:
                stream.seek(max(0, size - _WORKER_LOG_TAIL_BYTES))
                payload = stream.read()
            target.write_bytes(payload)
            return {
                "source": str(source),
                "path": str(target),
                "original_size": size,
                "bundled_size": len(payload),
                "truncated": True,
                "tail_bytes": _WORKER_LOG_TAIL_BYTES,
            }
        shutil.copy2(source, target)
        return {
            "source": str(source),
            "path": str(target),
            "original_size": size,
            "bundled_size": size,
            "truncated": False,
        }

    def _stage_runtime_diagnostics(
        self,
        *,
        job_id: str,
        owner_id: str,
        out_dir: Path,
        job_root: Path | None,
    ) -> dict[str, Any]:
        metadata_dir = out_dir / "_autogenbook_companion"
        diagnostics_dir = metadata_dir / "diagnostics"
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        copied: list[dict[str, Any]] = []
        if job_root is not None:
            candidates = (
                (job_root / "logs" / "worker.log", diagnostics_dir / "worker.log"),
                (job_root / "request.json", diagnostics_dir / "request.json"),
                (job_root / ".autogenbook-progress.json", diagnostics_dir / "progress.json"),
            )
            for source, target in candidates:
                row = self._copy_file(source, target)
                if row:
                    copied.append(row)

        job = self.database.get_job_unscoped(job_id) or {}
        safe_job = {
            key: job.get(key)
            for key in (
                "id",
                "owner_id",
                "project_id",
                "status",
                "exit_code",
                "error",
                "pid",
                "resume",
                "created_at",
                "started_at",
                "finished_at",
                "out_dir",
            )
            if key in job
        }
        status_path = diagnostics_dir / "job_status.json"
        status_path.write_text(
            json.dumps(safe_job, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        copied.append(
            {
                "source": "database",
                "path": str(status_path),
                "original_size": status_path.stat().st_size,
                "bundled_size": status_path.stat().st_size,
                "truncated": False,
            }
        )
        return {
            "copied": copied,
            "job": safe_job,
        }

    def _write_bundle_manifest(self, out_dir: Path, job_id: str) -> Path:
        rows: list[dict[str, Any]] = []
        for path in sorted(out_dir.rglob("*")):
            if not self._include(path, out_dir):
                continue
            if path.name.endswith("_complete.zip"):
                continue
            rows.append(
                {
                    "path": path.relative_to(out_dir).as_posix(),
                    "size": path.stat().st_size,
                    "role": infer_role(path).value,
                }
            )
        path = out_dir / "_autogenbook_companion" / "bundle_manifest.json"
        path.write_text(
            json.dumps(
                {
                    "job_id": job_id,
                    "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "files": rows,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def _create_bundle(self, out_dir: Path, job_id: str) -> Path:
        bundle = out_dir / f"autogenbook_{job_id[:8]}_complete.zip"
        with zipfile.ZipFile(
            bundle,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
            allowZip64=True,
        ) as archive:
            for path in sorted(out_dir.rglob("*")):
                if path == bundle or not self._include(path, out_dir):
                    continue
                archive.write(path, path.relative_to(out_dir).as_posix())
        return bundle

    def collect(
        self,
        *,
        job_id: str,
        owner_id: str,
        out_dir: Path,
        job_root: Path | None = None,
    ) -> list[dict[str, Any]]:
        self.database.clear_artifacts(job_id)
        metadata_dir = out_dir / "_autogenbook_companion"
        metadata_dir.mkdir(parents=True, exist_ok=True)
        diagnostics = self._stage_runtime_diagnostics(
            job_id=job_id,
            owner_id=owner_id,
            out_dir=out_dir,
            job_root=job_root,
        )
        job = diagnostics.get("job") or {}
        (metadata_dir / "companion_manifest.json").write_text(
            json.dumps(
                {
                    "job_id": job_id,
                    "owner_id": owner_id,
                    "companion_version": __version__,
                    "protocol_version": PROTOCOL_VERSION,
                    "status": job.get("status"),
                    "exit_code": job.get("exit_code"),
                    "error": job.get("error"),
                    "diagnostics": diagnostics.get("copied") or [],
                    "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "note": "Generated by AutoGenBook Companion. Secrets are never included.",
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        self._write_bundle_manifest(out_dir, job_id)
        self._create_bundle(out_dir, job_id)

        rows: list[dict[str, Any]] = []
        for path in sorted(out_dir.rglob("*")):
            if not self._include(path, out_dir):
                continue
            size = path.stat().st_size
            digest = ""
            if size <= self.max_hash_bytes:
                digest = sha256_file(path)
            else:
                self.database.add_event(
                    job_id,
                    owner_id,
                    "info",
                    {
                        "code": "ARTIFACT_HASH_DEFERRED",
                        "message": f"Hash velkého souboru {path.name} byl odložen, aby neblokoval dokončení úlohy.",
                        "size": size,
                    },
                )
            mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            rows.append(
                self.database.add_artifact(
                    job_id=job_id,
                    owner_id=owner_id,
                    filename=safe_filename(path.name),
                    path=str(path.resolve()),
                    mime=mime,
                    size=size,
                    sha256=digest,
                    role=infer_role(path).value,
                )
            )

        (metadata_dir / "artifacts.json").write_text(
            json.dumps(
                {
                    "job_id": job_id,
                    "artifacts": [
                        {
                            "id": item["id"],
                            "filename": item["filename"],
                            "mime": item["mime"],
                            "size": item["size"],
                            "sha256": item["sha256"],
                            "role": item["role"],
                        }
                        for item in rows
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return rows
