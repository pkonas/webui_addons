from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

import uvicorn

from .config import Settings
from .service import create_app
from .version import PROTOCOL_VERSION, __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="autogenbook-companion")
    parser.add_argument("command", nargs="?", choices=["serve", "doctor"], default="serve")
    parser.add_argument("--home", default=None)
    parser.add_argument("--source-dir", default=None)
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--log-level", default="info")
    return parser


def doctor(settings: Settings) -> int:
    settings.ensure_layout()
    payload = {
        "protocol_version": PROTOCOL_VERSION,
        "companion_version": __version__,
        "python": sys.executable,
        "python_version": sys.version,
        "home": str(settings.home),
        "source_dir": str(settings.source_dir),
        "source_available": (settings.source_dir / "main.py").exists(),
        "database": str(settings.database_path),
        "converters": {
            "pandoc": shutil.which("pandoc"),
            "lualatex": shutil.which("lualatex"),
            "ffmpeg": shutil.which("ffmpeg"),
        },
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["source_available"] else 2


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.from_env(home=args.home, source_dir=args.source_dir, host=args.host, port=args.port)
    if args.command == "doctor":
        return doctor(settings)
    settings.get_or_create_token()
    settings.write_bridge(pid=os.getpid())
    app = create_app(settings)
    uvicorn.run(app, host=settings.host, port=settings.port, log_level=args.log_level, access_log=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
