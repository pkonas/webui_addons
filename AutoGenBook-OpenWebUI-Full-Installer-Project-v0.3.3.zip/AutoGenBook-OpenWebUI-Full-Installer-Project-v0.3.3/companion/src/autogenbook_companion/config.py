from __future__ import annotations

import json
import os
import secrets
import socket
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .version import PROTOCOL_VERSION, __version__


def default_home() -> Path:
    override = os.environ.get("AUTOGENBOOK_COMPANION_HOME")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "AutoGenBook-OpenWebUI" / "data"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "AutoGenBook-OpenWebUI" / "data"
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / "autogenbook-openwebui" / "data"


def default_source_dir() -> Path:
    override = os.environ.get("AUTOGENBOOK_SOURCE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    # Installed layout: <install-root>/runtime/python/... and <install-root>/app.
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "app" / "main.py"
        if candidate.exists():
            return candidate.parent
    cwd = Path.cwd().resolve()
    if (cwd / "main.py").exists():
        return cwd
    return cwd


def find_free_port(host: str = "127.0.0.1", preferred: int = 8765) -> int:
    # Port 0 asks the operating system for an ephemeral port. Returning the
    # literal 0 would make the bridge unusable because clients would not know
    # which port Uvicorn selected. Resolve it before the bridge is written.
    if preferred <= 0:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, 0))
            return int(sock.getsockname()[1])
    for port in range(preferred, preferred + 100):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind((host, 0))
        return int(sock.getsockname()[1])


@dataclass
class Settings:
    home: Path
    source_dir: Path
    host: str = "127.0.0.1"
    port: int = 8765
    concurrency: int = 1
    max_upload_bytes: int = 512 * 1024 * 1024
    max_artifact_bytes: int = 2 * 1024 * 1024 * 1024
    max_hash_bytes: int = 64 * 1024 * 1024
    download_url_ttl_seconds: int = 24 * 60 * 60
    api_token_file: Path | None = None
    download_signing_key_file: Path | None = None
    bridge_file: Path | None = None

    @classmethod
    def from_env(
        cls,
        *,
        home: str | Path | None = None,
        source_dir: str | Path | None = None,
        host: str | None = None,
        port: int | None = None,
    ) -> "Settings":
        resolved_home = Path(home).expanduser().resolve() if home else default_home()
        resolved_source = Path(source_dir).expanduser().resolve() if source_dir else default_source_dir()
        resolved_host = host or os.environ.get("AUTOGENBOOK_COMPANION_HOST", "127.0.0.1")
        raw_port = port if port is not None else int(os.environ.get("AUTOGENBOOK_COMPANION_PORT", "8765"))
        resolved_port = find_free_port(resolved_host, raw_port) if raw_port == 0 else raw_port
        token_file = Path(
            os.environ.get("AUTOGENBOOK_COMPANION_TOKEN_FILE", resolved_home / "secrets" / "api-token")
        ).expanduser().resolve()
        signing_key_file = Path(
            os.environ.get(
                "AUTOGENBOOK_COMPANION_DOWNLOAD_SIGNING_KEY_FILE",
                resolved_home / "secrets" / "download-signing-key",
            )
        ).expanduser().resolve()
        bridge_file = Path(
            os.environ.get("AUTOGENBOOK_COMPANION_BRIDGE_FILE", resolved_home / "bridge.json")
        ).expanduser().resolve()
        return cls(
            home=resolved_home,
            source_dir=resolved_source,
            host=resolved_host,
            port=resolved_port,
            concurrency=max(1, int(os.environ.get("AUTOGENBOOK_COMPANION_CONCURRENCY", "1"))),
            max_upload_bytes=max(
                1024 * 1024,
                int(os.environ.get("AUTOGENBOOK_COMPANION_MAX_UPLOAD_BYTES", str(512 * 1024 * 1024))),
            ),
            max_artifact_bytes=max(
                1024 * 1024,
                int(os.environ.get("AUTOGENBOOK_COMPANION_MAX_ARTIFACT_BYTES", str(2 * 1024 * 1024 * 1024))),
            ),
            max_hash_bytes=max(
                0,
                int(os.environ.get("AUTOGENBOOK_COMPANION_MAX_HASH_BYTES", str(64 * 1024 * 1024))),
            ),
            download_url_ttl_seconds=max(
                60,
                int(os.environ.get("AUTOGENBOOK_COMPANION_DOWNLOAD_URL_TTL_SECONDS", str(24 * 60 * 60))),
            ),
            api_token_file=token_file,
            download_signing_key_file=signing_key_file,
            bridge_file=bridge_file,
        )

    @property
    def database_path(self) -> Path:
        return self.home / "jobs.sqlite3"

    @property
    def projects_dir(self) -> Path:
        return self.home / "projects"

    @property
    def logs_dir(self) -> Path:
        return self.home / "logs"

    @property
    def secrets_dir(self) -> Path:
        return self.home / "secrets"

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def ensure_layout(self) -> None:
        for path in (self.home, self.projects_dir, self.logs_dir, self.secrets_dir):
            path.mkdir(parents=True, exist_ok=True)
        if self.api_token_file is None:
            self.api_token_file = self.secrets_dir / "api-token"
        if self.download_signing_key_file is None:
            self.download_signing_key_file = self.secrets_dir / "download-signing-key"
        if self.bridge_file is None:
            self.bridge_file = self.home / "bridge.json"

    def get_or_create_token(self) -> str:
        self.ensure_layout()
        assert self.api_token_file is not None
        env_token = os.environ.get("AUTOGENBOOK_COMPANION_API_TOKEN", "").strip()
        if env_token:
            return env_token
        if self.api_token_file.exists():
            token = self.api_token_file.read_text(encoding="utf-8").strip()
            if token:
                return token
        token = secrets.token_urlsafe(48)
        self.api_token_file.write_text(token + "\n", encoding="utf-8")
        try:
            os.chmod(self.api_token_file, 0o600)
        except OSError:
            pass
        return token

    def get_or_create_download_signing_key(self) -> str:
        """Return a stable key used only for short-lived browser download links.

        The key is intentionally separate from the Companion bearer token. Rotating or
        recreating the bearer token therefore cannot invalidate otherwise unexpired
        download links. Open WebUI responses use durable Open WebUI file IDs instead;
        these signed links remain a temporary API fallback only.
        """

        self.ensure_layout()
        assert self.download_signing_key_file is not None
        env_key = os.environ.get("AUTOGENBOOK_COMPANION_DOWNLOAD_SIGNING_KEY", "").strip()
        if env_key:
            return env_key
        if self.download_signing_key_file.exists():
            key = self.download_signing_key_file.read_text(encoding="utf-8").strip()
            if key:
                return key
        key = secrets.token_urlsafe(64)
        tmp = self.download_signing_key_file.with_suffix(".tmp")
        tmp.write_text(key + "\n", encoding="utf-8")
        tmp.replace(self.download_signing_key_file)
        try:
            os.chmod(self.download_signing_key_file, 0o600)
        except OSError:
            pass
        return key

    def write_bridge(self, *, pid: int, python_executable: str | None = None) -> dict[str, Any]:
        self.ensure_layout()
        assert self.api_token_file is not None and self.bridge_file is not None
        python_path = python_executable or sys.executable
        payload: dict[str, Any] = {
            "protocol_version": PROTOCOL_VERSION,
            "companion_version": __version__,
            "url": self.url,
            "pid": int(pid),
            "home": str(self.home),
            "source_dir": str(self.source_dir),
            "token_file": str(self.api_token_file),
            "python": python_path,
            "start_command": [
                python_path,
                "-m",
                "autogenbook_companion.cli",
                "serve",
                "--home",
                str(self.home),
                "--source-dir",
                str(self.source_dir),
                "--host",
                self.host,
                "--port",
                "0",
            ],
            "log_file": str(self.logs_dir / "companion.log"),
        }
        tmp = self.bridge_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.bridge_file)
        try:
            os.chmod(self.bridge_file, 0o600)
        except OSError:
            pass
        return payload
