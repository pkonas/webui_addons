from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Iterable

from .models import JobStatus, Mode, ProjectSpec


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    def init(self) -> None:
        schema = """
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            owner_id TEXT NOT NULL,
            status TEXT NOT NULL,
            spec_json TEXT NOT NULL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner_id, updated_at DESC);

        CREATE TABLE IF NOT EXISTS files (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            owner_id TEXT NOT NULL,
            role TEXT NOT NULL,
            filename TEXT NOT NULL,
            stored_path TEXT NOT NULL,
            size INTEGER NOT NULL,
            sha256 TEXT NOT NULL,
            created_at REAL NOT NULL,
            FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_files_project ON files(project_id, owner_id);

        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            owner_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            idempotency_key TEXT NOT NULL,
            status TEXT NOT NULL,
            mode TEXT NOT NULL,
            out_dir TEXT,
            pid INTEGER,
            exit_code INTEGER,
            error TEXT,
            cancel_requested INTEGER NOT NULL DEFAULT 0,
            resume INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL,
            started_at REAL,
            finished_at REAL,
            UNIQUE(owner_id, idempotency_key),
            FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at);

        CREATE TABLE IF NOT EXISTS events (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id TEXT NOT NULL,
            owner_id TEXT NOT NULL,
            timestamp REAL NOT NULL,
            type TEXT NOT NULL,
            data_json TEXT NOT NULL,
            FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_events_job ON events(job_id, seq);

        CREATE TABLE IF NOT EXISTS artifacts (
            id TEXT PRIMARY KEY,
            job_id TEXT NOT NULL,
            owner_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            mime TEXT NOT NULL,
            size INTEGER NOT NULL,
            sha256 TEXT NOT NULL,
            role TEXT NOT NULL,
            created_at REAL NOT NULL,
            FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_artifacts_job ON artifacts(job_id, owner_id);
        """
        with self._lock, self._connect() as connection:
            connection.executescript(schema)

    @staticmethod
    def _row(row: sqlite3.Row | None) -> dict[str, Any] | None:
        return dict(row) if row is not None else None

    def create_project(self, owner_id: str, spec: ProjectSpec) -> dict[str, Any]:
        project_id = str(uuid.uuid4())
        now = time.time()
        with self._lock, self._connect() as connection:
            connection.execute(
                "INSERT INTO projects(id, owner_id, status, spec_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                (project_id, owner_id, "DRAFT", spec.model_dump_json(), now, now),
            )
        return self.get_project(project_id, owner_id)  # type: ignore[return-value]

    def get_project(self, project_id: str, owner_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM projects WHERE id=? AND owner_id=?", (project_id, owner_id)
            ).fetchone()
        result = self._row(row)
        if result:
            result["spec"] = json.loads(result.pop("spec_json"))
        return result

    def update_project(self, project_id: str, owner_id: str, spec: ProjectSpec, status: str = "DRAFT") -> dict[str, Any] | None:
        with self._lock, self._connect() as connection:
            connection.execute(
                "UPDATE projects SET spec_json=?, status=?, updated_at=? WHERE id=? AND owner_id=?",
                (spec.model_dump_json(), status, time.time(), project_id, owner_id),
            )
        return self.get_project(project_id, owner_id)

    def set_project_status(self, project_id: str, owner_id: str, status: str) -> None:
        with self._lock, self._connect() as connection:
            connection.execute(
                "UPDATE projects SET status=?, updated_at=? WHERE id=? AND owner_id=?",
                (status, time.time(), project_id, owner_id),
            )

    def add_file(
        self,
        *,
        project_id: str,
        owner_id: str,
        role: str,
        filename: str,
        stored_path: str,
        size: int,
        sha256: str,
    ) -> dict[str, Any]:
        file_id = str(uuid.uuid4())
        now = time.time()
        with self._lock, self._connect() as connection:
            connection.execute(
                "INSERT INTO files(id, project_id, owner_id, role, filename, stored_path, size, sha256, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (file_id, project_id, owner_id, role, filename, stored_path, size, sha256, now),
            )
        return self.get_file(file_id, owner_id)  # type: ignore[return-value]

    def get_file(self, file_id: str, owner_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            return self._row(
                connection.execute("SELECT * FROM files WHERE id=? AND owner_id=?", (file_id, owner_id)).fetchone()
            )

    def list_files(self, project_id: str, owner_id: str) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM files WHERE project_id=? AND owner_id=? ORDER BY created_at", (project_id, owner_id)
            ).fetchall()
        return [dict(row) for row in rows]

    def create_job(
        self,
        *,
        owner_id: str,
        project_id: str,
        idempotency_key: str,
        mode: Mode,
        resume: bool,
    ) -> tuple[dict[str, Any], bool]:
        with self._lock, self._connect() as connection:
            existing = connection.execute(
                "SELECT * FROM jobs WHERE owner_id=? AND idempotency_key=?",
                (owner_id, idempotency_key),
            ).fetchone()
            if existing:
                return dict(existing), False
            job_id = str(uuid.uuid4())
            now = time.time()
            connection.execute(
                "INSERT INTO jobs(id, owner_id, project_id, idempotency_key, status, mode, cancel_requested, resume, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)",
                (job_id, owner_id, project_id, idempotency_key, JobStatus.queued.value, mode.value, int(resume), now),
            )
            row = connection.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            return dict(row), True

    def get_job(self, job_id: str, owner_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            return self._row(
                connection.execute("SELECT * FROM jobs WHERE id=? AND owner_id=?", (job_id, owner_id)).fetchone()
            )

    def get_job_unscoped(self, job_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            return self._row(connection.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    def list_jobs_by_status(self, statuses: Iterable[JobStatus]) -> list[dict[str, Any]]:
        values = [status.value for status in statuses]
        if not values:
            return []
        placeholders = ",".join("?" for _ in values)
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM jobs WHERE status IN ({placeholders}) ORDER BY created_at", values
            ).fetchall()
        return [dict(row) for row in rows]

    def list_jobs(self, owner_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM jobs WHERE owner_id=? ORDER BY created_at DESC LIMIT ?", (owner_id, limit)
            ).fetchall()
        return [dict(row) for row in rows]

    def update_job(self, job_id: str, **fields: Any) -> None:
        allowed = {
            "status",
            "out_dir",
            "pid",
            "exit_code",
            "error",
            "cancel_requested",
            "resume",
            "started_at",
            "finished_at",
        }
        clean = {key: value for key, value in fields.items() if key in allowed}
        if not clean:
            return
        assignments = ", ".join(f"{key}=?" for key in clean)
        values = list(clean.values()) + [job_id]
        with self._lock, self._connect() as connection:
            connection.execute(f"UPDATE jobs SET {assignments} WHERE id=?", values)

    def request_cancel(self, job_id: str, owner_id: str) -> bool:
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                "UPDATE jobs SET cancel_requested=1 WHERE id=? AND owner_id=?", (job_id, owner_id)
            )
            return cursor.rowcount > 0

    def requeue_job(self, job_id: str, owner_id: str) -> bool:
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                "UPDATE jobs SET status=?, cancel_requested=0, error=NULL, exit_code=NULL, pid=NULL, finished_at=NULL, resume=1 WHERE id=? AND owner_id=?",
                (JobStatus.queued.value, job_id, owner_id),
            )
            return cursor.rowcount > 0

    def recover_after_restart(self) -> list[str]:
        with self._lock, self._connect() as connection:
            connection.execute(
                "UPDATE jobs SET status=?, pid=NULL, error=COALESCE(error, 'Companion restarted while the worker was active.'), finished_at=? WHERE status IN (?, ?)",
                (
                    JobStatus.interrupted.value,
                    time.time(),
                    JobStatus.running.value,
                    JobStatus.waiting_for_user.value,
                ),
            )
            rows = connection.execute(
                "SELECT id FROM jobs WHERE status=? ORDER BY created_at", (JobStatus.queued.value,)
            ).fetchall()
        return [str(row["id"]) for row in rows]

    def add_event(self, job_id: str, owner_id: str, event_type: str, data: dict[str, Any]) -> int:
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO events(job_id, owner_id, timestamp, type, data_json) VALUES (?, ?, ?, ?, ?)",
                (job_id, owner_id, time.time(), event_type, json.dumps(data, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def list_events(self, job_id: str, owner_id: str, after: int = 0, limit: int = 500) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM events WHERE job_id=? AND owner_id=? AND seq>? ORDER BY seq LIMIT ?",
                (job_id, owner_id, after, limit),
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["data"] = json.loads(item.pop("data_json"))
            result.append(item)
        return result

    def clear_artifacts(self, job_id: str) -> None:
        with self._lock, self._connect() as connection:
            connection.execute("DELETE FROM artifacts WHERE job_id=?", (job_id,))

    def add_artifact(
        self,
        *,
        job_id: str,
        owner_id: str,
        filename: str,
        path: str,
        mime: str,
        size: int,
        sha256: str,
        role: str,
    ) -> dict[str, Any]:
        artifact_id = str(uuid.uuid4())
        now = time.time()
        with self._lock, self._connect() as connection:
            connection.execute(
                "INSERT INTO artifacts(id, job_id, owner_id, filename, path, mime, size, sha256, role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (artifact_id, job_id, owner_id, filename, path, mime, size, sha256, role, now),
            )
            row = connection.execute("SELECT * FROM artifacts WHERE id=?", (artifact_id,)).fetchone()
        return dict(row)

    def get_artifact(self, artifact_id: str, owner_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            return self._row(
                connection.execute(
                    "SELECT * FROM artifacts WHERE id=? AND owner_id=?", (artifact_id, owner_id)
                ).fetchone()
            )

    def list_artifacts(self, job_id: str, owner_id: str) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM artifacts WHERE job_id=? AND owner_id=? ORDER BY CASE role WHEN 'primary' THEN 0 WHEN 'bundle' THEN 1 ELSE 2 END, filename",
                (job_id, owner_id),
            ).fetchall()
        return [dict(row) for row in rows]
