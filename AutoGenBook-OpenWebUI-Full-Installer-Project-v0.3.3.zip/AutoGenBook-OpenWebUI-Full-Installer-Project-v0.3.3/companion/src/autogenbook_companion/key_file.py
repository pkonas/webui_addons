from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

MAX_API_KEY_FILE_BYTES = 64 * 1024
REFERENCE_CONFIG_FILENAME = "external-secret-sources.json"
_ALLOWED_ASSIGNMENT_NAMES = {
    "api_key",
    "openwebui_api_key",
    "open_webui_api_key",
    "webui_api_key",
    "token",
}
_JWT_SEGMENT_RE = re.compile(r"^[A-Za-z0-9_-]+$")


class ApiKeyFileError(ValueError):
    """Raised when an external API-key text file is missing, ambiguous or unsafe."""


@dataclass(frozen=True)
class ApiKeyFileValue:
    path: Path
    value: str
    size: int
    encoding: str


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def looks_like_session_token(value: str) -> bool:
    token = value.strip()
    parts = token.split(".")
    return (
        token.startswith("eyJ")
        and len(parts) == 3
        and all(part and _JWT_SEGMENT_RE.fullmatch(part) for part in parts)
    )


def _decode_text(payload: bytes) -> tuple[str, str]:
    if payload.startswith(b"\xff\xfe") or payload.startswith(b"\xfe\xff"):
        try:
            return payload.decode("utf-16"), "utf-16"
        except UnicodeDecodeError as exc:
            raise ApiKeyFileError("TXT soubor s API klíčem není platný UTF-16 text.") from exc
    try:
        return payload.decode("utf-8-sig"), "utf-8"
    except UnicodeDecodeError as exc:
        raise ApiKeyFileError("TXT soubor s API klíčem musí být uložen jako UTF-8 nebo UTF-16.") from exc


def _strip_wrapping_quotes(value: str) -> str:
    candidate = value.strip()
    if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in {"'", '"'}:
        candidate = candidate[1:-1].strip()
    return candidate


def _candidate_from_line(line: str) -> str | None:
    candidate = line.strip()
    if not candidate or candidate.startswith("#") or candidate.startswith(";"):
        return None

    if candidate.casefold().startswith("authorization:"):
        candidate = candidate.split(":", 1)[1].strip()
    elif "=" in candidate:
        name, value = candidate.split("=", 1)
        normalized_name = name.strip().casefold().replace("-", "_")
        if normalized_name in _ALLOWED_ASSIGNMENT_NAMES:
            candidate = value.strip()

    if candidate.casefold().startswith("bearer "):
        candidate = candidate[7:].strip()
    return _strip_wrapping_quotes(candidate)


def normalize_api_key_text(
    text: str,
    *,
    reject_session_token: bool = False,
) -> str:
    """Normalize one API-key value from plain text without accepting ambiguity.

    The same parser is used for an interactive installer value and for the
    referenced TXT file.  It accepts a bare key, ``Bearer KEY``, an
    ``Authorization: Bearer KEY`` line or a conventional assignment such as
    ``OPENWEBUI_API_KEY=KEY``.  Embedded whitespace and control characters are
    rejected before the value can reach an HTTP header.
    """

    candidates: list[str] = []
    for line in str(text).splitlines():
        candidate = _candidate_from_line(line)
        if candidate is not None:
            candidates.append(candidate)
    distinct = list(dict.fromkeys(candidates))
    if not distinct:
        raise ApiKeyFileError("Nebyl zadán žádný Open WebUI API klíč.")
    if len(distinct) != 1:
        raise ApiKeyFileError(
            "Bylo zadáno více různých neprázdných hodnot. Použijte právě jeden Open WebUI API klíč."
        )
    value = distinct[0].strip()
    if len(value) < 8 or len(value) > 10_000:
        raise ApiKeyFileError("Open WebUI API klíč má neplatnou délku.")
    if any(character.isspace() or ord(character) < 0x20 or ord(character) == 0x7F for character in value):
        raise ApiKeyFileError(
            "Open WebUI API klíč nesmí obsahovat mezery, zalomení řádku ani řídicí znaky."
        )
    if reject_session_token and looks_like_session_token(value):
        raise ApiKeyFileError(
            "Byl zadán browserový session/JWT token. Pro vícedenní úlohy použijte osobní Open WebUI API klíč."
        )
    return value


def read_api_key_file(
    path: str | Path,
    *,
    max_bytes: int = MAX_API_KEY_FILE_BYTES,
    require_txt_suffix: bool = False,
    reject_session_token: bool = False,
) -> ApiKeyFileValue:
    raw_path = Path(path).expanduser()
    try:
        resolved = raw_path.resolve(strict=True)
    except OSError as exc:
        raise ApiKeyFileError(f"TXT soubor s API klíčem neexistuje nebo není dostupný: {raw_path}") from exc
    if not resolved.is_file():
        raise ApiKeyFileError(f"Odkaz na API klíč neukazuje na běžný soubor: {resolved}")
    if require_txt_suffix and resolved.suffix.casefold() != ".txt":
        raise ApiKeyFileError("Soubor s Open WebUI API klíčem musí mít příponu .txt.")

    try:
        size = resolved.stat().st_size
    except OSError as exc:
        raise ApiKeyFileError(f"Nelze zjistit velikost TXT souboru s API klíčem: {resolved}") from exc
    if size <= 0:
        raise ApiKeyFileError("TXT soubor s API klíčem je prázdný.")
    if size > max_bytes:
        raise ApiKeyFileError(
            f"TXT soubor s API klíčem je příliš velký ({size} B; maximum je {max_bytes} B)."
        )

    try:
        payload = resolved.read_bytes()
    except OSError as exc:
        raise ApiKeyFileError(f"TXT soubor s API klíčem nelze přečíst: {resolved}") from exc
    if b"\x00" in payload and not (payload.startswith(b"\xff\xfe") or payload.startswith(b"\xfe\xff")):
        raise ApiKeyFileError("TXT soubor s API klíčem obsahuje binární data.")
    text, encoding = _decode_text(payload)

    try:
        value = normalize_api_key_text(text, reject_session_token=reject_session_token)
    except ApiKeyFileError as exc:
        raise ApiKeyFileError(f"TXT soubor s API klíčem je neplatný: {exc}") from exc
    return ApiKeyFileValue(path=resolved, value=value, size=size, encoding=encoding)


def key_file_permission_warnings(path: str | Path) -> list[str]:
    resolved = Path(path).expanduser().resolve()
    warnings: list[str] = []
    if os.name != "nt":
        try:
            mode = stat.S_IMODE(resolved.stat().st_mode)
        except OSError:
            return warnings
        if mode & 0o077:
            warnings.append(
                f"Soubor {resolved} je čitelný také skupinou nebo ostatními uživateli (mode {mode:o}); doporučeno je chmod 600."
            )
    return warnings


def reference_config_path(secret_root: str | Path) -> Path:
    return Path(secret_root).expanduser().resolve() / REFERENCE_CONFIG_FILENAME


def load_reference_config(secret_root: str | Path) -> dict[str, Any]:
    path = reference_config_path(secret_root)
    if not path.exists():
        return {"schema_version": 1, "sources": {}}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ApiKeyFileError(f"Konfigurace odkazů na tajné údaje je poškozená: {path}") from exc
    if not isinstance(payload, dict):
        raise ApiKeyFileError(f"Konfigurace odkazů na tajné údaje má neplatný formát: {path}")
    sources = payload.get("sources")
    if not isinstance(sources, dict):
        sources = {}
    return {"schema_version": 1, "sources": dict(sources)}


def write_reference_config(secret_root: str | Path, payload: dict[str, Any]) -> Path:
    root = Path(secret_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    path = reference_config_path(root)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    temporary.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def set_file_reference(
    secret_root: str | Path,
    name: str,
    source_path: str | Path,
    *,
    configured_by: str = "installer",
    priority: str = "stored_first",
) -> dict[str, Any]:
    resolved = Path(source_path).expanduser().resolve(strict=True)
    normalized_priority = str(priority).strip().casefold()
    if normalized_priority not in {"stored_first", "external_first"}:
        raise ApiKeyFileError(
            "Priorita odkazu na API klíč musí být stored_first nebo external_first."
        )
    payload = load_reference_config(secret_root)
    sources = dict(payload.get("sources") or {})
    sources[str(name)] = {
        "type": "text_file",
        "path": str(resolved),
        "configured_at": utc_now(),
        "configured_by": configured_by,
        "read_mode": "live",
        "priority": normalized_priority,
    }
    payload["sources"] = sources
    config_path = write_reference_config(secret_root, payload)
    return {
        "name": str(name),
        "path": str(resolved),
        "config_path": str(config_path),
        "read_mode": "live",
        "priority": normalized_priority,
    }


def clear_file_reference(secret_root: str | Path, name: str) -> bool:
    payload = load_reference_config(secret_root)
    sources = dict(payload.get("sources") or {})
    removed = sources.pop(str(name), None) is not None
    payload["sources"] = sources
    if removed or reference_config_path(secret_root).exists():
        write_reference_config(secret_root, payload)
    return removed


def get_file_reference(secret_root: str | Path, name: str) -> dict[str, Any] | None:
    payload = load_reference_config(secret_root)
    source = (payload.get("sources") or {}).get(str(name))
    if not isinstance(source, dict) or source.get("type") != "text_file" or not source.get("path"):
        return None
    return dict(source)
