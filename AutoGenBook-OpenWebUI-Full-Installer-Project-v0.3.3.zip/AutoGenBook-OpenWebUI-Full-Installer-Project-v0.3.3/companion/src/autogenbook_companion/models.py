from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Mode(str, Enum):
    book = "book"
    paper = "paper"
    presentation = "presentation"
    scientist = "scientist"
    proposal = "proposal"
    reviewer = "reviewer"


class JobStatus(str, Enum):
    draft = "DRAFT"
    validating = "VALIDATING"
    ready = "READY"
    queued = "QUEUED"
    running = "RUNNING"
    waiting_for_user = "WAITING_FOR_USER"
    succeeded = "SUCCEEDED"
    failed = "FAILED"
    cancelled = "CANCELLED"
    interrupted = "INTERRUPTED"

    @property
    def terminal(self) -> bool:
        return self in {
            JobStatus.succeeded,
            JobStatus.failed,
            JobStatus.cancelled,
            JobStatus.interrupted,
        }


class ArtifactRole(str, Enum):
    primary = "primary"
    support = "support"
    bundle = "bundle"
    diagnostic = "diagnostic"


class ProviderProfile(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["openrouter", "openai_compatible", "openwebui"] = "openrouter"
    base_url: str | None = "https://openrouter.ai/api/v1"
    model: str = "e-infra.glm-5"
    api_key_secret: str = "openrouter_api_key"
    role_models: dict[str, str] = Field(default_factory=dict)


class ProviderValidationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: ProviderProfile


class ProviderValidationResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", protected_namespaces=())

    valid: bool
    code: str
    message: str
    provider_type: str
    base_url: str | None = None
    model: str
    auth_kind: str = "unknown"
    http_status: int | None = None
    model_available: bool | None = None
    available_models: list[str] = Field(default_factory=list)
    retryable: bool = False
    credential_source: str = "missing"
    credential_fingerprint: str | None = None
    credential_reference_path: str | None = None


class ReviewerContext(BaseModel):
    """Minimum context required before searching for reviewer regulations."""

    model_config = ConfigDict(extra="forbid")

    jurisdiction: str = Field(min_length=2, max_length=160)
    institution: str = Field(min_length=2, max_length=240)
    faculty: str | None = Field(default=None, max_length=240)
    work_type: str = Field(min_length=2, max_length=160)
    programme: str | None = Field(default=None, max_length=240)
    language: str = Field(default="cs", min_length=2, max_length=16)

    @field_validator("jurisdiction", "institution", "work_type", "faculty", "programme", "language", mode="before")
    @classmethod
    def normalize_context_text(cls, value: Any) -> Any:
        if value is None:
            return None
        return " ".join(str(value).strip().split())


class ReviewerKb1DiscoveryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    context: ReviewerContext
    max_candidates: int = Field(default=5, ge=1, le=8)


class ReviewerKb1Candidate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str
    url: str
    source_name: str | None = None
    document_type: str | None = None
    reason: str | None = None
    official_likelihood: Literal["high", "medium", "unknown"] = "unknown"
    verified_http: bool = False
    quality_code: str | None = None
    quality_score: int | None = Field(default=None, ge=0, le=100)


class ReviewerKb1DiscoveryResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    query: str
    candidates: list[ReviewerKb1Candidate] = Field(default_factory=list)
    code: str = "OK"
    message: str = ""


class ReviewerKb1ImportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_type: Literal["url", "text"]
    value: str = Field(min_length=1, max_length=2_000_000)
    filename: str | None = Field(default=None, max_length=180)
    provenance: dict[str, Any] = Field(default_factory=dict)


class OutputOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")

    formats: list[str] = Field(default_factory=lambda: ["md", "docx", "pdf", "zip"])
    attach_primary_to_chat: bool = True

    @field_validator("formats")
    @classmethod
    def normalize_formats(cls, value: list[str]) -> list[str]:
        allowed = {"md", "docx", "tex", "pdf", "pptx", "json", "bib", "audio", "video", "zip"}
        result: list[str] = []
        for item in value:
            normalized = str(item).strip().lower().lstrip(".")
            if normalized not in allowed:
                raise ValueError(f"Unsupported output format: {item}")
            if normalized not in result:
                result.append(normalized)
        return result or ["md", "zip"]


class ProjectSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: Mode
    brief: str = ""
    title: str | None = None
    language: str = "cs"
    audience: str | None = None
    style: str | None = None
    length: int | None = Field(default=None, ge=1, le=5000)
    outputs: OutputOptions = Field(default_factory=OutputOptions)
    provider: ProviderProfile = Field(default_factory=ProviderProfile)
    options: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProjectCreate(BaseModel):
    spec: ProjectSpec


class ProjectPatch(BaseModel):
    spec: ProjectSpec


class ProjectView(BaseModel):
    id: str
    owner_id: str
    status: str
    spec: ProjectSpec
    created_at: float
    updated_at: float


class StoredFileView(BaseModel):
    id: str
    project_id: str
    role: Literal["input", "structure", "kb", "kb1", "kb2"]
    filename: str
    size: int
    sha256: str
    created_at: float


class ValidationIssue(BaseModel):
    severity: Literal["error", "warning", "info"]
    code: str
    message: str
    field: str | None = None


class ValidationResponse(BaseModel):
    valid: bool
    issues: list[ValidationIssue]
    normalized_spec: ProjectSpec


class JobCreate(BaseModel):
    project_id: str
    idempotency_key: str = Field(min_length=8, max_length=300)
    resume: bool = False


class JobView(BaseModel):
    id: str
    owner_id: str
    project_id: str
    idempotency_key: str
    status: JobStatus
    mode: Mode
    out_dir: str | None = None
    pid: int | None = None
    exit_code: int | None = None
    error: str | None = None
    cancel_requested: bool = False
    created_at: float
    started_at: float | None = None
    finished_at: float | None = None


class JobEvent(BaseModel):
    seq: int
    job_id: str
    timestamp: float
    type: str
    data: dict[str, Any]


class ArtifactView(BaseModel):
    id: str
    job_id: str
    filename: str
    mime: str
    size: int
    sha256: str
    role: ArtifactRole
    created_at: float
    download_url: str | None = None
    download_expires_at: int | None = None
    download_url_kind: Literal["temporary"] | None = None
    supports_resume: bool = True
    etag: str | None = None


class JobProgress(BaseModel):
    job_id: str
    status: str
    stage: str
    progress: float = Field(ge=0, le=100)
    message: str = ""
    current: int | None = None
    total: int | None = None
    model: str = "e-infra.glm-5"
    pid: int | None = None
    started_at: str | None = None
    updated_at: str | None = None
    heartbeat_at: str | None = None
    stale: bool = False


class SecretBody(BaseModel):
    value: str = Field(min_length=1, max_length=10000)
    target: Literal["stored_per_user", "external_text_file"] = "stored_per_user"


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    protocol_version: int
    companion_version: str
    autogenbook_available: bool
    source_dir: str
    converters: dict[str, bool]
    secret_backend: str


class CapabilitiesResponse(BaseModel):
    protocol_version: int
    modes: dict[str, Any]
    supported_file_roles: list[str]
    supported_output_formats: list[str]
