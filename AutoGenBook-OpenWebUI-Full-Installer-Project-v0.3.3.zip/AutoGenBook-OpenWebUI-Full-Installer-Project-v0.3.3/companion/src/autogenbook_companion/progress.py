from __future__ import annotations

import json
import os
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_STAGE_BASE = {
    "queued": 0.0,
    "prepare": 2.0,
    "knowledge_base": 8.0,
    "structure": 16.0,
    "resume": 18.0,
    "content": 25.0,
    "audit": 86.0,
    "export": 92.0,
    "packaging": 98.0,
    "completed": 100.0,
}
_RATIO = re.compile(r"(?<!\d)(\d{1,7})\s*(?:/|of|z)\s*(\d{1,7})(?!\d)", re.I)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


class ProgressTracker:
    """Disk-backed, restart-readable progress state for multi-day jobs."""

    def __init__(self, path: Path, *, job_id: str, model: str, heartbeat_seconds: float = 30.0) -> None:
        self.path = path
        self.job_id = job_id
        self.model = model
        self.heartbeat_seconds = max(5.0, float(heartbeat_seconds))
        self._last_write = 0.0
        now = utc_now()
        self.state: dict[str, Any] = {
            "job_id": job_id,
            "status": "QUEUED",
            "stage": "queued",
            "progress": 0.0,
            "message": "Úloha čeká ve frontě.",
            "current": None,
            "total": None,
            "model": model,
            "pid": None,
            "started_at": None,
            "updated_at": now,
            "heartbeat_at": now,
        }
        self.write()

    def write(self) -> dict[str, Any]:
        now = utc_now()
        self.state["updated_at"] = now
        self.state["heartbeat_at"] = now
        atomic_write_json(self.path, self.state)
        self._last_write = time.monotonic()
        return dict(self.state)

    def update(
        self,
        *,
        status: str | None = None,
        stage: str | None = None,
        progress: float | None = None,
        message: str | None = None,
        current: int | None = None,
        total: int | None = None,
        pid: int | None = None,
        allow_decrease: bool = False,
    ) -> dict[str, Any]:
        if status is not None:
            self.state["status"] = str(status)
        if stage is not None:
            self.state["stage"] = str(stage)
        if message is not None:
            self.state["message"] = str(message)[:2000]
        if current is not None:
            self.state["current"] = int(current)
        if total is not None:
            self.state["total"] = int(total)
        if pid is not None:
            self.state["pid"] = int(pid)
        if self.state.get("started_at") is None and str(self.state.get("status", "")).upper() == "RUNNING":
            self.state["started_at"] = utc_now()
        if progress is not None:
            value = max(0.0, min(100.0, float(progress)))
            previous = float(self.state.get("progress") or 0.0)
            if not allow_decrease and str(self.state.get("status", "")).upper() == "RUNNING":
                value = max(previous, value)
            self.state["progress"] = round(value, 2)
        return self.write()

    def heartbeat_due(self) -> bool:
        return time.monotonic() - self._last_write >= self.heartbeat_seconds

    def heartbeat(self) -> dict[str, Any]:
        return self.write()

    def from_line(self, line: str, stage: str | None = None) -> dict[str, Any] | None:
        compact = " ".join(str(line).split())
        if not compact:
            return None
        selected_stage = stage or str(self.state.get("stage") or "content")
        base = _STAGE_BASE.get(selected_stage, float(self.state.get("progress") or 1.0))
        ratio = _RATIO.search(compact)
        current = total = None
        value = base
        if ratio:
            current, total = int(ratio.group(1)), int(ratio.group(2))
            if total > 0 and 0 <= current <= total:
                if selected_stage == "content":
                    value = 25.0 + 58.0 * current / total
                else:
                    value = min(99.0, base + 5.0 * current / total)
        elif selected_stage in _STAGE_BASE:
            value = _STAGE_BASE[selected_stage]
        return self.update(
            status="RUNNING",
            stage=selected_stage,
            progress=value,
            message=compact[:1000],
            current=current,
            total=total,
        )


def load_progress(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    return dict(value) if isinstance(value, dict) else None
