from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import signal
import sys
import time
from collections import deque
from pathlib import Path
from typing import Any

from .artifacts import ArtifactCollector
from .config import Settings
from .database import Database
from .models import JobStatus, Mode, ProjectSpec
from .progress import ProgressTracker
from .security import SecretStore, owner_storage_key, redact_text, safe_extract_zip, safe_filename, secret_fingerprint

_STAGE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\[KB\]", re.I), "knowledge_base"),
    (re.compile(r"\[JSON\]", re.I), "structure"),
    (re.compile(r"\[RESUME\]", re.I), "resume"),
    (re.compile(r"audit", re.I), "audit"),
    (re.compile(r"(?:pdf|pandoc|latex|pptx|docx|video|audio)", re.I), "export"),
    (re.compile(r"(?:section|sekc|chapter|kapitol|slide|snímek)", re.I), "content"),
]


class RunnerError(RuntimeError):
    pass


class AutoGenBookRunner:
    def __init__(self, settings: Settings, database: Database, secret_store: SecretStore) -> None:
        self.settings = settings
        self.database = database
        self.secret_store = secret_store
        self.collector = ArtifactCollector(database, settings.max_hash_bytes)

    def _job_root(self, owner_id: str, project_id: str, job_id: str) -> Path:
        return self.settings.projects_dir / owner_storage_key(owner_id) / project_id / job_id

    def _copy_project_files(
        self, files: list[dict[str, Any]], inputs_dir: Path
    ) -> dict[str, list[Path]]:
        roles: dict[str, list[Path]] = {"input": [], "structure": [], "kb": [], "kb1": [], "kb2": []}
        for item in files:
            role = str(item["role"])
            source = Path(item["stored_path"]).resolve()
            if not source.exists():
                raise RunnerError(f"Stored input is missing: {source}")
            role_dir = inputs_dir / role
            role_dir.mkdir(parents=True, exist_ok=True)
            target = role_dir / safe_filename(item["filename"])
            if source.suffix.lower() == ".zip" and role in {"kb", "kb1", "kb2"}:
                extract_dir = role_dir / target.stem
                safe_extract_zip(source, extract_dir)
                roles[role].append(extract_dir)
            else:
                shutil.copy2(source, target)
                roles[role].append(target)
        return roles

    @staticmethod
    def _bool_option(options: dict[str, Any], key: str, default: bool = False) -> bool:
        value = options.get(key, default)
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on", "ano"}
        return bool(value)

    @staticmethod
    def _clean_brief(value: str) -> str:
        text = re.sub(r"<attached_files>.*?</attached_files>", "", str(value or ""), flags=re.I | re.S)
        text = re.sub(r"<file\b[^>]*/?>", "", text, flags=re.I | re.S)
        return re.sub(r"\n{3,}", "\n\n", text).strip()

    @classmethod
    def _render_spec_input(cls, spec: ProjectSpec) -> str:
        lines = [f"Mode: {spec.mode.value}"]
        for label, value in (
            ("Title", spec.title),
            ("Language", spec.language),
            ("Audience", spec.audience),
            ("Style", spec.style),
            ("Length", spec.length),
        ):
            if value not in (None, ""):
                lines.append(f"{label}: {value}")
        brief = cls._clean_brief(spec.brief)
        if brief:
            lines.extend(["", "User brief:", brief])
        return "\n".join(lines).strip() + "\n"

    def _build_command(
        self,
        *,
        spec: ProjectSpec,
        roles: dict[str, list[Path]],
        job_root: Path,
        out_dir: Path,
        resume: bool,
    ) -> list[str]:
        generated_input = job_root / "input.txt"
        generated_input.write_text(self._render_spec_input(spec), encoding="utf-8")
        input_path = roles["input"][0] if roles["input"] else generated_input
        command = [
            sys.executable,
            "-m",
            "autogenbook_companion.worker_entry",
            "--mode",
            spec.mode.value,
            "--out-dir",
            str(out_dir),
        ]
        if spec.language:
            command.extend(["--language", str(spec.language)])

        if spec.mode == Mode.proposal:
            command.extend(["--proposal-input", str(input_path), "--dont-ask"])
        elif spec.mode != Mode.reviewer:
            command.extend(["--input", str(input_path)])

        if roles["structure"]:
            command.extend(["--json", str(roles["structure"][0]), "--use-json"])
        elif spec.mode in {Mode.book, Mode.paper, Mode.presentation}:
            command.append("--use-txt")

        if roles["kb"]:
            kb_path = roles["kb"][0] if roles["kb"][0].is_dir() and len(roles["kb"]) == 1 else job_root / "kb"
            if kb_path == job_root / "kb":
                kb_path.mkdir(parents=True, exist_ok=True)
                for item in roles["kb"]:
                    if item.is_dir():
                        for child in item.rglob("*"):
                            if child.is_file():
                                rel = child.relative_to(item)
                                destination = kb_path / item.name / rel
                                destination.parent.mkdir(parents=True, exist_ok=True)
                                shutil.copy2(child, destination)
                    else:
                        shutil.copy2(item, kb_path / item.name)
            command.extend(["--kb-dir", str(kb_path)])

        for role, flag in (("kb1", "--kb1-dir"), ("kb2", "--kb2-dir")):
            if roles[role]:
                role_path = job_root / role
                role_path.mkdir(parents=True, exist_ok=True)
                for item in roles[role]:
                    if item.is_dir():
                        for child in item.rglob("*"):
                            if child.is_file():
                                rel = child.relative_to(item)
                                destination = role_path / item.name / rel
                                destination.parent.mkdir(parents=True, exist_ok=True)
                                shutil.copy2(child, destination)
                    else:
                        shutil.copy2(item, role_path / item.name)
                command.extend([flag, str(role_path)])

        formats = set(spec.outputs.formats)
        if "md" not in formats:
            command.append("--no-md")
        if "pdf" not in formats:
            command.append("--no-pdf")
        if "tex" not in formats:
            command.append("--no-tex")
        if "docx" in formats:
            command.append("--docx")
        if spec.mode == Mode.book and ({"pdf", "tex"} & formats):
            command.append("--export-tex")
        if spec.mode == Mode.presentation:
            if "pptx" in formats:
                command.append("--presentation-pptx")
            if {"pdf", "tex"} & formats:
                command.append("--presentation-tex")
            if self._bool_option(spec.options, "narration"):
                command.append("--presentation-narration")
            if self._bool_option(spec.options, "tts"):
                command.append("--presentation-tts")
            if self._bool_option(spec.options, "video") or "video" in formats:
                command.append("--presentation-video")
            if not self._bool_option(spec.options, "images", True):
                command.append("--no-image")
            if self._bool_option(spec.options, "citations"):
                command.append("--presentation-citations")

        if self._bool_option(spec.options, "web_rag"):
            command.append("--enable-web-rag")
            command.extend(["--web-rag-k", str(int(spec.options.get("web_rag_k", 5)))])
        if self._bool_option(spec.options, "rebuild_kb"):
            command.append("--rebuild-kb")
        if resume:
            command.append("--resume")
        if self._bool_option(spec.options, "audit"):
            command.append("--audit")
        audit_mode = str(spec.options.get("audit_mode", "warn"))
        if audit_mode in {"off", "warn", "strict"}:
            command.extend(["--audit-mode", audit_mode])
        if self._bool_option(spec.options, "audit_book"):
            command.append("--audit-book")
        if self._bool_option(spec.options, "fail_fast_schema"):
            command.append("--fail-fast-schema")

        if spec.mode == Mode.paper:
            command.extend(["--paper-venue", str(spec.options.get("paper_venue", "arXiv"))])
            citation = str(spec.options.get("citation_style", "bibtex"))
            if citation in {"bibtex", "footnote"}:
                command.extend(["--citation-style", citation])
        if spec.mode in {Mode.proposal, Mode.scientist} and spec.options.get("max_iters") is not None:
            command.extend(["--max-iters", str(int(spec.options["max_iters"]))])
        if spec.mode == Mode.proposal:
            command.extend(["--section-retries", str(int(spec.options.get("section_retries", 3)))])
            command.extend(["--min-section-citations", str(int(spec.options.get("min_section_citations", 1)))])
        if spec.mode == Mode.reviewer:
            reviewer_instructions = job_root / "reviewer_instructions.txt"
            clean_brief = self._clean_brief(spec.brief)
            if not clean_brief:
                clean_brief = (
                    "Vypracuj úplný odborný posudek závěrečné práce podle standardního reviewer "
                    "promptu AutoGenBooku. Hodnoť obsahovou kvalitu, metodiku, výsledky, původnost, "
                    "inovaci, praktický přínos a formální požadavky z KB1; každé tvrzení opři o KB2."
                )
            reviewer_instructions.write_text(clean_brief + "\n", encoding="utf-8")
            command.extend(["--reviewer-instructions", str(reviewer_instructions)])
            profile = str(spec.options.get("reviewer_profile", "direct") or "direct").lower()
            if profile not in {"direct", "hybrid", "compliance"}:
                profile = "direct"
            command.extend(["--reviewer-profile", profile])
            # Persist the selected model in the command itself. Environment variables
            # remain authoritative inside the isolated worker, but this makes the
            # recorded command reproducible from the standalone CLI as well.
            reviewer_llm1_model = str(
                spec.provider.role_models.get("reviewer_llm1") or spec.provider.model
            ).strip()
            reviewer_llm2_model = str(
                spec.provider.role_models.get("reviewer_llm2") or spec.provider.model
            ).strip()
            if reviewer_llm1_model:
                command.extend(["--reviewer-llm1-model", reviewer_llm1_model])
            if reviewer_llm2_model:
                command.extend(["--reviewer-llm2-model", reviewer_llm2_model])
            if self._bool_option(spec.options, "reviewer_direct_pdf", True):
                command.append("--reviewer-direct-pdf")
            if self._bool_option(spec.options, "reviewer_allow_missing_kb1"):
                command.append("--reviewer-allow-missing-kb1")
            command.extend(
                [
                    "--reviewer-evidence-max-chars",
                    str(int(spec.options.get("reviewer_evidence_max_chars", 60000))),
                    "--reviewer-kb1-context-max-chars",
                    str(int(spec.options.get("reviewer_kb1_context_max_chars", 48000))),
                    "--reviewer-evidence-per-criterion",
                    str(int(spec.options.get("reviewer_evidence_per_criterion", 6))),
                    "--reviewer-max-output-tokens",
                    str(int(spec.options.get("reviewer_max_output_tokens", 32768))),
                    "--reviewer-pdf-engine",
                    str(spec.options.get("reviewer_pdf_engine", "auto") or "auto"),
                ]
            )
            if not self._bool_option(spec.options, "reviewer_quality_gate", True):
                command.append("--no-reviewer-quality-gate")

        role_flag_map = {
            "proposal_llm1": "--proposal-llm1-model",
            "proposal_llm2": "--proposal-llm2-model",
            "proposal_llm3": "--proposal-llm3-model",
            "proposal_llm4": "--proposal-llm4-model",
            "proposal_llm5": "--proposal-llm5-model",
            "reviewer_llm1": "--reviewer-llm1-model",
            "reviewer_llm2": "--reviewer-llm2-model",
            "presentation_narration": "--presentation-narration-model",
            "presentation_image": "--presentation-image-model",
        }
        for key, model in spec.provider.role_models.items():
            if spec.mode == Mode.reviewer and key in {"reviewer_llm1", "reviewer_llm2"}:
                continue
            if key in role_flag_map and model:
                command.extend([role_flag_map[key], str(model)])
        parity_request = {
            "schema_version": 1,
            "statement": (
                "This is the exact CLI command executed by the Companion. Running the same source revision "
                "with the same command, input files, model revision and generation parameters is the parity baseline."
            ),
            "command": command,
            "spec": spec.model_dump(mode="json"),
            "generated_input": str(generated_input),
            "required_environment": {
                "AUTOGENBOOK_PROVIDER_TYPE": spec.provider.type,
                "AUTOGENBOOK_LLM_BASE_URL": spec.provider.base_url,
                "AUTOGENBOOK_LLM_MODEL": spec.provider.model,
                "AUTOGENBOOK_FORCE_MODEL": spec.provider.model,
                "AUTOGENBOOK_LLM_API_KEY": "<same provider credential; intentionally not persisted>",
            },
            "parity_conditions": [
                "same AutoGenBook source revision and prompt files",
                "same input bytes and KB role assignment",
                "same model identifier, provider endpoint and model revision",
                "same generation and reviewer profile parameters",
            ],
        }
        payload = json.dumps(parity_request, ensure_ascii=False, indent=2)
        (job_root / "direct_cli_parity_request.json").write_text(payload, encoding="utf-8")
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "direct_cli_parity_request.json").write_text(payload, encoding="utf-8")
        return command

    def _build_env(self, owner_id: str, spec: ProjectSpec) -> tuple[dict[str, str], list[str]]:
        env = {str(k): str(v) for k, v in os.environ.items()}
        # A worker is provider-isolated. Ambient keys/base URLs from the shell,
        # Anaconda profile or Open WebUI process must never override the credential
        # selected and validated for this job.
        for inherited_name in (
            "OPENROUTER_API_KEY",
            "OPENAI_API_KEY",
            "OPENAI_BASE_URL",
            "OPENAI_API_BASE",
            "OPENROUTER_BASE_URL",
            "AUTOGENBOOK_FORCE_MINI_MODEL",
        ):
            env.pop(inherited_name, None)
        bundle_root = self.settings.source_dir.parent
        tools_root = bundle_root / "tools"
        path_entries: list[str] = []
        common_bin = tools_root / "bin"
        if common_bin.is_dir():
            path_entries.append(str(common_bin))
        tinytex_bin = tools_root / "tinytex" / "bin"
        if tinytex_bin.is_dir():
            path_entries.extend(str(item) for item in sorted(tinytex_bin.iterdir()) if item.is_dir())
        runtime_scripts = [
            Path(sys.executable).parent,
            Path(sys.executable).parent / "Scripts",
            Path(sys.executable).parent / "bin",
        ]
        path_entries.extend(str(item) for item in runtime_scripts if item.is_dir())
        current_path = env.get("PATH", "")
        env["PATH"] = os.pathsep.join([*path_entries, current_path] if current_path else path_entries)
        pandoc = common_bin / ("pandoc.exe" if os.name == "nt" else "pandoc")
        ffmpeg = common_bin / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
        piper_model = tools_root / "piper" / "cs_CZ-jirka-medium.onnx"
        piper_config = tools_root / "piper" / "cs_CZ-jirka-medium.onnx.json"
        if pandoc.exists():
            env["PYPANDOC_PANDOC"] = str(pandoc)
        if ffmpeg.exists():
            env["IMAGEIO_FFMPEG_EXE"] = str(ffmpeg)
            env["FFMPEG_BINARY"] = str(ffmpeg)
        if piper_model.exists() and piper_config.exists():
            env["AUTOGENBOOK_PIPER_MODEL"] = str(piper_model)
            env["AUTOGENBOOK_PIPER_CONFIG"] = str(piper_config)
        native_lib = tools_root / "lib"
        if native_lib.is_dir() and os.name != "nt":
            existing_ld = env.get("LD_LIBRARY_PATH", "")
            env["LD_LIBRARY_PATH"] = os.pathsep.join(
                [str(native_lib), existing_ld] if existing_ld else [str(native_lib)]
            )
        package_root = str(Path(__file__).resolve().parents[1])
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = os.pathsep.join(
            part for part in (package_root, str(self.settings.source_dir), existing_pythonpath) if part
        )
        env.update(
            {
                "AUTOGENBOOK_SOURCE_DIR": str(self.settings.source_dir),
                "AUTOGENBOOK_NONINTERACTIVE": "1",
                "PYTHONUNBUFFERED": "1",
                "PYTHONUTF8": "1",
                "PYTHONIOENCODING": "utf-8",
                "MCP_GATEWAY_ENABLE": "1" if self._bool_option(spec.options, "enable_mcp") else "0",
                "AUTOGENBOOK_FORCE_MODEL": spec.provider.model,
                "AUTOGENBOOK_LLM_MODEL": spec.provider.model,
                "OPENWEBUI_MODEL": spec.provider.model,
                "OPENAI_MODEL": spec.provider.model,
                "OPENROUTER_MODEL": spec.provider.model,
                "LLM_MODEL": spec.provider.model,
                "MODEL_NAME": spec.provider.model,
                "AUTOGENBOOK_PROVIDER_TYPE": spec.provider.type,
            }
        )
        secrets_for_redaction: list[str] = []
        api_key_resolution = self.secret_store.resolve(owner_id, spec.provider.api_key_secret)
        api_key = api_key_resolution.value
        base_url = (spec.provider.base_url or "").strip()
        if spec.provider.type == "openrouter":
            if not api_key:
                raise RunnerError(
                    f"Secret '{spec.provider.api_key_secret}' is required for the OpenRouter provider."
                )
            env["AUTOGENBOOK_LLM_API_KEY"] = api_key
            env["OPENROUTER_API_KEY"] = api_key
            if base_url:
                env["AUTOGENBOOK_LLM_BASE_URL"] = base_url
                env["OPENROUTER_BASE_URL"] = base_url
                env["OPENAI_BASE_URL"] = base_url
        elif spec.provider.type == "openwebui":
            if not api_key:
                if api_key_resolution.error:
                    raise RunnerError(
                        "[OPENWEBUI_SECRET_FILE_UNREADABLE] Open WebUI API key could not be read "
                        f"from the configured TXT reference: {api_key_resolution.error}"
                    )
                raise RunnerError(
                    f"Persistent Open WebUI API key '{spec.provider.api_key_secret}' is missing. "
                    "Use the Open WebUI command 'pokračuj JOB_ID' to store a new key and resume."
                )
            env["AUTOGENBOOK_LLM_API_KEY"] = api_key
            env["OPENAI_API_KEY"] = api_key
            if base_url:
                env["AUTOGENBOOK_LLM_BASE_URL"] = base_url
                env["OPENAI_BASE_URL"] = base_url
                env["OPENAI_API_BASE"] = base_url
        elif spec.provider.type == "openai_compatible":
            selected_key = api_key or "local"
            env["AUTOGENBOOK_LLM_API_KEY"] = selected_key
            env["OPENAI_API_KEY"] = selected_key
            if base_url:
                env["AUTOGENBOOK_LLM_BASE_URL"] = base_url
                env["OPENAI_BASE_URL"] = base_url
                env["OPENAI_API_BASE"] = base_url
        if api_key:
            secrets_for_redaction.append(api_key)
            env["AUTOGENBOOK_LLM_SECRET_SOURCE"] = api_key_resolution.source
            env["AUTOGENBOOK_LLM_KEY_FINGERPRINT"] = secret_fingerprint(api_key) or ""
            if api_key_resolution.reference_path:
                env["AUTOGENBOOK_LLM_SECRET_REFERENCE"] = api_key_resolution.reference_path
        env["AUTOGENBOOK_CREDENTIAL_ISOLATION"] = "provider-aware-v1"
        tavily_secret = str(spec.options.get("tavily_secret", "tavily_api_key"))
        tavily = self.secret_store.get(owner_id, tavily_secret)
        if tavily:
            env["TAVILY_API_KEY"] = tavily
            secrets_for_redaction.append(tavily)
        return env, secrets_for_redaction

    @staticmethod
    def _classify_worker_failure(
        exit_code: int,
        recent_lines: list[str],
        provider_type: str,
        job_id: str,
    ) -> tuple[str, str]:
        text = "\n".join(recent_lines[-120:])
        folded = text.casefold()
        reviewer_quality_codes = (
            "REVIEWER_KB1_AUTH_PAGE",
            "REVIEWER_KB1_ACCESS_GATE",
            "REVIEWER_KB1_UNREADABLE",
            "REVIEWER_KB1_TOO_SHORT",
            "REVIEWER_KB1_IRRELEVANT",
            "REVIEWER_KB1_INVALID",
        )
        for code in reviewer_quality_codes:
            if code.casefold() in folded:
                return (
                    code,
                    (
                        f"[{code}] Reviewer odmítl KB1, protože nejde o použitelný hodnoticí předpis/rubriku. "
                        "Přihlašovací stránky, chybové brány, příliš krátké a nerelevantní dokumenty se "
                        "nepředávají LLM. V reviewer chatu přiložte veřejný předpis nebo vložte podrobná "
                        f"kritéria a poté odešlete `pokračuj {job_id}`. Kompletní diagnostika je ve výstupech."
                    ),
                )
        if "reviewer_kb1_required" in folded:
            return (
                "REVIEWER_KB1_REQUIRED",
                (
                    "[REVIEWER_KB1_REQUIRED] Reviewer nelze spustit bez KB1 s hodnoticím předpisem "
                    "nebo explicitními kritérii. Vraťte se do reviewer chatu, přiložte předpis, vložte "
                    "jeho URL/text nebo spusťte kontextové dohledání; potom vytvořte nový běh. "
                    f"Diagnostické soubory jsou dostupné příkazem `výstupy {job_id}`."
                ),
            )
        if "openwebui_secret_file_unreadable" in folded:
            return (
                "OPENWEBUI_SECRET_FILE_UNREADABLE",
                (
                    "[OPENWEBUI_SECRET_FILE_UNREADABLE] Odkaz na TXT soubor s Open WebUI API klíčem "
                    "nelze přečíst nebo soubor neobsahuje právě jeden platný klíč. Upravte soubor, "
                    "spusťte Configure-OpenWebUI-ApiKeyFile.cmd a poté obnovte úlohu příkazem "
                    f"`pokračuj {job_id}`."
                ),
            )
        if "provider_model_unavailable" in folded:
            return (
                "OPENWEBUI_MODEL_UNAVAILABLE",
                (
                    "[OPENWEBUI_MODEL_UNAVAILABLE] Zvolený model není viditelný pro trvalý API klíč "
                    f"použitý workerem. Vyberte dostupný model a odešlete `pokračuj {job_id}`."
                ),
            )
        if "provider_preflight_unreachable" in folded:
            return (
                "OPENWEBUI_PROVIDER_UNREACHABLE",
                (
                    "[OPENWEBUI_PROVIDER_UNREACHABLE] Worker se před indexací KB nedokázal spojit s Open WebUI. "
                    "Zkontrolujte, že Open WebUI běží na uložené adrese, a poté odešlete "
                    f"`pokračuj {job_id}`."
                ),
            )
        if "provider_preflight_protocol_error" in folded:
            return (
                "OPENWEBUI_PROVIDER_PROTOCOL_ERROR",
                (
                    "[OPENWEBUI_PROVIDER_PROTOCOL_ERROR] Endpoint /api/models nevrátil použitelný seznam modelů. "
                    f"Zkontrolujte adresu Open WebUI a oprávnění API klíče; poté odešlete `pokračuj {job_id}`."
                ),
            )
        auth_invalid = (
            "error code: 401" in folded
            or "session has expired" in folded
            or "token is invalid" in folded
            or "provider_auth_invalid" in folded
            or "authentication failed (401)" in folded
        )
        auth_forbidden = (
            "error code: 403" in folded
            or "provider_auth_forbidden" in folded
            or "permission denied (403)" in folded
        )
        if provider_type == "openwebui" and auth_invalid:
            return (
                "OPENWEBUI_AUTH_INVALID",
                (
                    "[OPENWEBUI_AUTH_INVALID] Open WebUI odmítlo přesně ten izolovaný credential, který "
                    "worker obdržel. API klíč mohl být zrušen nebo TXT soubor mohl být změněn. "
                    f"V chatu odešlete `pokračuj {job_id}`; AutoGenBook vyžádá nový trvalý osobní API klíč "
                    "a obnoví úlohu ze stávajících vstupů/checkpointů."
                ),
            )
        if provider_type == "openwebui" and auth_forbidden:
            return (
                "OPENWEBUI_AUTH_FORBIDDEN",
                (
                    "[OPENWEBUI_AUTH_FORBIDDEN] Open WebUI API klíč nemá oprávnění k modelovému API. "
                    "Zkontrolujte povolení API Keys a endpointy /api/models a /api/chat/completions. "
                    f"Po opravě odešlete `pokračuj {job_id}`."
                ),
            )
        tail = next((line.strip() for line in reversed(recent_lines) if line.strip()), "")
        suffix = f" Poslední zpráva: {tail[:800]}" if tail else ""
        return (
            "WORKER_EXIT",
            f"AutoGenBook skončil návratovým kódem {exit_code}. Podrobnosti jsou ve worker.log.{suffix}",
        )

    @staticmethod
    def _write_failure_diagnostics(
        out_dir: Path,
        *,
        job_id: str,
        error_code: str,
        message: str,
        exit_code: int | None,
        recent_lines: list[str],
    ) -> None:
        metadata_dir = out_dir / "_autogenbook_companion"
        metadata_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "job_id": job_id,
            "error_code": error_code,
            "message": message,
            "exit_code": exit_code,
            "recent_worker_lines": recent_lines[-120:],
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        (metadata_dir / "failure.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        tail = "\n".join(recent_lines[-120:]).strip() or "(worker nevytvořil žádný výstup)"
        (metadata_dir / "failure.md").write_text(
            "# AutoGenBook failure diagnostic\n\n"
            f"- Job: `{job_id}`\n"
            f"- Code: `{error_code}`\n"
            f"- Exit code: `{exit_code}`\n\n"
            f"{message}\n\n"
            "## Poslední řádky workeru\n\n```text\n"
            f"{tail}\n```\n",
            encoding="utf-8",
        )

    @staticmethod
    async def _terminate(process: asyncio.subprocess.Process) -> None:
        if process.returncode is not None:
            return
        try:
            if os.name != "nt":
                os.killpg(process.pid, signal.SIGTERM)
            else:
                process.terminate()
        except ProcessLookupError:
            return
        try:
            await asyncio.wait_for(process.wait(), timeout=10)
            return
        except asyncio.TimeoutError:
            pass
        try:
            if os.name != "nt":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
        except ProcessLookupError:
            pass
        await process.wait()

    @staticmethod
    def _stage_for_line(line: str) -> str | None:
        for pattern, stage in _STAGE_PATTERNS:
            if pattern.search(line):
                return stage
        return None

    async def run(self, job_id: str) -> None:
        job = self.database.get_job_unscoped(job_id)
        if not job:
            return
        owner_id = str(job["owner_id"])
        project = self.database.get_project(str(job["project_id"]), owner_id)
        if not project:
            self.database.update_job(
                job_id,
                status=JobStatus.failed.value,
                error="Project does not exist.",
                finished_at=time.time(),
            )
            return
        spec = ProjectSpec.model_validate(project["spec"])
        job_root = self._job_root(owner_id, project["id"], job_id)
        inputs_dir = job_root / "inputs"
        out_dir = job_root / "output"
        logs_dir = job_root / "logs"
        for path in (inputs_dir, out_dir, logs_dir):
            path.mkdir(parents=True, exist_ok=True)
        tracker = ProgressTracker(
            job_root / ".autogenbook-progress.json",
            job_id=job_id,
            model=spec.provider.model,
            heartbeat_seconds=float(os.environ.get("AUTOGENBOOK_HEARTBEAT_SECONDS", "30")),
        )
        self.database.update_job(job_id, out_dir=str(out_dir))
        progress = tracker.update(status="RUNNING", stage="prepare", progress=2, message="Připravuji vstupy a pracovní adresáře.")
        self.database.add_event(job_id, owner_id, "progress", progress)
        self.database.add_event(job_id, owner_id, "stage", {"name": "prepare", "status": "started"})
        recent_lines: deque[str] = deque(maxlen=120)

        try:
            roles = self._copy_project_files(self.database.list_files(project["id"], owner_id), inputs_dir)
            command = self._build_command(
                spec=spec,
                roles=roles,
                job_root=job_root,
                out_dir=out_dir,
                resume=bool(job.get("resume")),
            )
            env, hidden = self._build_env(owner_id, spec)
            request_snapshot = {
                "job_id": job_id,
                "project_id": project["id"],
                "spec": spec.model_dump(mode="json"),
                "command": ["***" if part in hidden else part for part in command],
                "source_dir": str(self.settings.source_dir),
                "provider_auth": {
                    "source": env.get("AUTOGENBOOK_LLM_SECRET_SOURCE", "missing"),
                    "fingerprint": env.get("AUTOGENBOOK_LLM_KEY_FINGERPRINT") or None,
                    "reference_path": env.get("AUTOGENBOOK_LLM_SECRET_REFERENCE") or None,
                    "isolation": env.get("AUTOGENBOOK_CREDENTIAL_ISOLATION"),
                },
            }
            (job_root / "request.json").write_text(
                json.dumps(request_snapshot, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            creationflags = 0
            process_kwargs: dict[str, Any] = {}
            if os.name == "nt":
                creationflags = getattr(__import__("subprocess"), "CREATE_NEW_PROCESS_GROUP", 0)
                process_kwargs["creationflags"] = creationflags
            else:
                process_kwargs["start_new_session"] = True

            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=str(self.settings.source_dir),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                **process_kwargs,
            )
            self.database.update_job(
                job_id,
                status=JobStatus.running.value,
                pid=process.pid,
                started_at=time.time(),
                cancel_requested=0,
            )
            self.database.set_project_status(project["id"], owner_id, "RUNNING")
            progress = tracker.update(
                status="RUNNING",
                stage="content",
                progress=25,
                message="AutoGenBook generuje obsah.",
                pid=process.pid,
            )
            self.database.add_event(job_id, owner_id, "progress", progress)
            self.database.add_event(
                job_id,
                owner_id,
                "stage",
                {"name": "generate", "status": "started", "pid": process.pid},
            )

            log_path = logs_dir / "worker.log"
            last_stage: str | None = None
            recent_lines.clear()
            assert process.stdout is not None
            with log_path.open("a", encoding="utf-8") as log_stream:
                while True:
                    try:
                        raw = await asyncio.wait_for(process.stdout.readline(), timeout=0.75)
                    except asyncio.TimeoutError:
                        raw = b""
                    if raw:
                        line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                        line = redact_text(line, hidden)
                        recent_lines.append(line)
                        log_stream.write(line + "\n")
                        log_stream.flush()
                        if line:
                            self.database.add_event(job_id, owner_id, "log", {"line": line[-4000:]})
                            stage = self._stage_for_line(line)
                            if stage and stage != last_stage:
                                last_stage = stage
                                self.database.add_event(
                                    job_id,
                                    owner_id,
                                    "stage",
                                    {"name": stage, "status": "running", "message": line[-500:]},
                                )
                            progress = tracker.from_line(line, stage=stage or last_stage)
                            if progress:
                                self.database.add_event(job_id, owner_id, "progress", progress)
                    elif tracker.heartbeat_due():
                        self.database.add_event(job_id, owner_id, "progress", tracker.heartbeat())
                    current = self.database.get_job_unscoped(job_id)
                    if current and current.get("cancel_requested"):
                        self.database.add_event(
                            job_id, owner_id, "stage", {"name": "cancel", "status": "requested"}
                        )
                        await self._terminate(process)
                        self.database.update_job(
                            job_id,
                            status=JobStatus.cancelled.value,
                            exit_code=process.returncode,
                            pid=None,
                            finished_at=time.time(),
                        )
                        self.database.set_project_status(project["id"], owner_id, "CANCELLED")
                        self.database.add_event(
                            job_id,
                            owner_id,
                            "progress",
                            tracker.update(
                                status="CANCELLED",
                                stage="cancelled",
                                message="Úloha byla zrušena.",
                                pid=0,
                            ),
                        )
                        self.collector.collect(
                            job_id=job_id,
                            owner_id=owner_id,
                            out_dir=out_dir,
                            job_root=job_root,
                        )
                        return
                    if process.returncode is not None:
                        break
                    if not raw and process.stdout.at_eof():
                        await process.wait()
                        break

            exit_code = await process.wait()
            if exit_code == 0:
                self.database.update_job(
                    job_id,
                    status=JobStatus.succeeded.value,
                    exit_code=0,
                    pid=None,
                    finished_at=time.time(),
                )
                self.database.set_project_status(project["id"], owner_id, "SUCCEEDED")
                self.database.add_event(
                    job_id,
                    owner_id,
                    "progress",
                    tracker.update(
                        status="SUCCEEDED",
                        stage="completed",
                        progress=100,
                        message="Generování bylo dokončeno; finalizuji manifest a balík výstupů.",
                        pid=0,
                    ),
                )
                artifacts = self.collector.collect(
                    job_id=job_id,
                    owner_id=owner_id,
                    out_dir=out_dir,
                    job_root=job_root,
                )
                self.database.add_event(
                    job_id,
                    owner_id,
                    "progress",
                    tracker.update(
                        status="SUCCEEDED",
                        stage="completed",
                        progress=100,
                        message=f"Generování bylo dokončeno; nalezeno {len(artifacts)} výstupů.",
                        pid=0,
                    ),
                )
                self.database.add_event(
                    job_id,
                    owner_id,
                    "completed",
                    {"status": "SUCCEEDED", "artifacts": len(artifacts)},
                )
            else:
                error_code, error = self._classify_worker_failure(
                    exit_code, list(recent_lines), spec.provider.type, job_id
                )
                self.database.update_job(
                    job_id,
                    status=JobStatus.failed.value,
                    exit_code=exit_code,
                    error=error,
                    pid=None,
                    finished_at=time.time(),
                )
                self.database.set_project_status(project["id"], owner_id, "FAILED")
                self.database.add_event(
                    job_id,
                    owner_id,
                    "progress",
                    tracker.update(status="FAILED", stage="failed", message=error, pid=0),
                )
                self.database.add_event(
                    job_id, owner_id, "error", {"code": error_code, "message": error}
                )
                self._write_failure_diagnostics(
                    out_dir,
                    job_id=job_id,
                    error_code=error_code,
                    message=error,
                    exit_code=exit_code,
                    recent_lines=list(recent_lines),
                )
                self.collector.collect(
                    job_id=job_id,
                    owner_id=owner_id,
                    out_dir=out_dir,
                    job_root=job_root,
                )
        except Exception as exc:
            message = redact_text(str(exc), [])
            self.database.update_job(
                job_id,
                status=JobStatus.failed.value,
                error=message,
                pid=None,
                finished_at=time.time(),
            )
            self.database.set_project_status(project["id"], owner_id, "FAILED")
            self.database.add_event(
                job_id,
                owner_id,
                "progress",
                tracker.update(status="FAILED", stage="failed", message=message, pid=0),
            )
            self.database.add_event(
                job_id, owner_id, "error", {"code": "RUNNER_EXCEPTION", "message": message}
            )
            self._write_failure_diagnostics(
                out_dir,
                job_id=job_id,
                error_code="RUNNER_EXCEPTION",
                message=message,
                exit_code=None,
                recent_lines=list(recent_lines),
            )
            try:
                self.collector.collect(
                    job_id=job_id,
                    owner_id=owner_id,
                    out_dir=out_dir,
                    job_root=job_root,
                )
            except Exception:
                pass
