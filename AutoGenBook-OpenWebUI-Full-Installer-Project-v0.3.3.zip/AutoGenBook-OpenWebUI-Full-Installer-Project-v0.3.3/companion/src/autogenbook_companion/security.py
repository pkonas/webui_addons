from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .key_file import ApiKeyFileError, get_file_reference, normalize_api_key_text, read_api_key_file

_OWNER_RE = re.compile(r"[^A-Za-z0-9_.:@-]+")
_FILENAME_RE = re.compile(r"[^A-Za-z0-9._()\- +]+")


def normalize_owner_id(value: str | None) -> str:
    raw = (value or "local").strip()[:256]
    clean = _OWNER_RE.sub("_", raw).strip("._") or "local"
    if len(clean) > 128:
        digest = hashlib.sha256(clean.encode("utf-8")).hexdigest()[:16]
        clean = clean[:100] + "-" + digest
    return clean


def owner_storage_key(owner_id: str) -> str:
    return hashlib.sha256(normalize_owner_id(owner_id).encode("utf-8")).hexdigest()[:20]


def safe_filename(name: str | None, default: str = "file.bin") -> str:
    raw = Path(name or default).name.replace("\x00", "")
    clean = _FILENAME_RE.sub("_", raw).strip(" .")
    return (clean or default)[:180]


def ensure_within(path: Path, root: Path) -> Path:
    resolved = path.expanduser().resolve()
    root_resolved = root.expanduser().resolve()
    try:
        resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"Path escapes managed root: {resolved}") from exc
    return resolved


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def secret_fingerprint(value: str | None) -> str | None:
    """Return a non-secret fingerprint suitable for diagnostics and correlation."""

    normalized = str(value or "").strip()
    if not normalized:
        return None
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def safe_extract_zip(
    archive: Path,
    destination: Path,
    *,
    max_files: int = 5000,
    max_uncompressed_bytes: int = 2 * 1024 * 1024 * 1024,
) -> list[Path]:
    destination.mkdir(parents=True, exist_ok=True)
    extracted: list[Path] = []
    total = 0
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        if len(infos) > max_files:
            raise ValueError(f"Archive contains too many entries ({len(infos)} > {max_files}).")
        for info in infos:
            if info.is_dir():
                continue
            total += int(info.file_size)
            if total > max_uncompressed_bytes:
                raise ValueError("Archive exceeds the uncompressed size limit.")
            # Reject absolute paths, traversal and Unix symlinks.
            rel = Path(info.filename.replace("\\", "/"))
            if rel.is_absolute() or ".." in rel.parts:
                raise ValueError(f"Unsafe archive path: {info.filename}")
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise ValueError(f"Symlink entries are not accepted: {info.filename}")
            target = ensure_within(destination / rel, destination)
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as source, target.open("wb") as output:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
            extracted.append(target)
    return extracted


@dataclass(frozen=True)
class SecretResolution:
    value: str | None
    source: str
    reference_path: str | None = None
    error: str | None = None


class SecretStore:
    """Resolve per-user secrets and optional live TXT-file references safely.

    A reference can use ``stored_first`` (the compatibility default) or
    ``external_first``.  The installer deliberately configures the Open WebUI API
    key as ``external_first`` so a stale browser/session credential previously
    stored for one user cannot shadow the administrator-selected key file.  Only
    the absolute path is persisted; the key itself stays in the user-managed file
    and is re-read whenever a worker starts or the provider is validated.
    """

    service_name = "AutoGenBook-OpenWebUI"

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._keyring = None
        try:
            import keyring  # type: ignore

            self._keyring = keyring
        except Exception:
            self._keyring = None

    @property
    def backend_name(self) -> str:
        if self._keyring is not None:
            try:
                return f"keyring:{self._keyring.get_keyring().__class__.__name__}"
            except Exception:
                return "keyring"
        return "permission-restricted-file"

    @staticmethod
    def _account(owner_id: str, name: str) -> str:
        return f"{normalize_owner_id(owner_id)}:{safe_filename(name, 'secret')}"

    def _fallback_path(self, owner_id: str, name: str) -> Path:
        account = self._account(owner_id, name)
        digest = hashlib.sha256(account.encode("utf-8")).hexdigest()
        return self.root / f"{digest}.json"

    def set(self, owner_id: str, name: str, value: str) -> None:
        value = value.strip()
        if not value:
            raise ValueError("Secret value must not be empty.")
        account = self._account(owner_id, name)
        if self._keyring is not None:
            try:
                self._keyring.set_password(self.service_name, account, value)
                return
            except Exception:
                pass
        path = self._fallback_path(owner_id, name)
        payload = {
            "account": account,
            "value": base64.b64encode(value.encode("utf-8")).decode("ascii"),
            "nonce": secrets.token_hex(8),
            "warning": "Base64 is not encryption; access is protected by filesystem permissions.",
        }
        path.write_text(json.dumps(payload), encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def set_external(self, name: str, value: str) -> SecretResolution:
        """Atomically replace the configured authoritative TXT credential.

        The destination path is never supplied by the caller; it must already be
        present in the installer-managed reference configuration.
        """

        reference = get_file_reference(self.root, name)
        if not reference:
            raise ValueError(f"No external TXT reference is configured for secret '{name}'.")
        reference_path = Path(str(reference.get("path") or "")).expanduser().resolve(strict=True)
        if not reference_path.is_file():
            raise ValueError(f"The configured credential reference is not a regular file: {reference_path}")
        normalized = normalize_api_key_text(
            value,
            reject_session_token=(name == "openwebui_api_key"),
        )
        temporary = reference_path.with_name(reference_path.name + ".autogenbook.tmp")
        try:
            temporary.write_text(normalized + "\n", encoding="utf-8", newline="\n")
            try:
                mode = reference_path.stat().st_mode & 0o777
                os.chmod(temporary, mode)
            except OSError:
                pass
            os.replace(temporary, reference_path)
        finally:
            temporary.unlink(missing_ok=True)
        return SecretResolution(
            value=normalized,
            source="external_text_file",
            reference_path=str(reference_path),
        )

    def _direct_value(self, owner_id: str, name: str) -> str | None:
        account = self._account(owner_id, name)
        if self._keyring is not None:
            try:
                value = self._keyring.get_password(self.service_name, account)
                if value:
                    return value.strip()
            except Exception:
                pass
        path = self._fallback_path(owner_id, name)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            value = base64.b64decode(payload["value"]).decode("utf-8").strip()
            return value or None
        except Exception:
            return None

    def _external_resolution(self, name: str, reference: dict[str, object]) -> SecretResolution:
        reference_path = str(reference.get("path") or "")
        try:
            loaded = read_api_key_file(
                reference_path,
                reject_session_token=(name == "openwebui_api_key"),
            )
        except ApiKeyFileError as exc:
            return SecretResolution(
                value=None,
                source="external_text_file",
                reference_path=reference_path or None,
                error=str(exc),
            )
        return SecretResolution(
            value=loaded.value,
            source="external_text_file",
            reference_path=str(loaded.path),
        )

    def resolve(self, owner_id: str, name: str) -> SecretResolution:
        try:
            reference = get_file_reference(self.root, name)
        except ApiKeyFileError as exc:
            return SecretResolution(value=None, source="external_text_file", error=str(exc))

        priority = str((reference or {}).get("priority") or "stored_first").strip().casefold()
        if priority not in {"stored_first", "external_first"}:
            priority = "stored_first"

        # An installer-managed key-file reference is authoritative.  Returning its
        # validation error (instead of silently falling back) is intentional: an
        # unreadable/rotated file must be visible and must never revive a stale key.
        if reference and priority == "external_first":
            return self._external_resolution(name, reference)

        direct = self._direct_value(owner_id, name)
        if direct:
            return SecretResolution(value=direct, source="stored_per_user")

        if reference:
            return self._external_resolution(name, reference)
        return SecretResolution(value=None, source="missing")

    def get(self, owner_id: str, name: str) -> str | None:
        return self.resolve(owner_id, name).value

    def exists(self, owner_id: str, name: str) -> bool:
        return bool(self.resolve(owner_id, name).value)

    def status(self, owner_id: str, name: str) -> dict[str, str | bool | None]:
        resolution = self.resolve(owner_id, name)
        return {
            "name": name,
            "exists": bool(resolution.value),
            "backend": self.backend_name,
            "source": resolution.source,
            "reference_path": resolution.reference_path,
            "error": resolution.error,
        }

    def delete(self, owner_id: str, name: str) -> None:
        """Delete only the per-user override; a global TXT reference is retained."""

        account = self._account(owner_id, name)
        if self._keyring is not None:
            try:
                self._keyring.delete_password(self.service_name, account)
            except Exception:
                pass
        self._fallback_path(owner_id, name).unlink(missing_ok=True)


def redact_text(text: str, secrets_to_hide: Iterable[str | None]) -> str:
    redacted = text
    for value in secrets_to_hide:
        if value and len(value) >= 4:
            redacted = redacted.replace(value, "***REDACTED***")
    return redacted
