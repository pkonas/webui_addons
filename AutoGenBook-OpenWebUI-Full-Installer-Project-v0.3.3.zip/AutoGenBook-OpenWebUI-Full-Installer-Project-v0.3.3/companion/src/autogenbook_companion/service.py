from __future__ import annotations

import asyncio
import hashlib
import hmac
import html
import ipaddress
import json
import mimetypes
import os
import re
import shutil
import socket
import time

from contextlib import asynccontextmanager
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, AsyncIterator, Iterable, Literal
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import (
    HTTPRedirectHandler,
    ProxyHandler,
    Request as UrlRequest,
    build_opener,
    urlopen,
)

from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, Request, Response, UploadFile, status
from fastapi.responses import JSONResponse, StreamingResponse

from autogenbook.reviewer_kb1_quality import (
    assess_file as assess_reviewer_kb1_file,
    assess_text as assess_reviewer_kb1_text,
    authentication_url_reasons,
    is_metadata_sidecar,
)

from .config import Settings
from .database import Database
from .models import (
    ArtifactView,
    CapabilitiesResponse,
    HealthResponse,
    JobCreate,
    JobEvent,
    JobProgress,
    JobStatus,
    JobView,
    ProjectCreate,
    ProjectPatch,
    ProjectSpec,
    ProjectView,
    ProviderProfile,
    ProviderValidationRequest,
    ProviderValidationResponse,
    ReviewerContext,
    ReviewerKb1Candidate,
    ReviewerKb1DiscoveryRequest,
    ReviewerKb1DiscoveryResponse,
    ReviewerKb1ImportRequest,
    SecretBody,
    StoredFileView,
    ValidationIssue,
    ValidationResponse,
)
from .runner import AutoGenBookRunner
from .progress import load_progress
from .security import SecretStore, ensure_within, normalize_owner_id, owner_storage_key, safe_filename, secret_fingerprint, sha256_file
from .version import PROTOCOL_VERSION, __version__



def _download_signature(signing_key: str, artifact_id: str, owner: str, expires: int) -> str:
    payload = f"{artifact_id}\n{owner}\n{expires}".encode("utf-8")
    return hmac.new(signing_key.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def _valid_download_signature(
    signing_key: str,
    artifact_id: str,
    owner: str,
    expires: int | None,
    signature: str | None,
) -> bool:
    if not signature or expires is None or expires < int(time.time()):
        return False
    expected = _download_signature(signing_key, artifact_id, owner, expires)
    return hmac.compare_digest(expected, signature)


def _parse_range(value: str, size: int) -> tuple[int, int] | None:
    value = value.strip()
    if not value:
        return None
    if not value.startswith("bytes=") or "," in value:
        raise ValueError("Podporován je právě jeden byte range.")
    start_text, sep, end_text = value[6:].partition("-")
    if not sep or (not start_text and not end_text):
        raise ValueError("Neplatný Range header.")
    if size <= 0:
        raise ValueError("Prázdný soubor nemá platný byte range.")
    if not start_text:
        length = int(end_text)
        if length <= 0:
            raise ValueError("Neplatný suffix range.")
        start = max(0, size - length)
        end = size - 1
    else:
        start = int(start_text)
        end = int(end_text) if end_text else size - 1
    if start < 0 or start >= size or end < start:
        raise ValueError("Požadovaný rozsah je mimo soubor.")
    return start, min(end, size - 1)


def _file_chunks(path: Path, start: int, end: int, chunk_size: int = 1024 * 1024) -> Iterable[bytes]:
    remaining = max(0, end - start + 1)
    with path.open("rb") as stream:
        stream.seek(start)
        while remaining:
            chunk = stream.read(min(chunk_size, remaining))
            if not chunk:
                break
            remaining -= len(chunk)
            yield chunk


def _artifact_etag(row: dict[str, Any], path: Path) -> str:
    digest = str(row.get("sha256") or "").strip()
    if digest:
        return f'"sha256-{digest}"'
    stat = path.stat()
    return f'"file-{stat.st_size:x}-{stat.st_mtime_ns:x}"'


class JobManager:
    def __init__(self, runner: AutoGenBookRunner, database: Database, concurrency: int = 1) -> None:
        self.runner = runner
        self.database = database
        self.concurrency = max(1, concurrency)
        self.queue: asyncio.Queue[str | None] = asyncio.Queue()
        self.tasks: list[asyncio.Task[None]] = []
        self.enqueued: set[str] = set()
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        queued = await asyncio.to_thread(self.database.recover_after_restart)
        for _ in range(self.concurrency):
            self.tasks.append(asyncio.create_task(self._worker()))
        for job_id in queued:
            await self.enqueue(job_id)

    async def stop(self) -> None:
        for _ in self.tasks:
            await self.queue.put(None)
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.tasks.clear()

    async def enqueue(self, job_id: str) -> None:
        async with self._lock:
            if job_id in self.enqueued:
                return
            self.enqueued.add(job_id)
            await self.queue.put(job_id)

    async def _worker(self) -> None:
        while True:
            job_id = await self.queue.get()
            if job_id is None:
                self.queue.task_done()
                return
            try:
                await self.runner.run(job_id)
            finally:
                async with self._lock:
                    self.enqueued.discard(job_id)
                self.queue.task_done()


def capabilities_payload() -> dict[str, Any]:
    common = {
        "language": {"type": "string", "default": "cs"},
        "brief": {"type": "string", "minLength": 1},
        "outputs": {
            "type": "array",
            "items": {"enum": ["md", "docx", "tex", "pdf", "pptx", "audio", "video", "zip"]},
        },
        "web_rag": {"type": "boolean", "default": False},
        "audit_mode": {"enum": ["off", "warn", "strict"], "default": "warn"},
    }
    return {
        "book": {"required": ["brief"], "properties": {**common, "length": {"type": "integer", "minimum": 1}}},
        "paper": {
            "required": ["brief"],
            "properties": {
                **common,
                "paper_venue": {"type": "string", "default": "arXiv"},
                "citation_style": {"enum": ["bibtex", "footnote"], "default": "bibtex"},
            },
        },
        "presentation": {
            "required": ["brief"],
            "properties": {
                **common,
                "length": {"type": "integer", "minimum": 3, "maximum": 100, "default": 12},
                "images": {"type": "boolean", "default": True},
                "citations": {"type": "boolean", "default": False},
                "narration": {"type": "boolean", "default": False},
                "tts": {"type": "boolean", "default": False},
                "video": {"type": "boolean", "default": False},
            },
        },
        "scientist": {"required": ["brief"], "properties": {**common, "max_iters": {"type": "integer", "minimum": 1}}},
        "proposal": {
            "required": ["brief"],
            "properties": {
                **common,
                "max_iters": {"type": "integer", "minimum": 1, "default": 3},
                "section_retries": {"type": "integer", "minimum": 1, "default": 3},
                "min_section_citations": {"type": "integer", "minimum": 0, "default": 1},
            },
        },
        "reviewer": {
            "required": ["kb1", "kb2"],
            "properties": {
                **common,
                "reviewer_profile": {
                    "enum": ["direct", "hybrid", "compliance"],
                    "default": "direct",
                },
                "reviewer_direct_pdf": {"type": "boolean", "default": True},
                "reviewer_allow_missing_kb1": {"type": "boolean", "default": False},
                "reviewer_evidence_max_chars": {"type": "integer", "minimum": 12000, "default": 60000},
                "reviewer_kb1_context_max_chars": {"type": "integer", "minimum": 4000, "default": 48000},
                "reviewer_evidence_per_criterion": {"type": "integer", "minimum": 1, "default": 6},
                "reviewer_max_output_tokens": {"type": "integer", "minimum": 2048, "default": 32768},
                "reviewer_quality_gate": {"type": "boolean", "default": True},
                "reviewer_pdf_engine": {
                    "enum": ["auto", "lualatex", "xelatex", "pdflatex"],
                    "default": "auto",
                },
                "reviewer_kb1_policy": {
                    "enum": ["ask_or_search", "require_source", "allow_without_kb1"],
                    "default": "ask_or_search",
                },
            },
        },
    }


def _project_view(row: dict[str, Any]) -> ProjectView:
    return ProjectView(
        id=row["id"],
        owner_id=row["owner_id"],
        status=row["status"],
        spec=ProjectSpec.model_validate(row["spec"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _file_view(row: dict[str, Any]) -> StoredFileView:
    return StoredFileView(
        id=row["id"],
        project_id=row["project_id"],
        role=row["role"],
        filename=row["filename"],
        size=row["size"],
        sha256=row["sha256"],
        created_at=row["created_at"],
    )


def _job_view(row: dict[str, Any]) -> JobView:
    return JobView(
        id=row["id"],
        owner_id=row["owner_id"],
        project_id=row["project_id"],
        idempotency_key=row["idempotency_key"],
        status=JobStatus(row["status"]),
        mode=row["mode"],
        out_dir=row.get("out_dir"),
        pid=row.get("pid"),
        exit_code=row.get("exit_code"),
        error=row.get("error"),
        cancel_requested=bool(row.get("cancel_requested")),
        created_at=row["created_at"],
        started_at=row.get("started_at"),
        finished_at=row.get("finished_at"),
    )


def _artifact_view(row: dict[str, Any]) -> ArtifactView:
    payload = {key: row.get(key) for key in ArtifactView.model_fields}
    return ArtifactView(**payload)



def _model_ids(value: Any, *, limit: int = 2000) -> list[str]:
    rows: list[str] = []

    def visit(item: Any) -> None:
        if len(rows) >= limit:
            return
        if isinstance(item, dict):
            identifier = str(item.get("id") or item.get("model_id") or item.get("model") or "").strip()
            if identifier and identifier not in rows:
                rows.append(identifier)
            for key in ("data", "models", "items", "results"):
                if key in item:
                    visit(item[key])
        elif isinstance(item, (list, tuple, set)):
            for child in item:
                visit(child)
                if len(rows) >= limit:
                    break

    visit(value)
    return rows


def _normalized_provider_base_url(value: str | None) -> str | None:
    raw = str(value or "").strip().rstrip("/")
    if not raw:
        return None
    parsed = urlsplit(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.query or parsed.fragment:
        return None
    return raw


def _looks_like_session_token(value: str) -> bool:
    token = value.strip()
    if token.startswith("sk-"):
        return False
    parts = token.split(".")
    return len(parts) == 3 and all(parts)

_REVIEWER_SOURCE_MAX_BYTES = 32 * 1024 * 1024
_REVIEWER_SOURCE_PROBE_BYTES = 256 * 1024
_REVIEWER_URL_RE = re.compile(r"https?://[^\\s<>\\]\[(){}\"']+", re.IGNORECASE)


class _HtmlTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.title_parts: list[str] = []
        self._skip_depth = 0
        self._in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        folded = tag.casefold()
        if folded in {"script", "style", "noscript", "svg"}:
            self._skip_depth += 1
        if folded == "title":
            self._in_title = True
        if folded in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        folded = tag.casefold()
        if folded in {"script", "style", "noscript", "svg"} and self._skip_depth:
            self._skip_depth -= 1
        if folded == "title":
            self._in_title = False
        if folded in {"p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip_depth:
            return
        compact = " ".join(data.split())
        if not compact:
            return
        self.parts.append(compact + " ")
        if self._in_title:
            self.title_parts.append(compact)

    def result(self) -> tuple[str, str]:
        body = "\n".join(line.strip() for line in "".join(self.parts).splitlines() if line.strip())
        title = " ".join(self.title_parts).strip()
        return body, title


def _validate_public_source_url(value: str) -> str:
    raw = str(value or "").strip()
    parsed = urlsplit(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Zdroj musí být platná HTTP/HTTPS URL.")
    if parsed.username or parsed.password:
        raise ValueError("URL s vloženými přihlašovacími údaji není dovolena.")
    if parsed.port not in {None, 80, 443}:
        raise ValueError("Pro externí KB1 zdroje jsou povoleny pouze porty 80 a 443.")
    hostname = parsed.hostname.rstrip(".")
    if not hostname:
        raise ValueError("URL neobsahuje platný hostname.")
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        addresses = socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError(f"Hostname zdroje nelze přeložit: {hostname}") from exc
    if not addresses:
        raise ValueError(f"Hostname zdroje nemá žádnou IP adresu: {hostname}")
    for item in addresses:
        address = item[4][0].split("%", 1)[0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError as exc:
            raise ValueError(f"Zdroj má neplatnou IP adresu: {address}") from exc
        if not ip.is_global:
            raise ValueError("Soukromé, lokální, link-local a rezervované adresy nejsou pro KB1 URL povoleny.")
    return raw


class _PublicRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> Any:
        checked = _validate_public_source_url(urljoin(req.full_url, newurl))
        return super().redirect_request(req, fp, code, msg, headers, checked)


def _public_url_opener() -> Any:
    # Ignore environment proxies: a proxy could turn an otherwise public URL into
    # an unintended route to private infrastructure.
    return build_opener(ProxyHandler({}), _PublicRedirectHandler())


def _read_bounded_response(response: Any, max_bytes: int) -> bytes:
    declared = response.headers.get("Content-Length")
    if declared:
        try:
            if int(declared) > max_bytes:
                raise ValueError(f"Zdroj je větší než povolený limit {max_bytes} B.")
        except ValueError as exc:
            if "větší" in str(exc):
                raise
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = response.read(min(1024 * 1024, max_bytes - total + 1))
        if not chunk:
            break
        total += len(chunk)
        if total > max_bytes:
            raise ValueError(f"Zdroj je větší než povolený limit {max_bytes} B.")
        chunks.append(chunk)
    return b"".join(chunks)


def _fetch_public_source(value: str, *, max_bytes: int = _REVIEWER_SOURCE_MAX_BYTES) -> tuple[bytes, str, str, str]:
    checked = _validate_public_source_url(value)
    request = UrlRequest(
        checked,
        method="GET",
        headers={
            "Accept": "application/pdf,text/html,text/plain,text/markdown,application/vnd.openxmlformats-officedocument.wordprocessingml.document;q=0.9,*/*;q=0.1",
            "User-Agent": "AutoGenBook-Reviewer-KB1/0.3.3",
        },
    )
    opener = _public_url_opener()
    with opener.open(request, timeout=30.0) as response:
        final_url = _validate_public_source_url(str(response.geturl()))
        status_code = int(getattr(response, "status", 200))
        if status_code >= 400:
            raise ValueError(f"Zdroj vrátil HTTP {status_code}.")
        content_type = str(response.headers.get_content_type() or "application/octet-stream").casefold()
        payload = _read_bounded_response(response, max_bytes)
    title = ""
    if content_type in {"text/html", "application/xhtml+xml"}:
        parser = _HtmlTextExtractor()
        parser.feed(payload.decode("utf-8", errors="replace"))
        _body, title = parser.result()
    return payload, content_type, final_url, title


def _source_payload_to_file(
    payload: bytes,
    content_type: str,
    final_url: str,
    title: str,
    requested_filename: str | None = None,
) -> tuple[str, bytes, str]:
    path_name = Path(urlsplit(final_url).path).name
    filename = safe_filename(requested_filename or path_name or "reviewer_kb1_source")
    if content_type == "application/pdf" or payload.startswith(b"%PDF-"):
        if not filename.lower().endswith(".pdf"):
            filename += ".pdf"
        return filename, payload, "application/pdf"
    if content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        if not filename.lower().endswith(".docx"):
            filename += ".docx"
        return filename, payload, content_type
    if content_type in {"text/html", "application/xhtml+xml"}:
        parser = _HtmlTextExtractor()
        parser.feed(payload.decode("utf-8", errors="replace"))
        body, parsed_title = parser.result()
        display_title = title or parsed_title or final_url
        document = (
            f"# {display_title}\n\n"
            f"- Zdroj: {final_url}\n"
            f"- Importováno: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n\n"
            f"{body}\n"
        ).encode("utf-8")
        stem = Path(filename).stem or "reviewer_kb1_source"
        return safe_filename(stem + ".md"), document, "text/markdown"
    text_value = payload.decode("utf-8-sig", errors="replace").strip()
    document = (
        f"# Hodnoticí předpis / kritéria\n\n"
        f"- Zdroj: {final_url}\n"
        f"- Importováno: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n\n"
        f"{text_value}\n"
    ).encode("utf-8")
    stem = Path(filename).stem or "reviewer_kb1_source"
    return safe_filename(stem + ".md"), document, "text/markdown"


def _extract_chat_content(payload: Any) -> str:
    if not isinstance(payload, dict):
        return ""
    choices = payload.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message") if isinstance(choices[0], dict) else None
        if isinstance(message, dict):
            content = message.get("content")
            if isinstance(content, str):
                return content.strip()
            if isinstance(content, list):
                return "\n".join(
                    str(item.get("text") or item.get("content") or "")
                    for item in content
                    if isinstance(item, dict)
                ).strip()
    return str(payload.get("content") or payload.get("response") or "").strip()


def _json_from_text(value: str) -> Any:
    text_value = value.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text_value, re.IGNORECASE | re.DOTALL)
    if fenced:
        text_value = fenced.group(1)
    else:
        start = text_value.find("{")
        end = text_value.rfind("}")
        if start >= 0 and end > start:
            text_value = text_value[start : end + 1]
    try:
        return json.loads(text_value)
    except Exception:
        return None


def _official_likelihood(url: str, context: ReviewerContext, title: str = "") -> Literal["high", "medium", "unknown"]:
    if authentication_url_reasons(url):
        return "unknown"
    host = (urlsplit(url).hostname or "").casefold()
    compact_host = re.sub(r"[^a-z0-9]", "", host)
    institution_tokens = [
        token for token in re.findall(r"[a-z0-9]+", context.institution.casefold()) if len(token) >= 3
    ]
    government = host.endswith(".gov") or ".gov." in host or host.endswith(".gov.cz")
    academic = any(marker in host for marker in (".edu", ".ac.", "university", "universita"))
    institution_match = any(token in compact_host for token in institution_tokens)
    title_folded = title.casefold()
    topical = any(token in title_folded for token in ("závěreč", "zaverec", "thesis", "hodnoc", "assessment", "review", "směrnic", "smernic", "vyhlášk", "vyhlask", "metodik", "řád", "rad"))
    if government or institution_match or (academic and topical):
        return "high"
    if academic or topical:
        return "medium"
    return "unknown"


def _probe_public_source(url: str) -> tuple[bool, str, str]:
    """Verify that a candidate is public and not an authentication/error page.

    HEAD is sufficient only for binary documents. HTML and textual sources are
    always sampled with GET and subjected to the same fail-closed quality gate
    used by the full importer.
    """

    checked = _validate_public_source_url(url)
    opener = _public_url_opener()
    for method in ("HEAD", "GET"):
        headers = {"User-Agent": "AutoGenBook-Reviewer-KB1/0.3.3"}
        if method == "GET":
            headers["Range"] = f"bytes=0-{_REVIEWER_SOURCE_PROBE_BYTES - 1}"
        request = UrlRequest(checked, method=method, headers=headers)
        try:
            with opener.open(request, timeout=20.0) as response:
                final_url = _validate_public_source_url(str(response.geturl()))
                if authentication_url_reasons(final_url):
                    return False, final_url, ""
                status_code = int(getattr(response, "status", 200))
                if status_code >= 400:
                    continue
                content_type = str(
                    response.headers.get_content_type() or "application/octet-stream"
                ).casefold()
                title = Path(urlsplit(final_url).path).name or (
                    urlsplit(final_url).hostname or final_url
                )
                textual = content_type in {
                    "text/html",
                    "application/xhtml+xml",
                    "text/plain",
                    "text/markdown",
                }
                if method == "HEAD" and textual:
                    continue
                if method == "GET" and textual:
                    payload = response.read(_REVIEWER_SOURCE_PROBE_BYTES)
                    if content_type in {"text/html", "application/xhtml+xml"}:
                        parser = _HtmlTextExtractor()
                        parser.feed(payload.decode("utf-8", errors="replace"))
                        body, parsed_title = parser.result()
                        title = parsed_title or title
                    else:
                        body = payload.decode("utf-8-sig", errors="replace")
                    quality = assess_reviewer_kb1_text(
                        body,
                        source_name=title,
                        source_url=final_url,
                        title=title,
                        source_kind="url",
                    )
                    if not quality.valid:
                        return False, final_url, title
                return True, final_url, title
        except HTTPError as exc:
            if method == "HEAD" and int(exc.code) in {400, 403, 405, 501}:
                continue
            return False, checked, ""
        except Exception:
            if method == "HEAD":
                continue
            return False, checked, ""
    return False, checked, ""


def _reviewer_search_query(context: ReviewerContext) -> str:
    parts = [
        context.jurisdiction,
        context.institution,
        context.faculty or "",
        context.work_type,
        context.programme or "",
        "hodnocení závěrečných prací směrnice vyhláška pravidla posudek",
    ]
    return " ".join(part for part in parts if part).strip()


async def discover_reviewer_kb1_sources(
    request: ReviewerKb1DiscoveryRequest,
    provider: ProviderProfile,
    secret_store: SecretStore,
    owner_id: str,
) -> ReviewerKb1DiscoveryResponse:
    query = _reviewer_search_query(request.context)
    if provider.type != "openwebui":
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="WEB_SEARCH_REQUIRES_OPENWEBUI",
            message=(
                "Automatické dohledání KB1 je dostupné pouze přes Open WebUI provider s nakonfigurovaným "
                "webovým vyhledáváním. Nahrajte předpis, vložte jeho URL nebo přepněte provider."
            ),
        )
    validation = await validate_provider_profile(provider, secret_store, owner_id)
    if not validation.valid:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code=validation.code,
            message=validation.message,
        )
    secret = secret_store.resolve(owner_id, provider.api_key_secret).value
    base_url = _normalized_provider_base_url(provider.base_url)
    if not secret or not base_url:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="PROVIDER_NOT_READY",
            message="Open WebUI provider nebo jeho API klíč není připraven.",
        )
    system_prompt = (
        "Jsi rešeršní pomocník pro sestavení KB1 odborného posudku závěrečné práce. "
        "Vyhledej pouze veřejné, pokud možno oficiální předpisy instituce, fakulty nebo státu, "
        "které skutečně upravují hodnocení, obhajobu, posudky nebo požadavky na závěrečné práce. "
        "Nevymýšlej URL. Vrať výhradně JSON objekt s polem candidates; každá položka musí mít "
        "title, url, source_name, document_type a reason. Pokud kontext nestačí nebo žádný předpis "
        "nelze ověřit, vrať prázdné candidates a vysvětlení v message."
    )
    user_prompt = (
        f"Jurisdikce: {request.context.jurisdiction}\n"
        f"Instituce: {request.context.institution}\n"
        f"Fakulta/součást: {request.context.faculty or 'neuvedena'}\n"
        f"Typ práce: {request.context.work_type}\n"
        f"Program/obor: {request.context.programme or 'neuveden'}\n"
        f"Dotaz: {query}\n"
        f"Maximálně {request.max_candidates} kandidátů."
    )
    body = {
        "model": provider.model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "temperature": 0,
        "features": {"web_search": True},
    }

    def post() -> tuple[int, str]:
        raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request_obj = UrlRequest(
            base_url + "/chat/completions",
            data=raw,
            method="POST",
            headers={
                "Authorization": f"Bearer {secret}",
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json",
                "User-Agent": "AutoGenBook-Reviewer-KB1/0.3.3",
            },
        )
        opener = build_opener(ProxyHandler({}))
        try:
            with opener.open(request_obj, timeout=120.0) as response:
                return int(getattr(response, "status", 200)), response.read().decode("utf-8", errors="replace")
        except HTTPError as exc:
            return int(exc.code), exc.read().decode("utf-8", errors="replace")

    try:
        status_code, response_text = await asyncio.to_thread(post)
    except Exception as exc:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="WEB_SEARCH_FAILED",
            message=f"Webové vyhledávání se nepodařilo spustit: {type(exc).__name__}: {exc}",
        )
    if status_code >= 400:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="WEB_SEARCH_HTTP_ERROR",
            message=f"Open WebUI web search vrátil HTTP {status_code}: {response_text[:500]}",
        )
    try:
        response_payload = json.loads(response_text)
    except Exception:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="WEB_SEARCH_PROTOCOL_ERROR",
            message="Open WebUI web search nevrátil platný JSON.",
        )
    content = _extract_chat_content(response_payload)
    parsed = _json_from_text(content)
    candidate_rows: list[dict[str, Any]] = []
    if isinstance(parsed, dict) and isinstance(parsed.get("candidates"), list):
        candidate_rows = [item for item in parsed["candidates"] if isinstance(item, dict)]
    if not candidate_rows:
        candidate_rows = [{"url": match.group(0), "title": match.group(0)} for match in _REVIEWER_URL_RE.finditer(content)]

    candidates: list[ReviewerKb1Candidate] = []
    seen: set[str] = set()
    for row in candidate_rows:
        raw_url = str(row.get("url") or row.get("link") or "").rstrip(".,;:)")
        if not raw_url:
            continue
        try:
            verified, final_url, probed_title = await asyncio.to_thread(_probe_public_source, raw_url)
        except Exception:
            continue
        if not verified or final_url in seen:
            continue
        seen.add(final_url)
        title = str(row.get("title") or probed_title or final_url).strip()
        candidates.append(
            ReviewerKb1Candidate(
                title=title,
                url=final_url,
                source_name=str(row.get("source_name") or (urlsplit(final_url).hostname or "")).strip() or None,
                document_type=str(row.get("document_type") or "").strip() or None,
                reason=str(row.get("reason") or "").strip() or None,
                official_likelihood=_official_likelihood(final_url, request.context, title),
                verified_http=True,
                quality_code="URL_PROBE_OK",
            )
        )
        if len(candidates) >= request.max_candidates:
            break
    if not candidates:
        return ReviewerKb1DiscoveryResponse(
            query=query,
            code="NO_VERIFIABLE_SOURCES",
            message=(
                "Webové vyhledávání nevrátilo žádný veřejně dostupný a HTTP ověřitelný předpis. "
                "Nahrajte oficiální dokument nebo vložte jeho URL ručně."
            ),
        )
    return ReviewerKb1DiscoveryResponse(
        query=query,
        candidates=candidates,
        code="OK",
        message="Kandidáti byli dohledáni a technicky ověřeni. Před použitím musí uživatel potvrdit výběr.",
    )


async def validate_provider_profile(
    provider: ProviderProfile,
    secret_store: SecretStore,
    owner_id: str,
    *,
    client: Any | None = None,
) -> ProviderValidationResponse:
    provider_type = provider.type
    base_url = _normalized_provider_base_url(provider.base_url)
    model = str(provider.model or "").strip()
    secret_resolution = secret_store.resolve(owner_id, provider.api_key_secret)
    secret = secret_resolution.value

    def result(
        valid: bool,
        code: str,
        message: str,
        *,
        auth_kind: str = "unknown",
        http_status: int | None = None,
        model_available: bool | None = None,
        available_models: list[str] | None = None,
        retryable: bool = False,
    ) -> ProviderValidationResponse:
        return ProviderValidationResponse(
            valid=valid,
            code=code,
            message=message,
            provider_type=provider_type,
            base_url=base_url,
            model=model,
            auth_kind=auth_kind,
            http_status=http_status,
            model_available=model_available,
            available_models=available_models or [],
            retryable=retryable,
            credential_source=secret_resolution.source,
            credential_fingerprint=secret_fingerprint(secret),
            credential_reference_path=secret_resolution.reference_path,
        )

    if base_url is None:
        return result(False, "BASE_URL_INVALID", "Adresa LLM provideru není platná HTTP/HTTPS URL.")

    if provider_type == "openai_compatible":
        # Many local OpenAI-compatible servers accept a dummy key and do not expose /models.
        return result(True, "OK", "OpenAI-compatible provider configuration is syntactically valid.", auth_kind="local")

    if not secret:
        if secret_resolution.error:
            source = secret_resolution.reference_path or "nakonfigurovaný TXT soubor"
            return result(
                False,
                "SECRET_FILE_UNREADABLE",
                (
                    f"Open WebUI API klíč nelze načíst z odkazu {source}: "
                    f"{secret_resolution.error} Upravte TXT soubor nebo znovu spusťte "
                    "Configure-OpenWebUI-ApiKeyFile.cmd."
                ),
                auth_kind="external_text_file",
            )
        return result(
            False,
            "MISSING_SECRET",
            f"Chybí uložený API klíč '{provider.api_key_secret}'.",
            auth_kind="none",
        )

    if provider_type == "openwebui" and _looks_like_session_token(secret):
        return result(
            False,
            "SESSION_TOKEN_NOT_ALLOWED",
            (
                "Byl uložen přihlašovací/session token. Ten pro několikadenní úlohy není vhodný, "
                "protože expiruje. Vytvořte osobní Open WebUI API klíč v Nastavení → Účet → API Keys."
            ),
            auth_kind="session_token",
        )

    if secret_resolution.source == "external_text_file":
        auth_kind = "openwebui_api_key_file" if provider_type == "openwebui" else "api_key_file"
    else:
        auth_kind = "openwebui_api_key" if provider_type == "openwebui" and secret.startswith("sk-") else "api_key"
    endpoint = base_url + "/models"
    response_status: int
    response_text: str
    payload: Any = None

    if client is not None:
        try:
            response = await client.get(
                endpoint,
                headers={"Authorization": f"Bearer {secret}", "Accept": "application/json"},
            )
            response_status = int(response.status_code)
            response_text = str(response.text or "")
            if response_status < 400:
                payload = response.json()
        except Exception as exc:
            return result(
                False,
                "PROVIDER_HTTP_ERROR",
                f"Kontrola provideru selhala: {type(exc).__name__}: {exc}",
                auth_kind=auth_kind,
                retryable=True,
            )
    else:
        def fetch() -> tuple[int, str]:
            request = UrlRequest(
                endpoint,
                method="GET",
                headers={"Authorization": f"Bearer {secret}", "Accept": "application/json"},
            )
            try:
                # Provider validation must use the same proxy-free transport as the
                # detached worker preflight; otherwise the Companion could validate
                # one route and the worker could execute through another.
                opener = build_opener(ProxyHandler({}))
                with opener.open(request, timeout=20.0) as response:
                    body = response.read().decode("utf-8", errors="replace")
                    return int(getattr(response, "status", 200)), body
            except HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                return int(exc.code), body

        try:
            response_status, response_text = await asyncio.to_thread(fetch)
        except (URLError, TimeoutError, OSError) as exc:
            return result(
                False,
                "PROVIDER_UNREACHABLE",
                f"Provider na {base_url} není dostupný: {type(exc).__name__}.",
                auth_kind=auth_kind,
                retryable=True,
            )
        except Exception as exc:
            return result(
                False,
                "PROVIDER_HTTP_ERROR",
                f"Kontrola provideru selhala: {type(exc).__name__}: {exc}",
                auth_kind=auth_kind,
                retryable=True,
            )
        if response_status < 400:
            try:
                payload = json.loads(response_text)
            except Exception:
                payload = None

    if response_status == 401:
        return result(
            False,
            "AUTH_INVALID",
            (
                "Open WebUI API klíč je neplatný, zrušený nebo byl místo něj použit expirovaný session token. "
                "Vytvořte nový osobní API klíč a zkuste úlohu obnovit."
            ),
            auth_kind=auth_kind,
            http_status=401,
        )
    if response_status == 403:
        return result(
            False,
            "AUTH_FORBIDDEN",
            (
                "Open WebUI API klíč nemá potřebné oprávnění. Zkontrolujte ENABLE_API_KEYS, oprávnění uživatele "
                "a případná omezení endpointů /api/models a /api/chat/completions."
            ),
            auth_kind=auth_kind,
            http_status=403,
        )
    if response_status >= 400:
        body = response_text.strip().replace("\n", " ")[:500]
        return result(
            False,
            "PROVIDER_HTTP_ERROR",
            f"Provider vrátil při kontrole /models HTTP {response_status}: {body or 'bez detailu'}",
            auth_kind=auth_kind,
            http_status=response_status,
            retryable=response_status >= 500,
        )

    if payload is None:
        return result(
            False,
            "PROVIDER_PROTOCOL_ERROR",
            "Provider /models nevrátil platný JSON.",
            auth_kind=auth_kind,
            http_status=response_status,
        )

    models = _model_ids(payload)
    model_available = model in models if model and models else None
    if model and models and not model_available:
        return result(
            False,
            "MODEL_UNAVAILABLE",
            f"Model '{model}' není pro tento API klíč v Open WebUI dostupný.",
            auth_kind=auth_kind,
            http_status=response_status,
            model_available=False,
            available_models=models[:200],
        )
    return result(
        True,
        "OK",
        "Provider i trvalý API klíč byly úspěšně ověřeny.",
        auth_kind=auth_kind,
        http_status=response_status,
        model_available=model_available,
        available_models=models[:200],
    )


def validate_project(spec: ProjectSpec, files: list[dict[str, Any]], secret_store: SecretStore, owner_id: str) -> ValidationResponse:
    issues: list[ValidationIssue] = []
    roles = {item["role"] for item in files}
    if not spec.brief.strip() and not ({"input", "structure"} & roles):
        issues.append(
            ValidationIssue(
                severity="error",
                code="MISSING_INPUT",
                field="brief",
                message="Provide a text brief, an input file, or a structure JSON file.",
            )
        )
    if spec.mode.value == "reviewer":
        allow_missing_kb1 = bool(spec.options.get("reviewer_allow_missing_kb1"))
        supported_kb_exts = {".pdf", ".docx", ".pptx", ".md", ".txt"}
        kb1_rows = [item for item in files if item.get("role") == "kb1"]
        kb2_rows = [item for item in files if item.get("role") == "kb2"]
        structural_kb1 = [
            item
            for item in kb1_rows
            if int(item.get("size") or 0) > 0
            and Path(str(item.get("filename") or "")).suffix.casefold() in supported_kb_exts
            and not is_metadata_sidecar(str(item.get("filename") or ""))
        ]
        usable_kb2 = [
            item
            for item in kb2_rows
            if int(item.get("size") or 0) > 0
            and Path(str(item.get("filename") or "")).suffix.casefold() in supported_kb_exts
        ]
        valid_kb1: list[dict[str, Any]] = []
        invalid_kb1: list[tuple[dict[str, Any], Any]] = []
        for item in structural_kb1:
            stored_path = Path(str(item.get("stored_path") or ""))
            report = assess_reviewer_kb1_file(stored_path)
            if report.valid:
                valid_kb1.append(item)
            elif report.code != "REVIEWER_KB1_METADATA_ONLY":
                invalid_kb1.append((item, report))

        if not usable_kb2:
            issues.append(
                ValidationIssue(
                    severity="error",
                    code="MISSING_KB2",
                    field="files",
                    message="Reviewer mode requires a non-empty supported reviewed document in KB2.",
                )
            )

        if not valid_kb1 and not allow_missing_kb1:
            if invalid_kb1:
                priority = {
                    "REVIEWER_KB1_AUTH_PAGE": 0,
                    "REVIEWER_KB1_ACCESS_GATE": 1,
                    "REVIEWER_KB1_UNREADABLE": 2,
                    "REVIEWER_KB1_TOO_SHORT": 3,
                    "REVIEWER_KB1_IRRELEVANT": 4,
                }
                item, report = sorted(
                    invalid_kb1,
                    key=lambda row: priority.get(row[1].code, 99),
                )[0]
                issues.append(
                    ValidationIssue(
                        severity="error",
                        code=report.code,
                        field="files",
                        message=(
                            f"KB1 soubor '{item.get('filename')}' byl odmítnut: {report.message} "
                            f"(skóre {report.score}/100)."
                        ),
                    )
                )
            else:
                kb1_code = "EMPTY_REVIEWER_KB1" if kb1_rows else "MISSING_REVIEWER_KB1"
                kb1_message = (
                    "The supplied reviewer KB1 is empty, unsupported, or otherwise unusable. Replace it with a "
                    "non-empty PDF, DOCX, PPTX, Markdown, or TXT source containing the evaluation rules."
                    if kb1_rows
                    else
                    "Reviewer mode requires KB1 with explicit evaluation rules, an official regulation, "
                    "a rubric, or user-supplied criteria. Attach a source, paste its URL/text, or use the "
                    "guided context-aware lookup in the Open WebUI Pipe."
                )
                issues.append(
                    ValidationIssue(
                        severity="error",
                        code=kb1_code,
                        field="files",
                        message=kb1_message,
                    )
                )
        elif not valid_kb1:
            issues.append(
                ValidationIssue(
                    severity="warning",
                    code="REVIEWER_KB1_EXPLICITLY_WAIVED",
                    field="files",
                    message=(
                        "Reviewer KB1 was explicitly waived. The resulting review must be treated as a "
                        "general qualitative review, not as verified compliance with institutional rules."
                    ),
                )
            )
        elif invalid_kb1:
            rejected = ", ".join(str(item.get("filename") or "soubor") for item, _report in invalid_kb1)
            issues.append(
                ValidationIssue(
                    severity="warning",
                    code="REVIEWER_KB1_REJECTED_SOURCES",
                    field="files",
                    message=(
                        "Některé KB1 zdroje byly odmítnuty a nebudou použity, protože nejsou hodnoticími "
                        f"pravidly nebo jsou přístupovou stránkou: {rejected}."
                    ),
                )
            )
    if spec.mode.value == "proposal":
        if "kb1" not in roles:
            issues.append(
                ValidationIssue(
                    severity="warning",
                    code="MISSING_KB1",
                    field="files",
                    message="No KB1 requirements/call documents were supplied.",
                )
            )
        if "kb2" not in roles:
            issues.append(
                ValidationIssue(
                    severity="warning",
                    code="MISSING_KB2",
                    field="files",
                    message="No KB2 project background documents were supplied.",
                )
            )
    if spec.provider.type in {"openrouter", "openwebui"} and not secret_store.exists(owner_id, spec.provider.api_key_secret):
        issues.append(
            ValidationIssue(
                severity="error",
                code="MISSING_PROVIDER_SECRET",
                field="provider.api_key_secret",
                message=f"The secret '{spec.provider.api_key_secret}' has not been stored.",
            )
        )
    if "pdf" in spec.outputs.formats and not (shutil.which("pandoc") or shutil.which("lualatex")):
        issues.append(
            ValidationIssue(
                severity="warning",
                code="PDF_ENGINE_NOT_SYSTEM_WIDE",
                field="outputs.formats",
                message="No system-wide Pandoc/LaTeX executable was found. A bundled converter may still be available.",
            )
        )
    if ("video" in spec.outputs.formats or spec.options.get("video")) and not shutil.which("ffmpeg"):
        issues.append(
            ValidationIssue(
                severity="warning",
                code="FFMPEG_NOT_FOUND",
                field="outputs.formats",
                message="FFmpeg was not found; video export may fail until the multimedia component is installed.",
            )
        )
    return ValidationResponse(
        valid=not any(issue.severity == "error" for issue in issues),
        issues=issues,
        normalized_spec=spec,
    )


def create_app(settings: Settings | None = None, *, start_workers: bool = True) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.ensure_layout()
    token = settings.get_or_create_token()
    download_signing_key = settings.get_or_create_download_signing_key()
    database = Database(settings.database_path)
    database.init()
    secret_store = SecretStore(settings.secrets_dir)
    runner = AutoGenBookRunner(settings, database, secret_store)
    manager = JobManager(runner, database, settings.concurrency)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.settings = settings
        app.state.database = database
        app.state.secret_store = secret_store
        app.state.job_manager = manager
        if start_workers:
            await manager.start()
        yield
        if start_workers:
            await manager.stop()

    app = FastAPI(
        title="AutoGenBook Companion",
        version=__version__,
        description="Local, authenticated job service used by the AutoGenBook Open WebUI Pipe.",
        lifespan=lifespan,
    )

    async def authenticate(authorization: str | None = Header(default=None)) -> None:
        expected = f"Bearer {token}"
        if authorization != expected:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid companion token.")

    async def owner_id(
        _auth: None = Depends(authenticate),
        x_autogenbook_user: str | None = Header(default=None),
    ) -> str:
        return normalize_owner_id(x_autogenbook_user)

    @app.get("/v1/health", response_model=HealthResponse)
    async def health(_auth: None = Depends(authenticate)) -> HealthResponse:
        available = (settings.source_dir / "main.py").exists()
        return HealthResponse(
            status="ok" if available else "degraded",
            protocol_version=PROTOCOL_VERSION,
            companion_version=__version__,
            autogenbook_available=available,
            source_dir=str(settings.source_dir),
            converters={
                "pandoc": bool(shutil.which("pandoc")),
                "lualatex": bool(shutil.which("lualatex")),
                "ffmpeg": bool(shutil.which("ffmpeg")),
            },
            secret_backend=secret_store.backend_name,
        )

    @app.get("/v1/capabilities", response_model=CapabilitiesResponse)
    async def capabilities(owner: str = Depends(owner_id)) -> CapabilitiesResponse:
        return CapabilitiesResponse(
            protocol_version=PROTOCOL_VERSION,
            modes=capabilities_payload(),
            supported_file_roles=["input", "structure", "kb", "kb1", "kb2"],
            supported_output_formats=["md", "docx", "tex", "pdf", "pptx", "audio", "video", "zip"],
        )

    @app.post("/v1/providers/validate", response_model=ProviderValidationResponse)
    async def validate_provider(
        form: ProviderValidationRequest, owner: str = Depends(owner_id)
    ) -> ProviderValidationResponse:
        return await validate_provider_profile(form.provider, secret_store, owner)

    @app.post("/v1/projects", response_model=ProjectView, status_code=status.HTTP_201_CREATED)
    async def create_project(form: ProjectCreate, owner: str = Depends(owner_id)) -> ProjectView:
        row = await asyncio.to_thread(database.create_project, owner, form.spec)
        return _project_view(row)

    @app.get("/v1/projects/{project_id}", response_model=ProjectView)
    async def get_project(project_id: str, owner: str = Depends(owner_id)) -> ProjectView:
        row = await asyncio.to_thread(database.get_project, project_id, owner)
        if not row:
            raise HTTPException(status_code=404, detail="Project not found.")
        return _project_view(row)

    @app.patch("/v1/projects/{project_id}", response_model=ProjectView)
    async def patch_project(project_id: str, form: ProjectPatch, owner: str = Depends(owner_id)) -> ProjectView:
        row = await asyncio.to_thread(database.update_project, project_id, owner, form.spec)
        if not row:
            raise HTTPException(status_code=404, detail="Project not found.")
        return _project_view(row)

    @app.get("/v1/projects/{project_id}/files", response_model=list[StoredFileView])
    async def list_project_files(project_id: str, owner: str = Depends(owner_id)) -> list[StoredFileView]:
        if not await asyncio.to_thread(database.get_project, project_id, owner):
            raise HTTPException(status_code=404, detail="Project not found.")
        rows = await asyncio.to_thread(database.list_files, project_id, owner)
        return [_file_view(row) for row in rows]

    @app.post("/v1/projects/{project_id}/files", response_model=StoredFileView, status_code=201)
    async def upload_project_file(
        project_id: str,
        owner: str = Depends(owner_id),
        role: Literal["input", "structure", "kb", "kb1", "kb2"] = Query("kb"),
        file: UploadFile = File(...),
    ) -> StoredFileView:
        if not await asyncio.to_thread(database.get_project, project_id, owner):
            raise HTTPException(status_code=404, detail="Project not found.")
        filename = safe_filename(file.filename)
        destination_dir = settings.projects_dir / "uploads" / owner / project_id
        destination_dir.mkdir(parents=True, exist_ok=True)
        temporary = destination_dir / f".{time.time_ns()}-{filename}.part"
        size = 0
        try:
            with temporary.open("wb") as stream:
                while True:
                    chunk = await file.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > settings.max_upload_bytes:
                        raise HTTPException(status_code=413, detail="Uploaded file exceeds the configured limit.")
                    stream.write(chunk)
            digest = await asyncio.to_thread(sha256_file, temporary)
            destination = destination_dir / f"{digest[:16]}-{filename}"
            temporary.replace(destination)
            row = await asyncio.to_thread(
                database.add_file,
                project_id=project_id,
                owner_id=owner,
                role=role,
                filename=filename,
                stored_path=str(destination),
                size=size,
                sha256=digest,
            )
            return _file_view(row)
        finally:
            temporary.unlink(missing_ok=True)

    @app.post(
        "/v1/projects/{project_id}/reviewer/kb1/discover",
        response_model=ReviewerKb1DiscoveryResponse,
    )
    async def discover_reviewer_kb1(
        project_id: str,
        form: ReviewerKb1DiscoveryRequest,
        owner: str = Depends(owner_id),
    ) -> ReviewerKb1DiscoveryResponse:
        project = await asyncio.to_thread(database.get_project, project_id, owner)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found.")
        spec = ProjectSpec.model_validate(project["spec"])
        if spec.mode.value != "reviewer":
            raise HTTPException(status_code=409, detail="KB1 discovery is available only for reviewer projects.")
        return await discover_reviewer_kb1_sources(form, spec.provider, secret_store, owner)

    @app.post(
        "/v1/projects/{project_id}/reviewer/kb1/import",
        response_model=StoredFileView,
        status_code=201,
    )
    async def import_reviewer_kb1(
        project_id: str,
        form: ReviewerKb1ImportRequest,
        owner: str = Depends(owner_id),
    ) -> StoredFileView:
        project = await asyncio.to_thread(database.get_project, project_id, owner)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found.")
        spec = ProjectSpec.model_validate(project["spec"])
        if spec.mode.value != "reviewer":
            raise HTTPException(status_code=409, detail="KB1 import is available only for reviewer projects.")

        try:
            destination_dir = settings.projects_dir / "uploads" / owner / project_id
            destination_dir.mkdir(parents=True, exist_ok=True)
            source_url = ""
            source_title = ""

            if form.source_type == "url":
                payload, content_type, final_url, title = await asyncio.to_thread(
                    _fetch_public_source, form.value
                )
                source_url = final_url
                source_title = title
                filename, file_payload, mime = _source_payload_to_file(
                    payload, content_type, final_url, title, form.filename
                )
                if authentication_url_reasons(final_url):
                    raise ValueError(
                        "[REVIEWER_KB1_AUTH_PAGE] URL byla přesměrována na přihlašovací/OAuth endpoint."
                    )

                if content_type in {"text/html", "application/xhtml+xml"}:
                    parser = _HtmlTextExtractor()
                    parser.feed(payload.decode("utf-8", errors="replace"))
                    quality_text, parsed_title = parser.result()
                    source_title = title or parsed_title
                    quality = assess_reviewer_kb1_text(
                        quality_text,
                        source_name=filename,
                        source_url=final_url,
                        title=source_title,
                        source_kind="url",
                    )
                elif mime in {"text/markdown", "text/plain"}:
                    quality = assess_reviewer_kb1_text(
                        payload.decode("utf-8-sig", errors="replace"),
                        source_name=filename,
                        source_url=final_url,
                        title=title,
                        source_kind="url",
                    )
                else:
                    quality_temp = destination_dir / (
                        f".{time.time_ns()}-{safe_filename(filename)}.quality.part{Path(filename).suffix}"
                    )
                    quality_temp.write_bytes(file_payload)
                    try:
                        quality = await asyncio.to_thread(
                            assess_reviewer_kb1_file,
                            quality_temp,
                            source_url=final_url,
                            title=title,
                            source_kind="url",
                        )
                    finally:
                        quality_temp.unlink(missing_ok=True)

                if not quality.valid:
                    raise ValueError(f"[{quality.code}] {quality.message}")
                provenance = {
                    **dict(form.provenance or {}),
                    "source_type": "url",
                    "requested_url": str(form.value),
                    "source_url": final_url,
                    "title": source_title or None,
                    "quality": quality.to_dict(),
                }
            else:
                text_value = str(form.value or "").strip()
                if not text_value:
                    raise ValueError("Text hodnoticích kritérií je prázdný.")
                quality = assess_reviewer_kb1_text(
                    text_value,
                    source_name=form.filename or "reviewer_kb1_user_criteria.md",
                    source_kind="user_text",
                )
                if not quality.valid:
                    raise ValueError(f"[{quality.code}] {quality.message}")
                provenance = {
                    **dict(form.provenance or {}),
                    "source_type": "user_text",
                    "quality": quality.to_dict(),
                }
                provenance_json = json.dumps(provenance, ensure_ascii=False, indent=2)
                document = (
                    "# Hodnoticí předpis / kritéria dodaná uživatelem\n\n"
                    "Tento dokument tvoří KB1 pro reviewer režim. AutoGenBook jej nesmí zaměňovat "
                    "za obecně platnou právní normu, pokud uživatel takovou povahu výslovně neuvedl.\n\n"
                    f"## Provenance\n\n```json\n{provenance_json}\n```\n\n"
                    f"## Kritéria\n\n{text_value}\n"
                )
                filename = safe_filename(form.filename or "reviewer_kb1_user_criteria.md")
                if not filename.lower().endswith((".md", ".txt")):
                    filename += ".md"
                file_payload = document.encode("utf-8")
                mime = "text/markdown"

            digest = hashlib.sha256(file_payload).hexdigest()
            destination = destination_dir / f"{digest[:16]}-{safe_filename(filename)}"
            destination.write_bytes(file_payload)
            try:
                os.chmod(destination, 0o600)
            except OSError:
                pass
            row = await asyncio.to_thread(
                database.add_file,
                project_id=project_id,
                owner_id=owner,
                role="kb1",
                filename=safe_filename(filename),
                stored_path=str(destination),
                size=len(file_payload),
                sha256=digest,
            )

            # Keep provenance and the semantic quality verdict auditable without
            # feeding the metadata sidecar into the reviewer knowledge base.
            provenance_payload = json.dumps(
                {
                    **provenance,
                    "stored_filename": safe_filename(filename),
                    "mime": mime,
                    "imported_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                },
                ensure_ascii=False,
                indent=2,
            ).encode("utf-8")
            provenance_digest = hashlib.sha256(provenance_payload).hexdigest()
            provenance_name = safe_filename(Path(filename).stem + ".provenance.json")
            provenance_path = destination_dir / f"{provenance_digest[:16]}-{provenance_name}"
            provenance_path.write_bytes(provenance_payload)
            try:
                os.chmod(provenance_path, 0o600)
            except OSError:
                pass
            await asyncio.to_thread(
                database.add_file,
                project_id=project_id,
                owner_id=owner,
                role="kb1",
                filename=provenance_name,
                stored_path=str(provenance_path),
                size=len(provenance_payload),
                sha256=provenance_digest,
            )
            await asyncio.to_thread(database.set_project_status, project_id, owner, "DRAFT")
            return _file_view(row)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"KB1 source import failed: {exc}") from exc

    @app.post("/v1/projects/{project_id}/validate", response_model=ValidationResponse)
    async def validate(project_id: str, owner: str = Depends(owner_id)) -> ValidationResponse:
        project = await asyncio.to_thread(database.get_project, project_id, owner)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found.")
        files = await asyncio.to_thread(database.list_files, project_id, owner)
        spec = ProjectSpec.model_validate(project["spec"])
        result = validate_project(spec, files, secret_store, owner)
        issues = list(result.issues)
        if not any(issue.severity == "error" for issue in issues) and spec.provider.type in {"openwebui", "openrouter"}:
            provider_result = await validate_provider_profile(spec.provider, secret_store, owner)
            if not provider_result.valid:
                issues.append(
                    ValidationIssue(
                        severity="error",
                        code=provider_result.code,
                        field="provider",
                        message=provider_result.message,
                    )
                )
        result = ValidationResponse(
            valid=not any(issue.severity == "error" for issue in issues),
            issues=issues,
            normalized_spec=spec,
        )
        await asyncio.to_thread(
            database.set_project_status,
            project_id,
            owner,
            "READY" if result.valid else "DRAFT",
        )
        return result

    @app.post("/v1/jobs", response_model=JobView, status_code=201)
    async def create_job(form: JobCreate, owner: str = Depends(owner_id)) -> JobView:
        project = await asyncio.to_thread(database.get_project, form.project_id, owner)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found.")
        spec = ProjectSpec.model_validate(project["spec"])
        files = await asyncio.to_thread(database.list_files, form.project_id, owner)
        validation = validate_project(spec, files, secret_store, owner)
        if not validation.valid:
            raise HTTPException(
                status_code=422,
                detail={"message": "Project validation failed.", "issues": [item.model_dump() for item in validation.issues]},
            )
        if spec.provider.type in {"openwebui", "openrouter"}:
            provider_result = await validate_provider_profile(spec.provider, secret_store, owner)
            if not provider_result.valid:
                raise HTTPException(
                    status_code=422,
                    detail={
                        "message": "Provider validation failed.",
                        "issues": [
                            {
                                "severity": "error",
                                "code": provider_result.code,
                                "field": "provider",
                                "message": provider_result.message,
                            }
                        ],
                        "provider": provider_result.model_dump(mode="json"),
                    },
                )
        row, created = await asyncio.to_thread(
            database.create_job,
            owner_id=owner,
            project_id=form.project_id,
            idempotency_key=form.idempotency_key,
            mode=spec.mode,
            resume=form.resume,
        )
        if created and start_workers:
            await manager.enqueue(row["id"])
        return _job_view(row)

    @app.get("/v1/jobs", response_model=list[JobView])
    async def list_jobs(owner: str = Depends(owner_id), limit: int = Query(50, ge=1, le=200)) -> list[JobView]:
        rows = await asyncio.to_thread(database.list_jobs, owner, limit)
        return [_job_view(row) for row in rows]

    @app.get("/v1/jobs/{job_id}", response_model=JobView)
    async def get_job(job_id: str, owner: str = Depends(owner_id)) -> JobView:
        row = await asyncio.to_thread(database.get_job, job_id, owner)
        if not row:
            raise HTTPException(status_code=404, detail="Job not found.")
        return _job_view(row)

    @app.get("/v1/jobs/{job_id}/progress", response_model=JobProgress)
    async def get_progress(job_id: str, owner: str = Depends(owner_id)) -> JobProgress:
        row = await asyncio.to_thread(database.get_job, job_id, owner)
        if not row:
            raise HTTPException(status_code=404, detail="Job not found.")
        root = settings.projects_dir / owner_storage_key(owner) / str(row["project_id"]) / job_id
        payload = await asyncio.to_thread(load_progress, root / ".autogenbook-progress.json")
        if payload is None:
            status_value = str(row["status"])
            percent = 100.0 if status_value == JobStatus.succeeded.value else (1.0 if status_value == JobStatus.running.value else 0.0)
            project = await asyncio.to_thread(database.get_project, str(row["project_id"]), owner)
            model = "e-infra.glm-5"
            if project:
                model = str(project.get("spec", {}).get("provider", {}).get("model") or model)
            payload = {
                "job_id": job_id,
                "status": status_value,
                "stage": status_value.lower(),
                "progress": percent,
                "message": row.get("error") or "Stav je uložen v databázi; podrobný progress zatím nebyl zapsán.",
                "model": model,
                "pid": row.get("pid"),
            }
        heartbeat = str(payload.get("heartbeat_at") or "")
        stale = False
        if heartbeat and str(payload.get("status", "")).upper() == "RUNNING":
            try:
                from datetime import datetime, timezone

                timestamp = datetime.fromisoformat(heartbeat.replace("Z", "+00:00"))
                stale = (datetime.now(timezone.utc) - timestamp).total_seconds() > 600
            except Exception:
                stale = False
        payload["stale"] = stale
        return JobProgress.model_validate(payload)

    @app.get("/v1/jobs/{job_id}/events", response_model=list[JobEvent])
    async def get_events(
        job_id: str,
        owner: str = Depends(owner_id),
        after: int = Query(0, ge=0),
        limit: int = Query(500, ge=1, le=2000),
    ) -> list[JobEvent]:
        if not await asyncio.to_thread(database.get_job, job_id, owner):
            raise HTTPException(status_code=404, detail="Job not found.")
        rows = await asyncio.to_thread(database.list_events, job_id, owner, after, limit)
        return [
            JobEvent(
                seq=row["seq"],
                job_id=row["job_id"],
                timestamp=row["timestamp"],
                type=row["type"],
                data=row["data"],
            )
            for row in rows
        ]

    @app.get("/v1/jobs/{job_id}/events/stream")
    async def stream_events(job_id: str, owner: str = Depends(owner_id), after: int = Query(0, ge=0)) -> StreamingResponse:
        if not await asyncio.to_thread(database.get_job, job_id, owner):
            raise HTTPException(status_code=404, detail="Job not found.")

        async def generate() -> AsyncIterator[str]:
            cursor = after
            while True:
                rows = await asyncio.to_thread(database.list_events, job_id, owner, cursor, 500)
                for row in rows:
                    cursor = row["seq"]
                    payload = {
                        "seq": row["seq"],
                        "job_id": row["job_id"],
                        "timestamp": row["timestamp"],
                        "type": row["type"],
                        "data": row["data"],
                    }
                    yield f"id: {cursor}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
                job = await asyncio.to_thread(database.get_job, job_id, owner)
                if job and JobStatus(job["status"]).terminal and not rows:
                    break
                yield ": keepalive\n\n"
                await asyncio.sleep(1)

        return StreamingResponse(generate(), media_type="text/event-stream")

    @app.post("/v1/jobs/{job_id}/cancel", response_model=JobView)
    async def cancel_job(job_id: str, owner: str = Depends(owner_id)) -> JobView:
        if not await asyncio.to_thread(database.request_cancel, job_id, owner):
            raise HTTPException(status_code=404, detail="Job not found.")
        row = await asyncio.to_thread(database.get_job, job_id, owner)
        assert row
        return _job_view(row)

    @app.post("/v1/jobs/{job_id}/resume", response_model=JobView)
    async def resume_job(job_id: str, owner: str = Depends(owner_id)) -> JobView:
        row = await asyncio.to_thread(database.get_job, job_id, owner)
        if not row:
            raise HTTPException(status_code=404, detail="Job not found.")
        if row["status"] not in {
            JobStatus.failed.value,
            JobStatus.cancelled.value,
            JobStatus.interrupted.value,
        }:
            raise HTTPException(status_code=409, detail="Only failed, cancelled or interrupted jobs can be resumed.")
        await asyncio.to_thread(database.requeue_job, job_id, owner)
        if start_workers:
            await manager.enqueue(job_id)
        updated = await asyncio.to_thread(database.get_job, job_id, owner)
        assert updated
        return _job_view(updated)

    @app.get("/v1/jobs/{job_id}/artifacts", response_model=list[ArtifactView])
    async def list_artifacts(
        job_id: str,
        request: Request,
        owner: str = Depends(owner_id),
    ) -> list[ArtifactView]:
        if not await asyncio.to_thread(database.get_job, job_id, owner):
            raise HTTPException(status_code=404, detail="Job not found.")
        rows = await asyncio.to_thread(database.list_artifacts, job_id, owner)
        expires = int(time.time()) + int(settings.download_url_ttl_seconds)
        base = str(request.base_url).rstrip("/")
        result: list[ArtifactView] = []
        for row in rows:
            signature = _download_signature(download_signing_key, str(row["id"]), owner, expires)
            row = dict(row)
            row["download_url"] = (
                f"{base}/v1/artifacts/{row['id']}/download"
                f"?owner={owner}&expires={expires}&signature={signature}"
            )
            row["download_expires_at"] = expires
            row["download_url_kind"] = "temporary"
            row["supports_resume"] = True
            path = Path(str(row["path"]))
            if path.exists():
                row["etag"] = _artifact_etag(row, path)
            result.append(_artifact_view(row))
        return result

    @app.api_route("/v1/artifacts/{artifact_id}/download", methods=["GET", "HEAD"])
    async def download_artifact(
        artifact_id: str,
        request: Request,
        signed_owner: str | None = Query(default=None, alias="owner"),
        expires: int | None = Query(default=None),
        signature: str | None = Query(default=None),
        authorization: str | None = Header(default=None),
        owner_header: str | None = Header(default=None, alias="X-AutoGenBook-User"),
    ) -> Response:
        owner: str
        signed_request = any(value is not None for value in (signed_owner, expires, signature))
        if signed_request:
            if not signed_owner or expires is None or not signature:
                raise HTTPException(status_code=403, detail="Incomplete artifact download signature.")
            if expires < int(time.time()):
                raise HTTPException(
                    status_code=410,
                    detail=(
                        "Artifact download link expired. Return to the AutoGenBook chat and request "
                        "`výstupy <job-id>` to migrate or refresh the file."
                    ),
                )
            valid = _valid_download_signature(
                download_signing_key,
                artifact_id,
                signed_owner,
                expires,
                signature,
            )
            # Backwards compatibility for unexpired links produced before 0.3.1.
            if not valid:
                valid = _valid_download_signature(token, artifact_id, signed_owner, expires, signature)
            if not valid:
                raise HTTPException(status_code=403, detail="Invalid artifact download signature.")
            owner = normalize_owner_id(signed_owner)
        else:
            await authenticate(authorization)
            owner = normalize_owner_id(owner_header or "local")
        row = await asyncio.to_thread(database.get_artifact, artifact_id, owner)
        if not row:
            raise HTTPException(status_code=404, detail="Artifact not found.")
        try:
            path = ensure_within(Path(row["path"]), settings.projects_dir)
        except ValueError as exc:
            raise HTTPException(status_code=403, detail="Artifact path is outside the managed directory.") from exc
        if not path.exists() or not path.is_file():
            raise HTTPException(status_code=410, detail="Artifact file no longer exists.")
        size = path.stat().st_size
        etag = _artifact_etag(row, path)
        range_header = str(request.headers.get("range") or "")
        if_range = str(request.headers.get("if-range") or "")
        if if_range and if_range != etag:
            range_header = ""
        try:
            byte_range = _parse_range(range_header, size)
        except (ValueError, TypeError) as exc:
            raise HTTPException(
                status_code=416,
                detail=str(exc),
                headers={"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"},
            ) from exc
        if byte_range is None:
            start, end = 0, size - 1
            status_code = 200
        else:
            start, end = byte_range
            status_code = 206
        content_length = max(0, end - start + 1)
        headers = {
            "Accept-Ranges": "bytes",
            "Content-Length": str(content_length),
            "Content-Disposition": f'attachment; filename="{safe_filename(str(row["filename"]))}"',
            "Cache-Control": "private, max-age=0, must-revalidate",
            "ETag": etag,
            "X-Content-Type-Options": "nosniff",
        }
        if byte_range is not None:
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        media_type = str(row.get("mime") or mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        if request.method == "HEAD":
            return Response(status_code=status_code, headers=headers, media_type=media_type)
        return StreamingResponse(
            _file_chunks(path, start, end),
            status_code=status_code,
            headers=headers,
            media_type=media_type,
        )

    @app.get("/v1/secrets/{name}/status")
    async def secret_status(name: str, owner: str = Depends(owner_id)) -> dict[str, Any]:
        return await asyncio.to_thread(secret_store.status, owner, name)

    @app.put("/v1/secrets/{name}", status_code=204)
    async def put_secret(name: str, form: SecretBody, owner: str = Depends(owner_id)) -> None:
        if form.target == "external_text_file":
            await asyncio.to_thread(secret_store.set_external, name, form.value)
        else:
            await asyncio.to_thread(secret_store.set, owner, name, form.value)

    @app.delete("/v1/secrets/{name}", status_code=204)
    async def delete_secret(name: str, owner: str = Depends(owner_id)) -> None:
        await asyncio.to_thread(secret_store.delete, owner, name)

    return app
