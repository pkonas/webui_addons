from __future__ import annotations

import dataclasses
import json
import os
import sys
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener
from pathlib import Path


def _preflight_selected_provider() -> None:
    provider_type = os.environ.get("AUTOGENBOOK_PROVIDER_TYPE", "").strip().casefold()
    model = os.environ.get("AUTOGENBOOK_LLM_MODEL", "").strip()
    base_url = os.environ.get("AUTOGENBOOK_LLM_BASE_URL", "").strip().rstrip("/")
    fingerprint = os.environ.get("AUTOGENBOOK_LLM_KEY_FINGERPRINT", "").strip() or "missing"
    source = os.environ.get("AUTOGENBOOK_LLM_SECRET_SOURCE", "").strip() or "missing"
    isolation = os.environ.get("AUTOGENBOOK_CREDENTIAL_ISOLATION", "").strip() or "unknown"
    print(
        f"[PROVIDER] type={provider_type or 'unknown'} model={model or 'unknown'} "
        f"credential_source={source} fingerprint={fingerprint} isolation={isolation}",
        flush=True,
    )
    if provider_type != "openwebui":
        return
    key = os.environ.get("AUTOGENBOOK_LLM_API_KEY", "").strip()
    if not key:
        raise RuntimeError("PROVIDER_AUTH_INVALID: Open WebUI job credential is missing before worker startup.")
    if not base_url:
        raise RuntimeError("PROVIDER_BASE_URL_INVALID: Open WebUI base URL is missing before worker startup.")
    request = Request(
        base_url + "/models",
        method="GET",
        headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
    )
    opener = build_opener(ProxyHandler({}))
    try:
        with opener.open(request, timeout=20.0) as response:
            status = int(getattr(response, "status", 200))
            payload = response.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        status = int(exc.code)
        payload = exc.read().decode("utf-8", errors="replace")
    except (URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(
            "PROVIDER_PREFLIGHT_UNREACHABLE: Open WebUI could not be reached before worker startup: "
            f"{type(exc).__name__}: {exc}"
        ) from exc
    if status == 401:
        raise RuntimeError(
            "PROVIDER_AUTH_INVALID: Open WebUI rejected the exact isolated worker credential (401). "
            f"credential_source={source}; fingerprint={fingerprint}."
        )
    if status == 403:
        raise RuntimeError(
            "PROVIDER_AUTH_FORBIDDEN: Open WebUI denied the exact isolated worker credential (403). "
            f"credential_source={source}; fingerprint={fingerprint}."
        )
    if status >= 400:
        raise RuntimeError(f"PROVIDER_PREFLIGHT_FAILED: Open WebUI /models returned HTTP {status}: {payload[:500]}")
    try:
        parsed = json.loads(payload)
    except Exception as exc:
        raise RuntimeError("PROVIDER_PREFLIGHT_PROTOCOL_ERROR: Open WebUI /models did not return JSON.") from exc
    if isinstance(parsed, dict):
        rows = parsed.get("data") or parsed.get("models") or []
    else:
        rows = parsed
    ids = {str(row.get("id") or row.get("model")) for row in rows or [] if isinstance(row, dict) and (row.get("id") or row.get("model"))}
    if not ids:
        raise RuntimeError("PROVIDER_PREFLIGHT_PROTOCOL_ERROR: Open WebUI /models returned no model identifiers.")
    if model and model not in ids:
        raise RuntimeError(
            f"PROVIDER_MODEL_UNAVAILABLE: selected model {model!r} is not visible to the isolated worker credential."
        )
    print(f"[PROVIDER] preflight=ok visible_models={len(ids)}", flush=True)


def _patch_model_override() -> None:
    forced_model = os.environ.get("AUTOGENBOOK_FORCE_MODEL", "").strip()
    if not forced_model:
        return
    try:
        import openrouter_llm
    except ImportError:
        return

    original_init = openrouter_llm.OpenRouterLLM.__init__

    def patched_init(self, config=None):
        current = config or openrouter_llm.LLMConfig()
        try:
            current = dataclasses.replace(current, model=forced_model)
        except Exception:
            current = openrouter_llm.LLMConfig(
                model=forced_model,
                temperature=getattr(current, "temperature", 0.2),
                max_tokens=getattr(current, "max_tokens", None),
                input_cost_per_million=getattr(current, "input_cost_per_million", None),
                output_cost_per_million=getattr(current, "output_cost_per_million", None),
                base_url=getattr(current, "base_url", None),
                api_key=getattr(current, "api_key", None),
            )
        return original_init(self, current)

    openrouter_llm.OpenRouterLLM.__init__ = patched_init


def main(argv: list[str] | None = None) -> int:
    source_dir = Path(os.environ["AUTOGENBOOK_SOURCE_DIR"]).expanduser().resolve()
    if not (source_dir / "main.py").exists():
        raise RuntimeError(f"AutoGenBook main.py was not found in {source_dir}")
    sys.path.insert(0, str(source_dir))
    os.chdir(source_dir)
    try:
        _preflight_selected_provider()
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr, flush=True)
        return 2
    _patch_model_override()
    import main as autogenbook_main

    return int(autogenbook_main.main(argv or sys.argv[1:]))


if __name__ == "__main__":
    raise SystemExit(main())
