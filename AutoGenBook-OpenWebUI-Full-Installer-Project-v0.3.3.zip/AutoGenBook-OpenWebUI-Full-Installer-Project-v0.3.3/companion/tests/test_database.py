from pathlib import Path

from autogenbook_companion.database import Database
from autogenbook_companion.models import JobStatus, Mode, ProjectSpec


def test_project_and_idempotent_job(tmp_path: Path) -> None:
    db = Database(tmp_path / "jobs.sqlite3")
    db.init()
    project = db.create_project("user", ProjectSpec(mode=Mode.book, brief="Write a test book"))
    job1, created1 = db.create_job(
        owner_id="user",
        project_id=project["id"],
        idempotency_key="abcdefgh-12345678",
        mode=Mode.book,
        resume=False,
    )
    job2, created2 = db.create_job(
        owner_id="user",
        project_id=project["id"],
        idempotency_key="abcdefgh-12345678",
        mode=Mode.book,
        resume=False,
    )
    assert created1 is True
    assert created2 is False
    assert job1["id"] == job2["id"]
    assert job1["status"] == JobStatus.queued.value
