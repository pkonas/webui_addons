from __future__ import annotations

import asyncio
from pathlib import Path

from autogenbook_companion.config import Settings
from autogenbook_companion.database import Database
from autogenbook_companion.models import JobStatus, Mode, OutputOptions, ProjectSpec, ProviderProfile
from autogenbook_companion.runner import AutoGenBookRunner
from autogenbook_companion.security import SecretStore


def test_runner_executes_isolated_worker(tmp_path: Path, monkeypatch) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text(
        """
import argparse
from pathlib import Path

def main(argv=None):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--mode')
    p.add_argument('--out-dir')
    p.add_argument('--input')
    p.add_argument('--use-txt', action='store_true')
    p.add_argument('--no-pdf', action='store_true')
    p.add_argument('--no-tex', action='store_true')
    p.add_argument('--docx', action='store_true')
    p.add_argument('--audit-mode')
    args, _ = p.parse_known_args(argv)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    print('[KB] ready', flush=True)
    (out / 'result.md').write_text('# generated', encoding='utf-8')
    return 0
""",
        encoding="utf-8",
    )
    home = tmp_path / "home"
    settings = Settings(home=home, source_dir=source, port=8765)
    settings.ensure_layout()
    db = Database(settings.database_path)
    db.init()
    secrets = SecretStore(settings.secrets_dir)
    secrets.set("user", "local_key", "test")
    spec = ProjectSpec(
        mode=Mode.book,
        brief="Test",
        outputs=OutputOptions(formats=["md", "zip"]),
        provider=ProviderProfile(type="openai_compatible", base_url="http://localhost:1234/v1", api_key_secret="local_key"),
    )
    project = db.create_project("user", spec)
    job, _ = db.create_job(
        owner_id="user",
        project_id=project["id"],
        idempotency_key="runner-test-12345678",
        mode=Mode.book,
        resume=False,
    )
    runner = AutoGenBookRunner(settings, db, secrets)
    asyncio.run(runner.run(job["id"]))
    final = db.get_job(job["id"], "user")
    assert final is not None
    assert final["status"] == JobStatus.succeeded.value
    artifacts = db.list_artifacts(job["id"], "user")
    assert any(item["filename"] == "result.md" for item in artifacts)
    assert any(item["role"] == "bundle" for item in artifacts)


def test_failed_worker_bundle_contains_worker_log_and_failure_metadata(tmp_path: Path) -> None:
    import zipfile

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text(
        """
import argparse
from pathlib import Path

def main(argv=None):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--mode')
    parser.add_argument('--out-dir')
    parser.add_argument('--input')
    parser.add_argument('--use-txt', action='store_true')
    parser.add_argument('--no-pdf', action='store_true')
    parser.add_argument('--no-tex', action='store_true')
    parser.add_argument('--audit-mode')
    args, _ = parser.parse_known_args(argv)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    print('[REVIEWER_KB1_AUTH_PAGE] redirected to OAuth login page', flush=True)
    return 2
""",
        encoding="utf-8",
    )
    home = tmp_path / "home"
    settings = Settings(home=home, source_dir=source, port=8766)
    settings.ensure_layout()
    db = Database(settings.database_path)
    db.init()
    secrets = SecretStore(settings.secrets_dir)
    secrets.set("user", "local_key", "test")
    spec = ProjectSpec(
        mode=Mode.book,
        brief="Test failure diagnostics",
        outputs=OutputOptions(formats=["md", "zip"]),
        provider=ProviderProfile(
            type="openai_compatible",
            base_url="http://localhost:1234/v1",
            api_key_secret="local_key",
        ),
    )
    project = db.create_project("user", spec)
    job, _ = db.create_job(
        owner_id="user",
        project_id=project["id"],
        idempotency_key="runner-failure-test-12345678",
        mode=Mode.book,
        resume=False,
    )
    runner = AutoGenBookRunner(settings, db, secrets)
    asyncio.run(runner.run(job["id"]))
    final = db.get_job(job["id"], "user")
    assert final is not None
    assert final["status"] == JobStatus.failed.value
    assert "REVIEWER_KB1_AUTH_PAGE" in str(final["error"])

    artifacts = db.list_artifacts(job["id"], "user")
    bundle_row = next(item for item in artifacts if item["role"] == "bundle")
    bundle = Path(bundle_row["path"])
    assert bundle.exists()
    with zipfile.ZipFile(bundle) as archive:
        names = set(archive.namelist())
        assert "_autogenbook_companion/diagnostics/worker.log" in names
        assert "_autogenbook_companion/diagnostics/job_status.json" in names
        assert "_autogenbook_companion/diagnostics/request.json" in names
        assert "_autogenbook_companion/diagnostics/progress.json" in names
        assert "_autogenbook_companion/failure.json" in names
        assert "_autogenbook_companion/failure.md" in names
        assert "_autogenbook_companion/companion_manifest.json" in names
        worker_log = archive.read(
            "_autogenbook_companion/diagnostics/worker.log"
        ).decode("utf-8")
        failure = archive.read("_autogenbook_companion/failure.json").decode("utf-8")
        manifest = archive.read("_autogenbook_companion/companion_manifest.json").decode("utf-8")
    assert "REVIEWER_KB1_AUTH_PAGE" in worker_log
    assert "REVIEWER_KB1_AUTH_PAGE" in failure
    assert '"companion_version"' in manifest
    assert '"status": "FAILED"' in manifest
