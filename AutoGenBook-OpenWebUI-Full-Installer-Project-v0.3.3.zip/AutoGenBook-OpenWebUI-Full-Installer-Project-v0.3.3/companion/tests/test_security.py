from pathlib import Path
import zipfile

import pytest

from autogenbook_companion.security import safe_extract_zip, safe_filename


def test_safe_filename() -> None:
    assert safe_filename("../../bad:name?.pdf").endswith("bad_name_.pdf")


def test_zip_traversal_rejected(tmp_path: Path) -> None:
    archive = tmp_path / "bad.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("../escape.txt", "no")
    with pytest.raises(ValueError):
        safe_extract_zip(archive, tmp_path / "out")


def test_dynamic_port_is_resolved() -> None:
    from autogenbook_companion.config import find_free_port

    port = find_free_port("127.0.0.1", 0)
    assert isinstance(port, int)
    assert 0 < port <= 65535
