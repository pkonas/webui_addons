from pathlib import Path

from fastapi.testclient import TestClient

from autogenbook_companion.config import Settings
from autogenbook_companion.service import create_app


def test_project_api_and_validation(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source, port=8765)
    token = settings.get_or_create_token()
    app = create_app(settings, start_workers=False)
    headers = {"Authorization": f"Bearer {token}", "X-AutoGenBook-User": "user-1"}
    with TestClient(app) as client:
        response = client.get("/v1/health", headers=headers)
        assert response.status_code == 200
        response = client.put(
            "/v1/secrets/openrouter_api_key",
            headers=headers,
            json={"value": "test-key"},
        )
        assert response.status_code == 204
        response = client.post(
            "/v1/projects",
            headers=headers,
            json={
                "spec": {
                    "mode": "book",
                    "brief": "Test book",
                    "provider": {
                        "type": "openai_compatible",
                        "base_url": "http://127.0.0.1:9999/v1",
                        "model": "local-test-model",
                        "api_key_secret": "local_no_key",
                    },
                }
            },
        )
        assert response.status_code == 201
        project_id = response.json()["id"]
        response = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert response.status_code == 200
        assert response.json()["valid"] is True
        response = client.post(
            "/v1/jobs",
            headers=headers,
            json={"project_id": project_id, "idempotency_key": "service-test-12345678"},
        )
        assert response.status_code == 201
        assert response.json()["status"] == "QUEUED"
