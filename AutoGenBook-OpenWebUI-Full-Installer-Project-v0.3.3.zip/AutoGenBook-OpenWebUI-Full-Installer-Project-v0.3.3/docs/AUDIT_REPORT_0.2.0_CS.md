# Audit AutoGenBook Open WebUI 0.2.0

- Vygenerováno: `2026-08-19T11:20:25.589123Z`
- Výsledek: **PASS**
- Python: `3.12.13 (main, Mar 10 2026, 18:17:25) [Clang 21.1.4 ]`
- Kontrol: `13`
- Souborů v inventáři: `475`

## Kontroly

| Kontrola | Stav | Detail |
|---|---:|---|
| Povinné projektové soubory | **PASS** | missing=[] |
| README pokrytí | **PASS** | missing_sections=[]; recognized_examples=7; bytes=21427 |
| Konzistence verze | **PASS** | {"pyproject": "0.2.0", "version.py": "0.2.0", "pipe": "0.2.0", "builder": "0.2.0"} |
| Open WebUI modelový a long-job kontrakt | **PASS** | missing=[] |
| Progress a obnovitelné downloady | **PASS** | missing=[] |
| Statická bezpečnost subprocess/loopback | **PASS** | shell_true=[]; public_bind_defaults=[] |
| Odstranění historického patchovacího řetězce | **PASS** | legacy=[] |
| Deterministický Open WebUI bundle | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 tools/build_openwebui_integration.py verify |
| Python compileall | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 -m compileall -q autogenbook companion/src integrations installer build tools |
| Validace Open WebUI Pipe | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 build/validate_pipe.py integrations/openwebui/autogenbook_pipe.py |
| Start CLI a argparse kontrakt | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 main.py --help |
| Konzistence nainstalovaných balíků | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 -m pip check |
| Kompletní pytest sada | **PASS** | exit=0; command=/mnt/data/agb-offline-audit/AutoGenBook-OpenWebUI-Full-Build-linux-x64/build-inputs/python/bin/python3.12 -m pytest -c /dev/null -q |

## Rozsah auditu

Audit ověřuje zdrojový kontrakt, deterministický integrační bundle, Python syntaxi, Open WebUI Pipe, kompletní pytest sadu, CLI start, offline konzistenci instalovaných balíků a bezpečnostní invariance dlouhých úloh a downloadů.

## Omezení auditu

Audit negarantuje faktickou správnost dokumentů generovaných libovolným LLM. Podepisování Windows instalátoru a notarizace macOS vyžadují certifikáty vlastníka projektu a nejsou součástí zdrojového testu.
