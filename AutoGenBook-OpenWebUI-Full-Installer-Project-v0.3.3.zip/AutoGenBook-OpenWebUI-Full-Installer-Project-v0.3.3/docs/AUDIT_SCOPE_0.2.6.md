# Rozsah auditu verze 0.2.6

Tento dokument přesně vymezuje, co bylo ověřeno ve zdrojovém předávacím prostředí a co musí ještě ověřit platformní dependency-complete release workflow.

## Ověřeno v tomto zdrojovém projektu

- 63 cílených release-regresních testů pro reviewer KB1 včetně odmítnutí OAuth/SSO a úplného failure bundle, TXT referenci API klíče, normalizaci přímo zadaného klíče, bezpečnou registraci Open WebUI Function, trvalou autentizaci, progress a obnovitelné downloady;
- fail-closed reviewer: chybějící i prázdná KB1 zastaví běh před prvním LLM voláním;
- interaktivní doplnění KB1 souborem, veřejnou URL nebo explicitním textem;
- kontextové dohledání s povinnou zemí/jurisdikcí, institucí a typem závěrečné práce;
- explicitní potvrzení webového hledání i následný výběr kandidáta;
- SSRF ochrana URL importu, zákaz privátních/loopback/link-local adres a opětovná kontrola redirectů;
- kompilace Python zdrojů;
- načtení a validace Open WebUI Pipe;
- start CLI a argparse kontrakt;
- deterministický Open WebUI integrační bundle a jeho SHA-256;
- integrita výsledných ZIP a TAR.GZ archivů.

## Testovací pomocné moduly

Zdrojové testovací prostředí neobsahovalo volitelné balíky `rank-bm25` a `openai`. Pro izolovanou cílenou testovací sadu byly proto mimo projektový adresář použity minimální test-only stuby. Stuby nejsou součástí zdrojového projektu, integračního bundle ani instalačního archivu a nejsou používány v produkčním runtime.

## Co zajišťuje platformní release workflow

Úplný offline runtime je platformně závislý. Přiložená workflow proto musí před publikací konkrétního Windows, Linux nebo macOS instalátoru znovu ověřit:

- instalaci z přibaleného CPython runtime a offline wheelhouse;
- `pip check` uvnitř sestaveného runtime;
- nativní DLL a platformní knihovny;
- Pandoc, FFmpeg, TinyTeX a Piper podle zvoleného profilu;
- skutečný startup instalátoru a Companionu v cílovém operačním systému;
- vytvoření `bridge.json` a autorizovaný health request;
- podepisování Windows balíku nebo notarizaci macOS, jsou-li k dispozici certifikáty vlastníka.

## Známé omezení zdrojového builderu

Globální Python prostředí builderu obsahovalo nesouvisející konflikt MoviePy/Pillow. Z tohoto důvodu byl v lokálním zdrojovém auditu přeskočen globální `pip check`; tento krok není vydáván za úspěšné ověření finálního runtime. Dependency-complete release workflow obsahuje vlastní offline toolchain gate a je autoritativní pro konkrétní binární instalační artefakt.

## Faktická správnost dohledaného předpisu

Automatické dohledání nevytváří právní jistotu. Kandidáti musí být před importem zobrazeni uživateli a uživatel musí explicitně vybrat zdroj, který odpovídá jeho instituci, fakultě, programu, typu práce a relevantnímu období. Reviewer ukládá provenance zvoleného zdroje, ale nenahrazuje odbornou nebo právní kontrolu aktuálnosti předpisu.
