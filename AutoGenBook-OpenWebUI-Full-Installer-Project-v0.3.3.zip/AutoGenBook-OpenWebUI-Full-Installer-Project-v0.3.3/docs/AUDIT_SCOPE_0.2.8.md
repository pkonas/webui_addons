# Rozsah auditu verze 0.2.8

Tento dokument vymezuje zdrojový audit opravy providerové autentizace a povinnosti platformního dependency-complete release workflow.

## Ověřeno v tomto zdrojovém projektu

Audit obsahuje 21 kontrolních kategorií.

- 113 automatických testů v kompletní projektové sadě, včetně cílených regresí credential precedence;
- job-scoped Open WebUI klíč má přednost před ambientním `OPENROUTER_API_KEY` a `OPENAI_API_KEY`;
- job-scoped base URL má přednost před role-level a ambientními endpointy;
- runner odstraňuje inherited cross-provider credentials a zapisuje bezpečný fingerprint;
- exact-key `/api/models` preflight používá stejný klíč a endpoint jako následný worker;
- preflight proběhne před importem AutoGenBooku a před indexací KB;
- autoritativní externí TXT klíč lze atomicky rotovat a následně znovu načíst;
- chybějící, neplatná a nerelevantní reviewer KB1 zůstává fail-closed;
- interaktivní upload KB1, progress, failure bundle a obnovitelné downloady;
- kompilace Python zdrojů, validace Pipe, CLI preflight a deterministický integrační bundle;
- integrita výsledných ZIP a TAR.GZ archivů.

## Citlivá data a diagnostika

Audit kontroluje, že request snapshot, progress, worker log a provider validation obsahují pouze zdroj credentialu a 16znakový SHA-256 fingerprint. Hodnota API klíče nesmí být zapsána do projektu, job JSON, logu ani výstupního ZIPu.

## Co musí znovu ověřit platformní release workflow

- offline instalaci z přibaleného CPython runtime a wheelhouse;
- `pip check` v cílovém runtime;
- nativní DLL a nástroje Pandoc/FFmpeg/TinyTeX/Piper;
- skutečný startup Windows/macOS/Linux instalačního artefaktu;
- vytvoření `bridge.json`, health request a spojení s konkrétní lokální instancí Open WebUI;
- podepisování Windows balíku a notarizaci macOS, jsou-li dostupné certifikáty vlastníka.

## Forenzní omezení incidentu 0.2.7

Starý diagnostický archiv neobsahoval fingerprint použitého klíče, proto nelze zpětně zobrazit hodnotu ambientního credentialu. Zdrojový audit však prokázal chybnou deterministickou prioritu a verze 0.2.8 přidává korelační fingerprint, aby další běh mohl potvrdit shodu bez zveřejnění tajného údaje.
