# Rozsah auditu verze 0.2.9

Tento audit se zaměřuje na trvalou dostupnost AutoGenBook výstupů v Open WebUI a na zachování předchozích bezpečnostních a dlouhodobých kontraktů.

## Ověřované vlastnosti

- publikované artefakty jsou streamovány do Open WebUI storage bez načtení celého souboru do RAM;
- limit pro uživatelské vstupy neblokuje velké výstupy;
- odpovědi používají `/api/v1/files/<id>/content?attachment=true`, nikoli expirovatelnou Companion URL;
- Open WebUI file ID je deterministické, uživatelsky oddělené a idempotentní;
- opakovaný příkaz `výstupy <job-id>` nevytváří duplicity a migruje staré úlohy;
- event `files` obsahuje stejný trvalý file ID a URL jako text odpovědi;
- dočasné Companion odkazy mají samostatný signing key;
- rotace Companion bearer tokenu nezneplatní neexpirovaný fallback link;
- expirovaný fallback link vrací HTTP 410, nikoli zavádějící `Invalid companion token`;
- Range/HEAD/ETag podpora Companion API zůstává zachována;
- modelový selector, providerová izolace, dlouhé joby, persistentní progress a reviewer KB1 workflow zůstávají funkční;
- integrační bundle je deterministický a odpovídá zdrojovému stromu;
- výsledný ZIP a TAR.GZ obsahují celý projekt instalátoru, testy, dokumentaci a auditní důkazy.

## Praktický rozsah trvalosti

„Trvalý“ znamená bez časové expirace odkazu a nezávisle na Companion bearer tokenu či náhodném portu. Soubor zůstává součástí úložiště a databáze Open WebUI, dokud jej uživatel/správce výslovně nesmaže nebo dokud jej neodstraní nakonfigurovaná retenční politika hostitelského Open WebUI.

## Platformní omezení

Zdrojový audit neprovádí kryptografické podepsání Windows instalátoru ani notarizaci macOS. Dependency-complete platformní workflow musí znovu ověřit vlastní Python runtime, wheelhouse, nativní konvertory a startup na cílovém operačním systému.
