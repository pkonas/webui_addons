# Rozsah auditu AutoGenBook Open WebUI 0.3.1

## Auditované vlastnosti

- integrace bez forku Open WebUI;
- dynamický výběr modelu a výchozí `e-infra.glm-5`;
- exact-key provider preflight a izolace credentialů;
- několikadenní joby, progress, heartbeat, resume a cancel;
- trvalé Open WebUI artefakty a obnovitelné velké downloady;
- fail-closed reviewer KB1 workflow;
- interaktivní vložení KB1 a SSRF ochrana veřejných URL;
- reviewer direct parity s kanonickými prompty;
- odstranění attachment XML před parsováním zadání a exportů;
- criterion-aware/document-stratified KB2 evidence pack;
- úplný dokumentově seřazený KB1 kontext;
- explicitní jazyk a uživatelské instrukce;
- quality gate s jedním repair pokusem;
- fail-closed kontrola požadovaných exportů;
- Unicode-capable PDF engine fallback;
- reprodukovatelný `direct_cli_parity_request.json`;
- deterministický integrační bundle;
- instalátor, aktualizace bez ztráty dat a TXT reference API klíče.

## Testovací hranice

Zdrojový release audit této opravy spouští cílenou sadu 56 regresních testů pro trvalé Open WebUI artefakty, kontrakt Function, instalátor, autentizaci, izolaci provideru a Companion služby. Dále spouští `compileall`, validátor Pipe, CLI `--help` a ověření deterministického bundle. Úplná historická sada reviewer pipeline nebyla v tomto builderu znovu spuštěna, protože prostředí neobsahuje volitelné vývojové balíky `PyLaTeX` a `rank-bm25`; jejich úplnost a platformní nativní závislosti ověřuje dependency-complete workflow.

Platformní dependency-complete workflow musí navíc na každém cílovém OS ověřit vlastní Python runtime, wheelhouse, Pandoc, TinyTeX, FFmpeg, Piper, nativní knihovny a skutečný startup instalace bez sítě.

## Co audit negarantuje

- faktickou správnost tvrzení vytvořených libovolným LLM;
- bitově totožný text při nedeterministickém modelu nebo jiné revizi modelu;
- správnost externího automaticky dohledaného předpisu bez lidského potvrzení;
- platnost podpisu Windows/macOS balíku, pokud nebyl použit certifikát vlastníka;
- dostupnost vzdáleného provideru po skončení auditu.

Ekvivalence znamená stejný core, prompty, vstupy, konfiguraci, modelový endpoint a výstupní kontrakt. Přesná reprodukce jednoho jobu je popsána v `docs/OUTPUT_PARITY.md` a zaznamenána v jeho `direct_cli_parity_request.json`.
