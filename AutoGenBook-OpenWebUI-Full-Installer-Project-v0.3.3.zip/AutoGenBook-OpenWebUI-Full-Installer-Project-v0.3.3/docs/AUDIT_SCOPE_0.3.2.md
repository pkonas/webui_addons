# Rozsah auditu AutoGenBook Open WebUI 0.3.2

## Účel releasu

Verze 0.3.2 opravuje poslední nefunkční cestu stahování výstupů v Open WebUI. Audit se zaměřuje na to, že soubor vytvořený dlouhotrvající úlohou lze po dokončení bezpečně, trvale a opakovaně stáhnout z desktopového rozhraní bez odhalení bearer tokenu nebo závislosti na Companion portu.

## Ověřované oblasti

1. **Úplnost projektu instalátoru** — AutoGenBook core, Companion, Function, instalátor, build skripty, testy a dokumentace jsou součástí archivu.
2. **Konzistence verze** — root, Companion, Function, installer, Inno Setup a release builder používají 0.3.2.
3. **Bez forku Open WebUI** — integrace zůstává Function + lokální Companion.
4. **Autentizovaný download broker** — veřejná landing stránka nevydává data; tiket se vydá až po ověření Open WebUI identity a přístupu k souboru.
5. **Ochrana tajných údajů** — bearer token, osobní API klíč ani Companion token nejsou v URL, zprávě nebo file metadata.
6. **Velké soubory** — streamování podporuje GET, HEAD, Range, If-Range, ETag, 206 a 416 bez načtení celého souboru do RAM.
7. **Vlastnictví a sdílení** — tiket se vydá jen vlastníkovi, administrátorovi nebo uživateli s read grantem a je svázán s aktuálním vlastníkem záznamu.
8. **Open WebUI file contract** — událost obsahuje `type=file`, stabilní ID, stav `uploaded`, název, velikost a MIME typ.
9. **Binární náhled** — `data.content` obsahuje užitečnou Markdown kartu namísto fallbacku `No content`.
10. **Idempotentní migrace** — `výstupy JOB_ID` opravuje staré záznamy bez duplicit a bez nové LLM generace.
11. **Dlouhé úlohy** — progress, heartbeat, cancel/resume a provider credential isolation zůstávají zachovány.
12. **Reviewer parity** — direct profil, document-wide evidence pack, explicitní jazyk/model, quality gate a fail-closed export zůstávají součástí releasu.
13. **Deterministický integrační bundle** — bundle lze sestavit dvakrát se stejným hashem a ověřit proti manifestu.
14. **Bezpečnost archivů** — ZIP CRC, bezpečné TAR cesty, žádné symlinky/hardlinky a vnitřní SHA-256 inventář.

## Co audit negarantuje

- faktickou správnost textů vygenerovaných zvoleným LLM;
- dostupnost vzdáleného modelového provideru;
- neomezenou kapacitu lokálního disku nebo cloudového storage;
- fungování souboru po jeho explicitním smazání nebo po zásahu retenční politiky;
- kryptografické podepsání Windows instalátoru nebo notarizaci macOS balíku bez certifikátů vlastníka projektu;
- bitově totožný text při nedeterministickém modelovém backendu.

## Autoritativní testy releasu

- `tests/test_openwebui_authenticated_downloads.py`
- `tests/test_openwebui_persistent_artifacts.py`
- `tests/test_openwebui_persistent_auth.py`
- `tests/test_openwebui_function_frontmatter.py`
- `tests/test_openwebui_integration_v6.py`
- `tests/test_provider_credential_isolation.py`
- instalační, reviewer a Companion regresní testy vyjmenované v auditním reportu.
