# Rozsah auditu AutoGenBook Open WebUI 0.3.3

## Účel vydání

Verze 0.3.3 opravuje download cestu, která ve verzi 0.3.2 stále závisela na dostupnosti browserového tokenu nebo cookie v nově otevřeném okně. Audit ověřuje, že vytvořené artefakty lze po registraci do Open WebUI stáhnout běžným kliknutím bez `localStorage`, bez bearer hlavičky přidávané JavaScriptem a bez Companion tokenu.

## Ověřovaný kontrakt

1. Konzistence verze napříč Function, Companionem, instalátorem a buildem.
2. Deterministické uživatelské file ID a idempotentní příkaz `výstupy JOB_ID`.
3. Stabilní capability podpis odvozený od `WEBUI_SECRET_KEY`.
4. Vazba capability na ID souboru, vlastníka, hash a velikost.
5. Přímý download bez browserové autentizace a bez zveřejnění tajných klíčů.
6. `GET`, `HEAD`, `Range`, `If-Range`, `ETag`, 206 a 416.
7. Odmítnutí změněného podpisu, jiného vlastníka, hashe nebo velikosti.
8. Přežití Function reloadu se stejným Open WebUI secret key.
9. Nativní assistant-file objekt `type=file` a neprázdné `data.content`.
10. Staré broker endpointy vracejí HTTP 410 s použitelným návodem.
11. Streamované kopírování velkých artefaktů a kontrola velikosti/SHA-256.
12. Zachování progressu, credential izolace, reviewer KB1 a výstupní parity.
13. Kontrola instalačního projektu, ZIP CRC, bezpečných TAR cest a interních hashů.

## Omezení

Capability URL je bearer capability. Kdo získá její úplnou hodnotu, může soubor stáhnout. Odkaz je neuhodnutelný a svázaný s konkrétním souborem, ale nemá být publikován. Rotace `WEBUI_SECRET_KEY` zneplatní dříve vytvořené odkazy; příkaz `výstupy JOB_ID` vytvoří nové.

Zdrojový audit nenahrazuje platformní podpis Windows instalátoru, macOS notarizaci ani úplný offline toolchain test na cílovém operačním systému.
