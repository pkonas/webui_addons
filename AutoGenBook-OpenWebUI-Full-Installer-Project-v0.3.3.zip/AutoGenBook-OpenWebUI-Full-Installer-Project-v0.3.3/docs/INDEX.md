# Documentation Index

- README: `../README.md`
- User guide: `USER_GUIDE.md`
- Examples: `EXAMPLES.md`
- Architecture: `ARCHITECTURE.md`
- API reference (CLI): `API_REFERENCE.md`
- Configuration: `CONFIGURATION.md`
- Operations: `OPERATIONS.md`
- Troubleshooting: `TROUBLESHOOTING.md`
- Reviewer KB1 workflow: `REVIEWER_KB1_WORKFLOW.md`
- Output parity: `OUTPUT_PARITY.md`
- Developer guide: `DEVELOPER_GUIDE.md`
- Security: `SECURITY.md`
- Glossary: `GLOSSARY.md`

Existing design notes:
- Proposal mode repo analysis: `proposal_mode_repo_analysis.md`
- Proposal mode design: `proposal_mode_design.md`
- Proposal mode changes: `proposal_mode_changes.md`

Reference PDFs (source materials stored in `docs/`):
- `AI - 101 tipu.pdf`
- `UNESCO_Guidance_GenAI_Education_Research_2023.pdf`
- Other PDFs in `docs/` (see directory listing)

Incident reports:
- Reviewer 401 credential incident: `incidents/2026-08-19-openwebui-reviewer-401.md`
- Installer HTTP 400: `incidents/2026-08-20-installer-http-400.md`
- Reviewer KB1 policy: `incidents/2026-08-20-reviewer-kb1-policy.md`


## Verze 0.3.3

- [Rozsah auditu 0.3.3](AUDIT_SCOPE_0.3.3.md)
- [Incident: browserová autentizace brokeru a capability oprava](incidents/2026-09-18-openwebui-capability-download.md)

## Verze 0.3.2

- [Rozsah auditu 0.3.2](AUDIT_SCOPE_0.3.2.md)
- [Incident: autentizovaný download broker](incidents/2026-09-18-openwebui-authenticated-download-broker.md)

## Verze 0.3.1

- [Rozsah auditu 0.3.1](AUDIT_SCOPE_0.3.1.md)
- [Incident: expirované Companion odkazy](incidents/2026-08-27-expiring-companion-download-links.md)

- Incident: reviewer output degradation and parity repair: `incidents/2026-08-28-openwebui-reviewer-output-degradation.md`

- [`incidents/2026-09-18-openwebui-output-download-contract.md`](incidents/2026-09-18-openwebui-output-download-contract.md) – oprava nativních souborových karet a stahování výstupů v Open WebUI 0.3.1.
