# AutoGenBook pro Open WebUI Desktop

## Co balík obsahuje

- lokální službu **AutoGenBook Companion** s autentizovaným API na `127.0.0.1`;
- Pipe Function se šesti modely: kniha, paper, prezentace, scientist, proposal a reviewer;
- trvalou SQLite frontu, samostatný worker proces pro každý běh, zrušení a obnovu;
- bezpečný přenos příloh, role `input`, `structure`, `kb`, `kb1`, `kb2`;
- registraci výsledků zpět jako soubory Open WebUI;
- offline Python runtime a všechny Python závislosti v platformním installeru;
- úplný build balík s checkoutem zdrojů, wheelhouse, runtime archivem, stagingem a kontrolními součty.

## Instalace na Windows

Použijte dependency-complete Windows balík. Zdrojový archiv `Audited-Project` slouží k auditu a reprodukci buildu; pro laika není náhradou přibaleného runtime a wheelhouse.

1. Spusťte `AutoGenBook-OpenWebUI-Setup-Windows-x64.exe`.
2. Po instalaci ponechte zaškrtnuté **Register AutoGenBook in Open WebUI now**.
3. Instalátor zkusí nalézt lokální Open WebUI na portech 8080–8180.
4. Pro automatickou registraci vložte administrátorský API klíč Open WebUI. Klíč se používá pouze pro vytvoření/aktualizaci Function a není uložen instalátorem.
5. Bez API klíče importujte ručně soubor `integrations/openwebui/autogenbook_pipe.py` v Admin Panel → Functions.

## Použití

Vyberte jeden z modelů `AutoGenBook / …`, připojte podklady a napište zadání. Volitelné direktivy mohou být na samostatných řádcích:

```text
Název: Bezpečná AI ve vysokoškolské výuce
Jazyk: cs
Publikum: vedení univerzity
Snímky: 15
Výstupy: pptx, pdf, md, zip
Citace: ano
Obrázky: ano

Vytvoř prezentaci založenou na přiložené metodice a článcích.
```

Příkazy pro dlouhé běhy:

```text
stav <job-id>
zruš <job-id>
pokračuj <job-id>
výstupy <job-id>
```

## Role příloh

Role se odvozují z názvu souboru. Pro proposal/reviewer doporučujeme názvy s prefixem:

- `kb1_...` – pravidla, výzva, hodnoticí kritéria;
- `kb2_...` – projektové podklady nebo posuzovaná práce;
- `structure_...json` – explicitní struktura;
- `input_...txt` – primární zadání;
- ostatní soubory – běžná znalostní báze.

## Bezpečnost

Companion naslouchá pouze na loopbacku. API je chráněno náhodným tokenem uloženým s omezenými oprávněními. Modelové API klíče se ukládají přednostně do systémového keychainu; pokud keyring není dostupný, použije se soubor dostupný pouze aktuálnímu uživateli a diagnostika tuto skutečnost oznámí. Klíče nejsou zapisovány do projektů, logů ani ZIP výstupů.

## Reprodukce buildu

Kompletní příkazy jsou v `.github/workflows/build-openwebui-companion.yml`. Platformní build:

1. stáhne připnutý `python-build-standalone` runtime;
2. vytvoří wheelhouse všech závislostí;
3. nainstaluje závislosti a Companion do přibaleného Pythonu;
4. spustí testy a diagnostiku;
5. sestaví staging, kontrolní součty a platformní installer;
6. uloží samostatný `Full-Build` archiv se všemi vstupy použitými pro installer.

Installer není podepsaný certifikátem. Pro veřejnou distribuci je nutné doplnit Windows Authenticode a macOS signing/notarizaci.

## Trvalé výstupy v Open WebUI

Od verze 0.3.3 Pipe po dokončení streamuje publikované artefakty do Open WebUI storage a vrací stabilní HMAC capability adresy `/api/autogenbook/download/...`. Odkaz je svázán s file ID, vlastníkem, hashem a velikostí a nevyžaduje browserový token, cookie ani Companion port. Binární karta současně dostává užitečný Markdown náhled s tlačítkem Stáhnout místo textu `No content`. Dočasné Companion odkazy se v odpovědi nezobrazují. Příkaz `výstupy <job-id>` funguje jako idempotentní migrace a oprava starších záznamů. Úplná capability URL je přístupový údaj a nemá se zveřejňovat.
