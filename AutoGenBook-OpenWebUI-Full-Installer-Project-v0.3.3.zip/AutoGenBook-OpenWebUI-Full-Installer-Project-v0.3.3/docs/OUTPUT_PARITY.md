# Ekvivalence výstupů Open WebUI a samostatného AutoGenBook CLI

## Cíl

Open WebUI integrace je transportní, interakční a provozní vrstva. Nesmí vytvářet jiný obsahový produkt než stejné jádro AutoGenBooku spuštěné ze samostatného CLI se stejnými vstupy, prompty, modelem, endpointem a parametry generování.

Verze 0.3.1 zavádí **parity contract**. Pro reviewer režim je výchozí profil `direct`, který zachovává kanonický `prompts/reviewer/prompt1_default.md` jako systémový prompt, používá kanonický `prompt2.md` jako zadání a nepovoluje integrační vrstvě nahradit rubriku novým LLM-generovaným promptem.

## Co znamená ekvivalence

### Garantovaná strukturální ekvivalence

Při shodném zdrojovém revision, vstupních bytech a konfiguraci jsou v Open WebUI a CLI stejné:

- core pipeline a prompt soubory;
- role KB1/KB2 a jejich zdrojové soubory;
- zvolený model a OpenAI-compatible endpoint;
- reviewer profil a parametry evidence packu;
- jazyk, uživatelské zadání a požadované exporty;
- validační a exportní pravidla;
- výstupní schéma a povinná hodnoticí kritéria.

Každý job zapisuje `direct_cli_parity_request.json` s přesným příkazem, normalizovanou specifikací, nesekretními proměnnými prostředí a podmínkami reprodukce.

### Co nelze garantovat bitově

LLM výstup nemusí být bitově totožný při:

- jiném modelu nebo jiné revizi modelu pod stejným aliasem;
- jiném provider endpointu;
- nedeterministickém samplingu na serveru;
- změně promptů, vstupních souborů nebo pořadí zdrojů;
- aktivních modelových filtrech či systémových šablonách Open WebUI, které nejsou použity při přímém běhu.

Pro srovnání textu je proto nutné spustit zaznamenaný příkaz proti témuž Open WebUI API endpointu a témuž modelu. Parity contract garantuje stejný vstupní kontrakt a kvalitu/formát, ne kryptografickou shodu nedeterministické LLM odpovědi.

## Reviewer profily

| Profil | Systémový prompt | KB1 | LLM1 | Účel |
|---|---|---|---:|---|
| `direct` | kanonický standalone prompt beze změny obsahu | úplný kontext v uživatelské zprávě | ne | výchozí ekvivalence s CLI |
| `hybrid` | kanonický prompt + oddělené KB1 addendum | úplný kontext | ano | institucionální doplnění bez ztráty akademické rubriky |
| `compliance` | KB1-centrický prompt | úplný kontext | ano | explicitní kompatibilní compliance audit, nikoli výchozí posudek |

Původní integrační chování, které nechalo LLM1 přepsat celý systémový prompt z několika KB1 fragmentů, není v profilu `direct` použito.

## Evidence pack KB2

Starší implementace provedla jediný retrieval s `k=6`. U práce s 248 chunky tak LLM viděl přibližně 2,4 % dokumentových částí. Verze 0.3.1 skládá deterministický evidence pack z:

1. rovnoměrně rozložených dokumentových kotvicích chunků;
2. samostatného retrievalu pro každé ze sedmi kanonických hodnoticích kritérií;
3. dalších chunků v pořadí dokumentu, je-li aktivní `--reviewer-direct-pdf`;
4. deduplikace podle stabilního ID;
5. explicitního manifestu použitých důkazů.

Výchozí limit je 60 000 znaků a šest retrieval výsledků na kritérium. Přesná sada je uložena v `reviewer_evidence_manifest.json`; samotný kontext v `reviewer_evidence_pack.md`.

## KB1

V profilu `direct` se validní KB1 nepoužívá k nahrazení akademické rubriky. Je předána v dokumentovém pořadí jako institucionální kontext. Výchozí limit je 48 000 znaků a manifest uvádí každé použité ID a případné zkrácení.

## Jazyk a uživatelské zadání

Open WebUI attachment XML se před analýzou odstraní. Zbytek uživatelského textu se uloží do `reviewer_instructions.txt` a vloží do skutečného reviewer promptu. Parametr `language` se vynucuje samostatnou instrukcí; pro `cs` vyžaduje český posudek.

Metadata přílohy už nesmějí měnit výstupní formáty. Název vstupního souboru končící `.pdf` se proto neinterpretuje jako pokyn „vytvoř pouze PDF“.

## Quality gate

Výchozí reviewer quality gate kontroluje:

- minimální rozsah;
- požadovaný jazyk;
- úplnou markdownovou hodnoticí tabulku;
- dostatek známek 0–9;
- pokrytí kanonických kritérií;
- nepřítomnost placeholderů.

První nevyhovující draft se jednou opraví s původními důkazy. Pokud nevyhoví ani opravený draft, job skončí kódem `REVIEWER_OUTPUT_QUALITY_FAILED`; horší výstup se nevydává za úspěch.

## Exportní parita

Požadovaný formát je úspěšný pouze tehdy, když jeho soubor skutečně existuje a není prázdný. PDF `auto` preferuje LuaLaTeX, poté XeLaTeX a až nakonec pdfLaTeX. Markdown se před TeX exportem normalizuje pro běžné Unicode matematické znaky.

Pokud požadovaný PDF/DOCX/TEX export nevznikne, reviewer vrátí `REVIEWER_EXPORT_FAILED` a zapíše `reviewer_conversion_report.json`. Stav jobu už nesmí být `SUCCEEDED` pouze proto, že vznikl mezilehlý Markdown.

## Artefakty auditu jednoho běhu

- `direct_cli_parity_request.json`
- `reviewer_prompt1_effective.md`
- `reviewer_prompt2_effective.md`
- `reviewer_evidence_pack.md`
- `reviewer_evidence_manifest.json`
- `reviewer_parity_manifest.json`
- `reviewer_quality_report.json`
- `reviewer_conversion_report.json`
- `run_meta.json`

## Reprodukce

Zkopírujte příkaz z `direct_cli_parity_request.json`, nastavte stejné nesekretní proměnné a dodejte stejný osobní API klíč pouze v prostředí. Použijte stejné zdrojové revision a stejné vstupní adresáře. U reviewer režimu má zaznamenaný příkaz explicitně `--reviewer-llm1-model` a `--reviewer-llm2-model`, takže vybraný Open WebUI model není skryt pouze v prostředí Companionu.
