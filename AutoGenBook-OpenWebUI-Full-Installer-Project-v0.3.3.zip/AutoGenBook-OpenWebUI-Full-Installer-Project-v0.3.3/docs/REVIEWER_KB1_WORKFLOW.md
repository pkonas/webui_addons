# Reviewer KB1 workflow

## Purpose

The reviewer pipeline evaluates a thesis, dissertation, or similar work. It must distinguish the evaluated material from the rules used to judge it:

- **KB1** defines the evaluation framework.
- **KB2** contains the work being evaluated.

Version 0.2.7 does not silently substitute generic criteria when KB1 is absent.

## Accepted KB1 sources

A KB1 source can be:

- an official university/faculty regulation or directive;
- a public legal or institutional rule applicable to the work type;
- an evaluation rubric or reviewer template;
- a methodology for thesis/dissertation assessment;
- explicit criteria entered by the user.

The source should make its institution, scope, work type, and effective date identifiable whenever possible.

## Open WebUI flow

1. The user selects `autogenbook.reviewer` and attaches the work as KB2.
2. The Pipe detects that KB1 is absent or unusable.
3. It asks for one of:
   - `SOUBOR` to open a native multi-file picker inside Open WebUI;
   - `URL: https://...`
   - `TEXT: ...`
   - `HLEDAT: země=...; instituce=...; fakulta=...; typ práce=...`
4. The file picker accepts PDF, DOCX, PPTX, Markdown and TXT and uploads them to the
   current Open WebUI origin before the Pipe resolves their file IDs and streams them to
   the Companion as role `kb1`.
5. URL import validates scheme, DNS target, redirects, size, and content type.
6. Search requires explicit confirmation and sufficient context.
7. Candidate URLs are shown with title, source, type, reason, and likelihood of being official.
8. Only user-selected candidates are imported.
9. The project is revalidated before the job may start.

## Follow-up attachment command

When the two-way file picker is unavailable or the user closes the original question,
the source can be attached to a later chat message. The message must contain:

```text
KB1 <PROJECT_OR_JOB_ID>
```

The Pipe resolves the target as either a reviewer project or an existing reviewer job,
stores every attached supported document explicitly as KB1, patches provenance metadata,
and runs Companion validation. A valid draft project is queued as a new job. A valid
failed, cancelled or interrupted job is resumed while retaining its KB2 and checkpoints.
Unsupported, empty, login-page, unreadable or irrelevant documents do not start or resume
the reviewer.

The picker uses an Open WebUI `execute` event only to present the visible native input and
perform a same-origin upload. Its return value contains file metadata/IDs, never an API key
or browser token.

## Fail-closed behavior

If KB1 is still unavailable, the CLI exits with code 2 and writes:

```text
reviewer_kb1_diagnostic.json
reviewer_kb1_diagnostic.md
```

The diagnostic code is `REVIEWER_KB1_REQUIRED`. No reviewer LLM call is performed.

## Explicit waiver

The override `--reviewer-allow-missing-kb1` or Valve policy `allow_without_kb1` is intended only for a general, non-institutional critique. The output is marked `REVIEWER_KB1_EXPLICITLY_WAIVED` and should not be presented as compliance with a specific regulation.

## Security and provenance

- Private, loopback, link-local, reserved, and non-global destinations are rejected.
- Redirect targets are revalidated.
- Environment proxy variables are ignored for KB1 import.
- Download size is bounded.
- Imported text receives a provenance header; binary files receive a provenance sidecar.
- Search results are candidates, not authoritative legal findings.

## Obnova existující úlohy

Příkaz `pokračuj JOB_ID` před znovuzařazením reviewer jobu znovu ověří provider i projekt. Pokud KB1 chybí nebo je prázdná, Pipe otevře průvodce a job se neobnoví, dokud uživatel nedodá použitelný zdroj nebo vědomě nezvolí explicitní waiver ve Valve. To umožňuje opravit také úlohy, které dříve selhaly například kvůli expirovanému browserovému tokenu.

## Kontrola relevance a přístupových bran (0.2.7)

Companion i reviewer runtime používají stejný fail-closed hodnoticí modul. Kontroluje
finální URL po redirectech, název a skutečný extrahovaný obsah. HTML/TXT se posuzují
přímo; PDF, DOCX a PPTX se nejprve lokálně extrahují. Následující výsledky jsou chybou a
job se nezařadí:

- `REVIEWER_KB1_AUTH_PAGE` — OAuth/SAML/SSO/login;
- `REVIEWER_KB1_ACCESS_GATE` — přístup odepřen, 404 nebo obdobná brána;
- `REVIEWER_KB1_UNREADABLE` — žádný extrahovatelný text;
- `REVIEWER_KB1_TOO_SHORT` — nedostatečný rozsah pravidel;
- `REVIEWER_KB1_IRRELEVANT` — chybí znaky hodnoticí normy/rubriky.

Provenance sidecar `*.provenance.json` je auditní metadata a není součástí RAG. Pokud
existuje alespoň jeden validní zdroj, neplatné zdroje se vyřadí a vypíší jako varování.
Souhrn je v `reviewer_kb1_quality.json`.

## Diagnostika selhání

Complete bundle obsahuje `diagnostics/worker.log`, `failure.json`, `failure.md`, request,
progress a stav úlohy. Tím lze rozlišit chybu KB1, provideru, modelu a exportu i tehdy, když
se proces ukončí před vytvořením hlavního dokumentu.

