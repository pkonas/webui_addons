# Security

## Secrets and credentials

- Open WebUI background jobs accept only a persistent personal API key. JWT-like browser session tokens are rejected before use. (`companion/src/autogenbook_companion/service.py:validate_provider_profile`)
- The Pipe validates the key and selected model before creating or resuming a job. (`integrations/openwebui/autogenbook_pipe.py:_ensure_provider_ready`)
- The secret is stored through the Companion `SecretStore`; persisted project/job JSON contains only the secret reference, never the key value. (`companion/src/autogenbook_companion/security.py`, `companion/src/autogenbook_companion/models.py:ProviderProfile`)
- Worker logs redact registered secrets. (`companion/src/autogenbook_companion/runner.py`)
- An installer-managed TXT reference stores only an absolute path; the key is read live at validation/worker start and is never copied into project/job JSON. (`companion/src/autogenbook_companion/key_file.py`, `security.py`)
- The runner scrubs inherited OpenRouter/OpenAI credentials and endpoints, then injects one provider-specific job credential. (`companion/src/autogenbook_companion/runner.py:_build_env`)
- The OpenAI-compatible client gives the isolated `AUTOGENBOOK_LLM_API_KEY` and `AUTOGENBOOK_LLM_BASE_URL` precedence over ambient or role-level values. (`openrouter_llm.py`)
- The worker performs a proxy-free exact-key preflight before importing AutoGenBook or indexing KB. (`companion/src/autogenbook_companion/worker_entry.py`)
- Diagnostics expose only credential source and a short SHA-256 fingerprint; they never expose the key. (`security.py:secret_fingerprint`, `runner.py`)
- MCP gateway credentials are read from environment variables. (`mcp_gateway.py:MCPGatewayClient.__init__`)
- Tavily API key is read from `TAVILY_API_KEY`. (`autogenbook/retrieval/tavily.py:search_web`)

## Prompt-injection mitigation

- Retrieved context is sanitized to drop common prompt-injection patterns. (`autogenbook/retrieval/sanitize.py:sanitize_context_text`)

## Safe code patching (scientist mode)

- Patch application rejects forbidden imports and suspicious strings. (`autogenbook/runner/patch_apply.py:_safety_scan_diff`)
- Patches are constrained to the experiment workdir and disallow path traversal. (`autogenbook/runner/patch_apply.py:_sanitize_patch_path`)

## Data handling

- KB files are read locally and cached to `.kb_cache` under the output directory. (`rag_kb.py:KnowledgeBase.build_from_directory`)
- Run artifacts, logs, and metadata are stored under `--out-dir`. (`autogenbook/state.py:RunContext`, `autogenbook/llm_usage.py:write_run_meta`)

## Network surface

- LLM requests go to the configured base URL (default OpenRouter; override via `AUTOGENBOOK_LLM_BASE_URL`). (`openrouter_llm.py:OpenRouterLLM.__init__`)
- Optional web retrieval calls MCP gateway tools or Tavily search. (`autogenbook/retrieval/mcp_papers.py:MCPPaperRetriever`, `autogenbook/retrieval/tavily.py:search_web`, `mcp_gateway.py:MCPGatewayClient`)
## Persistent Open WebUI output capabilities

- Version 0.3.3 uses an HMAC capability URL derived from Open WebUI's stable `WEBUI_SECRET_KEY`; no browser JWT, API key, cookie or Companion bearer token is embedded. (`integrations/openwebui/autogenbook_pipe.py:_agb_download_secret`)
- The signed claims bind file ID, owner ID, SHA-256 and size. The route rechecks the current database row before streaming. (`_agb_make_capability`, `_agb_download_capability`)
- Capability URLs are bearer capabilities: possession grants download access. They are unguessable and normally live only in the owner's private chat, but must not be published.
- Deleting/replacing the file, changing owner/hash/size or rotating `WEBUI_SECRET_KEY` invalidates the old URL.
- Streaming supports HEAD and byte ranges without reading the whole artifact into memory. (`_agb_stream_file_record`)

