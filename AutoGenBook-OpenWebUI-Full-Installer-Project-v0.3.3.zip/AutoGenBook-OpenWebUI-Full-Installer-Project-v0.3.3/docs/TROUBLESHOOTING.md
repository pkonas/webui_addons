# Troubleshooting

## Symptom -> cause -> fix

| Symptom | Likely cause | Fix | Source |
| --- | --- | --- | --- |
| `OPENROUTER_API_KEY` missing error at startup | Using OpenRouter without an API key | Export `OPENROUTER_API_KEY` or set `AUTOGENBOOK_LLM_BASE_URL` to a local endpoint | `openrouter_llm.py:OpenRouterLLM.__init__` |
| `LuaLaTeX not available` error | `lualatex` binary not found | Install LuaLaTeX or pass `--no-pdf` | `book_builder.py:compile_pdf`, `main.py:parse_args` |
| Book/paper input file not found | `--input` path is wrong | Fix the path or use the sample input | `autogenbook/pipelines/book_pipeline.py:run_book`, `autogenbook/pipelines/paper_pipeline.py:run_paper` |
| Proposal mode fails with MCP tools unavailable | MCP gateway not running or missing tools | Enable MCP gateway and required paper tools, rerun with `--enable-web-rag` | `autogenbook/pipelines/proposal_pipeline.py:run_proposal`, `mcp_gateway.py:MCPGatewayClient` |
| Proposal mode fails due to missing KB1/KB2 | Required directories not provided or empty | Provide valid `--kb1-dir` and `--kb2-dir` | `autogenbook/pipelines/proposal_pipeline.py:run_proposal` |
| Audit fails in strict mode (exit code 4) | Missing citations, figures, or evidence for numeric claims | Review `audit_report.json` and fix inputs/prompts or use `--audit-mode warn` | `autogenbook/audit/latex_auditor.py:audit_latex`, `autogenbook/pipelines/*:run_*` |
| Proposal mode reports missing citations after drafting | Section citations do not match allowed MCP source keys | Ensure MCP tools are available and citations are present in section outputs | `autogenbook/pipelines/proposal_pipeline.py:run_proposal`, `autogenbook/citations/markdown.py:extract_markdown_citation_keys` |
| Reviewer mode returns exit code 2 | KB2 missing or empty | Provide valid `--kb2-dir` with supported files | `autogenbook/pipelines/reviewer_pipeline.py:run_reviewer`, `tests/test_reviewer_mode.py` |
| Pandoc conversion skipped | `pandoc` not installed | Install pandoc or accept Markdown-only outputs | `autogenbook/pipelines/proposal_pipeline.py:_convert_with_pandoc`, `autogenbook/pipelines/reviewer_pipeline.py:run_reviewer` |

## Debugging tips

- Check `out_dir/logs/run.log` for run-level logs. (`autogenbook/logging.py:get_logger`)
- Inspect `out_dir/agent_logs` for agent input/output payloads. (`autogenbook/agents/io_log.py:write_agent_io`)
- Review `out_dir/llm_usage.jsonl` for per-call usage and cost. (`autogenbook/llm_usage.py:log_usage`)
- Look at `structure_graph.json` to confirm the section graph and leaf nodes. (`autogenbook/graph/doc_graph.py:save_graph_json`)
- Use `AUTOGENBOOK_NONINTERACTIVE=1` to avoid blocking prompts in book/proposal flows. (`autogenbook/pipelines/book_pipeline.py:_ask_choice`, `autogenbook/pipelines/proposal_pipeline.py:_is_noninteractive`)

## Windows installer: chybějící `bridge.json`

### Příznak

Instalátor 0.2.0 skončí přibližně po 30 sekundách zprávou:

```text
RuntimeError: Companion did not become healthy:
No such file or directory: ...\data\bridge.json
```

### Příčina

`bridge.json` není primární chyba. Vzniká až po úspěšném importu a spuštění Companionu. Verze 0.2.0 při instalaci ze zdrojového archivu:

- nepřidala `companion\src` do `PYTHONPATH`, takže subprocess mohl skončit na `ModuleNotFoundError: autogenbook_companion`;
- vždy předala `--source-dir <install>\app`, přestože zdrojový archiv má `main.py` přímo v kořeni;
- nekontrolovala návratový kód procesu a do výsledné chyby nepřidala obsah `companion.log`.

### Oprava

Použijte verzi 0.2.1 nebo novější. Opravený instalátor:

1. rozpozná `app\main.py` i kořenový `main.py`;
2. sestaví `PYTHONPATH` pro instalovaný i zdrojový layout;
3. před startem provede importní a `doctor` preflight;
4. sleduje návratový kód subprocessu;
5. při chybě vypíše poslední řádky `data\logs\companion.log`.

Pro běžnou offline instalaci používejte Windows **Complete Offline Installer** nebo **Complete Offline Portable**. Zdrojový archiv `Audited-Project` není náhradou dependency-complete platformního balíku.

## Function nelze vytvořit: `Invalid requirement: '<1'`

Příčina ve verzi 0.2.1 byla ve frontmatter Pipe: `httpx>=0.27,<1`. Open WebUI seznam
závislostí rozděluje čárkami a předalo pipu samostatný neplatný argument `<1`.

Řešení: importujte `integrations/openwebui/autogenbook_pipe.py` z verze 0.2.2 nebo novější.
Companion není potřeba přeinstalovat. Opravená Pipe nepoužívá frontmatter instalaci balíků.

## Reviewer nebo jiný job selže s 401 / `session has expired`

### Příznak

Worker nejprve vytvoří KB a poté skončí například zprávou:

```text
Error: LLM2 reviewer call failed: Error code: 401 - session has expired or token is invalid
```

### Příčina

Do Companionu byl uložen browser session/JWT token nebo byl osobní API klíč zrušen. Session token je krátkodobý a pro několikadenní background job není platný credential.

### Oprava

1. Nainstalujte projekt 0.2.3 do stejného cílového adresáře; instalátor zachová `data`.
2. Ujistěte se, že je v Open WebUI povoleno vytváření API klíčů a že uživatel smí volat `/api/models` a `/api/chat/completions`.
3. Otevřete **Nastavení → Účet → API Keys** a vytvořte osobní API klíč.
4. V AutoGenBook chatu odešlete `pokračuj JOB_ID`.
5. Vložte API klíč do maskovaného dialogu. Nevkládejte jej do běžné chatové zprávy.

Verze 0.2.3 token před spuštěním ověří, zkontroluje dostupnost vybraného modelu a při 401/403 vrátí konkrétní diagnostický kód.


## Reviewer stops before generation with `REVIEWER_KB1_REQUIRED`

Cause: KB2 contains the evaluated work, but KB1 is missing, empty, unsupported, or produced zero retrievable chunks. Version 0.2.7 intentionally refuses to fabricate an institutional review from generic criteria.

Resolution in Open WebUI:

1. Attach the official regulation/rubric as a file whose name clearly contains `kb1`, `směrnice`, `vyhláška`, `hodnocení`, `rubric`, `policy`, or a similar marker; or
2. provide `URL: https://...` to an official public source; or
3. provide `TEXT: ...` with explicit user criteria; or
4. provide context such as `HLEDAT: země=ČR; instituce=VUT; fakulta=FAST; typ práce=diplomová práce` and explicitly select a returned candidate.

The discovery route will not run without jurisdiction, institution, and work type. Private/loopback URLs and unsafe redirects are rejected. The user remains responsible for checking that the selected regulation is current and applicable.

For a deliberately general review, set `Reviewer KB1 policy = allow_without_kb1` or use `--reviewer-allow-missing-kb1`. The run will carry the warning `REVIEWER_KB1_EXPLICITLY_WAIVED`.

## `REVIEWER_KB1_AUTH_PAGE`

Zdroj byl po redirectu přihlašovací nebo OAuth/SSO stránkou. Nepokoušejte se předávat
browser cookie ani session token. Nahrajte stažený předpis, použijte veřejný přímý odkaz
nebo vložte explicitní kritéria. Poté obnovte job příkazem `pokračuj JOB_ID`.

## Complete ZIP neobsahuje hlavní výstup

U neúspěšného jobu je to očekávané, ale od 0.2.7 musí archiv obsahovat alespoň
`_autogenbook_companion/failure.json` a `diagnostics/worker.log`. Pokud chybí, běží starší
Companion. Zkontrolujte `companion_manifest.json` a aktualizujte Companion i Function.


## Reviewer asks for KB1 but I need to upload a local file

At the **Chybí hodnoticí předpis (KB1)** prompt enter:

```text
SOUBOR
```

A native picker accepts PDF, DOCX, PPTX, Markdown and TXT. If no picker appears, close the
prompt, attach the document to a new chat message and send:

```text
KB1 <PROJECT_OR_JOB_ID>
```

The project/job ID is shown in the original KB1 message or failure response. The document
is stored as an explicit KB1 candidate and must pass semantic validation before a reviewer
job is started or resumed. A login page, access-denied page, empty file, unreadable document
or unrelated text remains rejected.

## Provider validation succeeds but the worker still returns 401

Affected version: 0.2.7. A detached worker could inherit `OPENROUTER_API_KEY` or a role-level base URL and use it before the validated `AUTOGENBOOK_LLM_API_KEY`. KB1/KB2 could therefore be built successfully and the first LLM call could still fail with 401.

Resolution:

1. Update both Companion and Pipe to 0.2.8.
2. Keep the existing `data` directory.
3. Confirm the TXT file contains one current personal Open WebUI API key.
4. Resume with `pokračuj JOB_ID`.

Version 0.2.8 scrubs inherited provider credentials/endpoints, performs an exact-key preflight before KB indexing, and records only a non-secret source/fingerprint pair. See `docs/incidents/2026-08-20-openwebui-worker-credential-precedence.md`.

## Výstupní odkaz po čase vrátí `Invalid companion token`

Tento odkaz pochází z Pipe 0.2.8 nebo starší a míří přímo na časově podepsaný endpoint Companionu. Aktualizujte Companion i Function na 0.3.3 a odešlete:

```text
výstupy JOB_ID
```

Příkaz zaregistruje stále existující artefakty jako trvalé soubory Open WebUI a vytvoří nové capability odkazy `/api/autogenbook/download/...`. Opakované spuštění nevytvoří duplicity. Starý text zprávy se automaticky nepřepíše.

## Velký výstup se neobjeví jako soubor Open WebUI

Ověřte ve Valve:

- `PERSIST_OUTPUTS_TO_OPENWEBUI = true`;
- `PERSIST_OUTPUT_MAX_BYTES = 0` nebo hodnota větší než daný soubor;
- dostatek místa v Open WebUI storage;
- oprávnění procesu Open WebUI zapisovat do `UPLOAD_DIR`.

`ATTACH_MAX_BYTES` omezuje vstupní přílohy, nikoli výstupy. Při přenosu sledujte status „Trvale ukládám … do Open WebUI“. Nedokončený `.autogenbook.part` soubor není publikován jako výsledek.

## Výstup existuje, ale odkaz vrací 401 nebo modal ukazuje `No content`

Logy verze 0.3.2 typicky ukazují:

```text
GET /api/autogenbook/files/<id>/download 200
POST /api/autogenbook/download-ticket 401
```

Landing stránka se otevřela, ale nové okno nemělo použitelný browser token ani cookie. Aktualizujte současně Companion i Function na 0.3.3, restartujte Open WebUI Desktop a odešlete:

```text
výstupy ID_ÚLOHY
```

Nová odpověď musí:

- zobrazit nativní souborovou kartu `type=file`, `status=uploaded`;
- používat URL `/api/autogenbook/download/PODEPSANÁ_CAPABILITY`;
- v modalu zobrazit Markdown popis s tlačítkem **Stáhnout**, ne `No content`;
- stáhnout soubor bez požadavku na `localStorage`, cookie nebo bearer hlavičku;
- podporovat Range/HEAD a obnovení přenosu.

Staré endpointy `/api/autogenbook/files/<id>/download`, `/api/autogenbook/download-ticket` a `/api/autogenbook/download-stream/...` jsou migrační a vracejí HTTP 410. Podrobnosti jsou v `docs/incidents/2026-09-18-openwebui-capability-download.md`.

Capability URL je přístupový údaj. Nezveřejňujte ji mimo zamýšlené příjemce.
