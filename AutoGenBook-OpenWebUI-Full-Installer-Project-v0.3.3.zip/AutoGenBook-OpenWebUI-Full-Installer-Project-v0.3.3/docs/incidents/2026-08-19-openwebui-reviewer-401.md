# Incident: reviewer selhal na expirovaném Open WebUI session tokenu

## Rozsah

- Režim: `reviewer`
- Job: `23e18c2a-a871-4abe-bfb4-541fbeafebb4`
- Pozorovaný návratový kód workeru: `2`
- Skutečná příčina: HTTP `401` z Open WebUI při prvním LLM2 reviewer volání.

## Důkazy

Worker před selháním úspěšně:

1. vytvořil KB2 z jednoho zdroje a 248 chunků;
2. korektně přeskočil nepovinnou KB1;
3. inicializoval retriever;
4. sestavil výchozí reviewer prompt.

První LLM volání následně obdrželo zprávu, že session vypršela nebo token není platný. Nešlo tedy o chybu ingestu PDF, reviewer pipeline ani modelového výběru.

## Kořenová příčina

Verze 0.2.2 přijala libovolný neprázdný credential a dlouhodobý worker jej používal jako bearer token. Browser session/JWT je časově omezený a není vhodný pro úlohy trvající hodiny nebo dny.

## Oprava 0.2.3

- pro Open WebUI provider je vyžadován trvalý osobní API klíč;
- JWT-like token je odmítnut před uložením;
- klíč je před startem validován na `/api/models`;
- kontroluje se dostupnost zvoleného modelu;
- 401/403 mají diagnostické kódy;
- příkaz `pokračuj JOB_ID` vyžádá nový klíč a znovu zařadí existující job;
- aktualizace instalace zachová původní `data` adresář atomicky.

## Obnova postižené úlohy

Po instalaci 0.2.3 a aktualizaci Function odešlete v AutoGenBook chatu:

```text
pokračuj 23e18c2a-a871-4abe-bfb4-541fbeafebb4
```

Vložte osobní Open WebUI API klíč z **Nastavení → Účet → API Keys**, nikoliv token z cookies, localStorage nebo hlavičky běžné browser session.
