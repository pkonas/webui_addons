# Incident: Open WebUI Function registration returned HTTP 400

## Symptom

During installation with a directly entered admin API key, the installer reported:

```text
Open WebUI rejected the Function (400): Invalid HTTP request received.
```

## Root causes addressed

The old registration path used a generic URL opener and accepted several raw key representations without a single normalization boundary. Depending on local proxy settings and copied key formatting, the server could receive a malformed request. The installer also treated Function registration as mandatory even though Companion installation itself had succeeded.

## Fix in 0.2.5

- normalize `sk-…`, `Bearer …`, `Authorization: Bearer …`, assignment, and quoted input;
- reject CR/LF, control characters, and browser JWT;
- use direct `http.client` HTTP/HTTPS connections with no environment proxy;
- verify Open WebUI through `/api/version`;
- perform `/api/v1/functions/list` admin preflight;
- use documented create/update/toggle endpoints with the exact `FunctionForm` JSON shape;
- treat automatic registration failure as a recoverable manual-import condition unless CI uses `--require-function-registration`.

## Recovery

The Companion installation remains usable. Import:

```text
integrations/openwebui/autogenbook_pipe.py
```

through **Admin Panel → Functions** and activate it manually.
