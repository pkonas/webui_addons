# Incident: Open WebUI worker credential precedence caused a false 401

## Affected run

- Job: `88b9592d-3d08-4c67-8ef5-ff49693efa70`
- Mode: `reviewer`
- Reported version: `0.2.7`
- Selected model: `e-infra.glm-5`
- Provider: local Open WebUI at `/api`

## Evidence from the complete diagnostic archive

The reviewer inputs were valid:

- KB2 was built from one source into 248 chunks.
- KB1 was built from `Směrnice_Závěrečné práce na VUT_2026.pdf` into 18 chunks.
- `reviewer_kb1_quality.json` marked the source valid with score 100, 3,087 words, and no authentication/access-gate hits.

The first reviewer LLM initialization then failed with HTTP 401. The failure was therefore not caused by an empty or irrelevant KB1.

## Root cause

Version 0.2.7 validated the persistent Open WebUI key through the Companion, but the detached worker inherited the whole parent environment. `openrouter_llm.py` then selected the request key in this order:

```text
explicit config key
OPENROUTER_API_KEY
AUTOGENBOOK_LLM_API_KEY
OPENAI_API_KEY
```

For an Open WebUI job this precedence was incorrect. An unrelated ambient `OPENROUTER_API_KEY` (or a role-level explicit override) could replace the already validated job-scoped Open WebUI key. The Companion and worker could therefore use different credentials: provider validation succeeded, while the real reviewer call received 401. The old diagnostic archive did not contain a non-secret key fingerprint, so the exact ambient value cannot be reconstructed after the fact; the source-level precedence defect is deterministic and directly explains that validation/execution mismatch.

## Resolution in 0.2.8

- The runner removes inherited OpenRouter/OpenAI key and base-URL variables before constructing the worker environment.
- `AUTOGENBOOK_LLM_API_KEY` and `AUTOGENBOOK_LLM_BASE_URL` are authoritative for a provider-isolated job.
- The OpenAI-compatible client resolves keys and endpoints according to the selected provider and cannot send an ambient OpenRouter key to Open WebUI.
- Before importing AutoGenBook or building KB indexes, the worker performs a proxy-free `/api/models` preflight with the exact credential it will use later.
- Provider validation and worker preflight use the same proxy-free transport.
- Diagnostics record only the credential source and a 16-character SHA-256 fingerprint, never the key itself.
- If the installer configured an authoritative TXT key reference, an interactively entered replacement updates that TXT file atomically instead of creating an ignored lower-priority override.

## Recovery

After updating both Companion and Pipe to 0.2.8, keep the existing `data` directory and resume with:

```text
pokračuj 88b9592d-3d08-4c67-8ef5-ff49693efa70
```

The existing KB1, KB2 and project inputs remain reusable. The new worker preflight fails before expensive indexing if the current TXT/API key is actually invalid.
