# Reviewer KB1 interactive file upload — design and remediation

## Problem

The fail-closed reviewer correctly requested a KB1 source, but the first interactive prompt
accepted only text commands. A user who already had the applicable regulation as a local PDF
or DOCX could not select it at the moment the source was requested. Filename heuristics on the
initial chat message were insufficient for recovery of an existing project or job.

## Resolution in 0.2.7

The Pipe offers `SOUBOR` in the KB1 question. It sends a two-way Open WebUI `execute` event
that renders a visible modal with a native multi-file input. The browser uploads selected
PDF/DOCX/PPTX/MD/TXT documents to the same Open WebUI origin using the authenticated current
session. Only Open WebUI file IDs and non-secret metadata are returned to the Pipe. The Pipe
then resolves ownership through Open WebUI storage and streams each file to the Companion as
role `kb1`.

A fallback command is also available:

```text
KB1 <PROJECT_OR_JOB_ID>
```

When used with ordinary chat attachments, it explicitly assigns the files to KB1, validates
the project, starts a ready draft or resumes a failed/cancelled/interrupted reviewer job.

## Security properties

- accepted extensions and file count/size are bounded in the UI and checked again server-side;
- upload is same-origin and uses the canonical `/api/v1/files/?process=false` endpoint;
- browser credentials are not returned by the JavaScript result;
- Open WebUI file ownership is checked before local storage resolution;
- filenames are rendered with `textContent`, not injected as HTML;
- Companion semantic validation still rejects login/access pages, unreadable, short or
  irrelevant material;
- no reviewer LLM call occurs before a valid KB1 is present unless the explicit waiver is set.

## Regression coverage

The release tests verify the prompt, generated picker contract, same-origin upload endpoint,
execute-result normalization, file-ID resolution, explicit KB1 upload, project patching,
semantic validation, follow-up project start and existing-job resume behavior.
