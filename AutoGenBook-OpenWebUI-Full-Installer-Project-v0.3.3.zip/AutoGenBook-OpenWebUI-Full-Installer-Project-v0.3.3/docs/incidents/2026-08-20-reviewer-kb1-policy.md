# Incident: reviewer proceeded without KB1

## Observation

A reviewer run successfully indexed KB2 but logged that KB1 was missing and continued with a default prompt. This was an unsafe semantic fallback: a plausible general review could be mistaken for an assessment based on the institution's actual rules.

In the captured run the immediate process failure was a separate HTTP 401 from the LLM provider, not the missing KB1. Nevertheless, the missing-KB1 behavior was a genuine design defect.

## Risk

Without KB1 the model does not know the applicable institution, faculty, programme, work type, regulation, rubric, or effective version. It may therefore invent or assume evaluation criteria.

## Fix in 0.2.5

- reviewer validation requires usable KB1 and KB2;
- the core pipeline fails before the first LLM call when KB1 is missing or zero-chunk;
- diagnostics are emitted as artifacts;
- the Pipe asks for file, URL, text criteria, or sufficient context for discovery;
- web discovery requires confirmation and user selection;
- unsafe/non-public URLs are rejected;
- an explicit waiver is available but prominently marked as non-institutional.

## Acceptance criteria

- Missing KB1: exit 2, diagnostic present, LLM call count zero.
- Empty KB1: same behavior.
- Valid KB1: prompt generated from KB1 and reviewer continues.
- Explicit waiver: reviewer continues with a warning diagnostic.
- Discovery: no browsing without context/confirmation; no import without selection.
