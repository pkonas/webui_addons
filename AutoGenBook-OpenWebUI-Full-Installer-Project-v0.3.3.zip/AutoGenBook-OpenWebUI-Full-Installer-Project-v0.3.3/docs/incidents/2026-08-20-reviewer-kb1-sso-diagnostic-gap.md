# Incident: reviewer accepted an OAuth login page as KB1 and hid the worker failure

## Symptom

A reviewer run produced a complete bundle with one KB1 chunk named `authorize.md`. The
chunk title was *Jednotné přihlášení VUT* and its source was an OAuth2 `authorize`
endpoint. The bundled `run.log` ended immediately after KB preparation and contained no
exception.

## Root causes

1. The public-source probe followed an institutional URL to an SSO/OAuth endpoint and
   treated the final HTTP 200 response as a valid regulation.
2. Project validation checked only file size and extension. One non-empty chunk was
   therefore considered a usable KB1.
3. The reviewer pipeline repeated the same structural check and started LLM1.
4. The complete bundle contained only the output directory. The actual
   `job_root/logs/worker.log` and DB failure record were outside the archive.
5. Failure classification occurred after the bundle was created.

The exact post-KB exception in the affected run cannot be reconstructed from the old
bundle because the relevant worker log was not packaged.

## Fix in 0.2.7

- semantic KB1 quality gate shared by Companion and reviewer runtime;
- explicit rejection of OAuth/SAML/SSO/login and access/error pages;
- relevance and minimum-content checks for HTML, text, PDF, DOCX and PPTX;
- metadata sidecars excluded from the knowledge base;
- only validated KB1 sources are staged for RAG;
- worker failure details are persisted before artifact collection;
- complete bundle includes worker log, request snapshot, progress, job status,
  `failure.json`, `failure.md`, Companion version and protocol version.

## Recovery

Update both Companion and the Open WebUI Function to 0.2.7, keep the existing `data`
directory, supply a public regulation/rubric or detailed explicit criteria, and resume the
job. An SSO-protected URL must be replaced by a directly downloadable public document.
