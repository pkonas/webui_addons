# Incident: výstupní odkazy po čase vracely `Invalid companion token`

## Dopad

AutoGenBook výstup byl fyzicky uložen v pracovním adresáři Companionu, ale text odpovědi v Open WebUI odkazoval na dočasnou adresu ve tvaru:

```text
http://127.0.0.1:<náhodný-port>/v1/artifacts/<id>/download
  ?owner=<uživatel>&expires=<čas>&signature=<podpis>
```

Po vypršení 24hodinového podpisu nebo po změně Companion bearer tokenu se odkaz již nedal otevřít. Starší route po neúspěšném ověření podpisu pokračovala do bearer autentizace. Běžné kliknutí v prohlížeči bearer hlavičku neposílá, a proto uživatel viděl:

```json
{"detail":"Invalid companion token."}
```

## Kořenová příčina

Verze 0.2.8 měla dva odlišné mechanismy, ale v odpovědi je zaměnila:

1. artefakt byl u malých souborů registrován jako Open WebUI File Object;
2. Markdown odpověď přesto nadále používala dočasný `download_url` Companionu;
3. soubory větší než `ATTACH_MAX_BYTES` se do Open WebUI vůbec nekopírovaly;
4. podpis dočasného odkazu používal stejný klíč jako Companion bearer token;
5. expirovaný podpis nebyl odlišen od chybějící bearer autentizace.

## Oprava 0.2.9

- Každý publikovaný výstup se streamuje po blocích do trvalého úložiště Open WebUI.
- Velikost vstupních příloh (`ATTACH_MAX_BYTES`) již neomezuje výstupy.
- Výchozí limit trvalého výstupu je `0`, tedy bez aplikačního limitu; rozhodující je volné místo a pravidla Open WebUI storage.
- Open WebUI file ID je deterministické a uživatelsky oddělené. Opakovaný příkaz `výstupy <job-id>` nevytváří duplicity.
- Odpověď i event `files` používají stabilní relativní adresu:

```text
/api/v1/files/<openwebui-file-id>/content?attachment=true
```

- Dočasný Companion link zůstává pouze API fallbackem a není publikován v chatové odpovědi.
- Klíč pro podpis fallback linku je oddělen od Companion bearer tokenu.
- Expirovaný podpis vrací HTTP 410 s akční zprávou; nepropadá do hlášky `Invalid companion token`.
- Příkaz `výstupy <job-id>` migruje i artefakty úloh vytvořených starší verzí.

## Migrace existujících konverzací

Starý text zprávy nelze bezpečně přepsat zpětně. Po aktualizaci Companionu i Pipe odešlete v AutoGenBook chatu:

```text
výstupy JOB_ID
```

Pipe vyhledá stále existující artefakty, trvale je zaregistruje v Open WebUI a vrátí nové stabilní odkazy. Soubor zůstává dostupný, dokud jej uživatel nebo správce neodstraní nebo dokud jej neodstraní explicitní retenční politika Open WebUI.

## Bezpečnostní vlastnosti

- přístup k trvalému souboru ověřuje Open WebUI vůči vlastníkovi souboru;
- cesta na disku není zveřejněna;
- Companion bearer token není vložen do URL;
- kopírování ověřuje deklarovanou velikost a SHA-256, je-li v manifestu k dispozici;
- dočasný `.part` soubor se při chybě odstraní a finální cesta se aktualizuje atomicky.
