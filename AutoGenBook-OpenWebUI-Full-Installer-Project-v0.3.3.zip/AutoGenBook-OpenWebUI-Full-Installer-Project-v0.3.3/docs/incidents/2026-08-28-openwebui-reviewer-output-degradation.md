# Incident 2026-08-28: degradace reviewer výstupu v Open WebUI

## Analyzovaný běh

- Job: `c1e7de76-c63b-4915-a748-fc161e6ea2ee`
- Stav zaznamenaný Companionem: `SUCCEEDED`
- Model: `e-infra.glm-5`
- Jazyk specifikace: `cs`
- Doba běhu: `180.1 s`
- KB1: 15 chunků z jednoho validovaného předpisu
- KB2: 248 chunků z jedné závěrečné práce
- Výsledný Markdown: 7000 znaků / 996 slov
- LLM-generovaný systémový prompt: 8025 znaků / 1277 slov
- Celkem tokenů: 33587
- Reasoning tokenů: 19310
- Viditelných textových tokenů: 3805

## Pozorované odchylky

### 1. Přepsání kanonické rubriky

Přímý AutoGenBook obsahoval rozsáhlý kanonický reviewer prompt s formální i akademickou rubrikou. WebUI běh však z maximálně osmi vybraných KB1 chunků nechal LLM1 vytvořit nový systémový prompt. Ten omezil posudek na šest procedurálních požadavků R1–R6 a výslovně zakázal hodnotit akademickou kvalitu, metodiku, originalitu, inovaci a přínos.

To bylo v přímém konfliktu s kanonickým `prompt2.md`, který naopak požaduje 0–9 známky právě pro téma/cíle, analýzu, návrhy a závěry, strukturu/formu, originalitu, inovaci a společenský/praktický přínos. Model konflikt vyřešil ve prospěch přepsaného systémového promptu, takže výsledkem nebyl běžný odborný posudek.

### 2. Ztráta většiny KB2

Legacy pipeline provedla jediný retrieval s `k=6`. Z 248 chunků práce tak do LLM2 vstoupilo šest fragmentů, tedy přibližně 2,4 % dostupných částí. Výsledek proto tvrdil, že měl jen stránky 44, 89 a 91, a nemohl posoudit celek.

### 3. Ignorovaný jazyk a zadání

Specifikace obsahovala `language=cs`, ale reviewer pipeline jazyk do promptu nepřidala. Výsledek byl převážně anglicky. Pole `brief` obsahovalo pouze technické `<attached_files>` XML; vlastní implicitní požadavek na úplný český posudek nebyl vytvořen ani předán.

### 4. Vstupní `.pdf` byl zaměněn za požadovaný export

Pipe prohledávala celý surový prompt na tokeny `pdf`, `docx` apod. Název přiložené práce `sdz_kopecek_pavel.pdf` proto mylně určil výstupy na samotné `pdf`. Command následně obsahoval `--no-md --no-tex`, přestože výchozí reviewer výstupy mají být Markdown, DOCX, PDF a ZIP.

### 5. Selhaný PDF export byl označen jako úspěch

Pandoc/pdfLaTeX skončil chybou na Unicode znaku `≥` a upozorněním na zvýšená oprávnění. PDF nevzniklo. Pipeline přesto zalogovala „Export conversion finished“, vrátila exit code 0 a Companion označil job jako `SUCCEEDED`.

### 6. Nevhodné využití tokenového rozpočtu

Z 23 115 výstupních tokenů připadlo 19 310 na reasoning a pouze 3 805 na viditelný text. Navíc první drahé modelové volání nebylo použito k posouzení práce, ale k přepsání systémového promptu. To prodloužilo běh a současně zhoršilo výsledný obsah.

## Kořenové příčiny

1. integrační vrstva měnila obsahový kontrakt core pipeline místo pouhého přenosu konfigurace;
2. KB1-generated prompt měl vyšší prioritu než kanonická rubrika;
3. retrieval byl dimenzován jako krátká QA odpověď, nikoli posouzení celého dokumentu;
4. Pipe nerozlišovala metadata příloh od uživatelského textu;
5. chyběl jazykový, obsahový a exportní quality gate;
6. command/manifesta nezachycovaly všechny podmínky pro reprodukci přímým CLI.

## Oprava 0.3.0

- výchozí `reviewer_profile=direct` zachovává kanonický systémový prompt a nevolá LLM1;
- profil `hybrid` smí vytvořit jen oddělené KB1 addendum;
- evidence pack kombinuje dokumentové kotvy a retrieval pro sedm kanonických kritérií;
- KB1 je předána v dokumentovém pořadí a nenahrazuje akademickou rubriku;
- attachment XML je odstraněno před parsováním zadání a exportů;
- jazyk a čisté uživatelské instrukce jsou explicitní součástí promptu;
- každý běh zapisuje parity/evidence/quality/conversion manifest;
- požadované exporty se ověřují fail-closed;
- PDF `auto` preferuje LuaLaTeX/XeLaTeX;
- model je explicitně uveden v CLI commandu i nesekretním parity manifestu;
- výstup, který neprojde quality gate, se nevydá za úspěšný.

## Omezení závěru

Příloha neobsahovala samostatný výstup přímého CLI pro automatickou textovou diff analýzu. Závěr o degradaci proto vychází z interního kontraktu stejného zdrojového projektu, promptů, exact commandu a diagnostiky WebUI běhu. Bitová shoda LLM textu vyžaduje stejný model revision a endpoint; verze 0.3.0 garantuje shodu vstupního/promptového/exportního kontraktu a fail-closed kvalitu.
