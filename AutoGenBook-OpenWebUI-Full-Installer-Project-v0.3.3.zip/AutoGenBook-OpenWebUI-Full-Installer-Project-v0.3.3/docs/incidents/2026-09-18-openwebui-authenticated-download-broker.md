# Incident: AutoGenBook output links returned `Not authenticated` or `No content`

**Status:** resolved in 0.3.2  
**Affected versions:** 0.3.1 and older output-link implementations  
**Date:** 2026-09-18

## User-visible symptoms

Two different controls in the same AutoGenBook answer failed differently:

1. A Markdown link such as `/api/v1/files/<id>/content?attachment=true` opened a JSON response:

   ```json
   {"detail":"Not authenticated"}
   ```

2. Clicking the Open WebUI file card opened a modal whose text area said:

   ```text
   No content
   ```

The generated binary file could still exist in Open WebUI storage. The failures were in the delivery contract between the Function and the Open WebUI browser client.

## Root cause 1: browser navigation did not carry a bearer header

The Open WebUI file-content endpoint is protected by `get_verified_user`. In desktop configurations where the active login is held in browser storage, a plain Markdown navigation or `window.open()` does not attach the `Authorization: Bearer ...` header. The endpoint therefore correctly returned HTTP 401.

Version 0.3.1 incorrectly treated a same-origin relative URL as sufficient authentication. Same-origin controls cookies and CORS; it does not synthesize an Authorization header.

## Root cause 2: binary files have no extracted text preview

Open WebUI's file modal renders `item.file.data.content` for the text-preview tab. AutoGenBook registered binary artifacts with status and provenance metadata but without textual `data.content`. The modal therefore displayed its fallback string `No content`.

That message did not prove the stored PDF, DOCX, ZIP, video or presentation was zero bytes. It meant only that the binary artifact had no extracted text representation.

## Resolution

Version 0.3.2 introduces a same-origin authenticated download broker inside the AutoGenBook Function.

### Durable landing URL

User-facing answers and file objects now point to:

```text
/api/autogenbook/files/<openwebui-file-id>/download
```

This URL contains no bearer token, API key, Companion token, random Companion port or expiring signature. It remains stable as long as the Function is installed and the Open WebUI file exists.

### Authenticated ticket issuance

The landing page never serves file bytes. It:

1. reads the current Open WebUI browser token at click time, or relies on the current secure cookie;
2. sends a same-origin authenticated POST to `/api/autogenbook/download-ticket`;
3. the server resolves the user through Open WebUI's own authentication stack;
4. it verifies file ownership, admin role or an explicit read grant;
5. it returns a short-lived HMAC ticket that contains only file/user identifiers and expiry.

### Streaming endpoint

The ticket is consumed by:

```text
/api/autogenbook/download-stream/<ticket>
```

The endpoint reads the file through Open WebUI's Storage abstraction and supports:

- `GET` and `HEAD`;
- `Range` and suffix ranges;
- `If-Range` and `ETag`;
- HTTP 206 for partial content;
- HTTP 416 for invalid or unsatisfiable ranges;
- bounded block streaming instead of loading the whole file into RAM.

The ticket is additionally bound to the file owner recorded when it was issued, preventing a file-record replacement from reusing an old ticket for another owner.

### Useful modal content

For binary AutoGenBook outputs, `data.content` now contains a short Markdown descriptor with:

- filename;
- MIME type;
- byte size;
- a durable authenticated **Download** link;
- an explanation that the binary itself is not copied into the text preview.

This removes the misleading `No content` fallback without pretending to extract text from arbitrary binary formats.

### Repair of existing jobs

The command:

```text
výstupy JOB_ID
```

is idempotent. On 0.3.2 it reuses the deterministic Open WebUI file ID, repairs the stored preview metadata and returns new broker URLs. It does not rerun the LLM or regenerate the document.

The old assistant message cannot be mutated retroactively; the newly produced response must be used.

## Security properties

- Public landing pages do not expose bytes or secrets.
- The ticket endpoint requires a current Open WebUI identity.
- Unauthorized callers receive 404 for existing files owned by another user.
- Download tickets are HMAC-protected and time-limited.
- Tokens are never put into query strings, response Markdown or file metadata.
- File bytes are served only from paths resolved through the Open WebUI Storage provider.
- Temporary Companion download URLs are not exposed as a user-facing fallback.

## Regression tests

The release gate covers:

- missing authentication → 401;
- correct owner → ticket issued;
- foreign user → 404;
- cookie and bearer authentication;
- full GET and HEAD;
- byte and suffix ranges → 206;
- mismatched and matching `If-Range`;
- invalid range → 416;
- tampered and expired tickets → 401;
- owner change after issuance → 404;
- route ordering before the SPA catch-all;
- idempotent route registration;
- repair of an older file record with missing preview content;
- no publication of a temporary Companion fallback.
