# Incident: stahování výstupů selhalo i přes autentizovaný broker

**Datum analýzy:** 2026-09-18  
**Opraveno ve verzi:** 0.3.3  
**Dotčená verze:** 0.3.2

## Pozorovaný stav

Generování i kopírování artefaktů do Open WebUI proběhlo úspěšně. Nativní detail souboru a jeho obsahový endpoint byly dostupné přes autentizované požadavky rozhraní. Přímá navigace na variantu s `?attachment=true` ale skončila HTTP 401.

Broker 0.3.2 následně otevřel landing stránku úspěšně, avšak každý požadavek na `/api/autogenbook/download-ticket` skončil HTTP 401. Ke streamovacímu endpointu se proto klient nikdy nedostal.

## Kořenová příčina

Landing stránka se snažila znovu získat identitu uživatele z browserového `localStorage` nebo z cookie. Open WebUI Desktop může otevřít novou stránku v jiném loopback originu nebo izolovaném renderer/storage kontextu. V takovém okně nemusí být token v `localStorage` dostupný a session cookie se nemusí vztahovat na použitý host. Výsledkem byl požadavek bez bearer credentialu i bez platné cookie.

Pouhé překreslení dialogu nebo opakování požadavku nemohlo problém vyřešit. Chyba byla v autentizačním předpokladu celé download cesty.

## Oprava 0.3.3

Výstupní soubor se při registraci do Open WebUI opatří stabilní HMAC capability:

```text
/api/autogenbook/download/PODEPSANÁ_CAPABILITY
```

Capability:

- neobsahuje Open WebUI API klíč, browserový JWT ani Companion token;
- je podepsána klíčem odvozeným od stabilního `WEBUI_SECRET_KEY`;
- je svázána s ID souboru, vlastníkem, SHA-256 a velikostí;
- funguje při běžné navigaci bez dodatečné hlavičky `Authorization`;
- podporuje `GET`, `HEAD`, `Range`, `If-Range`, `ETag`, odpovědi 206 a 416;
- zanikne při smazání nebo nahrazení souboru, změně vlastníka/hash/velikosti nebo rotaci `WEBUI_SECRET_KEY`.

Staré 0.3.2 endpointy zůstávají pouze jako diagnostický fallback a vracejí HTTP 410 s pokynem `výstupy JOB_ID`.

## Bezpečnostní model

Capability URL je přístupový údaj: kdokoli, komu je URL předána, může soubor stáhnout. URL je kryptograficky neuhodnutelná a standardně se objeví pouze v soukromé konverzaci vlastníka, ale nemá být zveřejňována. Tento model byl zvolen proto, že standalone Open WebUI bez úpravy frontendového kódu neumí při obyčejné navigaci spolehlivě připojit bearer hlavičku.

## Oprava starších úloh

Po aktualizaci Companionu i Function odešlete:

```text
výstupy JOB_ID
```

Příkaz znovu použije existující artefakty, opraví `data.content`, vytvoří nové capability odkazy a nevolá LLM znovu.
