# Incident: AutoGenBook output files were not downloadable from Open WebUI

**Resolved in:** 0.3.1  
**Date:** 2026-09-18

## User-visible symptom

AutoGenBook completed a job and created artifacts, but the Open WebUI response did not provide a usable native file attachment. Depending on the client version, users saw only textual output links, no file card, or a file item that could not be opened reliably.

## Root cause

Version 0.3.0 registered the artifact in the Open WebUI file database, but emitted the raw backend `FileModel` dictionary in the Function `files` event. That dictionary did not contain the top-level UI fields expected by the Open WebUI response renderer:

- `type: "file"`
- `id`
- `url` containing the Open WebUI file ID
- `status: "uploaded"`
- top-level `name`, `size`, and `content_type`

Open WebUI filters assistant response files to entries whose `type` is `file` or `image`. The missing `type` caused the artifact to be silently excluded from the response UI. The previous payload also used a full API path in `url`, while normal Open WebUI chat-file objects use the file ID and let the client construct `/api/v1/files/<id>/content`.

The earlier test suite verified that bytes reached the upload directory and that a `files` event was emitted, but it did not validate the frontend attachment contract or exercise the resulting content endpoint.

## Correction

Version 0.3.1:

1. emits the canonical Open WebUI assistant-file object;
2. sets `type="file"`, `status="uploaded"`, the durable Open WebUI `id`, and `url=<file-id>`;
3. includes the complete backend file record in `file` for preview dialogs;
4. retains `persistent_url` and `download_url` for markdown and fallback clients;
5. reads the file row back from Open WebUI before publishing the link;
6. verifies ownership, metadata size, and—on local storage—the physical file and exact byte size;
7. refuses to publish a broken native link;
8. falls back to a newly generated temporary Companion link when native registration is unavailable, while labeling it explicitly as temporary;
9. keeps the `výstupy <job-id>` repair command idempotent, so old jobs can be reattached without regeneration.

## Regression coverage

The release tests now verify:

- the exact `message.files` object consumed by Open WebUI;
- visibility under the response renderer's `type in {file,image}` filter;
- the native file ID used by `FileItemModal`;
- stable `/api/v1/files/<id>/content?attachment=true` markdown URLs;
- real byte retrieval through a FastAPI file-content endpoint;
- idempotent reuse after a later `výstupy` request;
- absence of an expiring Companion URL in the successful native path;
- an explicit fresh temporary fallback when native registration is unavailable.

## Repairing old conversations

After updating both Companion and Function to 0.3.1, run:

```text
výstupy <job-id>
```

The command reuses the existing artifacts, creates or verifies durable Open WebUI file records, and emits new native file cards. The original generation is not repeated.
