# Historický patchovací řetězec

Verze před 0.2.0 sestavovaly Open WebUI integraci pomocí postupných skriptů
`apply_openwebui_llm_progress_v2` až `v5`. Tento přístup dovoloval rozdíl mezi
vývojovým overlay a skutečně distribuovaným bundle a jeden historický CI běh
navíc odhalil chybu FastAPI `422` na progress endpointu.

Od verze 0.2.0 je výsledný zdroj přímo součástí projektu a jediným kanonickým
nástrojem je `tools/build_openwebui_integration.py`. Staré skripty a workflow
byly odstraněny, aby nemohly vytvořit neauditovanou variantu instalátoru.
