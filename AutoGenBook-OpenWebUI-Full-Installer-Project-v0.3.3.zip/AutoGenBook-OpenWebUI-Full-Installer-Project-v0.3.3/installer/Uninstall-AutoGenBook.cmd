@echo off
setlocal
set ROOT=%~dp0..
if exist "%ROOT%\runtime\python\python.exe" (
  "%ROOT%\runtime\python\python.exe" "%~dp0uninstall.py" --install-dir "%ROOT%" %*
) else (
  python "%~dp0uninstall.py" --install-dir "%ROOT%" %*
)
endlocal
