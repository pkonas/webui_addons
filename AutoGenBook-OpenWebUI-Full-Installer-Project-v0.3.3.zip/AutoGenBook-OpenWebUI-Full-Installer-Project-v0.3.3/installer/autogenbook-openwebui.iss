#ifndef StageDir
  #error StageDir must be supplied with /DStageDir=...
#endif
#ifndef OutputDir
  #define OutputDir "."
#endif
#ifndef AppVersion
  #define AppVersion "0.3.3"
#endif

[Setup]
AppId={{2E15B076-91C8-4C32-AF8C-31CA7E924B41}
AppName=AutoGenBook for Open WebUI
AppVersion={#AppVersion}
AppPublisher=AutoGenBook contributors
DefaultDirName={localappdata}\Programs\AutoGenBook OpenWebUI
DefaultGroupName=AutoGenBook for Open WebUI
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
OutputDir={#OutputDir}
OutputBaseFilename=AutoGenBook-OpenWebUI-Setup-Windows-x64
UninstallDisplayIcon={app}\runtime\python\python.exe

[Files]
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Configure AutoGenBook for Open WebUI"; Filename: "{app}\installer\Install-AutoGenBook.cmd"; WorkingDir: "{app}"
Name: "{group}\AutoGenBook integration documentation"; Filename: "{app}\docs\OPENWEBUI_INTEGRATION_CS.md"
Name: "{group}\Uninstall AutoGenBook for Open WebUI"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\runtime\python\python.exe"; Parameters: """{app}\installer\install.py"" --source-root ""{app}"" --install-dir ""{app}"" --configure-only --non-interactive"; WorkingDir: "{app}"; Flags: runhidden waituntilterminated
Filename: "{app}\installer\Install-AutoGenBook.cmd"; Description: "Register AutoGenBook in Open WebUI now"; WorkingDir: "{app}"; Flags: postinstall skipifsilent
