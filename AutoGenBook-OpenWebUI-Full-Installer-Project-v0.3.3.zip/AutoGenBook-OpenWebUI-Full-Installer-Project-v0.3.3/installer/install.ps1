$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$PythonCandidates = @(
  (Join-Path $Root "runtime\python\python.exe"),
  (Join-Path $Root "runtime\python\bin\python3"),
  "python"
)
$Python = $null
foreach ($Candidate in $PythonCandidates) {
  if (Test-Path $Candidate -PathType Leaf) { $Python = $Candidate; break }
  if (Get-Command $Candidate -ErrorAction SilentlyContinue) { $Python = $Candidate; break }
}
if (-not $Python) { throw "Python runtime was not found." }
& $Python (Join-Path $PSScriptRoot "install.py") --source-root $Root @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Read-Host "Press Enter to close"
