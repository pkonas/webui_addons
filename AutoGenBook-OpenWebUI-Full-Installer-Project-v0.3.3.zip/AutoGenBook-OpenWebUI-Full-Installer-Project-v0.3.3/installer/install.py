from __future__ import annotations

import argparse
import getpass
import hashlib
import http.client
import importlib.util
import json
import os
import shutil
import signal
import ssl
import subprocess
import sys
import time
import urllib.request
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Any, NamedTuple

FUNCTION_ID = "autogenbook_companion"
INSTALLER_VERSION = "0.3.3"
OPENWEBUI_API_KEY_SECRET = "openwebui_api_key"


class OpenWebUITransportError(RuntimeError):
    """The target could not be reached with a valid direct HTTP request."""


class OpenWebUIRegistrationError(RuntimeError):
    """Automatic Function registration is unavailable or not authorized."""


class OpenWebUITarget(NamedTuple):
    scheme: str
    host: str
    port: int
    base_path: str
    display_url: str


def default_install_dir() -> Path:
    home = Path.home()
    if sys.platform == "win32":
        local = Path(os.environ.get("LOCALAPPDATA") or home / "AppData" / "Local")
        return local / "Programs" / "AutoGenBook OpenWebUI"
    if sys.platform == "darwin":
        return home / "Library" / "Application Support" / "AutoGenBook-OpenWebUI"
    base = Path(os.environ.get("XDG_DATA_HOME") or home / ".local" / "share")
    return base / "autogenbook-openwebui"


def bundled_python(root: Path) -> Path:
    candidates = [
        root / "runtime" / "python" / "python.exe",
        root / "runtime" / "python" / "bin" / "python3",
        root / "runtime" / "python" / "bin" / "python",
        root / "runtime" / "venv" / "Scripts" / "python.exe",
        root / "runtime" / "venv" / "bin" / "python3",
        root / "runtime" / "venv" / "bin" / "python",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()
    if sys.version_info >= (3, 10):
        return Path(sys.executable).resolve()
    raise RuntimeError("Bundled Python was not found and the system Python is older than 3.10.")


def using_bundled_python(root: Path, python: Path | None = None) -> bool:
    executable = (python or bundled_python(root)).resolve()
    runtime = (root / "runtime").resolve()
    try:
        executable.relative_to(runtime)
        return True
    except ValueError:
        return False


def _load_key_file_module(install_dir: Path):
    module_path = install_dir / "companion" / "src" / "autogenbook_companion" / "key_file.py"
    if not module_path.is_file():
        module_path = install_dir / "app" / "companion" / "src" / "autogenbook_companion" / "key_file.py"
    if not module_path.is_file():
        raise RuntimeError(f"API-key file support module was not found: {module_path}")
    module_name = f"_autogenbook_installer_key_file_{abs(hash(str(module_path.resolve())))}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load API-key file support module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


def configure_api_key_file_reference(install_dir: Path, source_path: str | Path) -> tuple[str, dict[str, Any]]:
    """Validate a TXT file and persist only its absolute path as a live secret source."""

    module = _load_key_file_module(install_dir)
    loaded = module.read_api_key_file(
        source_path,
        require_txt_suffix=True,
        reject_session_token=True,
    )
    reference = module.set_file_reference(
        install_dir / "data" / "secrets",
        OPENWEBUI_API_KEY_SECRET,
        loaded.path,
        configured_by=f"installer-{INSTALLER_VERSION}",
        priority="external_first",
    )
    warnings = module.key_file_permission_warnings(loaded.path)
    source = {
        "type": "text_file_reference",
        "path": str(loaded.path),
        "read_mode": "live",
        "size": int(loaded.size),
        "encoding": str(loaded.encoding),
        "config_path": str(reference["config_path"]),
        "priority": str(reference["priority"]),
        "permission_warnings": list(warnings),
    }
    return str(loaded.value), source


def clear_api_key_file_reference(install_dir: Path) -> bool:
    module = _load_key_file_module(install_dir)
    return bool(
        module.clear_file_reference(
            install_dir / "data" / "secrets",
            OPENWEBUI_API_KEY_SECRET,
        )
    )


def normalize_direct_api_key(install_dir: Path, raw_value: str) -> str:
    """Normalize interactive/CLI input before it can become an HTTP header."""

    module = _load_key_file_module(install_dir)
    return str(
        module.normalize_api_key_text(
            raw_value,
            reject_session_token=True,
        )
    )


def api_key_fingerprint(api_key: str) -> str:
    return hashlib.sha256(str(api_key).strip().encode("utf-8")).hexdigest()[:16]


def validate_openwebui_api_key(base_url: str, api_key: str) -> dict[str, Any]:
    """Validate that the key can enumerate models without ever logging the key."""

    attempts: list[dict[str, Any]] = []
    for endpoint in ("/api/models", "/api/v1/models"):
        status_code, payload = api_request(base_url, api_key, "GET", endpoint, timeout=20.0)
        attempts.append({"endpoint": endpoint, "status": status_code})
        if status_code == 200:
            model_count = 0
            if isinstance(payload, list):
                model_count = len(payload)
            elif isinstance(payload, dict):
                rows = payload.get("data") or payload.get("models") or []
                if isinstance(rows, list):
                    model_count = len(rows)
            return {"valid": True, "endpoint": endpoint, "model_count": model_count, "attempts": attempts, "key_fingerprint": api_key_fingerprint(api_key)}
        if status_code in {401, 403}:
            raise RuntimeError(
                f"Open WebUI API key from the TXT file was rejected with HTTP {status_code} at {endpoint}."
            )
        if status_code != 404:
            raise RuntimeError(
                f"Open WebUI API-key validation failed with HTTP {status_code} at {endpoint}: {payload}"
            )
    raise RuntimeError(f"Open WebUI model API was not found; attempts={attempts}")


def resolve_source_dir(install_dir: Path) -> Path:
    """Support both the packaged installer layout and a checked-out source tree.

    Complete offline builds store AutoGenBook below ``app``.  The audited source
    archive stores ``main.py`` directly at the project root.  Older installers
    always selected ``app`` and therefore produced a degraded or unusable worker
    when launched from the source archive.
    """

    candidates = (
        install_dir / "app",
        install_dir,
        install_dir / "source",
    )
    for candidate in candidates:
        if (candidate / "main.py").is_file():
            return candidate.resolve()
    rendered = ", ".join(str(item / "main.py") for item in candidates)
    raise RuntimeError(f"AutoGenBook main.py was not found. Checked: {rendered}")


def companion_python_paths(install_dir: Path) -> list[Path]:
    candidates = (
        install_dir / "companion" / "src",
        install_dir / "app" / "companion" / "src",
        install_dir / "source" / "companion" / "src",
        install_dir,
        install_dir / "app",
        install_dir / "source",
    )
    rows: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        if not candidate.is_dir():
            continue
        resolved = candidate.resolve()
        key = os.path.normcase(str(resolved))
        if key in seen:
            continue
        seen.add(key)
        rows.append(resolved)
    return rows


def stop_process_tree(pid: int) -> None:
    if pid <= 0:
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            check=False,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return
    try:
        os.killpg(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            return
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return
        time.sleep(0.1)
    try:
        os.killpg(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def stop_installed_companion(install_dir: Path) -> bool:
    """Stop only a Companion that answers with this installation's bridge token."""

    data_home = install_dir / "data"
    bridge_path = data_home / "bridge.json"
    if not bridge_path.exists():
        return False
    try:
        bridge = wait_for_bridge(
            data_home,
            log_path=data_home / "logs" / "companion.log",
            timeout=2,
        )
        declared_home = Path(str(bridge.get("home", ""))).resolve()
        if declared_home != data_home.resolve():
            return False
        pid = int(bridge.get("pid", 0) or 0)
    except Exception:
        return False
    stop_process_tree(pid)
    bridge_path.unlink(missing_ok=True)
    return True


def copy_payload(source: Path, target: Path) -> None:
    source = source.resolve()
    target = target.resolve()
    if source == target:
        return
    staging = target.with_name(target.name + ".installing")
    if staging.exists():
        shutil.rmtree(staging)
    staging.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        source,
        staging,
        ignore=shutil.ignore_patterns(
            "data",
            "*.part",
            "__pycache__",
            ".pytest_cache",
            ".ruff_cache",
            ".DS_Store",
        ),
    )
    backup = target.with_name(target.name + ".previous")
    if target.exists():
        if backup.exists():
            shutil.rmtree(backup)
        target.replace(backup)
        try:
            # Preserve projects, job database, logs and per-user secrets without copying
            # potentially multi-gigabyte outputs. Both paths share the same parent volume,
            # so this is an atomic directory move on supported local filesystems.
            preserved_data = backup / "data"
            if preserved_data.exists():
                staged_data = staging / "data"
                if staged_data.exists():
                    shutil.rmtree(staged_data)
                preserved_data.replace(staged_data)
            staging.replace(target)
        except Exception:
            staged_data = staging / "data"
            backup_data = backup / "data"
            if staged_data.exists() and not backup_data.exists():
                staged_data.replace(backup_data)
            if not target.exists() and backup.exists():
                backup.replace(target)
            raise
    else:
        staging.replace(target)


def parse_openwebui_target(base_url: str) -> OpenWebUITarget:
    raw = str(base_url or "").strip().strip('"').strip("'")
    if not raw:
        raise ValueError("Open WebUI URL is empty.")
    if "://" not in raw:
        raw = "http://" + raw
    parsed = urllib.parse.urlsplit(raw)
    scheme = parsed.scheme.casefold()
    if scheme not in {"http", "https"}:
        raise ValueError("Open WebUI URL must use http:// or https://.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Open WebUI URL must not contain credentials.")
    if parsed.query or parsed.fragment:
        raise ValueError("Open WebUI URL must not contain a query string or fragment.")
    host = parsed.hostname
    if not host:
        raise ValueError("Open WebUI URL does not contain a host name.")
    try:
        port = parsed.port or (443 if scheme == "https" else 80)
    except ValueError as exc:
        raise ValueError("Open WebUI URL contains an invalid port.") from exc
    base_path = urllib.parse.quote(urllib.parse.unquote(parsed.path or ""), safe="/%:@-._~!$&'()*+,;=")
    base_path = "/" + base_path.strip("/") if base_path.strip("/") else ""
    host_display = f"[{host}]" if ":" in host and not host.startswith("[") else host
    default_port = 443 if scheme == "https" else 80
    authority = host_display if port == default_port else f"{host_display}:{port}"
    return OpenWebUITarget(
        scheme=scheme,
        host=host,
        port=port,
        base_path=base_path,
        display_url=f"{scheme}://{authority}{base_path}",
    )


def _request_path(target: OpenWebUITarget, path: str) -> str:
    raw_path = str(path or "").strip()
    if not raw_path.startswith("/"):
        raw_path = "/" + raw_path
    parsed = urllib.parse.urlsplit(raw_path)
    if parsed.scheme or parsed.netloc or parsed.fragment:
        raise ValueError("Open WebUI API path must be relative and must not contain a fragment.")
    normalized_path = urllib.parse.quote(
        urllib.parse.unquote(parsed.path or "/"),
        safe="/%:@-._~!$&'()*+,;=",
    )
    target_path = f"{target.base_path}{normalized_path}" or "/"
    if parsed.query:
        target_path += "?" + parsed.query
    if "\r" in target_path or "\n" in target_path or "\x00" in target_path:
        raise ValueError("Open WebUI API path contains an invalid control character.")
    return target_path


def _decode_http_payload(raw: bytes, content_type: str | None) -> Any:
    if not raw:
        return None
    text = raw.decode("utf-8", errors="replace")
    if "json" in str(content_type or "").casefold() or text.lstrip().startswith(("{", "[")):
        try:
            return json.loads(text)
        except Exception:
            pass
    return text.strip()


def api_request(
    base_url: str,
    api_key: str | None,
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    timeout: float = 20.0,
) -> tuple[int, Any]:
    """Send a proxy-free, standards-compliant request directly to Open WebUI.

    The previous urllib opener could inherit machine proxy settings and accepted
    unsanitized values from command-line/environment input.  A direct
    ``http.client`` connection avoids proxy rewriting and validates the request
    target and header value before any bytes are sent.
    """

    target = parse_openwebui_target(base_url)
    request_path = _request_path(target, path)
    method_name = str(method).strip().upper()
    if not method_name or any(character.isspace() for character in method_name):
        raise ValueError("Invalid HTTP method.")
    key = str(api_key or "").strip()
    if key and any(
        character in key for character in ("\r", "\n", "\x00")
    ):
        raise ValueError("Open WebUI API key contains a forbidden control character.")

    body = None if payload is None else json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    headers = {
        "Accept": "application/json",
        "Connection": "close",
        "User-Agent": f"AutoGenBook-OpenWebUI-Installer/{INSTALLER_VERSION}",
    }
    if key:
        headers["Authorization"] = f"Bearer {key}"
    if body is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"

    connection: http.client.HTTPConnection
    if target.scheme == "https":
        connection = http.client.HTTPSConnection(
            target.host,
            target.port,
            timeout=timeout,
            context=ssl.create_default_context(),
        )
    else:
        connection = http.client.HTTPConnection(target.host, target.port, timeout=timeout)
    try:
        connection.request(method_name, request_path, body=body, headers=headers)
        response = connection.getresponse()
        raw = response.read()
        return int(response.status), _decode_http_payload(raw, response.getheader("Content-Type"))
    except (OSError, ssl.SSLError, http.client.HTTPException, ValueError) as exc:
        raise OpenWebUITransportError(
            f"Direct HTTP request to {target.display_url}{request_path} failed: "
            f"{type(exc).__name__}: {exc}"
        ) from exc
    finally:
        try:
            connection.close()
        except Exception:
            pass


def is_openwebui_instance(base_url: str, *, timeout: float = 1.0) -> bool:
    """Require an Open WebUI-specific version response; do not accept any /health service."""

    try:
        status_code, payload = api_request(base_url, None, "GET", "/api/version", timeout=timeout)
    except Exception:
        return False
    if status_code != 200:
        return False
    if isinstance(payload, dict):
        version = payload.get("version") or payload.get("webui_version")
        return bool(str(version or "").strip())
    if isinstance(payload, str):
        return bool(re.search(r"\d+\.\d+", payload))
    return False


def discover_openwebui() -> str | None:
    env_url = os.environ.get("OPENWEBUI_URL")
    if env_url:
        try:
            target = parse_openwebui_target(env_url)
        except ValueError:
            return None
        return target.display_url if is_openwebui_instance(target.display_url, timeout=2.0) else None

    ports = [3000, 8000, *range(8080, 8181)]
    for port in ports:
        url = f"http://127.0.0.1:{port}"
        if is_openwebui_instance(url, timeout=0.2):
            return url
    return None


def registration_preflight(base_url: str, api_key: str) -> dict[str, Any]:
    """Verify that the key can access the admin Function API before sending source code."""

    target = parse_openwebui_target(base_url)
    if not is_openwebui_instance(target.display_url, timeout=3.0):
        raise OpenWebUIRegistrationError(
            f"The selected address is not a verified Open WebUI backend: {target.display_url}"
        )
    status_code, payload = api_request(
        target.display_url,
        api_key,
        "GET",
        "/api/v1/functions/list",
        timeout=20.0,
    )
    if status_code == 200 and isinstance(payload, list):
        return {
            "authorized": True,
            "target": target.display_url,
            "function_count": len(payload),
        }
    if status_code == 401:
        raise OpenWebUIRegistrationError(
            "The supplied key is invalid, expired, or is not accepted for the Open WebUI admin API (HTTP 401)."
        )
    if status_code == 403:
        raise OpenWebUIRegistrationError(
            "The supplied key does not have administrator access to the Open WebUI Function API (HTTP 403)."
        )
    if status_code == 404:
        raise OpenWebUIRegistrationError(
            "This Open WebUI version does not expose the expected Function administration API. Use manual import."
        )
    raise OpenWebUIRegistrationError(
        f"Open WebUI Function API preflight failed with HTTP {status_code}: {payload}"
    )


def log_tail(path: Path | None, max_bytes: int = 24_000) -> str:
    if path is None or not path.exists():
        return ""
    try:
        size = path.stat().st_size
        with path.open("rb") as stream:
            stream.seek(max(0, size - max_bytes))
            return stream.read().decode("utf-8", errors="replace").strip()
    except OSError as exc:
        return f"<log could not be read: {exc}>"


def _startup_error(message: str, log_path: Path | None) -> RuntimeError:
    tail = log_tail(log_path)
    if tail:
        message += f"\n\nLast lines from {log_path}:\n{tail}"
    return RuntimeError(message)


def wait_for_bridge(
    data_home: Path,
    *,
    process: subprocess.Popen[Any] | None = None,
    log_path: Path | None = None,
    timeout: float = 60.0,
) -> dict[str, Any]:
    bridge_path = data_home / "bridge.json"
    deadline = time.monotonic() + max(2.0, timeout)
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if process is not None:
            return_code = process.poll()
            if return_code is not None:
                raise _startup_error(
                    f"Companion process exited before becoming healthy (exit code {return_code}).",
                    log_path,
                )
        try:
            bridge = json.loads(bridge_path.read_text(encoding="utf-8"))
            token_path = Path(str(bridge["token_file"]))
            token = token_path.read_text(encoding="utf-8").strip()
            request = urllib.request.Request(
                f"{str(bridge['url']).rstrip('/')}/v1/health",
                headers={"Authorization": f"Bearer {token}"},
            )
            with urllib.request.urlopen(request, timeout=2) as response:
                raw = response.read()
                health = json.loads(raw.decode("utf-8")) if raw else {}
                if response.status == 200 and health.get("status") == "ok" and health.get(
                    "autogenbook_available", True
                ):
                    bridge["health"] = health
                    return bridge
                last_error = RuntimeError(f"Companion returned a degraded health response: {health}")
        except Exception as exc:
            last_error = exc
        time.sleep(0.35)
    detail = str(last_error) if last_error is not None else "no bridge or health response"
    raise _startup_error(f"Companion did not become healthy within {timeout:g} seconds: {detail}", log_path)


def bundled_environment(install_dir: Path) -> dict[str, str]:
    env = {str(k): str(v) for k, v in os.environ.items()}
    tools_root = install_dir / "tools"
    common_bin = tools_root / "bin"
    path_entries: list[str] = []
    if common_bin.is_dir():
        path_entries.append(str(common_bin.resolve()))
    tinytex_bin = tools_root / "tinytex" / "bin"
    if tinytex_bin.is_dir():
        path_entries.extend(str(item.resolve()) for item in sorted(tinytex_bin.iterdir()) if item.is_dir())
    python = bundled_python(install_dir)
    for item in (python.parent, python.parent / "Scripts", python.parent / "bin"):
        if item.is_dir():
            path_entries.append(str(item.resolve()))
    current_path = env.get("PATH", "")
    env["PATH"] = os.pathsep.join([*path_entries, current_path] if current_path else path_entries)

    python_paths = [str(item) for item in companion_python_paths(install_dir)]
    existing_pythonpath = env.get("PYTHONPATH", "")
    if existing_pythonpath:
        python_paths.append(existing_pythonpath)
    env["PYTHONPATH"] = os.pathsep.join(python_paths)

    source_dir = resolve_source_dir(install_dir)
    env.update(
        {
            "AUTOGENBOOK_INSTALL_ROOT": str(install_dir),
            "AUTOGENBOOK_SOURCE_DIR": str(source_dir),
            "AUTOGENBOOK_COMPANION_HOME": str(install_dir / "data"),
            "PYTHONUNBUFFERED": "1",
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
        }
    )

    pandoc = common_bin / ("pandoc.exe" if os.name == "nt" else "pandoc")
    ffmpeg = common_bin / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    piper_model = tools_root / "piper" / "cs_CZ-jirka-medium.onnx"
    piper_config = tools_root / "piper" / "cs_CZ-jirka-medium.onnx.json"
    if pandoc.exists():
        env["PYPANDOC_PANDOC"] = str(pandoc)
    if ffmpeg.exists():
        env["IMAGEIO_FFMPEG_EXE"] = str(ffmpeg)
        env["FFMPEG_BINARY"] = str(ffmpeg)
    if piper_model.exists() and piper_config.exists():
        env["AUTOGENBOOK_PIPER_MODEL"] = str(piper_model)
        env["AUTOGENBOOK_PIPER_CONFIG"] = str(piper_config)
    native_lib = tools_root / "lib"
    if native_lib.is_dir() and os.name != "nt":
        existing_ld = env.get("LD_LIBRARY_PATH", "")
        env["LD_LIBRARY_PATH"] = os.pathsep.join(
            [str(native_lib), existing_ld] if existing_ld else [str(native_lib)]
        )
    return env


def preflight_companion(
    install_dir: Path,
    python: Path,
    env: dict[str, str],
    source_dir: Path,
    data_home: Path,
) -> None:
    import_check = (
        "import json, sys\n"
        "modules = ['autogenbook_companion.cli', 'fastapi', 'uvicorn', 'pydantic', 'multipart']\n"
        "missing = []\n"
        "for name in modules:\n"
        "    try:\n"
        "        __import__(name)\n"
        "    except Exception as exc:\n"
        "        missing.append(f'{name}: {type(exc).__name__}: {exc}')\n"
        "if missing:\n"
        "    raise SystemExit('\\n'.join(missing))\n"
        "print(json.dumps({'python': sys.executable, 'imports': modules}))\n"
    )
    result = subprocess.run(
        [str(python), "-c", import_check],
        cwd=str(install_dir),
        env=env,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=45,
    )
    if result.returncode != 0:
        profile = "bundled runtime" if using_bundled_python(install_dir, python) else "system Python"
        wheelhouse = install_dir / "wheelhouse"
        advice = (
            "The complete offline installer should contain a prepared private runtime. "
            "This copy is using system Python instead."
            if not using_bundled_python(install_dir, python)
            else "The bundled runtime is incomplete or damaged. Re-extract the complete installer."
        )
        if wheelhouse.is_dir():
            advice += f" An offline wheelhouse is present at {wheelhouse}."
        detail = (result.stderr or result.stdout or "unknown import failure").strip()
        raise RuntimeError(
            f"Companion preflight failed in {profile}. {advice}\n"
            f"Python: {python}\nPYTHONPATH: {env.get('PYTHONPATH', '')}\n{detail}"
        )

    doctor = subprocess.run(
        [
            str(python),
            "-m",
            "autogenbook_companion.cli",
            "doctor",
            "--home",
            str(data_home),
            "--source-dir",
            str(source_dir),
            "--host",
            "127.0.0.1",
            "--port",
            "0",
        ],
        cwd=str(install_dir),
        env=env,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=45,
    )
    if doctor.returncode != 0:
        detail = (doctor.stderr or doctor.stdout or "doctor failed without output").strip()
        raise RuntimeError(
            "Companion doctor check failed before startup.\n"
            f"Python: {python}\nSource directory: {source_dir}\n{detail}"
        )


def start_companion(install_dir: Path, *, timeout: float = 60.0) -> dict[str, Any]:
    python = bundled_python(install_dir)
    source_dir = resolve_source_dir(install_dir)
    data_home = install_dir / "data"
    data_home.mkdir(parents=True, exist_ok=True)
    bridge_path = data_home / "bridge.json"
    log_path = data_home / "logs" / "companion.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    if bridge_path.exists():
        try:
            return wait_for_bridge(data_home, log_path=log_path, timeout=2)
        except Exception:
            bridge_path.unlink(missing_ok=True)

    env = bundled_environment(install_dir)
    preflight_companion(install_dir, python, env, source_dir, data_home)
    command = [
        str(python),
        "-m",
        "autogenbook_companion.cli",
        "serve",
        "--home",
        str(data_home),
        "--source-dir",
        str(source_dir),
        "--host",
        "127.0.0.1",
        "--port",
        "0",
    ]

    with log_path.open("ab", buffering=0) as stream:
        header = (
            f"\n=== AutoGenBook Companion startup {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n"
            f"installer_version={INSTALLER_VERSION}\n"
            f"python={python}\n"
            f"source_dir={source_dir}\n"
            f"cwd={install_dir}\n"
            f"pythonpath={env.get('PYTHONPATH', '')}\n"
            f"command={json.dumps(command, ensure_ascii=False)}\n"
        )
        stream.write(header.encode("utf-8", errors="replace"))
        kwargs: dict[str, Any] = {
            "stdin": subprocess.DEVNULL,
            "stdout": stream,
            "stderr": subprocess.STDOUT,
            "cwd": str(install_dir),
            "env": env,
            "close_fds": True,
        }
        if os.name == "nt":
            flags = int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            flags |= int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
            kwargs["creationflags"] = flags
        else:
            kwargs["start_new_session"] = True
        process = subprocess.Popen(command, **kwargs)

    return wait_for_bridge(
        data_home,
        process=process,
        log_path=log_path,
        timeout=timeout,
    )


def _response_detail(payload: Any) -> str:
    if isinstance(payload, dict):
        detail = payload.get("detail") or payload.get("message") or payload
    else:
        detail = payload
    rendered = str(detail).strip()
    return rendered[:2000] if rendered else "empty response"


def register_function(install_dir: Path, openwebui_url: str, api_key: str) -> dict[str, Any]:
    preflight = registration_preflight(openwebui_url, api_key)
    target_url = str(preflight["target"])
    pipe_path = install_dir / "integrations" / "openwebui" / "autogenbook_pipe.py"
    content = pipe_path.read_text(encoding="utf-8")
    form = {
        "id": FUNCTION_ID,
        "name": "AutoGenBook Companion",
        "content": content,
        "meta": {
            "description": "Long-form AutoGenBook workflows through a local, isolated Companion service.",
            "manifest": {},
        },
    }
    status_code, existing = api_request(
        target_url,
        api_key,
        "GET",
        f"/api/v1/functions/id/{FUNCTION_ID}",
    )
    if status_code == 200:
        status_code, result = api_request(
            target_url,
            api_key,
            "POST",
            f"/api/v1/functions/id/{FUNCTION_ID}/update",
            form,
        )
        action = "updated"
    elif status_code in {401, 404}:
        # Open WebUI historically returns 401 when an authenticated admin asks
        # for a Function ID that does not exist.  The separate preflight above
        # has already proven that this is not an authentication failure.
        status_code, result = api_request(
            target_url,
            api_key,
            "POST",
            "/api/v1/functions/create",
            form,
        )
        action = "created"
        if status_code == 400 and any(
            marker in _response_detail(result).casefold()
            for marker in ("already", "taken", "exist", "použ")
        ):
            status_code, result = api_request(
                target_url,
                api_key,
                "POST",
                f"/api/v1/functions/id/{FUNCTION_ID}/update",
                form,
            )
            action = "updated-after-race"
    else:
        raise OpenWebUIRegistrationError(
            f"Could not inspect the existing Function (HTTP {status_code}): {_response_detail(existing)}"
        )
    if status_code not in {200, 201}:
        detail = _response_detail(result)
        if status_code == 400 and "invalid http request" in detail.casefold():
            raise OpenWebUIRegistrationError(
                "The target returned 'Invalid HTTP request received' before the Open WebUI Function "
                "router accepted the request. The installer will use manual Function import. "
                f"Verified target: {target_url}."
            )
        raise OpenWebUIRegistrationError(
            f"Open WebUI rejected the Function (HTTP {status_code}): {detail}"
        )
    active = bool((result or {}).get("is_active")) if isinstance(result, dict) else False
    activated = active
    if not active:
        toggle_code, toggle_result = api_request(
            target_url,
            api_key,
            "POST",
            f"/api/v1/functions/id/{FUNCTION_ID}/toggle",
        )
        if toggle_code != 200:
            raise OpenWebUIRegistrationError(
                "Function was installed but could not be activated "
                f"(HTTP {toggle_code}): {_response_detail(toggle_result)}"
            )
        activated = bool((toggle_result or {}).get("is_active", True)) if isinstance(toggle_result, dict) else True
    return {
        "success": True,
        "action": action,
        "activated": activated,
        "target": target_url,
        "preflight": preflight,
    }


def write_install_record(
    install_dir: Path,
    bridge: dict[str, Any],
    *,
    api_key_source: dict[str, Any] | None = None,
    api_key_validation: dict[str, Any] | None = None,
    function_registration: dict[str, Any] | None = None,
) -> None:
    manifest_path = install_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    record = {
        "installer_version": INSTALLER_VERSION,
        "installed_at": time.time(),
        "install_dir": str(install_dir),
        "bridge": bridge,
        "openwebui_api_key_source": api_key_source,
        "openwebui_api_key_validation": api_key_validation,
        "function_registration": function_registration,
        "package_manifest": manifest,
    }
    (install_dir / "installation.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Install AutoGenBook Companion for Open WebUI Desktop.")
    p.add_argument("--source-root", default=str(Path(__file__).resolve().parents[1]))
    p.add_argument("--install-dir", default=str(default_install_dir()))
    p.add_argument("--openwebui-url", default=None)
    p.add_argument(
        "--webui-api-key-file",
        "--api-key-file",
        dest="api_key_file",
        default=None,
        help=(
            "Absolute or relative path to a .txt file containing one persistent Open WebUI API key. "
            "Only the resolved path is stored; the key is read live when a job starts."
        ),
    )
    p.add_argument(
        "--clear-webui-api-key-file",
        action="store_true",
        help="Remove the configured live TXT-file reference without deleting the TXT file.",
    )
    p.add_argument(
        "--skip-api-key-validation",
        action="store_true",
        help="Configure the TXT reference without testing it against the detected Open WebUI model API.",
    )
    p.add_argument(
        "--require-api-key-validation",
        action="store_true",
        help="Fail installation when the referenced TXT key cannot be validated immediately.",
    )
    p.add_argument(
        "--api-key",
        "--admin-api-key",
        dest="api_key",
        default=None,
        help=(
            "Administrator Open WebUI API key used only for automatic Function registration. "
            "Bearer prefixes, assignment syntax and wrapping quotes are normalized; the key is never persisted."
        ),
    )
    p.add_argument("--skip-function", action="store_true")
    p.add_argument(
        "--require-function-registration",
        action="store_true",
        help="Fail installation if automatic Function registration is rejected.",
    )
    p.add_argument("--non-interactive", action="store_true")
    p.add_argument("--configure-only", action="store_true")
    p.add_argument("--start-timeout", type=float, default=60.0)
    return p


def _redact_error(value: Any, *secrets_to_hide: str) -> str:
    rendered = str(value)
    for secret in secrets_to_hide:
        if secret and len(secret) >= 4:
            rendered = rendered.replace(secret, "***REDACTED***")
    return rendered


def _manual_function_path(install_dir: Path) -> Path:
    return install_dir / "integrations" / "openwebui" / "autogenbook_pipe.py"


def _print_manual_function_instructions(install_dir: Path, openwebui_url: str | None) -> None:
    pipe_path = _manual_function_path(install_dir)
    print("Import the Open WebUI Function manually from:")
    print(pipe_path)
    print("Open WebUI: Admin Panel -> Functions -> Import from file.")
    if openwebui_url:
        print(f"Verified/configured Open WebUI address: {openwebui_url}")


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    source_root = Path(args.source_root).expanduser().resolve()
    install_dir = Path(args.install_dir).expanduser().resolve()
    if not args.configure_only:
        print(f"Installing AutoGenBook Open WebUI integration to: {install_dir}")
        if install_dir.exists() and source_root != install_dir:
            stop_installed_companion(install_dir)
        copy_payload(source_root, install_dir)
    elif not install_dir.exists():
        raise RuntimeError(
            f"Configure-only mode requires an existing installation directory: {install_dir}"
        )

    openwebui_url: str | None
    if args.openwebui_url:
        openwebui_url = parse_openwebui_target(args.openwebui_url).display_url
    else:
        openwebui_url = discover_openwebui()

    raw_direct_key = str(args.api_key or os.environ.get("OPENWEBUI_API_KEY") or "")
    direct_registration_key = ""
    direct_key_error: str | None = None
    if raw_direct_key.strip():
        try:
            direct_registration_key = normalize_direct_api_key(install_dir, raw_direct_key)
        except Exception as exc:
            direct_key_error = _redact_error(exc, raw_direct_key)
            if args.require_function_registration:
                raise RuntimeError(f"The direct administrator API key is invalid: {direct_key_error}") from exc
            print(
                f"WARNING: The direct administrator API key was ignored: {direct_key_error}",
                file=sys.stderr,
            )

    api_key_file_input = str(
        args.api_key_file or os.environ.get("OPENWEBUI_API_KEY_FILE") or ""
    ).strip().strip('"').strip("'")

    if args.clear_webui_api_key_file:
        removed = clear_api_key_file_reference(install_dir)
        print(
            "Configured Open WebUI API-key TXT reference was removed."
            if removed
            else "No Open WebUI API-key TXT reference was configured."
        )

    if (
        openwebui_url
        and not api_key_file_input
        and not direct_registration_key
        and not args.non_interactive
        and not args.clear_webui_api_key_file
    ):
        print(f"Detected Open WebUI at {openwebui_url}")
        api_key_file_input = input(
            "Path to a .txt file with a persistent Open WebUI API key "
            "(leave blank to enter an administrator key only for Function registration): "
        ).strip().strip('"').strip("'")
        if not api_key_file_input:
            raw_prompt_key = getpass.getpass(
                "Open WebUI administrator API key "
                "(leave blank for safe manual Function import): "
            )
            if raw_prompt_key.strip():
                try:
                    direct_registration_key = normalize_direct_api_key(
                        install_dir,
                        raw_prompt_key,
                    )
                except Exception as exc:
                    direct_key_error = _redact_error(exc, raw_prompt_key)
                    if args.require_function_registration:
                        raise RuntimeError(
                            f"The direct administrator API key is invalid: {direct_key_error}"
                        ) from exc
                    print(
                        f"WARNING: The direct administrator API key was ignored: {direct_key_error}",
                        file=sys.stderr,
                    )

    api_key_source: dict[str, Any] | None = None
    api_key_validation: dict[str, Any] | None = None
    referenced_key = ""
    if api_key_file_input:
        referenced_key, api_key_source = configure_api_key_file_reference(
            install_dir,
            api_key_file_input,
        )
        print(f"Configured a live Open WebUI API-key TXT reference: {api_key_source['path']}")
        print("The API key itself was not copied to the installation and was not written to logs.")
        for warning in api_key_source.get("permission_warnings", []):
            print(f"WARNING: {warning}", file=sys.stderr)
        if openwebui_url and not args.skip_api_key_validation:
            try:
                api_key_validation = validate_openwebui_api_key(
                    openwebui_url,
                    referenced_key,
                )
                print(
                    "The API key from the TXT file was accepted by the Open WebUI model API "
                    f"({api_key_validation.get('model_count', 0)} visible models)."
                )
            except Exception as exc:
                validation_error = _redact_error(exc, referenced_key)
                api_key_validation = {
                    "valid": False,
                    "error": validation_error,
                }
                if args.require_api_key_validation:
                    raise RuntimeError(
                        f"The referenced Open WebUI API key could not be validated: {validation_error}"
                    ) from exc
                print(
                    "WARNING: The TXT-file API key reference was saved, but immediate validation failed: "
                    f"{validation_error}",
                    file=sys.stderr,
                )
                print(
                    "You can rotate/fix the single value in the referenced TXT file; new workers read it live."
                )
        elif not openwebui_url:
            api_key_validation = {
                "valid": None,
                "skipped": True,
                "reason": "Open WebUI was not detected during installation.",
            }
            print(
                "Open WebUI was not detected, so the TXT-file key reference was saved without online validation."
            )

    bridge = start_companion(install_dir, timeout=args.start_timeout)
    print(f"Companion is running at {bridge['url']}")

    function_registration: dict[str, Any] = {
        "success": False,
        "skipped": True,
        "reason": "Automatic Function registration was not attempted.",
    }
    if not args.skip_function:
        registration_key = direct_registration_key or referenced_key
        if openwebui_url and registration_key:
            try:
                function_registration = register_function(
                    install_dir,
                    openwebui_url,
                    registration_key,
                )
                print(
                    "Open WebUI Function was "
                    f"{function_registration['action']} and activated."
                )
            except Exception as exc:
                registration_error = _redact_error(
                    exc,
                    direct_registration_key,
                    referenced_key,
                    raw_direct_key,
                )
                function_registration = {
                    "success": False,
                    "skipped": False,
                    "target": openwebui_url,
                    "error": registration_error,
                    "manual_import_required": True,
                }
                # Automatic registration is an optional convenience.  The
                # Companion and the referenced key remain installed even when
                # the admin API is restricted, version-incompatible or returns
                # a low-level HTTP 400.  Strict mode remains available for CI.
                if args.require_function_registration:
                    write_install_record(
                        install_dir,
                        bridge,
                        api_key_source=api_key_source,
                        api_key_validation=api_key_validation,
                        function_registration=function_registration,
                    )
                    raise RuntimeError(
                        f"Automatic Open WebUI Function registration failed: {registration_error}"
                    ) from exc
                print(
                    "WARNING: Automatic Function registration was not completed: "
                    f"{registration_error}",
                    file=sys.stderr,
                )
                _print_manual_function_instructions(install_dir, openwebui_url)
        else:
            if not openwebui_url:
                reason = "A verified Open WebUI backend was not detected."
            elif not registration_key:
                reason = "No administrator key was supplied for the Function admin API."
            else:
                reason = "Automatic registration was unavailable."
            function_registration = {
                "success": False,
                "skipped": True,
                "reason": reason,
                "manual_import_required": True,
            }
            print(f"\nAutomatic Function registration was skipped: {reason}")
            _print_manual_function_instructions(install_dir, openwebui_url)
            if openwebui_url and not args.non_interactive:
                try:
                    webbrowser.open(openwebui_url.rstrip("/") + "/admin/functions")
                except Exception:
                    pass
    else:
        function_registration = {
            "success": False,
            "skipped": True,
            "reason": "Disabled by --skip-function.",
        }

    write_install_record(
        install_dir,
        bridge,
        api_key_source=api_key_source,
        api_key_validation=api_key_validation,
        function_registration=function_registration,
    )

    print("\nInstallation completed.")
    print(f"Install directory: {install_dir}")
    print(f"Diagnostic log: {install_dir / 'data' / 'logs' / 'companion.log'}")
    if api_key_source:
        print(
            "Persistent Open WebUI authentication uses the referenced TXT file. Keep that file readable "
            "and update its single key value when rotating the key; the next worker will read the new value."
        )
    else:
        print(
            "For multi-day Open WebUI model jobs, AutoGenBook will request a persistent personal "
            "Open WebUI API key (Settings -> Account -> API Keys). Browser session/JWT tokens are rejected."
        )
    if direct_key_error:
        print(
            "The rejected direct key was not stored. Use --admin-api-key with a valid admin key or import "
            "the Function manually."
        )
    return 0


def entrypoint() -> int:
    try:
        return main()
    except KeyboardInterrupt:
        print("\nInstallation cancelled.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"\nAutoGenBook installation failed: {exc}", file=sys.stderr)
        print(
            "The diagnostic log is normally located below "
            f"{default_install_dir() / 'data' / 'logs' / 'companion.log'}",
            file=sys.stderr,
        )
        if os.environ.get("AUTOGENBOOK_INSTALLER_DEBUG", "").strip() in {"1", "true", "yes"}:
            raise
        return 1


if __name__ == "__main__":
    raise SystemExit(entrypoint())
