#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
if [ -x "$ROOT/runtime/python/bin/python3" ]; then
  PY="$ROOT/runtime/python/bin/python3"
elif [ -x "$ROOT/runtime/python/bin/python" ]; then
  PY="$ROOT/runtime/python/bin/python"
else
  PY=${PYTHON:-python3}
fi
exec "$PY" "$ROOT/installer/install.py" --source-root "$ROOT" "$@"
