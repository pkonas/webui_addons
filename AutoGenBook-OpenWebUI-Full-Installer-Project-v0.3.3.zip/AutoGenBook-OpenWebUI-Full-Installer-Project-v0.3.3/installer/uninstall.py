from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

from install import default_install_dir


def stop_companion(install_dir: Path) -> None:
    bridge_path = install_dir / "data" / "bridge.json"
    if not bridge_path.exists():
        return
    try:
        bridge = json.loads(bridge_path.read_text(encoding="utf-8"))
        pid = int(bridge.get("pid") or 0)
    except Exception:
        return
    if pid <= 0:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], check=False, capture_output=True)
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(1)
    except Exception:
        pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--install-dir", default=str(default_install_dir()))
    parser.add_argument("--keep-data", action="store_true")
    args = parser.parse_args()
    install_dir = Path(args.install_dir).expanduser().resolve()
    stop_companion(install_dir)
    if args.keep_data and (install_dir / "data").exists():
        backup = install_dir.with_name(install_dir.name + "-data-backup")
        if backup.exists():
            shutil.rmtree(backup)
        shutil.move(str(install_dir / "data"), str(backup))
        print(f"Data preserved in {backup}")
    if os.name == "nt" and install_dir.exists():
        # Defer removal because this Python interpreter may live below install_dir.
        command = f'ping 127.0.0.1 -n 3 >nul & rmdir /S /Q "{install_dir}"'
        subprocess.Popen(["cmd", "/C", command], creationflags=subprocess.DETACHED_PROCESS)
    elif install_dir.exists():
        shutil.rmtree(install_dir)
    print("AutoGenBook Companion was removed. The Open WebUI Function can be deleted in Admin Panel → Functions.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
