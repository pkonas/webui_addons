"""
title: AutoGenBook Companion
id: autogenbook_companion
author: AutoGenBook contributors
version: 0.3.3
license: Apache-2.0
description: Create books, papers, presentations, proposals, reviews and scientist runs through a local AutoGenBook Companion.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import subprocess
import threading
import secrets
import sys
import time
import uuid
from contextvars import ContextVar
from pathlib import Path
from typing import Any, AsyncIterator, Literal, Optional
from urllib.parse import quote

import httpx
from fastapi import Request
from pydantic import BaseModel, Field


DEFAULT_LLM_MODEL = "e-infra.glm-5"
_MODEL_CACHE: dict[str, str] = {DEFAULT_LLM_MODEL: DEFAULT_LLM_MODEL}
_MODEL_CACHE_LOCK = threading.RLock()


def _model_rows(value: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    if isinstance(value, dict):
        if value.get("arena") is True or str(value.get("owned_by", "")).lower() == "arena":
            return rows
        if any(key in value for key in ("id", "model", "model_id")):
            model_id = str(value.get("id") or value.get("model_id") or value.get("model") or "").strip()
            label = str(value.get("name") or value.get("label") or model_id).strip()
            if model_id:
                rows.append((model_id, label or model_id))
        traversed = False
        for key in ("data", "models", "items", "results"):
            if key in value:
                rows.extend(_model_rows(value[key]))
                traversed = True
        if not traversed and not any(key in value for key in ("id", "model", "model_id")):
            for child in value.values():
                rows.extend(_model_rows(child))
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            rows.extend(_model_rows(item))
    elif isinstance(value, str):
        for item in re.split(r"[,\n]", value):
            item = item.strip()
            if item:
                rows.append((item, item))
    else:
        with_context = getattr(value, "model_dump", None)
        if callable(with_context):
            try:
                rows.extend(_model_rows(with_context()))
            except Exception:
                pass
    return rows


def _cache_model_rows(value: Any) -> None:
    with _MODEL_CACHE_LOCK:
        for model_id, label in _model_rows(value):
            folded = model_id.casefold()
            if not model_id or "autogenbook" in folded or folded.startswith("pipe."):
                continue
            _MODEL_CACHE[model_id] = label


def _run_async_sync(callable_obj: Any) -> Any:
    result: dict[str, Any] = {}
    error: list[BaseException] = []

    def runner() -> None:
        try:
            value = callable_obj()
            result["value"] = asyncio.run(value) if hasattr(value, "__await__") else value
        except BaseException as exc:
            error.append(exc)

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join(timeout=5)
    return None if error or thread.is_alive() else result.get("value")


def _discover_openwebui_models(__user__: Any = None) -> list[dict[str, str]]:
    _cache_model_rows(os.environ.get("OPENWEBUI_MODELS", ""))
    _cache_model_rows(os.environ.get("AUTOGENBOOK_OPENWEBUI_MODELS", ""))
    _cache_model_rows(__user__)
    for module_name in ("open_webui.main", "open_webui.app"):
        try:
            module = __import__(module_name, fromlist=["*"])
            app = getattr(module, "app", None)
            state = getattr(app, "state", None)
            if state is not None:
                _cache_model_rows(getattr(state, "MODELS", None))
                _cache_model_rows(getattr(state, "BASE_MODELS", None))
        except Exception:
            pass
    try:
        from open_webui.models.models import Models

        _cache_model_rows(_run_async_sync(Models.get_all_models))
    except Exception:
        pass
    with _MODEL_CACHE_LOCK:
        rows = [
            {"value": model_id, "label": label}
            for model_id, label in sorted(_MODEL_CACHE.items(), key=lambda item: (item[0] != DEFAULT_LLM_MODEL, item[1].casefold()))
        ]
    return rows or [{"value": DEFAULT_LLM_MODEL, "label": DEFAULT_LLM_MODEL}]


def _cache_request_models(request: Any, body: Any = None) -> None:
    _cache_model_rows((body or {}).get("models") if isinstance(body, dict) else None)
    state = getattr(getattr(request, "app", None), "state", None)
    if state is not None:
        _cache_model_rows(getattr(state, "MODELS", None))
        _cache_model_rows(getattr(state, "BASE_MODELS", None))

MODES = {"book", "paper", "presentation", "scientist", "proposal", "reviewer"}
TERMINAL_STATUSES = {"SUCCEEDED", "FAILED", "CANCELLED", "INTERRUPTED"}


class CompanionError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Durable capability downloads for Open WebUI Desktop
# ---------------------------------------------------------------------------
# Open WebUI's file-content endpoint is bearer protected. A normal browser
# navigation (Markdown link, window.open, FileItem title) does not attach the
# Authorization header used by the SPA's fetch helpers. Version 0.3.2 tried to
# recover that header in a landing page by reading localStorage, but Desktop can
# expose the UI and backend under different loopback origins (localhost vs
# 127.0.0.1), so the landing page sees an empty storage and receives HTTP 401.
#
# The current design creates a deterministic HMAC capability URL when the file
# is registered. The capability is bound to file id, owner, hash and size. It
# contains no API key, browser token or Companion token, does not expire, and is
# invalidated automatically if the file is deleted/replaced or the Open WebUI
# secret key is rotated. The URL is stored only in the user's private chat/file
# metadata. Anyone with a copied URL can use it, exactly like a private signed
# download link, so it must not be published outside the intended audience.

_AGB_DOWNLOAD_PREFIX = "/api/autogenbook"
_AGB_DOWNLOAD_ROUTE_LOCK = threading.RLock()
_AGB_REGISTERED_APP_IDS: set[int] = set()
_AGB_PUBLIC_ORIGIN: ContextVar[str] = ContextVar("autogenbook_public_origin", default="")
_AGB_CAPABILITY_SECRET: bytes | None = None
_AGB_CAPABILITY_SECRET_LOCK = threading.RLock()


def _agb_b64url_encode(payload: bytes) -> str:
    return base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")


def _agb_b64url_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _agb_download_secret() -> bytes:
    """Return a stable signing key derived from Open WebUI's own secret.

    The key is deterministic across Function reloads and Open WebUI restarts,
    unlike the module-random key used by older implementations. An explicit
    environment override exists for controlled tests and unusual deployments.
    """
    global _AGB_CAPABILITY_SECRET
    with _AGB_CAPABILITY_SECRET_LOCK:
        if _AGB_CAPABILITY_SECRET is not None:
            return _AGB_CAPABILITY_SECRET

        explicit = str(os.environ.get("AUTOGENBOOK_DOWNLOAD_CAPABILITY_SECRET") or "").strip()
        source = explicit
        if not source:
            try:
                from open_webui.env import WEBUI_SECRET_KEY

                source = str(WEBUI_SECRET_KEY or "").strip()
            except Exception:
                source = str(os.environ.get("WEBUI_SECRET_KEY") or "").strip()
        if not source:
            raise CompanionError(
                "Open WebUI neposkytlo stabilní WEBUI_SECRET_KEY; nelze vytvořit trvalý bezpečný odkaz."
            )
        _AGB_CAPABILITY_SECRET = hmac.new(
            source.encode("utf-8"),
            b"autogenbook-openwebui-download-capability-v1",
            hashlib.sha256,
        ).digest()
        return _AGB_CAPABILITY_SECRET


def _agb_make_capability(
    file_id: str,
    owner_id: str,
    *,
    file_hash: str = "",
    size: int = 0,
) -> str:
    payload = json.dumps(
        {
            "v": 2,
            "fid": str(file_id),
            "oid": str(owner_id),
            "sha256": str(file_hash or "").casefold(),
            "size": max(0, int(size or 0)),
        },
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    encoded = _agb_b64url_encode(payload)
    signature = _agb_b64url_encode(
        hmac.new(_agb_download_secret(), encoded.encode("ascii"), hashlib.sha256).digest()
    )
    return f"{encoded}.{signature}"


def _agb_read_capability(capability: str) -> dict[str, Any]:
    try:
        encoded, signature = capability.split(".", 1)
        expected = _agb_b64url_encode(
            hmac.new(_agb_download_secret(), encoded.encode("ascii"), hashlib.sha256).digest()
        )
        if not hmac.compare_digest(signature, expected):
            raise ValueError("signature")
        payload = json.loads(_agb_b64url_decode(encoded).decode("utf-8"))
        if int(payload.get("v") or 0) != 2:
            raise ValueError("version")
        file_id = str(payload.get("fid") or "")
        owner_id = str(payload.get("oid") or "")
        file_hash = str(payload.get("sha256") or "").casefold()
        size = int(payload.get("size") or 0)
        if not re.fullmatch(r"[A-Za-z0-9._:-]{1,240}", file_id):
            raise ValueError("file id")
        if not owner_id or len(owner_id) > 240:
            raise ValueError("owner")
        if file_hash and not re.fullmatch(r"[a-f0-9]{32,128}", file_hash):
            raise ValueError("hash")
        if size < 0:
            raise ValueError("size")
        return payload
    except Exception as exc:
        try:
            from fastapi import HTTPException

            raise HTTPException(
                status_code=401,
                detail="Invalid AutoGenBook download capability.",
            ) from exc
        except ImportError:
            raise CompanionError("Invalid AutoGenBook download capability.") from exc


async def _agb_maybe_await(value: Any) -> Any:
    return await value if hasattr(value, "__await__") else value


def _agb_request_origin(request: Any) -> str:
    if request is None:
        return ""
    try:
        return str(request.base_url).rstrip("/")
    except Exception:
        return ""


def _agb_capability_path(
    file_id: str,
    owner_id: str,
    *,
    file_hash: str = "",
    size: int = 0,
) -> str:
    capability = _agb_make_capability(
        file_id,
        owner_id,
        file_hash=file_hash,
        size=size,
    )
    return f"{_AGB_DOWNLOAD_PREFIX}/download/{quote(capability, safe='._-~')}"


def _agb_capability_url(
    file_id: str,
    owner_id: str,
    *,
    file_hash: str = "",
    size: int = 0,
    origin: str | None = None,
) -> str:
    path = _agb_capability_path(
        file_id,
        owner_id,
        file_hash=file_hash,
        size=size,
    )
    selected_origin = (origin if origin is not None else _AGB_PUBLIC_ORIGIN.get()).rstrip("/")
    return f"{selected_origin}{path}" if selected_origin else path


def _agb_preview_content(filename: str, download_url: str, size: int, content_type: str) -> str:
    return (
        f"# {filename}\n\n"
        "Toto je binární výstup AutoGenBooku uložený v trvalém úložišti Open WebUI. "
        "Textový náhled binárního souboru se nevytváří.\n\n"
        f"[**Stáhnout {filename}**]({download_url})\n\n"
        f"- Velikost: `{int(size)} B`\n"
        f"- Typ: `{content_type}`\n\n"
        "Odkaz je dlouhodobá kryptograficky podepsaná capability svázaná s tímto souborem, "
        "jeho vlastníkem, velikostí a kontrolním součtem. Neobsahuje API klíč ani session token."
    )


def _agb_file_meta(file_record: Any) -> tuple[dict[str, Any], str, str, int]:
    meta = getattr(file_record, "meta", {}) or {}
    if hasattr(meta, "model_dump"):
        meta = meta.model_dump()
    if not isinstance(meta, dict):
        meta = {}
    filename = str(meta.get("name") or getattr(file_record, "filename", "") or "artifact.bin")
    content_type = str(
        meta.get("content_type")
        or mimetypes.guess_type(filename)[0]
        or "application/octet-stream"
    )
    try:
        size = max(0, int(meta.get("size") or 0))
    except (TypeError, ValueError):
        size = 0
    return meta, filename, content_type, size


def _agb_range(range_header: str | None, size: int) -> tuple[int, int] | None:
    if not range_header:
        return None
    match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip(), flags=re.I)
    if not match or "," in range_header:
        raise ValueError("invalid range")
    raw_start, raw_end = match.groups()
    if not raw_start and not raw_end:
        raise ValueError("invalid range")
    if not raw_start:
        suffix = int(raw_end)
        if suffix <= 0:
            raise ValueError("invalid suffix")
        start = max(0, size - suffix)
        end = size - 1
    else:
        start = int(raw_start)
        end = int(raw_end) if raw_end else size - 1
    if size <= 0 or start < 0 or start >= size or end < start:
        raise ValueError("unsatisfiable range")
    return start, min(end, size - 1)


async def _agb_stream_file_record(request: Request, file_record: Any) -> Any:
    from fastapi import HTTPException
    from fastapi.responses import Response, StreamingResponse
    from open_webui.storage.provider import Storage

    try:
        resolved = Path(
            str(await asyncio.to_thread(Storage.get_file, str(getattr(file_record, "path", "") or "")))
        )
    except Exception as exc:
        raise HTTPException(status_code=404, detail="File data is unavailable.") from exc
    if not resolved.is_file():
        raise HTTPException(status_code=404, detail="File data is unavailable.")

    _meta, filename, content_type, declared_size = _agb_file_meta(file_record)
    stat = resolved.stat()
    size = stat.st_size
    if declared_size and declared_size != size:
        raise HTTPException(status_code=409, detail="Stored file size does not match its metadata.")
    hash_value = str(getattr(file_record, "hash", "") or "").strip().casefold()
    etag = f'"{hash_value}"' if hash_value else f'W/"{size:x}-{stat.st_mtime_ns:x}"'
    range_header = request.headers.get("range")
    if range_header and request.headers.get("if-range") not in (None, "", etag):
        range_header = None
    try:
        selected_range = _agb_range(range_header, size)
    except (TypeError, ValueError):
        return Response(
            status_code=416,
            headers={
                "Content-Range": f"bytes */{size}",
                "Accept-Ranges": "bytes",
                "ETag": etag,
                "Cache-Control": "private, no-store",
            },
        )

    start, end = selected_range if selected_range is not None else (0, max(0, size - 1))
    length = max(0, end - start + 1) if size else 0
    headers = {
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}",
        "Content-Length": str(length),
        "Accept-Ranges": "bytes",
        "ETag": etag,
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
    }
    status_code = 206 if selected_range is not None else 200
    if selected_range is not None:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    if request.method.upper() == "HEAD":
        return Response(status_code=status_code, headers=headers, media_type=content_type)

    async def iterator() -> AsyncIterator[bytes]:
        remaining = length
        with resolved.open("rb") as stream:
            stream.seek(start)
            while remaining > 0:
                block = await asyncio.to_thread(stream.read, min(1024 * 1024, remaining))
                if not block:
                    break
                remaining -= len(block)
                yield block

    return StreamingResponse(
        iterator(), status_code=status_code, headers=headers, media_type=content_type
    )


async def _agb_download_capability(request: Request, capability: str) -> Any:
    from fastapi import HTTPException
    from open_webui.models.files import Files

    claims = _agb_read_capability(str(capability))
    file_id = str(claims["fid"])
    file_record = await _agb_maybe_await(Files.get_file_by_id(file_id))
    if file_record is None:
        raise HTTPException(status_code=404, detail="File not found.")

    owner_id = str(getattr(file_record, "user_id", "") or "")
    if owner_id != str(claims.get("oid") or ""):
        raise HTTPException(status_code=404, detail="File not found.")
    record_hash = str(getattr(file_record, "hash", "") or "").casefold()
    claimed_hash = str(claims.get("sha256") or "").casefold()
    if claimed_hash and record_hash != claimed_hash:
        raise HTTPException(status_code=404, detail="File not found.")
    _meta, _filename, _content_type, declared_size = _agb_file_meta(file_record)
    claimed_size = int(claims.get("size") or 0)
    if claimed_size and declared_size and claimed_size != declared_size:
        raise HTTPException(status_code=404, detail="File not found.")

    return await _agb_stream_file_record(request, file_record)


async def _agb_legacy_download_landing(file_id: str) -> Any:
    """Explain why a link produced by 0.3.2 must be refreshed.

    The old URL contained only a file id and cannot be upgraded into an
    unauthenticated capability without weakening access control.
    """
    from fastapi.responses import HTMLResponse

    html = """<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AutoGenBook – starý odkaz</title><style>body{font:16px system-ui,sans-serif;max-width:760px;margin:10vh auto;padding:24px;color:#202124}code{background:#f3f4f6;padding:.15rem .35rem;border-radius:.3rem}</style></head><body><h1>Odkaz byl vytvořen starší verzí AutoGenBooku</h1><p>Tento odkaz nelze bezpečně převést bez aktuálního kontextu uživatele. Vraťte se do chatu a odešlete <code>výstupy ID_ÚLOHY</code>. AutoGenBook vytvoří novou odpověď s trvalými podepsanými odkazy; dokument se nebude znovu generovat.</p></body></html>"""
    return HTMLResponse(
        html,
        status_code=410,
        headers={"Cache-Control": "no-store, max-age=0", "X-Content-Type-Options": "nosniff"},
    )


async def _agb_legacy_download_ticket(_request: Request) -> Any:
    from fastapi.responses import JSONResponse

    return JSONResponse(
        {"detail": "This AutoGenBook download flow is obsolete. Refresh the job outputs."},
        status_code=410,
        headers={"Cache-Control": "no-store, max-age=0"},
    )


async def _agb_legacy_download_stream(_request: Request, ticket: str) -> Any:
    from fastapi.responses import JSONResponse

    return JSONResponse(
        {"detail": "This AutoGenBook download ticket is obsolete. Refresh the job outputs."},
        status_code=410,
        headers={"Cache-Control": "no-store, max-age=0"},
    )


def _agb_route_is_spa(route: Any) -> bool:
    path = str(getattr(route, "path", "") or "")
    name = str(getattr(route, "name", "") or "")
    return name == "spa-static-files" or path in {"/{path:path}", "/{full_path:path}"}


def _agb_register_download_routes(app: Any = None) -> bool:
    if app is None:
        for module_name in ("open_webui.main", "open_webui.app"):
            try:
                module = __import__(module_name, fromlist=["app"])
                app = getattr(module, "app", None)
                if app is not None:
                    break
            except Exception:
                continue
    if app is None or not hasattr(app, "add_api_route"):
        return False
    app_id = id(app)
    with _AGB_DOWNLOAD_ROUTE_LOCK:
        if app_id in _AGB_REGISTERED_APP_IDS:
            return True
        current_names = {
            "autogenbook-download-capability-v033",
            "autogenbook-download-landing-v033",
            "autogenbook-download-ticket-v033",
            "autogenbook-download-stream-v033",
        }
        stale_names = current_names | {
            "autogenbook-download-landing-v032",
            "autogenbook-download-ticket-v032",
            "autogenbook-download-stream-v032",
        }
        app.router.routes[:] = [
            route
            for route in app.router.routes
            if str(getattr(route, "name", "") or "") not in stale_names
        ]
        app.add_api_route(
            f"{_AGB_DOWNLOAD_PREFIX}/download/{{capability}}",
            _agb_download_capability,
            methods=["GET", "HEAD"],
            name="autogenbook-download-capability-v033",
            include_in_schema=False,
        )
        # Keep legacy paths explicit so old links fail with actionable HTTP 410
        # instead of the misleading 401 from the former localStorage broker.
        app.add_api_route(
            f"{_AGB_DOWNLOAD_PREFIX}/files/{{file_id}}/download",
            _agb_legacy_download_landing,
            methods=["GET"],
            name="autogenbook-download-landing-v033",
            include_in_schema=False,
        )
        app.add_api_route(
            f"{_AGB_DOWNLOAD_PREFIX}/download-ticket",
            _agb_legacy_download_ticket,
            methods=["POST"],
            name="autogenbook-download-ticket-v033",
            include_in_schema=False,
        )
        app.add_api_route(
            f"{_AGB_DOWNLOAD_PREFIX}/download-stream/{{ticket}}",
            _agb_legacy_download_stream,
            methods=["GET", "HEAD"],
            name="autogenbook-download-stream-v033",
            include_in_schema=False,
        )
        ours = [
            route
            for route in app.router.routes
            if str(getattr(route, "name", "") or "") in current_names
        ]
        remainder = [route for route in app.router.routes if route not in ours]
        insertion = next(
            (index for index, route in enumerate(remainder) if _agb_route_is_spa(route)),
            len(remainder),
        )
        app.router.routes[:] = remainder[:insertion] + ours + remainder[insertion:]
        _AGB_REGISTERED_APP_IDS.add(app_id)
        return True

class Pipe:
    class Valves(BaseModel):
        COMPANION_URL: str = Field(
            default="",
            description="Optional fixed AutoGenBook Companion URL. Leave blank to use bridge discovery.",
        )
        BRIDGE_FILE: str = Field(
            default="",
            description="Optional explicit path to bridge.json created by the installer.",
        )
        AUTO_START_COMPANION: bool = Field(
            default=True,
            description="Start the installed local Companion automatically when it is not running.",
        )
        POLL_INTERVAL_SECONDS: float = Field(default=2.0, ge=0.5, le=30.0)
        FOREGROUND_WAIT_SECONDS: int = Field(
            default=900,
            ge=15,
            le=21600,
            description="Maximum time one chat request waits for completion before returning a resumable job ID.",
        )
        ATTACH_MAX_BYTES: int = Field(
            default=250 * 1024 * 1024,
            ge=1024 * 1024,
            description="Limit jednoho uživatelského vstupního souboru (např. KB1).",
        )
        PERSIST_OUTPUTS_TO_OPENWEBUI: bool = Field(
            default=True,
            description=(
                "Po dokončení zkopíruje publikované artefakty do trvalého úložiště Open WebUI. "
                "Odpověď používá stabilní HMAC capability odkaz bez browserového tokenu, Companion tokenu a časové expirace."
            ),
        )
        PERSIST_OUTPUT_MAX_BYTES: int = Field(
            default=0,
            ge=0,
            description="Maximální velikost jednoho trvale kopírovaného výstupu; 0 znamená bez limitu.",
        )
        PERSIST_OUTPUT_MAX_FILES: int = Field(
            default=100,
            ge=1,
            le=1000,
            description="Maximální počet výstupů migrovaných jedním příkazem `výstupy`.",
        )
        PERSIST_DIAGNOSTIC_OUTPUTS: bool = Field(
            default=False,
            description="Připojí samostatně i diagnostické soubory; standardně jsou obsaženy v kompletním ZIPu.",
        )
        OUTPUT_COPY_CHUNK_BYTES: int = Field(
            default=4 * 1024 * 1024,
            ge=256 * 1024,
            le=64 * 1024 * 1024,
            description="Velikost bloku při streamovaném kopírování velkých výstupů do Open WebUI.",
        )
        DEBUG: bool = False

    class UserValves(BaseModel):
        LANGUAGE: str = Field(default="cs", description="Výchozí jazyk výstupu.")
        DEFAULT_OUTPUTS: str = Field(
            default="",
            description="Výstupní formáty oddělené čárkou; prázdná hodnota použije výchozí formáty režimu.",
        )
        PROVIDER_TYPE: Literal["openwebui", "openrouter", "openai_compatible"] = "openwebui"
        LLM_BASE_URL: str = Field(
            default="",
            description="Pro Open WebUI ponechte prázdné; adresa /api se odvodí z aktuální instalace.",
        )
        LLM_MODEL: str = Field(
            default=DEFAULT_LLM_MODEL,
            title="LLM model",
            description="Model dostupný přihlášenému uživateli v Open WebUI.",
            json_schema_extra={
                "input": {"type": "select", "options": "get_model_options"}
            },
        )
        API_SECRET_NAME: str = "openwebui_api_key"
        SHOW_PROGRESS: bool = True
        PROGRESS_INTERVAL_SECONDS: int = Field(default=15, ge=5, le=300)
        FOREGROUND_WAIT_MINUTES: int = Field(
            default=5,
            ge=0,
            le=30,
            description="Jak dlouho sledovat úlohu v otevřené odpovědi; poté pokračuje na pozadí.",
        )
        WEB_RAG: bool = False
        REVIEWER_KB1_POLICY: Literal[
            "ask_or_search", "require_source", "allow_without_kb1"
        ] = Field(
            default="ask_or_search",
            title="Reviewer: práce s KB1",
            description=(
                "Výchozí režim vyžádá hodnoticí předpis nebo nabídne kontextové dohledání. "
                "Volba allow_without_kb1 je pouze explicitní kompatibilní výjimka."
            ),
            json_schema_extra={
                "input": {
                    "type": "select",
                    "options": [
                        {"value": "ask_or_search", "label": "Vyžádat zdroj nebo nabídnout dohledání"},
                        {"value": "require_source", "label": "Vyžadovat explicitní soubor / URL / text"},
                        {"value": "allow_without_kb1", "label": "Výjimečně povolit obecný posudek bez KB1"},
                    ],
                }
            },
        )
        REVIEWER_SEARCH_MAX_CANDIDATES: int = Field(default=5, ge=1, le=8)
        REVIEWER_PROFILE: Literal["direct", "hybrid", "compliance"] = Field(
            default="direct",
            title="Reviewer: profil ekvivalence",
            description=(
                "direct používá kanonický standalone AutoGenBook reviewer prompt beze změny; "
                "hybrid přidá KB1 addendum; compliance je kompatibilní KB1-centrický režim."
            ),
            json_schema_extra={
                "input": {
                    "type": "select",
                    "options": [
                        {"value": "direct", "label": "Direct parity – stejné jádro jako CLI (doporučeno)"},
                        {"value": "hybrid", "label": "Hybrid – CLI rubrika + LLM addendum z KB1"},
                        {"value": "compliance", "label": "Compliance – KB1-centrický kompatibilní režim"},
                    ],
                }
            },
        )
        REVIEWER_DIRECT_PDF: bool = Field(
            default=True,
            description="Zvýší pokrytí celého PDF a použije dokumentově stratifikovaný evidence pack.",
        )
        REVIEWER_EVIDENCE_MAX_CHARS: int = Field(default=60000, ge=12000, le=500000)
        REVIEWER_KB1_CONTEXT_MAX_CHARS: int = Field(default=48000, ge=4000, le=300000)
        REVIEWER_EVIDENCE_PER_CRITERION: int = Field(default=6, ge=1, le=30)
        REVIEWER_MAX_OUTPUT_TOKENS: int = Field(default=32768, ge=2048, le=131072)
        REVIEWER_QUALITY_GATE: bool = Field(
            default=True,
            description="Ověří jazyk, rozsah, tabulku a kanonická kritéria; jednou opraví, jinak běh ukončí chybou.",
        )
        REVIEWER_PDF_ENGINE: Literal["auto", "lualatex", "xelatex", "pdflatex"] = "auto"
        AUDIT_MODE: Literal["off", "warn", "strict"] = "warn"
        AUTO_CONFIRM: bool = False
        PRESENTATION_SLIDES: int = Field(default=12, ge=3, le=100)
        PAPER_VENUE: str = "arXiv"
        CITATION_STYLE: Literal["bibtex", "footnote"] = "bibtex"

        @classmethod
        def get_model_options(cls, __user__=None) -> list[dict[str, str]]:
            return _discover_openwebui_models(__user__)

    def __init__(self) -> None:
        self.valves = self.Valves()
        self.type = "manifold"
        self.id = "autogenbook"
        self.name = "AutoGenBook / "
        self._bridge_cache: dict[str, Any] | None = None

    def pipes(self) -> list[dict[str, str]]:
        return [
            {"id": "book", "name": "Kniha / metodika"},
            {"id": "paper", "name": "Vědecký článek"},
            {"id": "presentation", "name": "Prezentace"},
            {"id": "scientist", "name": "Scientist workflow"},
            {"id": "proposal", "name": "Projektový návrh"},
            {"id": "reviewer", "name": "Odborný posudek"},
        ]

    @staticmethod
    def _mode_from_body(body: dict[str, Any]) -> str:
        raw = str(body.get("model") or "").lower()
        tokens = re.split(r"[./:_-]", raw)
        for token in reversed(tokens):
            if token in MODES:
                return token
        for mode in MODES:
            if mode in raw:
                return mode
        return "book"

    @staticmethod
    def _user_prompt(body: dict[str, Any], metadata: dict[str, Any] | None) -> str:
        if metadata and metadata.get("user_prompt"):
            return str(metadata["user_prompt"]).strip()
        for message in reversed(body.get("messages") or []):
            if message.get("role") != "user":
                continue
            content = message.get("content")
            if isinstance(content, str):
                return content.strip()
            if isinstance(content, list):
                parts = [str(item.get("text", "")) for item in content if isinstance(item, dict)]
                return "\n".join(part for part in parts if part).strip()
        return ""

    @staticmethod
    def _user_valves(user: dict[str, Any] | None, model_cls: type[BaseModel]) -> BaseModel:
        values = (user or {}).get("valves") or {}
        try:
            return model_cls(**values)
        except Exception:
            return model_cls()

    @staticmethod
    def _default_outputs(mode: str) -> list[str]:
        return {
            "book": ["md", "docx", "pdf", "zip"],
            "paper": ["md", "docx", "pdf", "zip"],
            "presentation": ["md", "pptx", "pdf", "zip"],
            "scientist": ["md", "pdf", "zip"],
            "proposal": ["md", "docx", "pdf", "zip"],
            "reviewer": ["md", "docx", "pdf", "zip"],
        }[mode]

    @staticmethod
    def _parse_bool(value: str) -> bool:
        return value.strip().lower() in {"1", "true", "yes", "on", "ano", "zapnout", "povolit"}

    @staticmethod
    def _clean_prompt_text(prompt: str) -> str:
        text = re.sub(r"<attached_files>.*?</attached_files>", "", str(prompt or ""), flags=re.I | re.S)
        text = re.sub(r"<file\b[^>]*/?>", "", text, flags=re.I | re.S)
        return re.sub(r"\n{3,}", "\n\n", text).strip()

    @staticmethod
    def _parse_directives(prompt: str) -> tuple[dict[str, str], str]:
        prompt = Pipe._clean_prompt_text(prompt)
        aliases = {
            "jazyk": "language",
            "language": "language",
            "název": "title",
            "nazev": "title",
            "title": "title",
            "publikum": "audience",
            "audience": "audience",
            "styl": "style",
            "style": "style",
            "rozsah": "length",
            "stran": "length",
            "pages": "length",
            "snímky": "length",
            "snimky": "length",
            "slides": "length",
            "výstupy": "outputs",
            "vystupy": "outputs",
            "outputs": "outputs",
            "web rag": "web_rag",
            "web_rag": "web_rag",
            "audit": "audit_mode",
            "venue": "paper_venue",
            "citační styl": "citation_style",
            "citacni styl": "citation_style",
            "citation style": "citation_style",
            "obrázky": "images",
            "obrazky": "images",
            "images": "images",
            "citace": "citations",
            "citations": "citations",
            "narrace": "narration",
            "narration": "narration",
            "tts": "tts",
            "video": "video",
        }
        directives: dict[str, str] = {}
        brief_lines: list[str] = []
        for line in prompt.splitlines():
            match = re.match(r"^\s*([^:]{2,40})\s*:\s*(.+?)\s*$", line)
            if match:
                key = aliases.get(match.group(1).strip().lower())
                if key:
                    directives[key] = match.group(2).strip()
                    continue
            brief_lines.append(line)
        brief = "\n".join(brief_lines).strip() or prompt.strip()
        return directives, brief

    @staticmethod
    def _extract_outputs(prompt: str, explicit: str | None, defaults: list[str]) -> list[str]:
        allowed = ["md", "docx", "tex", "pdf", "pptx", "audio", "video", "zip"]
        source = explicit or ""
        found: list[str] = []
        for item in re.split(r"[,;\s]+", source.lower()):
            normalized = item.strip().lstrip(".")
            if normalized in allowed and normalized not in found:
                found.append(normalized)
        lower_prompt = prompt.lower()
        for fmt in allowed:
            if re.search(rf"(?<![a-z0-9])\.?{re.escape(fmt)}(?![a-z0-9])", lower_prompt) and fmt not in found:
                found.append(fmt)
        return found or defaults

    @staticmethod
    def _extract_length(prompt: str, directive: str | None, mode: str, default_slides: int) -> int | None:
        if directive:
            match = re.search(r"\d+", directive)
            if match:
                return int(match.group())
        patterns = (
            [r"(\d+)\s*(?:snímků|snímky|snimku|slides?)"]
            if mode == "presentation"
            else [r"(\d+)\s*(?:stran|strany|pages?)"]
        )
        for pattern in patterns:
            match = re.search(pattern, prompt, re.I)
            if match:
                return int(match.group(1))
        return default_slides if mode == "presentation" else None

    def _bridge_candidates(self) -> list[Path]:
        candidates: list[Path] = []
        if self.valves.BRIDGE_FILE:
            candidates.append(Path(self.valves.BRIDGE_FILE).expanduser())
        env_bridge = os.environ.get("AUTOGENBOOK_COMPANION_BRIDGE_FILE")
        if env_bridge:
            candidates.append(Path(env_bridge).expanduser())
        home_override = os.environ.get("AUTOGENBOOK_COMPANION_HOME")
        if home_override:
            candidates.append(Path(home_override).expanduser() / "bridge.json")
        home = Path.home()
        if sys.platform == "win32":
            local = Path(os.environ.get("LOCALAPPDATA") or home / "AppData" / "Local")
            candidates.extend(
                [
                    local / "AutoGenBook-OpenWebUI" / "data" / "bridge.json",
                    local / "Programs" / "AutoGenBook OpenWebUI" / "data" / "bridge.json",
                ]
            )
        elif sys.platform == "darwin":
            candidates.append(home / "Library" / "Application Support" / "AutoGenBook-OpenWebUI" / "data" / "bridge.json")
        else:
            base = Path(os.environ.get("XDG_DATA_HOME") or home / ".local" / "share")
            candidates.append(base / "autogenbook-openwebui" / "data" / "bridge.json")
        data_dir = os.environ.get("DATA_DIR")
        if data_dir:
            candidates.append(Path(data_dir) / "autogenbook-companion" / "bridge.json")
        result: list[Path] = []
        seen: set[str] = set()
        for candidate in candidates:
            key = str(candidate.expanduser().resolve())
            if key not in seen:
                seen.add(key)
                result.append(Path(key))
        return result

    @staticmethod
    def _read_bridge(path: Path) -> dict[str, Any] | None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            token_file = Path(data["token_file"]).expanduser()
            data["token"] = token_file.read_text(encoding="utf-8").strip()
            data["bridge_file"] = str(path)
            return data
        except Exception:
            return None

    async def _health(self, bridge: dict[str, Any]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=4.0) as client:
            response = await client.get(
                f"{str(bridge['url']).rstrip('/')}/v1/health",
                headers={"Authorization": f"Bearer {bridge['token']}"},
            )
            response.raise_for_status()
            return response.json()

    @staticmethod
    def _detached_start(bridge: dict[str, Any]) -> None:
        command = [str(part) for part in bridge.get("start_command") or []]
        if not command:
            raise CompanionError("bridge.json does not contain a start_command.")
        log_path = Path(bridge.get("log_file") or Path(bridge.get("home", ".")) / "logs" / "companion.log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        stream = log_path.open("ab")
        kwargs: dict[str, Any] = {
            "stdin": subprocess.DEVNULL,
            "stdout": stream,
            "stderr": subprocess.STDOUT,
            "cwd": bridge.get("home") or None,
            "close_fds": os.name != "nt",
        }
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(command, **kwargs)

    async def _ensure_companion(self) -> dict[str, Any]:
        if self.valves.COMPANION_URL:
            token = os.environ.get("AUTOGENBOOK_COMPANION_API_TOKEN", "").strip()
            if not token:
                raise CompanionError(
                    "COMPANION_URL is set, but AUTOGENBOOK_COMPANION_API_TOKEN is missing. "
                    "Use the installer-generated bridge file instead."
                )
            bridge = {"url": self.valves.COMPANION_URL.rstrip("/"), "token": token}
            await self._health(bridge)
            return bridge

        for candidate in self._bridge_candidates():
            bridge = self._read_bridge(candidate)
            if not bridge:
                continue
            try:
                await self._health(bridge)
                self._bridge_cache = bridge
                return bridge
            except Exception:
                if not self.valves.AUTO_START_COMPANION:
                    continue
                try:
                    self._detached_start(bridge)
                except Exception:
                    continue
                deadline = time.monotonic() + 30
                while time.monotonic() < deadline:
                    await asyncio.sleep(0.75)
                    refreshed = self._read_bridge(candidate) or bridge
                    try:
                        await self._health(refreshed)
                        self._bridge_cache = refreshed
                        return refreshed
                    except Exception:
                        pass
        raise CompanionError(
            "AutoGenBook Companion není nainstalován nebo jej nelze spustit. "
            "Spusťte přiložený instalátor a poté tuto zprávu odešlete znovu."
        )

    @staticmethod
    def _headers(bridge: dict[str, Any], owner_id: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {bridge['token']}",
            "X-AutoGenBook-User": owner_id,
        }

    async def _api(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.request(
                method,
                f"{str(bridge['url']).rstrip('/')}{path}",
                headers=self._headers(bridge, owner_id),
                json=json_body,
            )
            if response.status_code >= 400:
                try:
                    detail = response.json()
                except Exception:
                    detail = response.text
                raise CompanionError(f"Companion API {response.status_code}: {detail}")
            if response.status_code == 204 or not response.content:
                return None
            return response.json()

    async def _upload_path(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        project_id: str,
        role: str,
        path: Path,
        filename: str,
    ) -> dict[str, Any]:
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        async with httpx.AsyncClient(timeout=None) as client:
            with path.open("rb") as stream:
                response = await client.post(
                    f"{str(bridge['url']).rstrip('/')}/v1/projects/{project_id}/files",
                    headers=self._headers(bridge, owner_id),
                    params={"role": role},
                    files={"file": (filename, stream, mime)},
                )
            if response.status_code >= 400:
                raise CompanionError(f"Upload failed ({response.status_code}): {response.text}")
            return response.json()

    @staticmethod
    async def _resolve_openwebui_file(entry: dict[str, Any], owner_id: str) -> tuple[Path, str]:
        raw = entry.get("file") or entry.get("files") or entry
        file_id = str(raw.get("id") or entry.get("id") or "")
        filename = str(raw.get("filename") or raw.get("name") or entry.get("name") or f"file-{file_id}")
        direct_paths = [raw.get("path"), entry.get("path")]
        for candidate in direct_paths:
            if candidate:
                path = Path(str(candidate)).expanduser()
                if path.exists() and path.is_file():
                    return path, filename
        if not file_id:
            raise CompanionError(f"Nelze určit ID přílohy {filename}.")
        try:
            from open_webui.models.files import Files
            from open_webui.storage.provider import Storage

            model = await Files.get_file_by_id_and_user_id(file_id, owner_id)
            if model is None or not model.path:
                raise CompanionError(
                    f"Příloha {filename} nebyla nalezena v úložišti aktuálního uživatele Open WebUI."
                )
            local_path = await asyncio.to_thread(Storage.get_file, model.path)
            path = Path(local_path)
            if not path.exists():
                raise CompanionError(f"Přílohu {filename} se nepodařilo načíst z úložiště.")
            return path, model.filename or filename
        except ImportError as exc:
            raise CompanionError("Tato verze Open WebUI neposkytuje rozhraní pro čtení příloh.") from exc

    @staticmethod
    def _infer_file_role(filename: str, mode: str) -> str:
        name = filename.casefold()
        if name.endswith(".json") and any(token in name for token in ("structure", "strukt", "outline")):
            return "structure"
        if any(token in name for token in ("input", "brief", "zadani", "zadání")):
            return "input"
        kb1_tokens = (
            "kb1", "requirements", "criteria", "criterion", "call", "vyzva", "výzva",
            "pravidla", "regulation", "directive", "guideline", "policy", "rubric",
            "evaluation", "assessment", "ordinance", "smernice", "směrnice", "vyhlaska",
            "vyhláška", "hodnoceni", "hodnocení", "hodnotici", "hodnoticí", "metodika",
            "pokyn", "statut", "kriteria", "kritéria", "rad_", "řád_", "rad-", "řád-",
            "sablona_posudku", "šablona_posudku", "thesis_rules", "zaverecnych_praci",
            "závěrečných_prací",
        )
        if any(token in name for token in kb1_tokens):
            return "kb1" if mode in {"proposal", "reviewer"} else "kb"
        kb2_tokens = (
            "kb2", "project", "thesis", "diplom", "bakalar", "bakalář", "disert",
            "zaverecna_prace", "závěrečná_práce", "prace", "práce", "background",
        )
        if any(token in name for token in kb2_tokens):
            return "kb2" if mode in {"proposal", "reviewer"} else "kb"
        if mode in {"reviewer", "proposal"}:
            return "kb2"
        return "kb"

    @staticmethod
    def _command(prompt: str) -> tuple[str | None, str | None]:
        patterns = {
            "status": r"^\s*(?:stav|status)\s+([0-9a-fA-F-]{8,})\s*$",
            "cancel": r"^\s*(?:zruš|zrus|cancel)\s+([0-9a-fA-F-]{8,})\s*$",
            "resume": r"^\s*(?:pokračuj|pokracuj|resume)\s+([0-9a-fA-F-]{8,})\s*$",
            "artifacts": r"^\s*(?:výstupy|vystupy|soubory|files|artifacts)\s+([0-9a-fA-F-]{8,})\s*$",
            "kb1": (
                r"^\s*(?:kb1|doplň\s+kb1|dopln\s+kb1|přidej\s+kb1|pridej\s+kb1|"
                r"nahrát\s+kb1|nahrat\s+kb1)\s*[:#]?\s*([0-9a-fA-F-]{8,})\s*$"
            ),
        }
        for command, pattern in patterns.items():
            match = re.match(pattern, prompt, re.I)
            if match:
                return command, match.group(1)
        return None, None

    @staticmethod
    def _input_value(result: Any) -> str:
        if isinstance(result, dict):
            return str(result.get("value") or result.get("data") or "").strip()
        return str(result or "").strip()

    @staticmethod
    def _execute_result_payload(result: Any) -> dict[str, Any]:
        """Normalize the value returned by Open WebUI's two-way execute event.

        Open WebUI versions differ slightly in whether the JavaScript return value is
        forwarded directly or wrapped in ``result``, ``value`` or ``data``.  The
        normalizer intentionally accepts only JSON-like values and never extracts or
        returns the browser authentication token used by the upload script.
        """

        current = result
        for _depth in range(4):
            if isinstance(current, str):
                value = current.strip()
                if not value:
                    return {}
                try:
                    current = json.loads(value)
                    continue
                except Exception:
                    return {"error": value}
            if isinstance(current, list):
                return {"files": current}
            if not isinstance(current, dict):
                return {}
            if any(key in current for key in ("files", "cancelled", "error")):
                return current
            nested = None
            for key in ("result", "value", "data"):
                candidate = current.get(key)
                if isinstance(candidate, (dict, list, str)):
                    nested = candidate
                    break
            if nested is None:
                return current
            current = nested
        return {}

    @staticmethod
    def _reviewer_file_picker_code(*, max_files: int, max_bytes: int) -> str:
        """Return audited, same-origin JavaScript for an interactive KB1 file picker.

        The code runs through Open WebUI's documented ``execute`` event.  It displays
        a visible modal containing a native ``<input type=file>``; the actual picker is
        therefore opened by the user's click, not by a background popup.  Selected
        files are uploaded to the current Open WebUI origin with ``process=false`` and
        only the resulting file IDs are returned to the Pipe.  The session token, when
        needed by an Open WebUI version, is used only in the same-origin request and is
        never part of the returned value.
        """

        config = json.dumps(
            {
                "maxFiles": max(1, min(int(max_files), 10)),
                "maxBytes": max(1024 * 1024, int(max_bytes)),
                "accept": ".pdf,.docx,.pptx,.md,.txt",
                "allowedExtensions": [".pdf", ".docx", ".pptx", ".md", ".txt"],
            },
            ensure_ascii=False,
        )
        template = r"""
const config = __AUTOGENBOOK_CONFIG__;
return await new Promise((resolve) => {
    const overlayId = "autogenbook-kb1-file-picker";
    const previous = document.getElementById(overlayId);
    if (previous) previous.remove();

    const overlay = document.createElement("div");
    overlay.id = overlayId;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", "Výběr zdroje KB1");
    overlay.style.cssText = [
        "position:fixed", "inset:0", "z-index:2147483647",
        "background:rgba(0,0,0,.58)", "display:flex", "align-items:center",
        "justify-content:center", "padding:20px", "box-sizing:border-box"
    ].join(";");

    const panel = document.createElement("div");
    panel.style.cssText = [
        "width:min(620px,100%)", "max-height:90vh", "overflow:auto",
        "background:var(--color-gray-50,#fff)", "color:var(--color-gray-900,#111827)",
        "border-radius:14px", "padding:22px", "box-shadow:0 24px 80px rgba(0,0,0,.35)",
        "font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"
    ].join(";");

    const title = document.createElement("h2");
    title.textContent = "Vyberte soubor pro KB1";
    title.style.cssText = "font-size:20px;font-weight:700;margin:0 0 8px";
    panel.appendChild(title);

    const help = document.createElement("p");
    help.textContent = "Vyberte jeden nebo více předpisů, směrnic, rubrik nebo šablon posudku. Podporované formáty: PDF, DOCX, PPTX, Markdown a TXT.";
    help.style.cssText = "font-size:14px;line-height:1.5;margin:0 0 16px;color:var(--color-gray-600,#4b5563)";
    panel.appendChild(help);

    const input = document.createElement("input");
    input.type = "file";
    input.multiple = true;
    input.accept = config.accept;
    input.style.cssText = "display:block;width:100%;padding:12px;border:1px solid #9ca3af;border-radius:10px;box-sizing:border-box;background:transparent";
    panel.appendChild(input);

    const selectedList = document.createElement("div");
    selectedList.style.cssText = "margin-top:12px;font-size:13px;line-height:1.5;white-space:pre-wrap";
    panel.appendChild(selectedList);

    const status = document.createElement("div");
    status.setAttribute("aria-live", "polite");
    status.style.cssText = "min-height:22px;margin-top:12px;font-size:13px;color:var(--color-gray-600,#4b5563)";
    panel.appendChild(status);

    const buttons = document.createElement("div");
    buttons.style.cssText = "display:flex;justify-content:flex-end;gap:10px;margin-top:18px";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = "Zrušit";
    cancel.style.cssText = "padding:9px 15px;border:1px solid #9ca3af;border-radius:9px;background:transparent;cursor:pointer";
    const submit = document.createElement("button");
    submit.type = "button";
    submit.textContent = "Použít jako KB1";
    submit.disabled = true;
    submit.style.cssText = "padding:9px 15px;border:0;border-radius:9px;background:#111827;color:white;cursor:pointer;opacity:.55";
    buttons.append(cancel, submit);
    panel.appendChild(buttons);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    const extensionOf = (name) => {
        const index = String(name || "").lastIndexOf(".");
        return index >= 0 ? String(name).slice(index).toLowerCase() : "";
    };
    const formatBytes = (value) => {
        const units = ["B", "KB", "MB", "GB"];
        let size = Number(value || 0);
        let unit = 0;
        while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit += 1; }
        return `${size.toFixed(unit ? 1 : 0)} ${units[unit]}`;
    };
    const selectedFiles = () => Array.from(input.files || []);
    const refresh = () => {
        const files = selectedFiles();
        selectedList.textContent = files.length
            ? files.map((file) => `• ${file.name} (${formatBytes(file.size)})`).join("\n")
            : "Nebyl vybrán žádný soubor.";
        submit.disabled = files.length === 0;
        submit.style.opacity = submit.disabled ? ".55" : "1";
    };
    input.addEventListener("change", refresh);
    refresh();

    let settled = false;
    const cleanup = () => {
        document.removeEventListener("keydown", onKeyDown, true);
        overlay.remove();
    };
    const finish = (payload) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(payload);
    };
    const onKeyDown = (event) => {
        if (event.key === "Escape") {
            event.preventDefault();
            finish({cancelled: true, files: []});
        }
    };
    document.addEventListener("keydown", onKeyDown, true);
    cancel.addEventListener("click", () => finish({cancelled: true, files: []}));

    submit.addEventListener("click", async () => {
        const files = selectedFiles();
        const invalid = [];
        if (files.length > config.maxFiles) {
            invalid.push(`Vyberte nejvýše ${config.maxFiles} souborů.`);
        }
        for (const file of files) {
            if (!config.allowedExtensions.includes(extensionOf(file.name))) {
                invalid.push(`${file.name}: nepodporovaný formát.`);
            }
            if (file.size <= 0) invalid.push(`${file.name}: soubor je prázdný.`);
            if (file.size > config.maxBytes) {
                invalid.push(`${file.name}: velikost ${formatBytes(file.size)} překračuje limit ${formatBytes(config.maxBytes)}.`);
            }
        }
        if (invalid.length) {
            status.textContent = invalid.join(" ");
            status.style.color = "#b91c1c";
            return;
        }

        input.disabled = true;
        cancel.disabled = true;
        submit.disabled = true;
        status.style.color = "var(--color-gray-600,#4b5563)";
        const uploaded = [];
        try {
            let token = localStorage.getItem("token") || "";
            try {
                const parsed = JSON.parse(token);
                if (typeof parsed === "string") token = parsed;
            } catch (_ignored) {}
            for (let index = 0; index < files.length; index += 1) {
                const file = files[index];
                status.textContent = `Nahrávám ${index + 1}/${files.length}: ${file.name}`;
                const form = new FormData();
                form.append("file", file, file.name);
                const headers = {};
                if (token) headers.Authorization = `Bearer ${token}`;
                const response = await fetch("/api/v1/files/?process=false", {
                    method: "POST",
                    headers,
                    body: form,
                    credentials: "include"
                });
                const bodyText = await response.text();
                let payload = {};
                if (bodyText) {
                    try { payload = JSON.parse(bodyText); }
                    catch (_ignored) { payload = {detail: bodyText}; }
                }
                if (!response.ok) {
                    throw new Error(payload.detail || payload.message || `Open WebUI upload selhal (${response.status}).`);
                }
                const record = payload && payload.file ? payload.file : payload;
                if (!record || !record.id) throw new Error("Open WebUI nevrátilo ID nahraného souboru.");
                uploaded.push({
                    id: String(record.id),
                    filename: String(record.filename || record.name || file.name),
                    name: String(record.filename || record.name || file.name),
                    size: Number(record.size || file.size),
                    content_type: String(record.content_type || file.type || "application/octet-stream")
                });
            }
            status.textContent = "Soubory byly nahrány a budou ověřeny jako KB1.";
            finish({cancelled: false, files: uploaded});
        } catch (error) {
            status.textContent = error && error.message ? error.message : String(error);
            status.style.color = "#b91c1c";
            input.disabled = false;
            cancel.disabled = false;
            submit.disabled = false;
        }
    });

    input.focus();
});
"""
        return template.replace("__AUTOGENBOOK_CONFIG__", config)

    async def _pick_reviewer_kb1_files(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        project_id: str,
        spec: dict[str, Any],
        policy: str,
        event_call: Any,
    ) -> list[tuple[str, str]]:
        if event_call is None:
            raise CompanionError(
                "Interaktivní výběr souboru není dostupný. Přiložte soubor k nové zprávě "
                f"s textem `KB1 {project_id}`."
            )
        raw_result = await event_call(
            {
                "type": "execute",
                "data": {
                    "code": self._reviewer_file_picker_code(
                        max_files=5,
                        max_bytes=int(self.valves.ATTACH_MAX_BYTES),
                    )
                },
            }
        )
        payload = self._execute_result_payload(raw_result)
        if payload.get("error"):
            raise CompanionError(
                "Open WebUI nemohlo otevřít dialog nahrání souboru: "
                f"{payload.get('error')}. Přiložte soubor k nové zprávě s textem `KB1 {project_id}`."
            )
        if payload.get("cancelled"):
            return []
        file_rows = payload.get("files")
        if not isinstance(file_rows, list) or not file_rows:
            return []

        imported: list[tuple[str, str]] = []
        for entry in file_rows[:5]:
            if not isinstance(entry, dict):
                continue
            path, filename = await self._resolve_openwebui_file(entry, owner_id)
            await self._upload_path(bridge, owner_id, project_id, "kb1", path, filename)
            imported.append((filename, "kb1"))
        if not imported:
            return []

        options = spec.setdefault("options", {})
        options["reviewer_kb1_policy"] = policy
        options["reviewer_kb1_origin"] = "interactive_file_upload"
        options["reviewer_kb1_selected_files"] = [name for name, _role in imported]
        await self._api(
            bridge,
            owner_id,
            "PATCH",
            f"/v1/projects/{project_id}",
            json_body={"spec": spec},
        )
        return imported

    async def _upload_reviewer_kb1_attachments(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        project_id: str,
        spec: dict[str, Any],
        policy: str,
        files: list[dict[str, Any]] | None,
        *,
        origin: str,
    ) -> list[tuple[str, str]]:
        """Store chat attachments explicitly as reviewer KB1 sources.

        This path is used by the follow-up command ``KB1 <project-or-job-id>``.
        It deliberately ignores filename heuristics: the user has explicitly declared
        that the attached documents are the evaluation rules.  Semantic validation in
        the Companion still decides whether the content is suitable before a job is
        started or resumed.
        """

        rows = list(files or [])
        if not rows:
            return []
        if len(rows) > 5:
            raise CompanionError("Pro jedno doplnění KB1 lze přiložit nejvýše 5 souborů.")

        allowed = {".pdf", ".docx", ".pptx", ".md", ".txt"}
        imported: list[tuple[str, str]] = []
        for entry in rows:
            path, filename = await self._resolve_openwebui_file(entry, owner_id)
            suffix = Path(filename).suffix.casefold()
            if suffix not in allowed:
                raise CompanionError(
                    f"Soubor `{filename}` nemá podporovaný formát. Pro KB1 použijte PDF, DOCX, "
                    "PPTX, Markdown nebo TXT."
                )
            size = path.stat().st_size
            if size <= 0:
                raise CompanionError(f"Soubor `{filename}` je prázdný.")
            if size > int(self.valves.ATTACH_MAX_BYTES):
                raise CompanionError(
                    f"Soubor `{filename}` překračuje limit {int(self.valves.ATTACH_MAX_BYTES)} bajtů."
                )
            await self._upload_path(bridge, owner_id, project_id, "kb1", path, filename)
            imported.append((filename, "kb1"))

        options = spec.setdefault("options", {})
        options["reviewer_kb1_policy"] = policy
        options["reviewer_kb1_origin"] = origin
        options["reviewer_kb1_selected_files"] = [name for name, _role in imported]
        await self._api(
            bridge,
            owner_id,
            "PATCH",
            f"/v1/projects/{project_id}",
            json_body={"spec": spec},
        )
        return imported

    async def _reviewer_target(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        target_id: str,
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        """Resolve either a reviewer project ID or a reviewer job ID."""

        project: dict[str, Any] | None = None
        job: dict[str, Any] | None = None
        project_error: Exception | None = None
        try:
            project = await self._api(
                bridge, owner_id, "GET", f"/v1/projects/{target_id}"
            )
        except CompanionError as exc:
            project_error = exc

        if project is None:
            try:
                job = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{target_id}")
                project = await self._api(
                    bridge,
                    owner_id,
                    "GET",
                    f"/v1/projects/{job['project_id']}",
                )
            except CompanionError as exc:
                detail = str(exc)
                if project_error is not None:
                    detail = f"{project_error}; {detail}"
                raise CompanionError(
                    f"ID `{target_id}` neodpovídá dostupnému projektu ani úloze. {detail}"
                ) from exc

        spec = dict(project.get("spec") or {})
        if str(spec.get("mode") or "") != "reviewer":
            raise CompanionError(
                f"Projekt `{project.get('id') or target_id}` není reviewer projekt; KB1 do něj nelze vložit."
            )
        return project, job

    @staticmethod
    def _reviewer_kb1_errors(validation: dict[str, Any]) -> list[dict[str, Any]]:
        codes = {
            "MISSING_REVIEWER_KB1",
            "EMPTY_REVIEWER_KB1",
            "REVIEWER_KB1_AUTH_PAGE",
            "REVIEWER_KB1_ACCESS_GATE",
            "REVIEWER_KB1_UNREADABLE",
            "REVIEWER_KB1_TOO_SHORT",
            "REVIEWER_KB1_IRRELEVANT",
        }
        return [
            item
            for item in validation.get("issues", [])
            if item.get("severity") == "error" and item.get("code") in codes
        ]

    async def _kb1_attachment_command(
        self,
        target_id: str,
        bridge: dict[str, Any],
        owner_id: str,
        files: list[dict[str, Any]] | None,
        event_emitter: Any,
        event_call: Any,
        user_valves: "Pipe.UserValves",
    ) -> str:
        """Attach an explicit KB1 document and continue an existing reviewer flow."""

        project, job = await self._reviewer_target(bridge, owner_id, target_id)
        project_id = str(project["id"])
        spec = dict(project.get("spec") or {})
        policy = str(
            spec.get("options", {}).get("reviewer_kb1_policy")
            or user_valves.REVIEWER_KB1_POLICY
            or "ask_or_search"
        )
        await self._emit_status(event_emitter, "Přijímám a ověřuji soubor pro reviewer KB1…")

        imported = await self._upload_reviewer_kb1_attachments(
            bridge,
            owner_id,
            project_id,
            spec,
            policy,
            files,
            origin="chat_attachment_followup",
        )
        if not imported:
            imported = await self._pick_reviewer_kb1_files(
                bridge,
                owner_id,
                project_id,
                spec,
                policy,
                event_call,
            )
        if not imported:
            return (
                f"Do projektu `{project_id}` nebyl přidán žádný soubor. Přiložte PDF, DOCX, PPTX, "
                f"MD nebo TXT k nové zprávě a odešlete `KB1 {target_id}`."
            )

        validation = await self._api(
            bridge,
            owner_id,
            "POST",
            f"/v1/projects/{project_id}/validate",
        )
        errors = [
            item for item in validation.get("issues", []) if item.get("severity") == "error"
        ]
        names = ", ".join(f"`{name}`" for name, _role in imported)
        if errors:
            detail = "\n".join(
                f"- {item.get('message') or item.get('code')}" for item in errors
            )
            kb1_invalid = bool(self._reviewer_kb1_errors(validation))
            guidance = (
                "\n\nVybraný dokument nebyl uznán jako použitelná KB1. Přiložte směrnici, "
                "vyhlášku, hodnoticí rubriku, metodiku nebo šablonu posudku a příkaz zopakujte."
                if kb1_invalid
                else ""
            )
            return (
                f"Soubor(y) {names} byly uloženy do projektu `{project_id}`, ale projekt stále "
                f"nelze spustit:\n{detail}{guidance}"
            )

        provider = dict(spec.get("provider") or {})
        await self._ensure_provider_ready(bridge, owner_id, provider, event_call)

        if job is not None:
            job_status = str(job.get("status") or "")
            if job_status in {"FAILED", "CANCELLED", "INTERRUPTED"}:
                resumed = await self._api(
                    bridge,
                    owner_id,
                    "POST",
                    f"/v1/jobs/{job['id']}/resume",
                )
                await self._emit_status(
                    event_emitter,
                    f"KB1 je validní; úloha {str(job['id'])[:8]} byla obnovena.",
                    done=True,
                )
                return (
                    f"Soubor(y) {names} byly ověřeny jako KB1. Úloha `{job['id']}` byla "
                    f"zařazena k pokračování. Stav: **{resumed['status']}**."
                )
            if job_status in {"QUEUED", "RUNNING", "WAITING_FOR_USER"}:
                return (
                    f"Soubor(y) {names} byly ověřeny jako KB1 projektu `{project_id}`. Úloha "
                    f"`{job['id']}` je již ve stavu **{job_status}**; nová KB1 se bezpečně použije "
                    "až při novém nebo obnoveném workeru."
                )
            return (
                f"Soubor(y) {names} byly ověřeny jako KB1 projektu `{project_id}`. Původní úloha "
                f"`{job['id']}` je ve stavu **{job_status or 'neznámý'}** a nebyla automaticky spuštěna znovu."
            )

        created = await self._api(
            bridge,
            owner_id,
            "POST",
            "/v1/jobs",
            json_body={
                "project_id": project_id,
                "idempotency_key": f"reviewer-kb1-followup:{owner_id}:{project_id}",
                "resume": False,
            },
        )
        await self._emit_status(
            event_emitter,
            f"KB1 je validní; reviewer úloha {str(created['id'])[:8]} byla spuštěna.",
            done=True,
        )
        return (
            f"Soubor(y) {names} byly ověřeny jako KB1. Reviewer projekt `{project_id}` byl "
            f"spuštěn jako úloha `{created['id']}` ve stavu **{created['status']}**."
        )

    @staticmethod
    def _looks_like_session_token(value: str) -> bool:
        token = value.strip()
        return not token.startswith("sk-") and len(token.split(".")) == 3

    @staticmethod
    def _parse_reviewer_context(value: str) -> tuple[dict[str, str], list[str]]:
        raw = re.sub(r"^\s*(?:hledat|dohledat|search)\s*:?\s*", "", value, flags=re.I).strip()
        aliases = {
            "zeme": "jurisdiction",
            "země": "jurisdiction",
            "stat": "jurisdiction",
            "stát": "jurisdiction",
            "jurisdikce": "jurisdiction",
            "country": "jurisdiction",
            "institution": "institution",
            "instituce": "institution",
            "univerzita": "institution",
            "skola": "institution",
            "škola": "institution",
            "fakulta": "faculty",
            "faculty": "faculty",
            "soucast": "faculty",
            "součást": "faculty",
            "typ": "work_type",
            "typ prace": "work_type",
            "typ práce": "work_type",
            "work type": "work_type",
            "prace": "work_type",
            "práce": "work_type",
            "program": "programme",
            "programme": "programme",
            "obor": "programme",
        }
        context: dict[str, str] = {}
        for part in re.split(r"[;\n]+", raw):
            key, sep, item = part.partition("=")
            if not sep:
                key, sep, item = part.partition(":")
            if not sep:
                continue
            normalized = aliases.get(" ".join(key.casefold().split()))
            if normalized and item.strip():
                context[normalized] = " ".join(item.strip().split())
        if not context and "|" in raw:
            rows = [" ".join(item.strip().split()) for item in raw.split("|")]
            keys = ("jurisdiction", "institution", "faculty", "work_type", "programme")
            context = {key: value for key, value in zip(keys, rows) if value}
        missing = [
            label
            for key, label in (
                ("jurisdiction", "země / jurisdikce"),
                ("institution", "instituce / univerzita"),
                ("work_type", "typ závěrečné práce"),
            )
            if not context.get(key)
        ]
        return context, missing

    @staticmethod
    def _reviewer_source_instruction(
        policy: str,
        last_error: str = "",
        project_id: str = "",
    ) -> str:
        prefix = f"{last_error}\n\n" if last_error else ""
        search_line = (
            "- `HLEDAT: země=ČR; instituce=VUT; fakulta=FAST; typ práce=diplomová práce` "
            "— AutoGenBook po potvrzení použije webové vyhledávání Open WebUI a nabídne ověřitelné kandidáty.\n"
            if policy == "ask_or_search"
            else ""
        )
        return (
            prefix
            + "Reviewer potřebuje **KB1 s hodnoticími pravidly**. Bez něj nelze určit, podle jaké "
            "institucionální normy má být práce posouzena. Zadejte jednu z možností:\n\n"
            "- `SOUBOR` — otevře bezpečný výběr souborů přímo v Open WebUI; vyberte PDF, DOCX, PPTX, MD nebo TXT.\n"
            "- `URL: https://…` — oficiální směrnice, vyhláška, metodika, hodnoticí rubrika nebo šablona posudku.\n"
            "- `TEXT: …` — explicitní kritéria vložená přímo uživatelem.\n"
            + search_line
            + "- `ZRUŠIT` — projekt zůstane konceptem. Soubor lze poté přiložit k nové zprávě s příkazem "
            + (f"`KB1 {project_id}`.\n\n" if project_id else "`KB1 <ID projektu>`.\n\n")
            + "Automatické dohledání se nespustí bez uvedení země, instituce a typu práce a bez vašeho potvrzení."
        )

    async def _import_reviewer_kb1(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        project_id: str,
        *,
        source_type: str,
        value: str,
        filename: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self._api(
            bridge,
            owner_id,
            "POST",
            f"/v1/projects/{project_id}/reviewer/kb1/import",
            json_body={
                "source_type": source_type,
                "value": value,
                "filename": filename,
                "provenance": provenance or {},
            },
            timeout=180,
        )

    @staticmethod
    def _candidate_selection(value: str, count: int) -> list[int]:
        folded = value.strip().casefold()
        if folded in {"vše", "vse", "all"}:
            return list(range(count))
        selected: list[int] = []
        for token in re.split(r"[,;\s]+", value.strip()):
            if not token:
                continue
            if not token.isdigit():
                continue
            index = int(token) - 1
            if 0 <= index < count and index not in selected:
                selected.append(index)
        return selected

    async def _ensure_reviewer_kb1(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        project_id: str,
        spec: dict[str, Any],
        user_valves: "Pipe.UserValves",
        event_call: Any,
    ) -> list[tuple[str, str]]:
        policy = str(user_valves.REVIEWER_KB1_POLICY or "ask_or_search")
        if policy == "allow_without_kb1":
            spec["options"]["reviewer_allow_missing_kb1"] = True
            spec["options"]["reviewer_kb1_policy"] = policy
            await self._api(
                bridge,
                owner_id,
                "PATCH",
                f"/v1/projects/{project_id}",
                json_body={"spec": spec},
            )
            return []
        if event_call is None:
            raise CompanionError(
                "Reviewer nemá KB1. Přiložte oficiální hodnoticí předpis/rubriku k nové zprávě "
                f"a odešlete `KB1 {project_id}`, vložte jeho URL nebo otevřete interaktivní chat, "
                "kde lze zvolit SOUBOR či zadat kontext pro bezpečné dohledání."
            )

        last_error = ""
        for attempt in range(4):
            result = await event_call(
                {
                    "type": "input",
                    "data": {
                        "title": "Chybí hodnoticí předpis (KB1)",
                        "message": self._reviewer_source_instruction(policy, last_error, project_id),
                        "placeholder": "SOUBOR | URL: https://… | TEXT: … | HLEDAT: země=…; instituce=…; typ práce=…",
                        "type": "text",
                    },
                }
            )
            value = self._input_value(result)
            if not value or value.casefold() in {"zrušit", "zrusit", "cancel", "stop"}:
                raise CompanionError(
                    "Reviewer nebyl spuštěn, protože nebyl dodán ani potvrzen zdroj KB1. "
                    f"Koncept projektu: {project_id}. Soubor lze doplnit zprávou `KB1 {project_id}`."
                )

            if re.match(
                r"^\s*(?:soubor|soubory|file|files|upload|nahrát|nahrat|vybrat\s+soubor)\s*$",
                value,
                re.I,
            ):
                try:
                    imported_files = await self._pick_reviewer_kb1_files(
                        bridge,
                        owner_id,
                        project_id,
                        spec,
                        policy,
                        event_call,
                    )
                except Exception as exc:
                    last_error = (
                        f"Soubor se nepodařilo vložit: {exc}. Můžete zkusit `SOUBOR` znovu, "
                        f"nebo přiložit dokument k nové zprávě s textem `KB1 {project_id}`."
                    )
                    continue
                if imported_files:
                    return imported_files
                last_error = "Nebyl vybrán žádný soubor. Zvolte `SOUBOR` znovu nebo použijte URL či text."
                continue

            url_match = re.match(r"^\s*(?:url\s*:\s*)?(https?://\S+)\s*$", value, re.I)
            if url_match:
                try:
                    imported = await self._import_reviewer_kb1(
                        bridge,
                        owner_id,
                        project_id,
                        source_type="url",
                        value=url_match.group(1),
                        provenance={"selection": "explicit_url", "attempt": attempt + 1},
                    )
                    spec["options"]["reviewer_kb1_policy"] = policy
                    spec["options"]["reviewer_kb1_origin"] = "explicit_url"
                    await self._api(
                        bridge,
                        owner_id,
                        "PATCH",
                        f"/v1/projects/{project_id}",
                        json_body={"spec": spec},
                    )
                    return [(str(imported["filename"]), "kb1")]
                except Exception as exc:
                    last_error = f"URL se nepodařilo importovat: {exc}"
                    continue

            text_match = re.match(r"^\s*text\s*:\s*(.+)$", value, re.I | re.S)
            if text_match or (len(value) >= 240 and not re.match(r"^\s*(?:hledat|dohledat|search)\b", value, re.I)):
                criteria = (text_match.group(1) if text_match else value).strip()
                if len(criteria) < 40:
                    last_error = "Vložená kritéria jsou příliš krátká; popište hodnoticí pravidla explicitně."
                    continue
                imported = await self._import_reviewer_kb1(
                    bridge,
                    owner_id,
                    project_id,
                    source_type="text",
                    value=criteria,
                    filename="reviewer_kb1_user_criteria.md",
                    provenance={"selection": "user_text", "attempt": attempt + 1},
                )
                spec["options"]["reviewer_kb1_policy"] = policy
                spec["options"]["reviewer_kb1_origin"] = "user_text"
                await self._api(
                    bridge,
                    owner_id,
                    "PATCH",
                    f"/v1/projects/{project_id}",
                    json_body={"spec": spec},
                )
                return [(str(imported["filename"]), "kb1")]

            if re.match(r"^\s*(?:hledat|dohledat|search)\b", value, re.I):
                if policy != "ask_or_search":
                    last_error = "Aktuální Valve vyžaduje explicitní soubor, URL nebo text; webové dohledání je vypnuté."
                    continue
                context, missing = self._parse_reviewer_context(value)
                if missing:
                    context_result = await event_call(
                        {
                            "type": "input",
                            "data": {
                                "title": "Kontext pro dohledání KB1",
                                "message": (
                                    "Bez kontextu nelze bezpečně určit příslušný předpis. Chybí: "
                                    + ", ".join(missing)
                                    + ".\n\nZadejte např.: `země=ČR; instituce=VUT; fakulta=FAST; "
                                    "typ práce=diplomová práce; program=Stavební inženýrství`."
                                ),
                                "placeholder": "země=…; instituce=…; fakulta=…; typ práce=…",
                                "type": "text",
                            },
                        }
                    )
                    context, missing = self._parse_reviewer_context(self._input_value(context_result))
                if missing:
                    last_error = "Dohledání nelze spustit bez: " + ", ".join(missing) + "."
                    continue
                confirmed = await event_call(
                    {
                        "type": "confirmation",
                        "data": {
                            "title": "Povolit dohledání hodnoticího předpisu?",
                            "message": (
                                "AutoGenBook použije webové vyhledávání nakonfigurované v Open WebUI pouze pro "
                                "nalezení kandidátních veřejných předpisů. Nic nebude přidáno do KB1 bez vašeho "
                                "následného výběru.\n\n"
                                + "\n".join(f"- {key}: {item}" for key, item in context.items())
                            ),
                        },
                    }
                )
                if not confirmed:
                    last_error = "Webové dohledání nebylo potvrzeno. Zadejte explicitní URL, text nebo přiložte soubor."
                    continue
                discovery = await self._api(
                    bridge,
                    owner_id,
                    "POST",
                    f"/v1/projects/{project_id}/reviewer/kb1/discover",
                    json_body={
                        "context": {**context, "language": spec.get("language") or "cs"},
                        "max_candidates": int(user_valves.REVIEWER_SEARCH_MAX_CANDIDATES),
                    },
                    timeout=180,
                )
                candidates = list(discovery.get("candidates") or [])
                if not candidates:
                    last_error = str(discovery.get("message") or "Nebyl nalezen ověřitelný předpis.")
                    continue
                candidate_lines = []
                for index, candidate in enumerate(candidates, start=1):
                    candidate_lines.append(
                        f"{index}. {candidate.get('title') or candidate.get('url')}\n"
                        f"   URL: {candidate.get('url')}\n"
                        f"   Pravděpodobnost oficiálního zdroje: {candidate.get('official_likelihood', 'unknown')}\n"
                        f"   Důvod: {candidate.get('reason') or 'neuveden'}\n"
                        f"   Kontrola: {candidate.get('quality_code') or 'HTTP ověřeno'}"
                    )
                selection_result = await event_call(
                    {
                        "type": "input",
                        "data": {
                            "title": "Vyberte předpisy pro KB1",
                            "message": (
                                "Kandidátní URL byly technicky ověřeny, ale význam a aktuálnost musí potvrdit uživatel. "
                                "Zadejte číslo nebo více čísel oddělených čárkou; `vše` vybere všechny.\n\n"
                                + "\n\n".join(candidate_lines)
                            ),
                            "placeholder": "např. 1,2",
                            "type": "text",
                        },
                    }
                )
                selected = self._candidate_selection(self._input_value(selection_result), len(candidates))
                if not selected:
                    last_error = "Nebyl vybrán žádný kandidátní předpis."
                    continue
                imported_rows: list[tuple[str, str]] = []
                selected_metadata: list[dict[str, Any]] = []
                for index in selected:
                    candidate = candidates[index]
                    try:
                        imported = await self._import_reviewer_kb1(
                            bridge,
                            owner_id,
                            project_id,
                            source_type="url",
                            value=str(candidate["url"]),
                            provenance={
                                "selection": "context_aware_web_lookup",
                                "query": discovery.get("query"),
                                "context": context,
                                "candidate": candidate,
                                "user_confirmed": True,
                            },
                        )
                    except Exception as exc:
                        last_error = f"Vybraný zdroj {candidate.get('url')} se nepodařilo importovat: {exc}"
                        continue
                    imported_rows.append((str(imported["filename"]), "kb1"))
                    selected_metadata.append(candidate)
                if imported_rows:
                    spec["options"]["reviewer_kb1_policy"] = policy
                    spec["options"]["reviewer_kb1_origin"] = "context_aware_web_lookup"
                    spec["options"]["reviewer_kb1_context"] = context
                    spec["options"]["reviewer_kb1_query"] = discovery.get("query")
                    spec["options"]["reviewer_kb1_selected_sources"] = selected_metadata
                    await self._api(
                        bridge,
                        owner_id,
                        "PATCH",
                        f"/v1/projects/{project_id}",
                        json_body={"spec": spec},
                    )
                    return imported_rows
                continue

            last_error = (
                "Nerozumím vstupu. Použijte `SOUBOR`, prefix `URL:`, `TEXT:` nebo "
                + ("`HLEDAT:`." if policy == "ask_or_search" else "přiložte soubor.")
            )
        raise CompanionError(
            "KB1 se nepodařilo získat. Reviewer nebyl spuštěn; projekt zůstává bezpečně uložen jako koncept "
            f"`{project_id}`."
        )

    async def _provider_validation(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        provider: dict[str, Any],
    ) -> dict[str, Any]:
        return await self._api(
            bridge,
            owner_id,
            "POST",
            "/v1/providers/validate",
            json_body={"provider": provider},
            timeout=30,
        )

    async def _ensure_provider_ready(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        provider: dict[str, Any],
        event_call: Any,
    ) -> None:
        provider_type = str(provider.get("type") or "")
        secret_name = str(provider.get("api_key_secret") or "provider_api_key")
        if provider_type == "openai_compatible":
            status_payload = await self._api(bridge, owner_id, "GET", f"/v1/secrets/{secret_name}/status")
            if not status_payload.get("exists"):
                await self._api(
                    bridge,
                    owner_id,
                    "PUT",
                    f"/v1/secrets/{secret_name}",
                    json_body={"value": "local"},
                )
            return

        validation = await self._provider_validation(bridge, owner_id, provider)
        if validation.get("valid"):
            return
        replaceable = {"MISSING_SECRET", "SESSION_TOKEN_NOT_ALLOWED", "AUTH_INVALID", "AUTH_FORBIDDEN"}
        if str(validation.get("code")) not in replaceable:
            raise CompanionError(str(validation.get("message") or "LLM provider se nepodařilo ověřit."))
        if event_call is None:
            raise CompanionError(
                str(validation.get("message") or "Chybí platný API klíč.")
                + " Otevřete tuto úlohu v interaktivním chatu a použijte příkaz pokračuj ID."
            )

        last_message = str(validation.get("message") or "Chybí platný API klíč.")
        status_payload = (
            await self._api(bridge, owner_id, "GET", f"/v1/secrets/{secret_name}/status")
            or {}
        )
        external_reference = (
            status_payload.get("reference_path")
            if status_payload.get("source") == "external_text_file"
            else None
        )
        for _attempt in range(2):
            if provider_type == "openwebui":
                destination_note = (
                    f" Nová hodnota bude atomicky zapsána do nakonfigurovaného TXT souboru `{external_reference}`."
                    if external_reference
                    else " Hodnota se uloží pouze do místního systémového keychainu Companionu."
                )
                prompt_message = (
                    f"{last_message}\n\n"
                    "AutoGenBook může běžet několik dnů, proto nelze použít přihlašovací JWT/session token. "
                    "V Open WebUI otevřete profil → Nastavení → Účet → API Keys, vytvořte osobní API klíč "
                    "(obvykle začíná sk-) a vložte jej sem. Klíč musí smět volat /api/models a "
                    "/api/chat/completions." + destination_note
                )
                placeholder = "sk-…"
                title = "Trvalý Open WebUI API klíč"
            else:
                prompt_message = (
                    f"{last_message}\n\n"
                    f"Zadejte nový API klíč pro provider {provider_type}. Bude uložen pouze do místního "
                    "systémového keychainu Companionu."
                )
                placeholder = "API key"
                title = "API klíč pro AutoGenBook"
            result = await event_call(
                {
                    "type": "input",
                    "data": {
                        "title": title,
                        "message": prompt_message,
                        "placeholder": placeholder,
                        "type": "password",
                    },
                }
            )
            value = self._input_value(result)
            if not value:
                raise CompanionError("Bez trvalého API klíče nelze úlohu spustit ani obnovit.")
            if provider_type == "openwebui" and self._looks_like_session_token(value):
                last_message = (
                    "Zadaná hodnota vypadá jako přihlašovací/session JWT. Ten expiruje a pro background úlohy "
                    "není podporován. Vložte osobní API klíč z Nastavení → Účet → API Keys."
                )
                continue
            await self._api(
                bridge,
                owner_id,
                "PUT",
                f"/v1/secrets/{secret_name}",
                json_body={
                    "value": value,
                    "target": "external_text_file" if external_reference else "stored_per_user",
                },
            )
            validation = await self._provider_validation(bridge, owner_id, provider)
            if validation.get("valid"):
                return
            await self._api(bridge, owner_id, "DELETE", f"/v1/secrets/{secret_name}")
            last_message = str(validation.get("message") or "API klíč se nepodařilo ověřit.")
        raise CompanionError(last_message)

    @staticmethod
    async def _await_if_needed(value: Any) -> Any:
        return await value if hasattr(value, "__await__") else value

    @staticmethod
    def _persistent_output_path(
        file_id: str,
        user_id: str,
        file_hash: str,
        size: int,
    ) -> str:
        return _agb_capability_path(
            file_id,
            user_id,
            file_hash=file_hash,
            size=size,
        )

    @staticmethod
    def _persistent_output_url(
        file_id: str,
        user_id: str,
        file_hash: str,
        size: int,
    ) -> str:
        return _agb_capability_url(
            file_id,
            user_id,
            file_hash=file_hash,
            size=size,
        )

    @staticmethod
    def _output_file_id(user_id: str, artifact: dict[str, Any]) -> str:
        # Deterministic and user-scoped: repeated `výstupy <job-id>` calls repair old
        # conversations without creating duplicate Open WebUI files.
        seed = ":".join(
            (
                "autogenbook-output-v1",
                user_id,
                str(artifact.get("id") or ""),
                str(artifact.get("size") or 0),
                str(artifact.get("sha256") or ""),
            )
        )
        return str(uuid.uuid5(uuid.NAMESPACE_URL, seed))

    @staticmethod
    def _output_storage_name(file_id: str, original_name: str, upload_dir: Path) -> str:
        basename = Path(str(original_name or "artifact.bin")).name or "artifact.bin"
        basename = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", basename).strip(" .") or "artifact.bin"
        suffix = Path(basename).suffix[:20]
        # Keep Windows paths comfortably below the legacy MAX_PATH boundary.
        candidate = f"{file_id}_{basename[:160]}"
        if len(str(upload_dir / candidate)) >= 235:
            candidate = f"{file_id}{suffix}"
        return candidate

    @staticmethod
    def _file_payload(
        item: Any,
        persistent_url: str,
        preview_url: str,
    ) -> dict[str, Any]:
        """Return the exact assistant-file shape consumed by Open WebUI.

        The frontend renders only ``type=file|image`` entries and resolves the
        modal from the top-level ``id``.  The title click uses ``url`` directly
        only when it starts with http, so it receives the absolute capability
        URL.  The modal content gets a same-origin relative capability URL,
        avoiding hostname/origin mismatches in Desktop.
        """
        raw = item.model_dump(exclude={"path"}) if hasattr(item, "model_dump") else dict(item)
        meta = raw.get("meta") or {}
        if hasattr(meta, "model_dump"):
            meta = meta.model_dump()
        elif not isinstance(meta, dict):
            meta = {}
        raw["meta"] = meta

        file_id = str(raw.get("id") or "")
        filename = str(meta.get("name") or raw.get("filename") or "artifact.bin")
        content_type = str(meta.get("content_type") or "application/octet-stream")
        try:
            size = int(meta.get("size") or 0)
        except (TypeError, ValueError):
            size = 0

        preview = _agb_preview_content(filename, preview_url, size, content_type)
        data = raw.get("data") or {}
        if hasattr(data, "model_dump"):
            data = data.model_dump()
        elif not isinstance(data, dict):
            data = {}
        # Never let FileItemModal fall back to the literal "No content".  This
        # assignment is deliberate even for rows created by older versions.
        data = {**data, "status": "completed", "content": preview}
        raw["data"] = data

        return {
            "type": "file",
            "id": file_id,
            "url": persistent_url,
            "name": filename,
            "filename": filename,
            "status": "uploaded",
            "size": size,
            "content_type": content_type,
            "collection_name": str(meta.get("collection_name") or ""),
            "file": raw,
            "meta": meta,
            "source": "autogenbook",
            "content": preview,
            "download_url": persistent_url,
            "persistent_url": persistent_url,
            "persistent_path": preview_url,
        }


    async def _stream_companion_artifact(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        artifact: dict[str, Any],
        target: Path,
        event_emitter: Any,
    ) -> tuple[int, str]:
        target.parent.mkdir(parents=True, exist_ok=True)
        partial = target.with_name(
            target.name + f".{uuid.uuid4().hex}.autogenbook.part"
        )
        expected_size = max(0, int(artifact.get("size") or 0))
        expected_hash = str(artifact.get("sha256") or "").casefold()
        digest = hashlib.sha256()
        copied = 0
        last_notice = 0.0
        url = f"{str(bridge['url']).rstrip('/')}/v1/artifacts/{artifact['id']}/download"
        timeout = httpx.Timeout(None, connect=30.0)
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                async with client.stream(
                    "GET",
                    url,
                    headers=self._headers(bridge, owner_id),
                ) as response:
                    response.raise_for_status()
                    with partial.open("wb") as stream:
                        async for chunk in response.aiter_bytes(
                            chunk_size=int(self.valves.OUTPUT_COPY_CHUNK_BYTES)
                        ):
                            if not chunk:
                                continue
                            stream.write(chunk)
                            digest.update(chunk)
                            copied += len(chunk)
                            now = time.monotonic()
                            if event_emitter is not None and now - last_notice >= 5:
                                last_notice = now
                                if expected_size:
                                    percent = min(100.0, copied * 100.0 / expected_size)
                                    description = (
                                        f"Trvale ukládám `{artifact['filename']}` do Open WebUI: "
                                        f"{percent:.1f} % ({copied}/{expected_size} B)"
                                    )
                                else:
                                    description = (
                                        f"Trvale ukládám `{artifact['filename']}` do Open WebUI: {copied} B"
                                    )
                                await self._emit_status(event_emitter, description)
            if expected_size and copied != expected_size:
                raise CompanionError(
                    f"Výstup `{artifact['filename']}` měl mít {expected_size} B, ale bylo přeneseno {copied} B."
                )
            actual_hash = digest.hexdigest()
            if expected_hash and actual_hash != expected_hash:
                raise CompanionError(
                    f"Kontrolní součet výstupu `{artifact['filename']}` nesouhlasí s manifestem Companionu."
                )
            partial.replace(target)
            return copied, actual_hash
        except BaseException:
            partial.unlink(missing_ok=True)
            raise

    async def _publish_artifact_to_openwebui(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        artifact: dict[str, Any],
        user: dict[str, Any],
        event_emitter: Any,
    ) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        enriched = dict(artifact)
        temporary_url = str(enriched.get("download_url") or "")
        if temporary_url:
            enriched["temporary_download_url"] = temporary_url
        if not self.valves.PERSIST_OUTPUTS_TO_OPENWEBUI:
            return None, enriched
        try:
            from open_webui.config import STORAGE_PROVIDER, UPLOAD_DIR
            try:
                from open_webui.config import STORAGE_LOCAL_CACHE
            except ImportError:
                STORAGE_LOCAL_CACHE = True
            from open_webui.models.files import FileForm, Files
            from open_webui.storage.provider import Storage
        except ImportError:
            return None, enriched

        user_id = str(user.get("id") or "")
        if not user_id:
            return None, enriched
        expected_size = max(0, int(enriched.get("size") or 0))
        max_bytes = max(0, int(self.valves.PERSIST_OUTPUT_MAX_BYTES))
        if max_bytes and expected_size > max_bytes:
            raise CompanionError(
                f"Výstup `{enriched['filename']}` překračuje administrátorský limit trvalého uložení "
                f"{max_bytes} B."
            )

        provider = str(STORAGE_PROVIDER or "local").casefold()
        file_id = self._output_file_id(user_id, enriched)
        get_file = getattr(Files, "get_file_by_id", None)
        if callable(get_file):
            existing = await self._await_if_needed(get_file(file_id))
            if existing is not None and str(getattr(existing, "user_id", user_id)) == user_id:
                meta = getattr(existing, "meta", {}) or {}
                if hasattr(meta, "model_dump"):
                    meta = meta.model_dump()
                existing_size = int(meta.get("size") or 0) if isinstance(meta, dict) else 0
                size_matches = not expected_size or existing_size == expected_size
                local_exists = True
                if provider == "local":
                    existing_path = Path(str(getattr(existing, "path", "") or ""))
                    local_exists = existing_path.is_file()
                    if local_exists and expected_size:
                        try:
                            local_exists = existing_path.stat().st_size == expected_size
                        except OSError:
                            local_exists = False
                if size_matches and local_exists:
                    _meta, _name, _content_type, _size = _agb_file_meta(existing)
                    existing_hash = str(
                        getattr(existing, "hash", "")
                        or (_meta.get("file_hash") if isinstance(_meta, dict) else "")
                        or enriched.get("sha256")
                        or ""
                    ).casefold()
                    persistent_path = self._persistent_output_path(
                        file_id, user_id, existing_hash, _size
                    )
                    persistent_url = self._persistent_output_url(
                        file_id, user_id, existing_hash, _size
                    )
                    preview = _agb_preview_content(
                        _name, persistent_path, _size, _content_type
                    )
                    update_data = getattr(Files, "update_file_data_by_id", None)
                    if not callable(update_data):
                        raise CompanionError(
                            "Tato verze Open WebUI neumí aktualizovat metadata výstupního souboru."
                        )
                    updated = await self._await_if_needed(
                        update_data(
                            file_id,
                            {
                                "status": "completed",
                                "content": preview,
                                "autogenbook_download_broker": "capability-v0.3.3",
                                "autogenbook_persistent_path": persistent_path,
                            },
                        )
                    )
                    existing = updated or await self._await_if_needed(get_file(file_id)) or existing
                    existing_data = getattr(existing, "data", {}) or {}
                    if hasattr(existing_data, "model_dump"):
                        existing_data = existing_data.model_dump()
                    if not isinstance(existing_data, dict) or not str(existing_data.get("content") or "").strip():
                        raise CompanionError(
                            f"Open WebUI neuložilo náhledovou kartu pro `{_name}`; soubor nebude zveřejněn."
                        )
                    payload = self._file_payload(existing, persistent_url, persistent_path)
                    enriched.update(
                        {
                            "openwebui_file_id": file_id,
                            "persistent_url": persistent_url,
                            "persistent_path": persistent_path,
                            "download_url": persistent_url,
                            "download_url_kind": "openwebui_capability_v1",
                        }
                    )
                    return payload, enriched
                delete_file = getattr(Files, "delete_file_by_id", None)
                if callable(delete_file):
                    await self._await_if_needed(delete_file(file_id))

        upload_dir = Path(str(UPLOAD_DIR)).expanduser().resolve()
        upload_dir.mkdir(parents=True, exist_ok=True)
        original_name = str(enriched.get("filename") or "artifact.bin")
        storage_name = self._output_storage_name(file_id, original_name, upload_dir)
        local_path = upload_dir / storage_name
        size, digest = await self._stream_companion_artifact(
            bridge,
            owner_id,
            enriched,
            local_path,
            event_emitter,
        )
        persistent_path = self._persistent_output_path(file_id, user_id, digest, size)
        persistent_url = self._persistent_output_url(file_id, user_id, digest, size)
        preview = _agb_preview_content(
            original_name,
            persistent_path,
            size,
            str(enriched.get("mime") or "application/octet-stream"),
        )
        stored_path = str(local_path)
        try:
            if provider == "local":
                stored_path = str(local_path)
            elif provider == "s3" and all(
                hasattr(Storage, name) for name in ("s3_client", "bucket_name")
            ):
                prefix = str(getattr(Storage, "key_prefix", "") or "").strip("/\\")
                key = f"{prefix}/{storage_name}" if prefix else storage_name
                await asyncio.to_thread(
                    Storage.s3_client.upload_file,
                    str(local_path),
                    Storage.bucket_name,
                    key,
                )
                stored_path = f"s3://{Storage.bucket_name}/{key}"
            elif provider == "gcs" and hasattr(Storage, "bucket"):
                blob = Storage.bucket.blob(storage_name)
                await asyncio.to_thread(blob.upload_from_filename, str(local_path))
                stored_path = f"gs://{Storage.bucket_name}/{storage_name}"
            elif provider == "azure" and hasattr(Storage, "container_client"):
                blob_client = Storage.container_client.get_blob_client(storage_name)
                with local_path.open("rb") as stream:
                    await asyncio.to_thread(blob_client.upload_blob, stream, overwrite=True)
                stored_path = f"{Storage.endpoint}/{Storage.container_name}/{storage_name}"
            else:
                raise CompanionError(
                    f"Open WebUI storage provider `{provider}` nepodporuje streamované AutoGenBook výstupy."
                )
        except BaseException:
            local_path.unlink(missing_ok=True)
            raise

        item = await self._await_if_needed(
            Files.insert_new_file(
                user_id,
                FileForm(
                    id=file_id,
                    hash=digest,
                    filename=original_name,
                    path=stored_path,
                    data={
                        "status": "completed",
                        "content": preview,
                        "autogenbook_download_broker": "capability-v0.3.3",
                        "autogenbook_persistent_path": persistent_path,
                        "autogenbook_artifact_id": str(enriched.get("id") or ""),
                        "autogenbook_job_id": str(enriched.get("job_id") or ""),
                    },
                    meta={
                        "name": original_name,
                        "content_type": enriched.get("mime") or "application/octet-stream",
                        "size": size,
                        "file_hash": digest,
                        "data": {
                            "source": "autogenbook",
                            "autogenbook_artifact_id": str(enriched.get("id") or ""),
                            "autogenbook_job_id": str(enriched.get("job_id") or ""),
                            "autogenbook_role": str(enriched.get("role") or "support"),
                            "companion_temporary_url_was_replaced": True,
                        },
                    },
                ),
            )
        )
        if item is None:
            # A second concurrent chat request may have inserted the same
            # deterministic file ID while this request was streaming it.
            get_file = getattr(Files, "get_file_by_id", None)
            item = (
                await self._await_if_needed(get_file(file_id))
                if callable(get_file)
                else None
            )
        if item is None:
            raise CompanionError(f"Open WebUI neuložilo databázový záznam pro `{original_name}`.")

        # Read the row back before publishing any link.  Files.insert_new_file()
        # intentionally returns None on several database errors in some Open WebUI
        # releases, so a successful-looking in-memory object is not sufficient.
        get_file = getattr(Files, "get_file_by_id", None)
        verified = (
            await self._await_if_needed(get_file(file_id))
            if callable(get_file)
            else item
        )
        if verified is None:
            raise CompanionError(
                f"Open WebUI po registraci nedokázalo znovu načíst soubor `{original_name}`."
            )
        verified_owner = str(getattr(verified, "user_id", "") or "")
        if verified_owner and verified_owner != user_id:
            raise CompanionError(
                f"Open WebUI přiřadilo soubor `{original_name}` jinému vlastníkovi; odkaz nebude zveřejněn."
            )
        verified_meta = getattr(verified, "meta", {}) or {}
        if hasattr(verified_meta, "model_dump"):
            verified_meta = verified_meta.model_dump()
        if not isinstance(verified_meta, dict):
            verified_meta = {}
        verified_size = int(verified_meta.get("size") or 0)
        if size and verified_size and verified_size != size:
            raise CompanionError(
                f"Open WebUI eviduje pro `{original_name}` velikost {verified_size} B, očekáváno {size} B."
            )

        # Some Open WebUI releases persist binary data but omit File.data during
        # direct model insertion. Repair it explicitly and read it back before
        # emitting the assistant file object; otherwise FileItemModal renders
        # the literal fallback "No content".
        update_data = getattr(Files, "update_file_data_by_id", None)
        if not callable(update_data):
            raise CompanionError(
                "Tato verze Open WebUI neumí uložit náhledovou kartu výstupního souboru."
            )
        updated = await self._await_if_needed(
            update_data(
                file_id,
                {
                    "status": "completed",
                    "content": preview,
                    "autogenbook_download_broker": "capability-v0.3.3",
                    "autogenbook_persistent_path": persistent_path,
                },
            )
        )
        verified = updated or (
            await self._await_if_needed(get_file(file_id)) if callable(get_file) else verified
        ) or verified
        verified_data = getattr(verified, "data", {}) or {}
        if hasattr(verified_data, "model_dump"):
            verified_data = verified_data.model_dump()
        if not isinstance(verified_data, dict) or not str(verified_data.get("content") or "").strip():
            raise CompanionError(
                f"Open WebUI po registraci nevrátilo obsah náhledové karty pro `{original_name}`."
            )

        if provider == "local":
            verified_path = Path(str(getattr(verified, "path", "") or ""))
            if not verified_path.is_file():
                raise CompanionError(
                    f"Soubor `{original_name}` byl zapsán do databáze Open WebUI, ale data na disku chybí."
                )
            actual_size = verified_path.stat().st_size
            if actual_size != size:
                raise CompanionError(
                    f"Soubor `{original_name}` má na disku {actual_size} B, očekáváno {size} B."
                )

        payload = self._file_payload(verified, persistent_url, persistent_path)
        enriched.update(
            {
                "openwebui_file_id": file_id,
                "persistent_url": persistent_url,
                "persistent_path": persistent_path,
                "download_url": persistent_url,
                "download_url_kind": "openwebui_capability_v1",
                "openwebui_registration_verified": True,
                "sha256": digest,
                "size": size,
            }
        )
        # Open WebUI's cloud upload path normally keeps a local cache for process=false.
        # Respect installations that explicitly disabled it and let Storage rehydrate later.
        if provider != "local" and not bool(STORAGE_LOCAL_CACHE):
            local_path.unlink(missing_ok=True)
        return payload, enriched

    def _select_published_artifacts(
        self,
        artifacts: list[dict[str, Any]],
        *,
        include_all: bool,
    ) -> tuple[list[dict[str, Any]], int]:
        role_order = {"primary": 0, "bundle": 1, "support": 2, "diagnostic": 3}
        candidates = [
            dict(item)
            for item in artifacts
            if include_all or str(item.get("role") or "") in {"primary", "bundle"}
        ]
        if not self.valves.PERSIST_DIAGNOSTIC_OUTPUTS:
            candidates = [item for item in candidates if item.get("role") != "diagnostic"]
        candidates.sort(
            key=lambda item: (
                role_order.get(str(item.get("role") or "support"), 9),
                str(item.get("filename") or "").casefold(),
            )
        )
        limit = max(1, int(self.valves.PERSIST_OUTPUT_MAX_FILES))
        selected = candidates[:limit]
        bundle = next((item for item in candidates if item.get("role") == "bundle"), None)
        if bundle is not None and bundle not in selected:
            if selected:
                selected[-1] = bundle
            else:
                selected.append(bundle)
        selected_ids = {str(item.get("id") or "") for item in selected}
        selected = [
            item
            for index, item in enumerate(selected)
            if str(item.get("id") or "") not in {
                str(other.get("id") or "") for other in selected[:index]
            }
        ]
        omitted = max(0, len(candidates) - len(selected_ids))
        return selected, omitted

    async def _attach_artifacts(
        self,
        bridge: dict[str, Any],
        owner_id: str,
        job_id: str,
        user: dict[str, Any],
        event_emitter: Any,
        *,
        include_all: bool = False,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        artifacts = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}/artifacts")
        selected, omitted = self._select_published_artifacts(artifacts, include_all=include_all)
        registered: list[dict[str, Any]] = []
        published: list[dict[str, Any]] = []
        skipped: list[str] = []
        if omitted:
            skipped.append(
                f"{omitted} dalších pomocných souborů není vypsáno samostatně; jsou obsaženy v kompletním ZIPu."
            )
        for artifact in selected:
            try:
                registered_file, enriched = await self._publish_artifact_to_openwebui(
                    bridge,
                    owner_id,
                    artifact,
                    user,
                    event_emitter,
                )
                if registered_file:
                    registered.append(registered_file)
                    published.append(enriched)
                else:
                    skipped.append(
                        f"{artifact['filename']} (trvalá registrace do Open WebUI není v této instalaci dostupná; "
                        "dočasný Companion odkaz se z bezpečnostních důvodů nezveřejňuje)"
                    )
            except Exception as exc:
                skipped.append(
                    f"{artifact['filename']} (trvalé uložení selhalo: {exc}; "
                    "dočasný Companion odkaz se nezveřejňuje)"
                )
        if registered and event_emitter is not None:
            await event_emitter({"type": "files", "data": {"files": registered}})
        return published, skipped

    @staticmethod
    def _summary(mode: str, spec: dict[str, Any], files: list[tuple[str, str]]) -> str:
        lines = [
            f"Režim: {mode}",
            f"Jazyk: {spec['language']}",
            f"Model: {spec['provider']['model']}",
            f"Provider: {spec['provider']['type']}",
            f"Výstupy: {', '.join(spec['outputs']['formats'])}",
        ]
        if spec.get("length"):
            lines.append(f"Rozsah: {spec['length']} {'snímků' if mode == 'presentation' else 'stran/jednotek'}")
        lines.append(f"Web RAG: {'ano' if spec['options'].get('web_rag') else 'ne'}")
        if mode == "reviewer":
            lines.append(f"KB1 politika: {spec['options'].get('reviewer_kb1_policy', 'ask_or_search')}")
            if spec['options'].get('reviewer_kb1_origin'):
                lines.append(f"Původ KB1: {spec['options'].get('reviewer_kb1_origin')}")
        if files:
            lines.append("Přílohy: " + ", ".join(f"{name} → {role}" for name, role in files))
        else:
            lines.append("Přílohy: žádné")
        return "\n".join(lines)

    async def _emit_status(
        self,
        emitter: Any,
        description: str,
        done: bool = False,
        progress: float | None = None,
    ) -> None:
        if emitter is not None:
            data: dict[str, Any] = {"description": description, "done": done, "hidden": False}
            if progress is not None:
                data["progress"] = max(0.0, min(100.0, float(progress)))
            await emitter({"type": "status", "data": data})

    async def _job_command(
        self,
        command: str,
        job_id: str,
        bridge: dict[str, Any],
        owner_id: str,
        user: dict[str, Any],
        event_emitter: Any,
        event_call: Any = None,
        user_valves: "Pipe.UserValves | None" = None,
    ) -> str:
        if command == "cancel":
            job = await self._api(bridge, owner_id, "POST", f"/v1/jobs/{job_id}/cancel")
            return f"Požadavek na zrušení úlohy `{job_id}` byl přijat. Aktuální stav: **{job['status']}**."
        if command == "resume":
            current = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}")
            project = await self._api(bridge, owner_id, "GET", f"/v1/projects/{current['project_id']}")
            spec = dict(project.get("spec") or {})
            provider = dict(spec.get("provider") or {})
            await self._ensure_provider_ready(bridge, owner_id, provider, event_call)

            if str(spec.get("mode") or "") == "reviewer":
                active_valves = user_valves or self.UserValves()
                validation = await self._api(
                    bridge,
                    owner_id,
                    "POST",
                    f"/v1/projects/{current['project_id']}/validate",
                )
                kb1_errors = [
                    item
                    for item in validation.get("issues", [])
                    if item.get("severity") == "error"
                    and item.get("code") in {
                        "MISSING_REVIEWER_KB1",
                        "EMPTY_REVIEWER_KB1",
                        "REVIEWER_KB1_AUTH_PAGE",
                        "REVIEWER_KB1_ACCESS_GATE",
                        "REVIEWER_KB1_UNREADABLE",
                        "REVIEWER_KB1_TOO_SHORT",
                        "REVIEWER_KB1_IRRELEVANT",
                    }
                ]
                if kb1_errors:
                    await self._emit_status(
                        event_emitter,
                        "Reviewer před obnovou vyžaduje použitelnou KB1…",
                    )
                    try:
                        await self._ensure_reviewer_kb1(
                            bridge,
                            owner_id,
                            current["project_id"],
                            spec,
                            active_valves,
                            event_call,
                        )
                    except CompanionError as exc:
                        return (
                            f"Úloha `{job_id}` nebyla obnovena, protože reviewer stále nemá ověřenou KB1.\n\n"
                            f"{exc}\n\nProjekt a dosavadní data zůstávají uložené."
                        )
                    validation = await self._api(
                        bridge,
                        owner_id,
                        "POST",
                        f"/v1/projects/{current['project_id']}/validate",
                    )
                    remaining_errors = [
                        item for item in validation.get("issues", []) if item.get("severity") == "error"
                    ]
                    if remaining_errors:
                        detail = "\n".join(
                            f"- {item.get('message') or item.get('code')}" for item in remaining_errors
                        )
                        return (
                            f"Úloha `{job_id}` nebyla obnovena, protože projekt po doplnění KB1 stále není validní:\n"
                            f"{detail}"
                        )

            job = await self._api(bridge, owner_id, "POST", f"/v1/jobs/{job_id}/resume")
            return (
                f"Úloha `{job_id}` byla po ověření trvalého API klíče a projektových vstupů "
                f"zařazena k pokračování. Stav: **{job['status']}**."
            )
        job = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}")
        progress = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}/progress")
        if command == "artifacts" or job["status"] == "SUCCEEDED":
            artifacts, skipped = await self._attach_artifacts(
                bridge,
                owner_id,
                job_id,
                user,
                event_emitter,
                include_all=(command == "artifacts"),
            )
            lines = [
                f"Úloha `{job_id}` — **{job['status']}** ({float(progress.get('progress', 0)):.1f} %)",
                "",
                "Výstupy:",
            ]
            for item in artifacts:
                url = str(item.get("persistent_url") or item.get("download_url") or "")
                label = f"{item['filename']} ({item['role']}, {item['size']} B)"
                lines.append(f"- [{label}]({url})" if url else f"- `{label}`")
            if skipped:
                lines.extend(["", "Poznámky k trvalému uložení:", *[f"- {item}" for item in skipped]])
            return "\n".join(lines)
        return (
            f"Úloha `{job_id}` je ve stavu **{job['status']}** — "
            f"**{float(progress.get('progress', 0)):.1f} %**.\n\n"
            f"Aktuální krok: {progress.get('message') or progress.get('stage') or 'bez podrobností'}\n\n"
            f"Heartbeat: `{progress.get('heartbeat_at') or 'zatím nezapsán'}`\n\n"
            f"Příkazy: `stav {job_id}`, `zruš {job_id}`, `pokračuj {job_id}`, `výstupy {job_id}`."
        )

    async def pipe(
        self,
        body: dict[str, Any],
        __user__: Optional[dict[str, Any]] = None,
        __metadata__: Optional[dict[str, Any]] = None,
        __files__: Optional[list[dict[str, Any]]] = None,
        __event_emitter__: Any = None,
        __event_call__: Any = None,
        __request__: Any = None,
        __task__: Optional[str] = None,
        **_: Any,
    ) -> str:
        if __task__:
            return "AutoGenBook"
        user = __user__ or {}
        if __request__ is not None:
            _AGB_PUBLIC_ORIGIN.set(_agb_request_origin(__request__))
            _agb_register_download_routes(getattr(__request__, "app", None))
        else:
            _agb_register_download_routes()
        _cache_request_models(__request__, body)
        owner_id = str(user.get("id") or (__metadata__ or {}).get("user_id") or "local")
        prompt = self._user_prompt(body, __metadata__)
        mode = self._mode_from_body(body)
        command, command_job_id = self._command(prompt)
        user_valves = self._user_valves(user, self.UserValves)
        assert isinstance(user_valves, self.UserValves)
        try:
            await self._emit_status(__event_emitter__, "Připojuji AutoGenBook Companion…")
            bridge = await self._ensure_companion()
            if command and command_job_id:
                if command == "kb1":
                    return await self._kb1_attachment_command(
                        command_job_id,
                        bridge,
                        owner_id,
                        __files__,
                        __event_emitter__,
                        __event_call__,
                        user_valves,
                    )
                return await self._job_command(
                    command,
                    command_job_id,
                    bridge,
                    owner_id,
                    user,
                    __event_emitter__,
                    __event_call__,
                    user_valves,
                )

            clean_prompt = self._clean_prompt_text(prompt)
            directives, brief = self._parse_directives(clean_prompt)
            defaults = (
                [part.strip().lower() for part in user_valves.DEFAULT_OUTPUTS.split(",") if part.strip()]
                or self._default_outputs(mode)
            )
            outputs = self._extract_outputs(clean_prompt, directives.get("outputs"), defaults)
            length = self._extract_length(
                clean_prompt,
                directives.get("length"),
                mode,
                user_valves.PRESENTATION_SLIDES,
            )
            options: dict[str, Any] = {
                "web_rag": self._parse_bool(directives["web_rag"])
                if directives.get("web_rag")
                else user_valves.WEB_RAG,
                "audit_mode": directives.get("audit_mode", user_valves.AUDIT_MODE).lower(),
                "audit": directives.get("audit_mode", user_valves.AUDIT_MODE).lower() != "off",
                "paper_venue": directives.get("paper_venue", user_valves.PAPER_VENUE),
                "citation_style": directives.get("citation_style", user_valves.CITATION_STYLE).lower(),
                "images": self._parse_bool(directives.get("images", "ano")),
                "citations": self._parse_bool(directives.get("citations", "ne")),
                "narration": self._parse_bool(directives.get("narration", "ne")),
                "tts": self._parse_bool(directives.get("tts", "ne")),
                "video": self._parse_bool(directives.get("video", "ne")),
                "reviewer_kb1_policy": user_valves.REVIEWER_KB1_POLICY,
                "reviewer_allow_missing_kb1": (
                    mode == "reviewer" and user_valves.REVIEWER_KB1_POLICY == "allow_without_kb1"
                ),
                "reviewer_profile": user_valves.REVIEWER_PROFILE,
                "reviewer_direct_pdf": user_valves.REVIEWER_DIRECT_PDF,
                "reviewer_evidence_max_chars": user_valves.REVIEWER_EVIDENCE_MAX_CHARS,
                "reviewer_kb1_context_max_chars": user_valves.REVIEWER_KB1_CONTEXT_MAX_CHARS,
                "reviewer_evidence_per_criterion": user_valves.REVIEWER_EVIDENCE_PER_CRITERION,
                "reviewer_max_output_tokens": user_valves.REVIEWER_MAX_OUTPUT_TOKENS,
                "reviewer_quality_gate": user_valves.REVIEWER_QUALITY_GATE,
                "reviewer_pdf_engine": user_valves.REVIEWER_PDF_ENGINE,
            }
            if mode == "reviewer" and not brief.strip():
                brief = (
                    "Vypracuj úplný odborný posudek závěrečné práce podle standardního reviewer promptu "
                    "AutoGenBooku. Hodnoť obsahovou kvalitu, metodiku, výsledky, původnost, inovaci, "
                    "praktický přínos a formální požadavky z KB1; každé hodnocení opři o důkazy z KB2."
                )
            spec = {
                "mode": mode,
                "brief": brief,
                "title": directives.get("title"),
                "language": directives.get("language", user_valves.LANGUAGE),
                "audience": directives.get("audience"),
                "style": directives.get("style"),
                "length": length,
                "outputs": {"formats": outputs, "attach_primary_to_chat": True},
                "provider": {
                    "type": user_valves.PROVIDER_TYPE,
                    "base_url": (
                        user_valves.LLM_BASE_URL.strip()
                        or (
                            f"{str(__request__.base_url).rstrip('/')}/api"
                            if user_valves.PROVIDER_TYPE == "openwebui" and __request__ is not None
                            else None
                        )
                    ),
                    "model": user_valves.LLM_MODEL or DEFAULT_LLM_MODEL,
                    "api_key_secret": user_valves.API_SECRET_NAME,
                    "role_models": {},
                },
                "options": options,
                "metadata": {
                    "chat_id": (__metadata__ or {}).get("chat_id"),
                    "message_id": (__metadata__ or {}).get("message_id"),
                    "interface": (__metadata__ or {}).get("interface"),
                },
            }

            await self._ensure_provider_ready(
                bridge,
                owner_id,
                spec["provider"],
                __event_call__,
            )
            await self._emit_status(__event_emitter__, "Vytvářím projekt a ukládám vstupy…")
            project = await self._api(
                bridge,
                owner_id,
                "POST",
                "/v1/projects",
                json_body={"spec": spec},
            )
            uploaded_summary: list[tuple[str, str]] = []
            for entry in __files__ or []:
                path, filename = await self._resolve_openwebui_file(entry, owner_id)
                role = self._infer_file_role(filename, mode)
                await self._upload_path(bridge, owner_id, project["id"], role, path, filename)
                uploaded_summary.append((filename, role))

            if mode == "reviewer" and not any(role == "kb1" for _name, role in uploaded_summary):
                await self._emit_status(
                    __event_emitter__,
                    "Reviewer potřebuje hodnoticí předpis nebo explicitní kritéria (KB1)…",
                )
                imported_kb1 = await self._ensure_reviewer_kb1(
                    bridge,
                    owner_id,
                    project["id"],
                    spec,
                    user_valves,
                    __event_call__,
                )
                uploaded_summary.extend(imported_kb1)

            validation = await self._api(
                bridge,
                owner_id,
                "POST",
                f"/v1/projects/{project['id']}/validate",
            )
            kb1_validation_errors = [
                item
                for item in validation["issues"]
                if item.get("severity") == "error"
                and item.get("code") in {
                        "MISSING_REVIEWER_KB1",
                        "EMPTY_REVIEWER_KB1",
                        "REVIEWER_KB1_AUTH_PAGE",
                        "REVIEWER_KB1_ACCESS_GATE",
                        "REVIEWER_KB1_UNREADABLE",
                        "REVIEWER_KB1_TOO_SHORT",
                        "REVIEWER_KB1_IRRELEVANT",
                    }
            ]
            if (
                mode == "reviewer"
                and kb1_validation_errors
                and user_valves.REVIEWER_KB1_POLICY != "allow_without_kb1"
            ):
                await self._emit_status(
                    __event_emitter__,
                    "Přiložená KB1 je prázdná, nerelevantní nebo přihlašovací stránka; vyžaduji náhradní zdroj…",
                )
                imported_kb1 = await self._ensure_reviewer_kb1(
                    bridge,
                    owner_id,
                    project["id"],
                    spec,
                    user_valves,
                    __event_call__,
                )
                uploaded_summary.extend(imported_kb1)
                validation = await self._api(
                    bridge,
                    owner_id,
                    "POST",
                    f"/v1/projects/{project['id']}/validate",
                )
            errors = [item for item in validation["issues"] if item["severity"] == "error"]
            warnings = [item for item in validation["issues"] if item["severity"] == "warning"]
            if errors:
                text = "\n".join(f"- {item['message']}" for item in errors)
                return f"Projekt `{project['id']}` nelze spustit:\n{text}"

            summary = self._summary(mode, spec, uploaded_summary)
            if warnings:
                summary += "\nVarování:\n" + "\n".join(f"- {item['message']}" for item in warnings)
            if not user_valves.AUTO_CONFIRM and __event_call__ is not None:
                confirmed = await __event_call__(
                    {
                        "type": "confirmation",
                        "data": {
                            "title": "Spustit AutoGenBook?",
                            "message": summary,
                        },
                    }
                )
                if not confirmed:
                    return (
                        f"Projekt byl uložen jako koncept (`{project['id']}`), ale generování nebylo spuštěno.\n\n"
                        f"{summary}"
                    )

            metadata = __metadata__ or {}
            idempotency = ":".join(
                str(value or "unknown")
                for value in (
                    owner_id,
                    metadata.get("chat_id"),
                    metadata.get("message_id"),
                    mode,
                )
            )
            job = await self._api(
                bridge,
                owner_id,
                "POST",
                "/v1/jobs",
                json_body={
                    "project_id": project["id"],
                    "idempotency_key": idempotency,
                    "resume": False,
                },
            )
            job_id = job["id"]
            await self._emit_status(__event_emitter__, f"AutoGenBook běží — úloha {job_id[:8]}…")
            started = time.monotonic()
            cursor = 0
            last_description = ""
            foreground_seconds = min(
                int(self.valves.FOREGROUND_WAIT_SECONDS),
                int(user_valves.FOREGROUND_WAIT_MINUTES) * 60,
            )
            while time.monotonic() - started < foreground_seconds:
                events = await self._api(
                    bridge,
                    owner_id,
                    "GET",
                    f"/v1/jobs/{job_id}/events?after={cursor}&limit=200",
                    timeout=15,
                )
                for event in events:
                    cursor = max(cursor, int(event["seq"]))
                    if event["type"] == "stage":
                        data = event["data"]
                        description = data.get("message") or f"{data.get('name', 'AutoGenBook')}: {data.get('status', 'běží')}"
                        description = str(description)[:500]
                        if description != last_description:
                            last_description = description
                            await self._emit_status(__event_emitter__, description)
                    elif event["type"] == "error":
                        await self._emit_status(__event_emitter__, str(event["data"].get("message") or "Chyba"))
                progress = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}/progress")
                if user_valves.SHOW_PROGRESS:
                    description = str(progress.get("message") or progress.get("stage") or "AutoGenBook běží.")[:500]
                    await self._emit_status(
                        __event_emitter__,
                        f"{float(progress.get('progress', 0)):.1f} % — {description}",
                        progress=float(progress.get("progress", 0)),
                    )
                job = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}")
                if job["status"] in TERMINAL_STATUSES:
                    break
                await asyncio.sleep(max(self.valves.POLL_INTERVAL_SECONDS, user_valves.PROGRESS_INTERVAL_SECONDS))

            job = await self._api(bridge, owner_id, "GET", f"/v1/jobs/{job_id}")
            if job["status"] not in TERMINAL_STATUSES:
                await self._emit_status(
                    __event_emitter__,
                    f"Úloha {job_id[:8]} pokračuje v lokálním Companionu.",
                    done=True,
                )
                return (
                    f"Generování bylo spuštěno jako úloha `{job_id}` a stále běží.\n\n"
                    f"{summary}\n\n"
                    f"Kontrola: `stav {job_id}`  \\n"
                    f"Zrušení: `zruš {job_id}`  \\n"
                    f"Výstupy po dokončení: `výstupy {job_id}`"
                )

            if job["status"] == "SUCCEEDED":
                artifacts, skipped = await self._attach_artifacts(
                    bridge, owner_id, job_id, user, __event_emitter__
                )
                await self._emit_status(__event_emitter__, "AutoGenBook dokončen.", done=True)
                primary = [item for item in artifacts if item["role"] in {"primary", "bundle"}]
                lines = [
                    f"AutoGenBook úloha `{job_id}` byla dokončena.",
                    "",
                    "Hlavní výstupy:",
                    *[
                        (
                            f"- [{item['filename']}]({item['persistent_url']}) ({item['size']} B)"
                            if item.get("persistent_url")
                            else f"- `{item['filename']}` ({item['size']} B)"
                        )
                        for item in primary[:10]
                    ],
                ]
                if skipped:
                    lines.extend(["", "Poznámky k trvalému uložení:", *[f"- {item}" for item in skipped]])
                return "\n".join(lines)

            await self._emit_status(__event_emitter__, f"AutoGenBook skončil stavem {job['status']}.", done=True)
            error_text = str(job.get("error") or "bez podrobností")
            recovery = ""
            if "OPENWEBUI_AUTH" in error_text or "API klíč" in error_text:
                recovery = (
                    f"\n\nObnova: odešlete `pokračuj {job_id}`. AutoGenBook ověří nebo vyžádá nový "
                    "trvalý Open WebUI API klíč a použije existující vstupy i checkpointy."
                )
            return (
                f"Úloha `{job_id}` skončila stavem **{job['status']}**.\n\n"
                f"Chyba: {error_text}{recovery}\n\n"
                f"Částečné výstupy: `výstupy {job_id}`"
            )
        except Exception as exc:
            await self._emit_status(__event_emitter__, "AutoGenBook se nepodařilo spustit.", done=True)
            if self.valves.DEBUG:
                return f"AutoGenBook chyba: `{type(exc).__name__}: {exc}`"
            return f"AutoGenBook chyba: {exc}"

# Resolve postponed annotations of nested Valve models explicitly. Some Open WebUI
# loaders execute Function source through ``exec`` without first registering a
# conventional module object, which otherwise leaves ``Literal`` unresolved in
# Pydantic when UserValves is instantiated.
try:
    Pipe.Valves.model_rebuild(_types_namespace=globals())
    Pipe.UserValves.model_rebuild(_types_namespace=globals())
except Exception:
    pass

try:
    _agb_register_download_routes()
except Exception:
    pass
