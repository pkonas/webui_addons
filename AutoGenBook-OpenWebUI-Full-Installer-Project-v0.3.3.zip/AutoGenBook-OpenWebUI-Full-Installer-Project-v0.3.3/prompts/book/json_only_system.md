Return ONLY valid JSON.
