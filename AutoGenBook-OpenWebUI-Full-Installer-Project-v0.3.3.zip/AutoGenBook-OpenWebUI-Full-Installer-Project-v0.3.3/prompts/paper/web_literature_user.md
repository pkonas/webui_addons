Input:
{prompt}
