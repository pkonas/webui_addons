from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from typing import Any

import pytest

from autogenbook_companion.key_file import (
    ApiKeyFileError,
    clear_file_reference,
    read_api_key_file,
    set_file_reference,
)
from autogenbook_companion.security import SecretStore

ROOT = Path(__file__).resolve().parents[1]


def load_installer():
    path = ROOT / "installer" / "install.py"
    spec = importlib.util.spec_from_file_location("autogenbook_installer_api_key_file_test", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_api_key_txt_accepts_utf8_bom_assignment_and_bearer(tmp_path: Path) -> None:
    assignment = tmp_path / "openwebui key.txt"
    assignment.write_bytes("\ufeff# comment\nOPENWEBUI_API_KEY='sk-persistent-file-key'\n".encode("utf-8"))
    loaded = read_api_key_file(
        assignment,
        require_txt_suffix=True,
        reject_session_token=True,
    )
    assert loaded.value == "sk-persistent-file-key"
    assert loaded.path == assignment.resolve()

    bearer = tmp_path / "bearer.txt"
    bearer.write_text("Authorization: Bearer sk-second-key\n", encoding="utf-8")
    assert read_api_key_file(bearer).value == "sk-second-key"


def test_api_key_txt_rejects_empty_multiple_binary_and_session_token(tmp_path: Path) -> None:
    empty = tmp_path / "empty.txt"
    empty.write_text("# comment only\n", encoding="utf-8")
    with pytest.raises(ApiKeyFileError, match="neplatný|zadán"):
        read_api_key_file(empty)

    multiple = tmp_path / "multiple.txt"
    multiple.write_text("sk-one-key\nsk-another-key\n", encoding="utf-8")
    with pytest.raises(ApiKeyFileError, match="více různých"):
        read_api_key_file(multiple)

    binary = tmp_path / "binary.txt"
    binary.write_bytes(b"sk-key\x00binary")
    with pytest.raises(ApiKeyFileError, match="binární"):
        read_api_key_file(binary)

    session = tmp_path / "session.txt"
    session.write_text("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.c2lnbmF0dXJl\n", encoding="utf-8")
    with pytest.raises(ApiKeyFileError, match="session/JWT"):
        read_api_key_file(session, reject_session_token=True)


def test_installer_persists_only_live_file_reference(tmp_path: Path) -> None:
    installer = load_installer()
    install_dir = tmp_path / "AutoGenBook OpenWebUI"
    module_dir = install_dir / "companion" / "src" / "autogenbook_companion"
    module_dir.mkdir(parents=True)
    (module_dir / "key_file.py").write_bytes(
        (ROOT / "companion" / "src" / "autogenbook_companion" / "key_file.py").read_bytes()
    )
    key_file = tmp_path / "persistent key.txt"
    key = "sk-key-must-never-be-persisted"
    key_file.write_text(key + "\n", encoding="utf-8")

    loaded_key, source = installer.configure_api_key_file_reference(install_dir, key_file)
    assert loaded_key == key
    assert source["path"] == str(key_file.resolve())
    config_path = install_dir / "data" / "secrets" / "external-secret-sources.json"
    raw = config_path.read_text(encoding="utf-8")
    assert key not in raw
    payload = json.loads(raw)
    assert payload["sources"]["openwebui_api_key"]["path"] == str(key_file.resolve())
    assert payload["sources"]["openwebui_api_key"]["read_mode"] == "live"
    assert payload["sources"]["openwebui_api_key"]["priority"] == "external_first"
    assert source["priority"] == "external_first"


def test_secret_store_reads_rotation_live_and_per_user_override_wins(tmp_path: Path) -> None:
    secret_root = tmp_path / "secrets"
    key_file = tmp_path / "key.txt"
    key_file.write_text("sk-first-live-key\n", encoding="utf-8")
    set_file_reference(secret_root, "openwebui_api_key", key_file, configured_by="pytest")

    store = SecretStore(secret_root)
    store._keyring = None
    first = store.resolve("owner-a", "openwebui_api_key")
    assert first.value == "sk-first-live-key"
    assert first.source == "external_text_file"

    key_file.write_text("sk-rotated-live-key\n", encoding="utf-8")
    assert store.get("owner-a", "openwebui_api_key") == "sk-rotated-live-key"

    store.set("owner-a", "openwebui_api_key", "sk-per-user-override")
    assert store.resolve("owner-a", "openwebui_api_key").source == "stored_per_user"
    assert store.get("owner-a", "openwebui_api_key") == "sk-per-user-override"
    assert store.get("owner-b", "openwebui_api_key") == "sk-rotated-live-key"

    store.delete("owner-a", "openwebui_api_key")
    assert store.get("owner-a", "openwebui_api_key") == "sk-rotated-live-key"



def test_installer_external_first_reference_overrides_stale_per_user_secret(tmp_path: Path) -> None:
    installer = load_installer()
    install_dir = tmp_path / "AutoGenBook OpenWebUI"
    module_dir = install_dir / "companion" / "src" / "autogenbook_companion"
    module_dir.mkdir(parents=True)
    (module_dir / "key_file.py").write_bytes(
        (ROOT / "companion" / "src" / "autogenbook_companion" / "key_file.py").read_bytes()
    )
    key_file = tmp_path / "authoritative-key.txt"
    key_file.write_text("sk-authoritative-file-key\n", encoding="utf-8")
    installer.configure_api_key_file_reference(install_dir, key_file)

    store = SecretStore(install_dir / "data" / "secrets")
    store._keyring = None
    store.set("owner-a", "openwebui_api_key", "sk-stale-per-user-key")
    resolution = store.resolve("owner-a", "openwebui_api_key")
    assert resolution.source == "external_text_file"
    assert resolution.value == "sk-authoritative-file-key"

    key_file.write_text("sk-rotated-authoritative-key\n", encoding="utf-8")
    assert store.get("owner-a", "openwebui_api_key") == "sk-rotated-authoritative-key"


def test_missing_referenced_file_has_actionable_resolution_error(tmp_path: Path) -> None:
    secret_root = tmp_path / "secrets"
    key_file = tmp_path / "key.txt"
    key_file.write_text("sk-valid-at-configuration-time\n", encoding="utf-8")
    set_file_reference(secret_root, "openwebui_api_key", key_file)
    key_file.unlink()

    store = SecretStore(secret_root)
    store._keyring = None
    resolution = store.resolve("owner", "openwebui_api_key")
    assert resolution.value is None
    assert resolution.source == "external_text_file"
    assert resolution.reference_path == str(key_file.resolve())
    assert resolution.error and "neexistuje" in resolution.error


def test_installer_record_never_contains_api_key_value(tmp_path: Path) -> None:
    installer = load_installer()
    install_dir = tmp_path / "installed"
    install_dir.mkdir()
    source = {
        "type": "text_file_reference",
        "path": str((tmp_path / "key.txt").resolve()),
        "read_mode": "live",
    }
    validation = {"valid": True, "endpoint": "/api/models", "model_count": 3}
    installer.write_install_record(
        install_dir,
        {"url": "http://127.0.0.1:8765", "token_file": "token-file"},
        api_key_source=source,
        api_key_validation=validation,
    )
    raw = (install_dir / "installation.json").read_text(encoding="utf-8")
    assert "sk-secret" not in raw
    assert source["path"] in raw
    assert json.loads(raw)["openwebui_api_key_validation"]["model_count"] == 3


def test_installer_api_key_file_cli_alias_and_environment_contract(monkeypatch: pytest.MonkeyPatch) -> None:
    installer = load_installer()
    parsed = installer.parser().parse_args(["--api-key-file", "C:/keys/openwebui.txt"])
    assert parsed.api_key_file == "C:/keys/openwebui.txt"
    parsed_admin = installer.parser().parse_args(["--admin-api-key", "Bearer sk-admin-test-key"])
    assert parsed_admin.api_key == "Bearer sk-admin-test-key"
    source = Path(ROOT / "installer" / "install.py").read_text(encoding="utf-8")
    assert "OPENWEBUI_API_KEY_FILE" in source
    assert "--require-api-key-validation" in source


def test_openwebui_key_validation_uses_model_endpoint_without_returning_key(monkeypatch: pytest.MonkeyPatch) -> None:
    installer = load_installer()
    calls: list[tuple[str, str]] = []

    def fake_api_request(
        base_url: str,
        api_key: str,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        timeout: float = 20.0,
    ) -> tuple[int, Any]:
        calls.append((api_key, path))
        return 200, [{"id": "e-infra.glm-5"}]

    monkeypatch.setattr(installer, "api_request", fake_api_request)
    result = installer.validate_openwebui_api_key("http://127.0.0.1:8080", "sk-not-in-result")
    assert result["valid"] is True
    assert result["model_count"] == 1
    assert "sk-not-in-result" not in json.dumps(result)
    assert calls == [("sk-not-in-result", "/api/models")]


def test_live_openwebui_reference_rejects_jwt_after_rotation(tmp_path: Path) -> None:
    secret_root = tmp_path / "secrets"
    key_file = tmp_path / "key.txt"
    key_file.write_text("sk-valid-personal-key\n", encoding="utf-8")
    set_file_reference(secret_root, "openwebui_api_key", key_file)
    store = SecretStore(secret_root)
    store._keyring = None
    assert store.get("owner", "openwebui_api_key") == "sk-valid-personal-key"

    key_file.write_text(
        "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.c2lnbmF0dXJl\n",
        encoding="utf-8",
    )
    resolution = store.resolve("owner", "openwebui_api_key")
    assert resolution.value is None
    assert resolution.source == "external_text_file"
    assert resolution.error and "session/JWT" in resolution.error


def test_clear_live_reference_does_not_delete_source_file(tmp_path: Path) -> None:
    secret_root = tmp_path / "secrets"
    key_file = tmp_path / "key.txt"
    key_file.write_text("sk-stays-on-disk\n", encoding="utf-8")
    set_file_reference(secret_root, "openwebui_api_key", key_file)
    assert clear_file_reference(secret_root, "openwebui_api_key") is True
    assert key_file.exists()
    store = SecretStore(secret_root)
    store._keyring = None
    assert store.get("owner", "openwebui_api_key") is None


def test_secret_store_can_atomically_rotate_authoritative_external_file(tmp_path: Path) -> None:
    secret_root = tmp_path / "secrets"
    key_file = tmp_path / "openwebui-api-key.txt"
    key_file.write_text("sk-old-authoritative-key\n", encoding="utf-8")
    set_file_reference(
        secret_root,
        "openwebui_api_key",
        key_file,
        priority="external_first",
    )
    store = SecretStore(secret_root)
    store._keyring = None

    result = store.set_external("openwebui_api_key", "Bearer sk-new-authoritative-key")

    assert result.source == "external_text_file"
    assert result.reference_path == str(key_file.resolve())
    assert key_file.read_text(encoding="utf-8") == "sk-new-authoritative-key\n"
    assert store.get("owner", "openwebui_api_key") == "sk-new-authoritative-key"
