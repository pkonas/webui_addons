from __future__ import annotations

import importlib.util
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterator

import pytest

ROOT = Path(__file__).resolve().parents[1]


def load_installer():
    path = ROOT / "installer" / "install.py"
    spec = importlib.util.spec_from_file_location("autogenbook_installer_http_test", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class OpenWebUIMockHandler(BaseHTTPRequestHandler):
    server_version = "OpenWebUIMock/1"
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def _json(self, status: int, payload: Any) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)

    @property
    def state(self) -> dict[str, Any]:
        return self.server.state  # type: ignore[attr-defined]

    def _record(self, body: bytes = b"") -> None:
        self.state.setdefault("requests", []).append(
            {
                "method": self.command,
                "path": self.path,
                "authorization": self.headers.get("Authorization"),
                "content_type": self.headers.get("Content-Type"),
                "body": body,
            }
        )

    def do_GET(self) -> None:  # noqa: N802
        self._record()
        if self.path == "/api/version":
            self._json(200, {"version": "0.6.99"})
            return
        if self.path == "/api/models":
            if self.headers.get("Authorization") != "Bearer sk-admin-test-key":
                self._json(401, {"detail": "invalid token"})
            else:
                self._json(200, [{"id": "e-infra.glm-5"}])
            return
        if self.path == "/api/v1/functions/list":
            if self.headers.get("Authorization") != "Bearer sk-admin-test-key":
                self._json(403, {"detail": "admin required"})
            else:
                self._json(200, [])
            return
        if self.path == "/api/v1/functions/id/autogenbook_companion":
            # Open WebUI has historically used 401 for an authenticated lookup
            # of a Function ID that does not yet exist.
            self._json(401, {"detail": "not found"})
            return
        self._json(404, {"detail": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        self._record(body)
        if self.state.get("force_invalid_http") and self.path == "/api/v1/functions/create":
            raw = b"Invalid HTTP request received."
            self.send_response(400)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(raw)
            return
        if self.path == "/api/v1/functions/create":
            payload = json.loads(body.decode("utf-8"))
            assert payload["id"] == "autogenbook_companion"
            assert "Příklady" in payload["content"] or "AutoGenBook" in payload["content"]
            self._json(201, {"id": payload["id"], "is_active": False})
            return
        if self.path == "/api/v1/functions/id/autogenbook_companion/toggle":
            self._json(200, {"id": "autogenbook_companion", "is_active": True})
            return
        self._json(404, {"detail": "not found"})


@pytest.fixture
def openwebui_mock() -> Iterator[tuple[str, dict[str, Any]]]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), OpenWebUIMockHandler)
    server.state = {"requests": []}  # type: ignore[attr-defined]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[:2]
        yield f"http://{host}:{port}", server.state  # type: ignore[attr-defined]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_direct_key_normalization_accepts_common_forms_and_rejects_session_tokens() -> None:
    installer = load_installer()
    module = installer._load_key_file_module(ROOT)
    forms = (
        "sk-admin-test-key",
        "Bearer sk-admin-test-key",
        "Authorization: Bearer sk-admin-test-key",
        "OPENWEBUI_API_KEY='sk-admin-test-key'",
        '"sk-admin-test-key"',
    )
    for value in forms:
        assert module.normalize_api_key_text(value, reject_session_token=True) == "sk-admin-test-key"

    with pytest.raises(Exception, match="více různých"):
        module.normalize_api_key_text("sk-first-value\nsk-second-value", reject_session_token=True)
    with pytest.raises(Exception, match="session/JWT"):
        module.normalize_api_key_text(
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.c2lnbmF0dXJl",
            reject_session_token=True,
        )


def test_proxy_free_http_client_and_complete_function_registration(
    monkeypatch: pytest.MonkeyPatch,
    openwebui_mock: tuple[str, dict[str, Any]],
) -> None:
    installer = load_installer()
    base_url, state = openwebui_mock
    monkeypatch.setenv("HTTP_PROXY", "http://127.0.0.1:1")
    monkeypatch.setenv("HTTPS_PROXY", "http://127.0.0.1:1")
    monkeypatch.setenv("ALL_PROXY", "http://127.0.0.1:1")

    assert installer.is_openwebui_instance(base_url)
    result = installer.register_function(ROOT, base_url, "sk-admin-test-key")
    assert result["success"] is True
    assert result["action"] == "created"
    assert result["activated"] is True

    requests = state["requests"]
    assert any(row["path"] == "/api/v1/functions/list" for row in requests)
    create = next(row for row in requests if row["path"] == "/api/v1/functions/create")
    assert create["authorization"] == "Bearer sk-admin-test-key"
    assert create["content_type"].startswith("application/json")
    parsed = json.loads(create["body"].decode("utf-8"))
    assert parsed["content"].startswith('"""')
    assert "sk-admin-test-key" not in create["body"].decode("utf-8")


def test_low_level_http_400_becomes_safe_manual_import_fallback(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    openwebui_mock: tuple[str, dict[str, Any]],
) -> None:
    installer = load_installer()
    base_url, state = openwebui_mock
    state["force_invalid_http"] = True

    monkeypatch.setattr(
        installer,
        "start_companion",
        lambda install_dir, timeout=60.0: {"url": "http://127.0.0.1:9999"},
    )
    records: list[dict[str, Any]] = []

    def capture_record(install_dir: Path, bridge: dict[str, Any], **kwargs: Any) -> None:
        records.append({"install_dir": install_dir, "bridge": bridge, **kwargs})

    monkeypatch.setattr(installer, "write_install_record", capture_record)
    result = installer.main(
        [
            "--configure-only",
            "--install-dir",
            str(ROOT),
            "--openwebui-url",
            base_url,
            "--admin-api-key",
            "Authorization: Bearer sk-admin-test-key",
            "--non-interactive",
        ]
    )
    assert result == 0
    captured = capsys.readouterr()
    assert "manual" in (captured.out + captured.err).casefold()
    assert "Installation completed" in captured.out
    assert records
    registration = records[-1]["function_registration"]
    assert registration["success"] is False
    assert registration["manual_import_required"] is True
    serialized = json.dumps(records, ensure_ascii=False, default=str)
    assert "sk-admin-test-key" not in serialized


def test_strict_registration_mode_still_fails_for_ci(
    monkeypatch: pytest.MonkeyPatch,
    openwebui_mock: tuple[str, dict[str, Any]],
) -> None:
    installer = load_installer()
    base_url, state = openwebui_mock
    state["force_invalid_http"] = True
    monkeypatch.setattr(
        installer,
        "start_companion",
        lambda install_dir, timeout=60.0: {"url": "http://127.0.0.1:9999"},
    )
    monkeypatch.setattr(installer, "write_install_record", lambda *args, **kwargs: None)
    with pytest.raises(RuntimeError, match="registration failed"):
        installer.main(
            [
                "--configure-only",
                "--install-dir",
                str(ROOT),
                "--openwebui-url",
                base_url,
                "--admin-api-key",
                "sk-admin-test-key",
                "--require-function-registration",
                "--non-interactive",
            ]
        )


def test_non_admin_key_skips_automatic_registration_without_breaking_install(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    openwebui_mock: tuple[str, dict[str, Any]],
) -> None:
    installer = load_installer()
    base_url, _ = openwebui_mock
    monkeypatch.setattr(
        installer,
        "start_companion",
        lambda install_dir, timeout=60.0: {"url": "http://127.0.0.1:9999"},
    )
    records: list[dict[str, Any]] = []
    monkeypatch.setattr(
        installer,
        "write_install_record",
        lambda install_dir, bridge, **kwargs: records.append(kwargs),
    )
    assert (
        installer.main(
            [
                "--configure-only",
                "--install-dir",
                str(ROOT),
                "--openwebui-url",
                base_url,
                "--admin-api-key",
                "sk-personal-not-admin",
                "--non-interactive",
            ]
        )
        == 0
    )
    captured = capsys.readouterr()
    assert "administrator" in (captured.out + captured.err).casefold()
    assert records[-1]["function_registration"]["manual_import_required"] is True
