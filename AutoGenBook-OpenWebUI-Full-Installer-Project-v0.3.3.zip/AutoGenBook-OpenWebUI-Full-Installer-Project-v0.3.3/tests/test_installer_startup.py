from __future__ import annotations

import importlib.util
import json
import os
import shutil
import signal
import subprocess
import time
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
INSTALLER_PATH = ROOT / "installer" / "install.py"


def load_installer():
    spec = importlib.util.spec_from_file_location("autogenbook_installer_under_test", INSTALLER_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stop_process(pid: int) -> None:
    if pid <= 0:
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return
    try:
        os.killpg(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            return
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return
        time.sleep(0.05)


def test_source_layout_and_pythonpath_are_detected(tmp_path: Path) -> None:
    installer = load_installer()
    (tmp_path / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    companion_src = tmp_path / "companion" / "src"
    companion_src.mkdir(parents=True)

    assert installer.resolve_source_dir(tmp_path) == tmp_path.resolve()
    env = installer.bundled_environment(tmp_path)
    pythonpath = env["PYTHONPATH"].split(os.pathsep)
    assert str(companion_src.resolve()) in pythonpath
    assert env["AUTOGENBOOK_SOURCE_DIR"] == str(tmp_path.resolve())


def test_packaged_app_layout_has_priority(tmp_path: Path) -> None:
    installer = load_installer()
    (tmp_path / "main.py").write_text("root = True\n", encoding="utf-8")
    app = tmp_path / "app"
    app.mkdir()
    (app / "main.py").write_text("packaged = True\n", encoding="utf-8")
    assert installer.resolve_source_dir(tmp_path) == app.resolve()


def test_wait_for_bridge_reports_process_log(tmp_path: Path) -> None:
    installer = load_installer()
    log = tmp_path / "companion.log"
    log.write_text("ModuleNotFoundError: No module named autogenbook_companion\n", encoding="utf-8")
    process = subprocess.Popen(
        [os.fspath(Path(os.sys.executable)), "-c", "raise SystemExit(7)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    process.wait(timeout=10)
    with pytest.raises(RuntimeError) as exc_info:
        installer.wait_for_bridge(tmp_path, process=process, log_path=log, timeout=2)
    message = str(exc_info.value)
    assert "exit code 7" in message
    assert "ModuleNotFoundError" in message


def test_installer_starts_companion_from_source_layout(tmp_path: Path) -> None:
    installer = load_installer()
    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    shutil.copytree(ROOT / "companion", source / "companion")
    # Companion imports the lightweight KB1 quality gate at service startup.
    # A source-layout fixture must therefore represent the real full project,
    # not only the companion package and a placeholder main.py.
    core_package = source / "autogenbook"
    core_package.mkdir()
    shutil.copy2(ROOT / "autogenbook" / "__init__.py", core_package / "__init__.py")
    shutil.copy2(ROOT / "autogenbook" / "state.py", core_package / "state.py")
    shutil.copy2(ROOT / "autogenbook" / "paths.py", core_package / "paths.py")
    shutil.copy2(
        ROOT / "autogenbook" / "reviewer_kb1_quality.py",
        core_package / "reviewer_kb1_quality.py",
    )
    install_dir = tmp_path / "installed source with spaces"
    installer.copy_payload(source, install_dir)

    bridge: dict[str, object] = {}
    try:
        bridge = installer.start_companion(install_dir, timeout=25)
        assert Path(str(bridge["source_dir"])) == install_dir.resolve()
        token = Path(str(bridge["token_file"])).read_text(encoding="utf-8").strip()
        request = urllib.request.Request(
            f"{str(bridge['url']).rstrip('/')}/v1/health",
            headers={"Authorization": f"Bearer {token}"},
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            health = json.loads(response.read().decode("utf-8"))
        assert response.status == 200
        assert health["status"] == "ok"
        assert health["autogenbook_available"] is True
    finally:
        stop_process(int(bridge.get("pid", 0) or 0))
