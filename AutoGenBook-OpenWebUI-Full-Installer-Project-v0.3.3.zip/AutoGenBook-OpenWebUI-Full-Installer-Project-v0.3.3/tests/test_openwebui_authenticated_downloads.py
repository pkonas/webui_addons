from __future__ import annotations

import hashlib
import importlib.util
import sys
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tests.test_openwebui_persistent_artifacts import (  # noqa: E402
    _Files,
    _Record,
    fake_openwebui_modules,
)


def load_pipe_module(tag: str = "default"):
    path = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"
    spec = importlib.util.spec_from_file_location(f"autogenbook_pipe_capability_{tag}", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _build_app(module: Any) -> FastAPI:
    app = FastAPI()

    # Reproduce Open WebUI's SPA catch-all being present before a Function is
    # hot-loaded. AutoGenBook routes must be moved in front of it.
    @app.get("/{path:path}", name="spa-static-files")
    async def spa(path: str) -> HTMLResponse:
        return HTMLResponse(f"SPA:{path}")

    assert module._agb_register_download_routes(app) is True
    names = [getattr(route, "name", "") for route in app.router.routes]
    assert names.index("autogenbook-download-capability-v033") < names.index("spa-static-files")
    assert names.index("autogenbook-download-landing-v033") < names.index("spa-static-files")
    assert names.index("autogenbook-download-ticket-v033") < names.index("spa-static-files")
    assert names.index("autogenbook-download-stream-v033") < names.index("spa-static-files")
    return app


def _record(tmp_path: Path, payload: bytes, *, user_id: str = "user-1") -> _Record:
    path = tmp_path / "artifact.bin"
    path.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    record = _Record(
        id="file-123",
        user_id=user_id,
        filename="výsledek.bin",
        path=str(path),
        hash=digest,
        data={"status": "completed", "content": "download card"},
        meta={
            "name": "výsledek.bin",
            "content_type": "application/octet-stream",
            "size": len(payload),
            "file_hash": digest,
        },
    )
    _Files.rows[record.id] = record
    return record


def _capability_url(module: Any, record: _Record) -> str:
    return module._agb_capability_path(
        record.id,
        record.user_id,
        file_hash=record.hash,
        size=record.meta["size"],
    )


def test_capability_download_is_direct_and_requires_no_browser_auth(tmp_path: Path) -> None:
    module = load_pipe_module("direct")
    payload = b"private AutoGenBook bytes"
    with fake_openwebui_modules(tmp_path):
        record = _record(tmp_path, payload)
        app = _build_app(module)
        url = _capability_url(module, record)
        assert url.startswith("/api/autogenbook/download/")
        assert "download-ticket" not in url
        assert "localStorage" not in url
        with TestClient(app) as client:
            response = client.get(url)
    assert response.status_code == 200
    assert response.content == payload
    assert response.headers["content-disposition"].startswith("attachment;")
    assert response.headers["accept-ranges"] == "bytes"
    assert response.headers["x-content-type-options"] == "nosniff"


def test_capability_survives_function_reload_with_stable_webui_secret(tmp_path: Path) -> None:
    payload = b"stable across reloads"
    with fake_openwebui_modules(tmp_path):
        first = load_pipe_module("reload_first")
        record = _record(tmp_path, payload)
        url = _capability_url(first, record)

        # A Function reload creates a new module and a new in-memory cache.  The
        # URL must still validate because its signing key derives from the stable
        # Open WebUI secret, not a process-random value.
        second = load_pipe_module("reload_second")
        app = _build_app(second)
        with TestClient(app) as client:
            response = client.get(url)
    assert response.status_code == 200
    assert response.content == payload


def test_capability_supports_head_ranges_if_range_and_rejects_tampering(tmp_path: Path) -> None:
    module = load_pipe_module("ranges")
    payload = bytes(range(256)) * 128
    with fake_openwebui_modules(tmp_path):
        record = _record(tmp_path, payload)
        app = _build_app(module)
        url = _capability_url(module, record)
        with TestClient(app) as client:
            full = client.get(url)
            assert full.status_code == 200
            assert full.content == payload
            assert full.headers["content-length"] == str(len(payload))
            etag = full.headers["etag"]

            head = client.head(url)
            assert head.status_code == 200
            assert head.content == b""
            assert head.headers["content-length"] == str(len(payload))

            partial = client.get(url, headers={"Range": "bytes=10-29"})
            assert partial.status_code == 206
            assert partial.content == payload[10:30]
            assert partial.headers["content-range"] == f"bytes 10-29/{len(payload)}"
            assert partial.headers["content-length"] == "20"

            suffix = client.get(url, headers={"Range": "bytes=-16"})
            assert suffix.status_code == 206
            assert suffix.content == payload[-16:]

            if_range = client.get(
                url, headers={"Range": "bytes=0-9", "If-Range": '"different"'}
            )
            assert if_range.status_code == 200
            assert if_range.content == payload

            matching_if_range = client.get(
                url, headers={"Range": "bytes=0-9", "If-Range": etag}
            )
            assert matching_if_range.status_code == 206
            assert matching_if_range.content == payload[:10]

            invalid = client.get(url, headers={"Range": f"bytes={len(payload)}-"})
            assert invalid.status_code == 416
            assert invalid.headers["content-range"] == f"bytes */{len(payload)}"

            tampered = url[:-1] + ("A" if url[-1] != "A" else "B")
            assert client.get(tampered).status_code == 401

            # The capability is tied to the immutable file identity. Replacing
            # the owner, hash or declared size invalidates an old URL.
            record.user_id = "user-2"
            assert client.get(url).status_code == 404
            record.user_id = "user-1"
            record.hash = hashlib.sha256(b"different").hexdigest()
            assert client.get(url).status_code == 404


def test_legacy_v032_broker_paths_fail_with_actionable_410(tmp_path: Path) -> None:
    module = load_pipe_module("legacy")
    with fake_openwebui_modules(tmp_path):
        _record(tmp_path, b"abc")
        app = _build_app(module)
        with TestClient(app) as client:
            landing = client.get("/api/autogenbook/files/file-123/download")
            ticket = client.post("/api/autogenbook/download-ticket", json={"file_id": "file-123"})
            stream = client.get("/api/autogenbook/download-stream/obsolete")
    assert landing.status_code == 410
    assert "výstupy ID_ÚLOHY" in landing.text
    assert ticket.status_code == 410
    assert stream.status_code == 410


def test_download_route_registration_is_idempotent_and_removes_v032_routes(tmp_path: Path) -> None:
    module = load_pipe_module("idempotent")
    with fake_openwebui_modules(tmp_path):
        app = _build_app(module)
        assert module._agb_register_download_routes(app) is True
        names = [getattr(route, "name", "") for route in app.router.routes]
        assert names.count("autogenbook-download-capability-v033") == 1
        assert names.count("autogenbook-download-landing-v033") == 1
        assert names.count("autogenbook-download-ticket-v033") == 1
        assert names.count("autogenbook-download-stream-v033") == 1
        assert not any(name.endswith("v032") for name in names if name.startswith("autogenbook-"))
