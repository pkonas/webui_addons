from __future__ import annotations

import os
import re
import sys
import types
from pathlib import Path

from packaging.requirements import Requirement

ROOT = Path(__file__).resolve().parents[1]
PIPE = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"


def extract_openwebui_frontmatter(content: str) -> dict[str, str]:
    """Mirror Open WebUI's line-oriented frontmatter parser."""
    result: dict[str, str] = {}
    lines = content.splitlines()
    if not lines or lines[0].strip() != '"""':
        return result
    pattern = re.compile(r"^\s*([a-z_]+):\s*(.*)\s*$", re.IGNORECASE)
    for line in lines[1:]:
        if '"""' in line:
            break
        match = pattern.match(line)
        if match:
            key, value = match.groups()
            result[key.strip()] = value.strip()
    return result


def test_frontmatter_does_not_generate_invalid_pip_arguments() -> None:
    content = PIPE.read_text(encoding="utf-8-sig")
    frontmatter = extract_openwebui_frontmatter(content)
    raw = frontmatter.get("requirements", "")
    tokens = [token.strip() for token in raw.split(",") if token.strip()]
    for token in tokens:
        Requirement(token)
    # The Pipe uses packages already bundled with Open WebUI, so importing it must
    # never trigger a network/pip installation in the host application's Python.
    assert tokens == []


def test_pipe_loads_and_exposes_dynamic_model_selector(monkeypatch) -> None:
    content = PIPE.read_text(encoding="utf-8-sig")
    module = types.ModuleType("function_autogenbook_companion_regression")
    module.__file__ = str(PIPE)
    sys.modules[module.__name__] = module
    try:
        exec(compile(content, str(PIPE), "exec"), module.__dict__)
    finally:
        # Keep the module registered while Pydantic resolves postponed annotations.
        pass

    pipe_class = module.Pipe
    instance = pipe_class()
    assert instance.id == "autogenbook"
    schema = pipe_class.UserValves.model_json_schema()["properties"]["LLM_MODEL"]
    assert schema["default"] == "e-infra.glm-5"
    assert schema["input"]["type"] == "select"
    assert schema["input"]["options"] == "get_model_options"

    monkeypatch.setenv("OPENWEBUI_MODELS", "e-infra.glm-5,local.test-model")
    options = pipe_class.UserValves.get_model_options()
    values = {row["value"] for row in options}
    assert "e-infra.glm-5" in values
    assert "local.test-model" in values
    sys.modules.pop(module.__name__, None)
