from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "companion" / "src"))


def load_pipe_module():
    path = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"
    spec = importlib.util.spec_from_file_location("autogenbook_pipe_v6", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_openwebui_model_valve_is_dynamic_select(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENWEBUI_MODELS", "local.llama,e-infra.glm-5,autogenbook.book")
    module = load_pipe_module()
    field = module.Pipe.UserValves.model_fields["LLM_MODEL"]
    assert field.default == "e-infra.glm-5"
    assert field.json_schema_extra == {
        "input": {"type": "select", "options": "get_model_options"}
    }
    options = module.Pipe.UserValves.get_model_options()
    values = [row["value"] for row in options]
    assert values[0] == "e-infra.glm-5"
    assert "local.llama" in values
    assert all("autogenbook" not in value.casefold() for value in values)


def test_pipe_caches_models_from_openwebui_request() -> None:
    module = load_pipe_module()
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                MODELS={
                    "e-infra.glm-5": {"id": "e-infra.glm-5", "name": "GLM-5"},
                    "company.model": {"id": "company.model", "name": "Company Model"},
                    "arena": {"id": "arena", "arena": True},
                },
                BASE_MODELS=[],
            )
        )
    )
    module._cache_request_models(request, {})
    values = [row["value"] for row in module.Pipe.UserValves.get_model_options()]
    assert "company.model" in values
    assert "arena" not in values


def test_runner_propagates_selected_model(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from autogenbook_companion.config import Settings
    from autogenbook_companion.database import Database
    from autogenbook_companion.models import Mode, ProjectSpec, ProviderProfile
    from autogenbook_companion.runner import AutoGenBookRunner
    from autogenbook_companion.security import SecretStore

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source, max_hash_bytes=1024)
    settings.ensure_layout()
    database = Database(settings.database_path)
    database.init()
    secrets = SecretStore(settings.secrets_dir)
    secrets.set("owner", "openwebui_api_key", "secret-value")
    runner = AutoGenBookRunner(settings, database, secrets)
    spec = ProjectSpec(
        mode=Mode.book,
        brief="test",
        provider=ProviderProfile(
            type="openwebui",
            base_url="http://127.0.0.1:8080/api",
            model="company.model",
            api_key_secret="openwebui_api_key",
        ),
    )
    env, redacted = runner._build_env("owner", spec)
    assert env["AUTOGENBOOK_FORCE_MODEL"] == "company.model"
    assert env["AUTOGENBOOK_LLM_MODEL"] == "company.model"
    assert env["OPENWEBUI_MODEL"] == "company.model"
    assert env["AUTOGENBOOK_LLM_BASE_URL"] == "http://127.0.0.1:8080/api"
    assert env["AUTOGENBOOK_LLM_API_KEY"] == "secret-value"
    assert "secret-value" in redacted


def test_openrouter_client_forces_job_model(monkeypatch: pytest.MonkeyPatch) -> None:
    import types

    monkeypatch.setenv("AUTOGENBOOK_FORCE_MODEL", "company.model")
    fake_openai = types.ModuleType("openai")
    fake_openai.OpenAI = object
    monkeypatch.setitem(sys.modules, "openai", fake_openai)
    import openrouter_llm

    assert openrouter_llm._selected_job_model("historical.default") == "company.model"


def test_progress_is_atomic_and_persistent(tmp_path: Path) -> None:
    from autogenbook_companion.progress import ProgressTracker, load_progress

    tracker = ProgressTracker(tmp_path / "progress.json", job_id="job-1", model="e-infra.glm-5")
    tracker.update(status="RUNNING", stage="content", progress=25, message="Kapitola 1/4")
    tracker.from_line("Kapitola 2/4", stage="content")
    payload = load_progress(tmp_path / "progress.json")
    assert payload is not None
    assert payload["job_id"] == "job-1"
    assert payload["model"] == "e-infra.glm-5"
    assert payload["progress"] > 25
    assert payload["current"] == 2
    assert payload["total"] == 4
    assert payload["heartbeat_at"]


def test_signed_resumable_large_download_and_progress(tmp_path: Path) -> None:
    from autogenbook_companion.config import Settings
    from autogenbook_companion.database import Database
    from autogenbook_companion.models import Mode, ProjectSpec, ProviderProfile
    from autogenbook_companion.progress import ProgressTracker
    from autogenbook_companion.security import SecretStore, owner_storage_key
    from autogenbook_companion.service import create_app

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source, max_hash_bytes=1024)
    settings.ensure_layout()
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "user-a",
    }

    with TestClient(app) as client:
        project_response = client.post(
            "/v1/projects",
            headers=headers,
            json={
                "spec": ProjectSpec(
                    mode=Mode.book,
                    brief="Test",
                    provider=ProviderProfile(
                        type="openai_compatible",
                        base_url="http://localhost:1234/v1",
                        model="e-infra.glm-5",
                        api_key_secret="local",
                    ),
                ).model_dump(mode="json")
            },
        )
        assert project_response.status_code == 201, project_response.text
        project_id = project_response.json()["id"]
        job_response = client.post(
            "/v1/jobs",
            headers=headers,
            json={"project_id": project_id, "idempotency_key": "test-user-a-job-0001"},
        )
        assert job_response.status_code == 201, job_response.text
        job_id = job_response.json()["id"]

        root = settings.projects_dir / owner_storage_key("user-a") / project_id / job_id
        output = root / "output"
        output.mkdir(parents=True)
        large = output / "large-output.bin"
        with large.open("wb") as stream:
            stream.seek(16 * 1024 * 1024 - 1)
            stream.write(b"X")
        with large.open("r+b") as stream:
            stream.seek(1024)
            stream.write(bytes(range(100)))

        tracker = ProgressTracker(root / ".autogenbook-progress.json", job_id=job_id, model="e-infra.glm-5")
        tracker.update(status="RUNNING", stage="content", progress=61, message="Rendering 6/10")

        database = Database(settings.database_path)
        database.add_artifact(
            job_id=job_id,
            owner_id="user-a",
            filename=large.name,
            path=str(large),
            mime="application/octet-stream",
            size=large.stat().st_size,
            sha256="",
            role="primary",
        )

        progress = client.get(f"/v1/jobs/{job_id}/progress", headers=headers)
        assert progress.status_code == 200, progress.text
        assert progress.json()["progress"] == 61
        assert progress.json()["model"] == "e-infra.glm-5"

        listed = client.get(f"/v1/jobs/{job_id}/artifacts", headers=headers)
        assert listed.status_code == 200, listed.text
        row = listed.json()[0]
        assert row["supports_resume"] is True
        assert row["download_url"]

        path = urlsplit(row["download_url"])
        relative_url = path.path + ("?" + path.query if path.query else "")
        response = client.get(relative_url, headers={"Range": "bytes=1024-1123"})
        assert response.status_code == 206, response.text
        assert response.headers["accept-ranges"] == "bytes"
        assert response.headers["content-range"] == f"bytes 1024-1123/{16 * 1024 * 1024}"
        assert response.content == bytes(range(100))

        head = client.head(relative_url)
        assert head.status_code == 200
        assert int(head.headers["content-length"]) == 16 * 1024 * 1024
        assert head.content == b""

        invalid = client.get(relative_url, headers={"Range": "bytes=999999999-1000000000"})
        assert invalid.status_code == 416
        assert invalid.headers["content-range"] == f"bytes */{16 * 1024 * 1024}"

        unauthorized = client.get(f"/v1/jobs/{job_id}/artifacts")
        assert unauthorized.status_code == 401
