from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
import threading
import types
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "companion" / "src"))


def load_pipe_module():
    path = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"
    spec = importlib.util.spec_from_file_location("autogenbook_pipe_persistent_files", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class _Record:
    def __init__(self, **payload: Any) -> None:
        self.__dict__.update(payload)

    def model_dump(self, *, exclude: set[str] | None = None) -> dict[str, Any]:
        result = dict(self.__dict__)
        for key in exclude or set():
            result.pop(key, None)
        return result


class _FileForm:
    def __init__(self, **payload: Any) -> None:
        self.payload = payload


class _Files:
    rows: dict[str, _Record] = {}

    @classmethod
    async def get_file_by_id(cls, file_id: str) -> _Record | None:
        return cls.rows.get(file_id)

    @classmethod
    async def insert_new_file(cls, user_id: str, form: _FileForm) -> _Record | None:
        payload = dict(form.payload)
        payload["user_id"] = user_id
        record = _Record(**payload)
        cls.rows[record.id] = record
        return record

    @classmethod
    async def update_file_data_by_id(cls, file_id: str, data: dict[str, Any]) -> _Record | None:
        record = cls.rows.get(file_id)
        if record is None:
            return None
        record.data = {**(getattr(record, "data", {}) or {}), **data}
        return record

    @classmethod
    async def delete_file_by_id(cls, file_id: str) -> bool:
        return cls.rows.pop(file_id, None) is not None


class _Storage:
    @staticmethod
    def get_file(path: str) -> str:
        return path


@contextmanager
def fake_openwebui_modules(tmp_path: Path) -> Iterator[None]:
    saved = {name: sys.modules.get(name) for name in list(sys.modules) if name == "open_webui" or name.startswith("open_webui.")}
    for name in list(saved):
        sys.modules.pop(name, None)
    _Files.rows = {}

    open_webui = types.ModuleType("open_webui")
    open_webui.__path__ = []  # type: ignore[attr-defined]
    config = types.ModuleType("open_webui.config")
    config.STORAGE_PROVIDER = "local"
    config.STORAGE_LOCAL_CACHE = True
    config.UPLOAD_DIR = tmp_path / "openwebui-uploads"
    env = types.ModuleType("open_webui.env")
    env.WEBUI_SECRET_KEY = "unit-test-openwebui-secret"
    env.DATA_DIR = tmp_path / "openwebui-data"
    models = types.ModuleType("open_webui.models")
    models.__path__ = []  # type: ignore[attr-defined]
    files = types.ModuleType("open_webui.models.files")
    files.FileForm = _FileForm
    files.Files = _Files
    storage = types.ModuleType("open_webui.storage")
    storage.__path__ = []  # type: ignore[attr-defined]
    provider = types.ModuleType("open_webui.storage.provider")
    provider.Storage = _Storage()

    utils = types.ModuleType("open_webui.utils")
    utils.__path__ = []  # type: ignore[attr-defined]
    auth = types.ModuleType("open_webui.utils.auth")

    async def get_current_user(
        request: Any,
        response: Any = None,
        background_tasks: Any = None,
        auth_token: Any = None,
    ) -> SimpleNamespace:
        token = getattr(auth_token, "credentials", None)
        if token is None:
            token = request.cookies.get("token")
        if token == "browser-token":
            return SimpleNamespace(id="user-1", role="user")
        if token == "other-token":
            return SimpleNamespace(id="user-2", role="user")
        if token == "admin-token":
            return SimpleNamespace(id="admin-1", role="admin")
        raise HTTPException(status_code=401, detail="Not authenticated")

    def get_http_authorization_cred(header: str):
        from fastapi.security import HTTPAuthorizationCredentials

        if not header.lower().startswith("bearer "):
            return None
        return HTTPAuthorizationCredentials(
            scheme="Bearer", credentials=header.split(None, 1)[1].strip()
        )

    auth.get_current_user = get_current_user
    auth.get_http_authorization_cred = get_http_authorization_cred

    access_control = types.ModuleType("open_webui.utils.access_control")
    access_control.__path__ = []  # type: ignore[attr-defined]
    access_files = types.ModuleType("open_webui.utils.access_control.files")

    async def has_access_to_file(
        _file_id: str, _permission: str, _user: Any, **_kwargs: Any
    ) -> bool:
        return False

    access_files.has_access_to_file = has_access_to_file

    modules = {
        "open_webui": open_webui,
        "open_webui.config": config,
        "open_webui.env": env,
        "open_webui.models": models,
        "open_webui.models.files": files,
        "open_webui.storage": storage,
        "open_webui.storage.provider": provider,
        "open_webui.utils": utils,
        "open_webui.utils.auth": auth,
        "open_webui.utils.access_control": access_control,
        "open_webui.utils.access_control.files": access_files,
    }
    sys.modules.update(modules)
    try:
        yield
    finally:
        for name in modules:
            sys.modules.pop(name, None)
        for name, module in saved.items():
            if module is not None:
                sys.modules[name] = module


@contextmanager
def artifact_server(payload: bytes) -> Iterator[tuple[str, dict[str, int]]]:
    state = {"requests": 0, "bytes": 0}

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def do_GET(self) -> None:  # noqa: N802
            state["requests"] += 1
            if self.path != "/v1/artifacts/artifact-1/download":
                self.send_error(404)
                return
            if self.headers.get("Authorization") != "Bearer companion-secret":
                self.send_error(401)
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            for start in range(0, len(payload), 32 * 1024):
                chunk = payload[start : start + 32 * 1024]
                self.wfile.write(chunk)
                self.wfile.flush()
                state["bytes"] += len(chunk)

        def log_message(self, _format: str, *_args: object) -> None:
            return

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", state
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_large_output_is_streamed_to_durable_openwebui_file_and_is_idempotent(tmp_path: Path) -> None:
    module = load_pipe_module()
    pipe = module.Pipe()
    pipe.valves.ATTACH_MAX_BYTES = 1024 * 1024  # old code would skip the artifact
    pipe.valves.PERSIST_OUTPUT_MAX_BYTES = 0
    pipe.valves.OUTPUT_COPY_CHUNK_BYTES = 64 * 1024
    payload = (bytes(range(256)) * 8192) + b"durable-autogenbook-output"
    artifact = {
        "id": "artifact-1",
        "job_id": "job-1",
        "filename": "large-result.bin",
        "mime": "application/octet-stream",
        "size": len(payload),
        "sha256": "",
        "role": "primary",
        "download_url": "http://temporary.invalid/?expires=1&signature=old",
    }
    events: list[dict[str, Any]] = []

    async def emitter(event: dict[str, Any]) -> None:
        events.append(event)

    async def fake_api(
        _bridge: dict[str, Any],
        _owner: str,
        method: str,
        path: str,
        **_kwargs: Any,
    ) -> Any:
        assert method == "GET"
        assert path == "/v1/jobs/job-1/artifacts"
        return [dict(artifact)]

    pipe._api = fake_api  # type: ignore[method-assign]
    user = {"id": "user-1", "name": "Tester", "email": "tester@example.test"}
    with fake_openwebui_modules(tmp_path), artifact_server(payload) as (base_url, state):
        module._AGB_PUBLIC_ORIGIN.set("http://testserver")
        bridge = {"url": base_url, "token": "companion-secret"}
        published, skipped = asyncio.run(
            pipe._attach_artifacts(bridge, "user-1", "job-1", user, emitter)
        )
        assert skipped == []
        assert len(published) == 1
        row = published[0]
        assert row["download_url_kind"] == "openwebui_capability_v1"
        assert row["persistent_url"].startswith(
            "http://testserver/api/autogenbook/download/"
        )
        assert row["persistent_path"].startswith("/api/autogenbook/download/")
        assert "expires=" not in row["persistent_url"]
        assert "/api/v1/files/" not in row["persistent_url"]
        assert "download-ticket" not in row["persistent_url"]
        assert "companion-secret" not in row["persistent_url"]
        assert row["temporary_download_url"].startswith("http://temporary.invalid/")
        assert state == {"requests": 1, "bytes": len(payload)}
        assert len(_Files.rows) == 1
        stored = next(iter(_Files.rows.values()))
        assert Path(stored.path).read_bytes() == payload
        file_events = [event for event in events if event.get("type") == "files"]
        assert file_events
        chat_file = file_events[-1]["data"]["files"][0]
        # This is the real Open WebUI assistant-file contract.  ResponseMessage
        # silently filters entries that do not declare type=file/image.
        assert chat_file["type"] == "file"
        assert chat_file["status"] == "uploaded"
        assert chat_file["id"] == row["openwebui_file_id"]
        assert chat_file["url"] == row["persistent_url"]
        assert chat_file["persistent_url"] == row["persistent_url"]
        assert chat_file["download_url"] == row["persistent_url"]
        assert chat_file["name"] == "large-result.bin"
        assert chat_file["size"] == len(payload)
        assert chat_file["content_type"] == "application/octet-stream"
        assert chat_file["file"]["id"] == row["openwebui_file_id"]
        assert "No content" not in chat_file["file"]["data"]["content"]
        assert row["persistent_path"] in chat_file["file"]["data"]["content"]
        assert "Stáhnout" in chat_file["file"]["data"]["content"]
        assert [f for f in file_events[-1]["data"]["files"] if f.get("type") in {"file", "image"}]
        assert row["openwebui_registration_verified"] is True

        # A later `výstupy` request reuses the same deterministic Open WebUI file.
        # Simulate a 0.3.1 row whose binary bytes exist but whose text preview
        # was missing and therefore rendered as Open WebUI's "No content".
        stored.data = {"status": "completed"}
        published_again, skipped_again = asyncio.run(
            pipe._attach_artifacts(bridge, "user-1", "job-1", user, emitter)
        )
        assert skipped_again == []
        assert published_again[0]["openwebui_file_id"] == row["openwebui_file_id"]
        assert "Stáhnout" in stored.data["content"]
        assert row["persistent_path"] in stored.data["content"]
        assert state["requests"] == 1
        assert len(_Files.rows) == 1


def test_output_command_uses_only_persistent_openwebui_links(tmp_path: Path) -> None:
    module = load_pipe_module()
    pipe = module.Pipe()
    payload = b"persistent report"
    artifact = {
        "id": "artifact-1",
        "job_id": "job-1",
        "filename": "report.pdf",
        "mime": "application/pdf",
        "size": len(payload),
        "sha256": "",
        "role": "primary",
        "download_url": "http://temporary.invalid/download?expires=1&signature=old",
    }

    async def fake_api(
        _bridge: dict[str, Any],
        _owner: str,
        method: str,
        path: str,
        **_kwargs: Any,
    ) -> Any:
        if path == "/v1/jobs/job-1":
            return {"id": "job-1", "status": "SUCCEEDED"}
        if path == "/v1/jobs/job-1/progress":
            return {"progress": 100, "message": "done"}
        if path == "/v1/jobs/job-1/artifacts":
            return [dict(artifact)]
        raise AssertionError((method, path))

    pipe._api = fake_api  # type: ignore[method-assign]
    with fake_openwebui_modules(tmp_path), artifact_server(payload) as (base_url, _state):
        module._AGB_PUBLIC_ORIGIN.set("http://testserver")
        text = asyncio.run(
            pipe._job_command(
                "artifacts",
                "job-1",
                {"url": base_url, "token": "companion-secret"},
                "user-1",
                {"id": "user-1"},
                None,
            )
        )
    assert "http://testserver/api/autogenbook/download/" in text
    assert "/api/autogenbook/download/" in text
    assert "/api/v1/files/" not in text
    assert "temporary.invalid" not in text
    assert "signature=" not in text


def _create_artifact_fixture(tmp_path: Path):
    from autogenbook_companion.config import Settings
    from autogenbook_companion.database import Database
    from autogenbook_companion.models import Mode, ProjectSpec, ProviderProfile
    from autogenbook_companion.security import owner_storage_key
    from autogenbook_companion.service import create_app

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source, max_hash_bytes=1024)
    settings.ensure_layout()
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "user-a",
    }
    with TestClient(app) as client:
        project = client.post(
            "/v1/projects",
            headers=headers,
            json={
                "spec": ProjectSpec(
                    mode=Mode.book,
                    brief="Test",
                    provider=ProviderProfile(
                        type="openai_compatible",
                        base_url="http://localhost:1234/v1",
                        model="e-infra.glm-5",
                        api_key_secret="local",
                    ),
                ).model_dump(mode="json")
            },
        ).json()
        job = client.post(
            "/v1/jobs",
            headers=headers,
            json={"project_id": project["id"], "idempotency_key": "persistent-link-test"},
        ).json()
    root = settings.projects_dir / owner_storage_key("user-a") / project["id"] / job["id"]
    output = root / "output"
    output.mkdir(parents=True)
    path = output / "report.bin"
    path.write_bytes(b"companion fallback")
    database = Database(settings.database_path)
    database.add_artifact(
        job_id=job["id"],
        owner_id="user-a",
        filename=path.name,
        path=str(path),
        mime="application/octet-stream",
        size=path.stat().st_size,
        sha256="",
        role="primary",
    )
    return settings, job["id"], headers, create_app


def test_expired_signed_link_returns_410_instead_of_invalid_companion_token(tmp_path: Path) -> None:
    from autogenbook_companion.database import Database
    from autogenbook_companion.service import _download_signature

    settings, job_id, headers, create_app = _create_artifact_fixture(tmp_path)
    database = Database(settings.database_path)
    artifact_id = database.list_artifacts(job_id, "user-a")[0]["id"]
    expired = 1
    signature = _download_signature(
        settings.get_or_create_download_signing_key(), artifact_id, "user-a", expired
    )
    app = create_app(settings, start_workers=False)
    with TestClient(app) as client:
        response = client.get(
            f"/v1/artifacts/{artifact_id}/download?owner=user-a&expires={expired}&signature={signature}"
        )
    assert response.status_code == 410
    assert "expired" in response.json()["detail"].casefold()
    assert "invalid companion token" not in response.text.casefold()
    # Bearer API access remains available and separate.
    with TestClient(create_app(settings, start_workers=False)) as client:
        assert client.get(f"/v1/jobs/{job_id}/artifacts", headers=headers).status_code == 200


def test_unexpired_signed_link_survives_companion_bearer_token_rotation(tmp_path: Path) -> None:
    settings, job_id, headers, create_app = _create_artifact_fixture(tmp_path)
    app_before = create_app(settings, start_workers=False)
    with TestClient(app_before) as client:
        listed = client.get(f"/v1/jobs/{job_id}/artifacts", headers=headers)
        assert listed.status_code == 200
        relative = urlsplit(listed.json()[0]["download_url"])
        signed_path = relative.path + "?" + relative.query

    assert settings.api_token_file is not None
    settings.api_token_file.write_text("rotated-companion-bearer-token\n", encoding="utf-8")
    app_after = create_app(settings, start_workers=False)
    with TestClient(app_after) as client:
        response = client.get(signed_path)
    assert response.status_code == 200
    assert response.content == b"companion fallback"


def test_temporary_companion_link_is_not_exposed_when_native_registration_is_unavailable() -> None:
    module = load_pipe_module()
    pipe = module.Pipe()
    pipe.valves.PERSIST_OUTPUTS_TO_OPENWEBUI = False
    artifact = {
        "id": "artifact-fallback",
        "job_id": "job-fallback",
        "filename": "fallback.zip",
        "mime": "application/zip",
        "size": 123,
        "sha256": "",
        "role": "bundle",
        "download_url": "http://127.0.0.1:54321/v1/artifacts/artifact-fallback/download?expires=999&signature=fresh",
    }

    async def fake_api(
        _bridge: dict[str, Any],
        _owner: str,
        method: str,
        path: str,
        **_kwargs: Any,
    ) -> Any:
        assert method == "GET"
        assert path == "/v1/jobs/job-fallback/artifacts"
        return [dict(artifact)]

    pipe._api = fake_api  # type: ignore[method-assign]
    published, skipped = asyncio.run(
        pipe._attach_artifacts(
            {"url": "http://127.0.0.1:1", "token": "unused"},
            "user-1",
            "job-fallback",
            {"id": "user-1"},
            None,
            include_all=True,
        )
    )
    assert published == []
    assert skipped
    assert "nezveřejňuje" in skipped[0].casefold()
