from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "companion" / "src"))


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = json.dumps(payload, ensure_ascii=False)

    def json(self) -> Any:
        return self._payload


class _FakeClient:
    def __init__(self, handler) -> None:
        self._handler = handler

    async def get(self, url: str, *, headers: dict[str, str]) -> _FakeResponse:
        result = self._handler(url, headers)
        if asyncio.iscoroutine(result):
            result = await result
        return result


def _store(tmp_path: Path):
    from autogenbook_companion.security import SecretStore

    store = SecretStore(tmp_path / "secrets")
    # Keep tests independent of the host's desktop keyring implementation.
    store._keyring = None
    return store


def _provider(model: str = "e-infra.glm-5"):
    from autogenbook_companion.models import ProviderProfile

    return ProviderProfile(
        type="openwebui",
        base_url="http://127.0.0.1:8080/api",
        model=model,
        api_key_secret="openwebui_api_key",
    )


def test_session_jwt_is_rejected_before_network(tmp_path: Path) -> None:
    from autogenbook_companion.service import validate_provider_profile

    store = _store(tmp_path)
    store.set("owner", "openwebui_api_key", "eyJhbGciOi.test.signature")

    async def run() -> Any:
        def handler(_: str, __: dict[str, str]) -> _FakeResponse:
            raise AssertionError("A browser session token must be rejected before any network request")

        return await validate_provider_profile(_provider(), store, "owner", client=_FakeClient(handler))

    result = asyncio.run(run())
    assert result.valid is False
    assert result.code == "SESSION_TOKEN_NOT_ALLOWED"
    assert result.auth_kind == "session_token"


def test_persistent_openwebui_api_key_and_model_are_validated(tmp_path: Path) -> None:
    from autogenbook_companion.service import validate_provider_profile

    store = _store(tmp_path)
    store.set("owner", "openwebui_api_key", "sk-persistent-test-key")

    async def run() -> Any:
        def handler(url: str, headers: dict[str, str]) -> _FakeResponse:
            assert url.endswith("/api/models")
            assert headers["Authorization"] == "Bearer sk-persistent-test-key"
            return _FakeResponse(
                200,
                {"data": [{"id": "e-infra.glm-5"}, {"id": "e-infra.other"}]},
            )

        return await validate_provider_profile(_provider(), store, "owner", client=_FakeClient(handler))

    result = asyncio.run(run())
    assert result.valid is True
    assert result.code == "OK"
    assert result.auth_kind == "openwebui_api_key"
    assert result.model_available is True
    assert "e-infra.glm-5" in result.available_models


def test_openwebui_401_is_reported_as_recoverable_credential_error(tmp_path: Path) -> None:
    from autogenbook_companion.service import validate_provider_profile

    store = _store(tmp_path)
    store.set("owner", "openwebui_api_key", "sk-revoked")

    async def run() -> Any:
        def handler(_: str, __: dict[str, str]) -> _FakeResponse:
            return _FakeResponse(
                401,
                {"detail": "Your session has expired or the token is invalid. Please sign in again."},
            )

        return await validate_provider_profile(_provider(), store, "owner", client=_FakeClient(handler))

    result = asyncio.run(run())
    assert result.valid is False
    assert result.code == "AUTH_INVALID"
    assert result.http_status == 401
    assert "API klíč" in result.message


def _load_pipe_module():
    path = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"
    spec = importlib.util.spec_from_file_location("autogenbook_pipe_auth_test", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_pipe_replaces_invalid_secret_with_persistent_key() -> None:
    module = _load_pipe_module()
    pipe = module.Pipe()
    calls: list[tuple[str, str, dict[str, Any] | None]] = []
    validation_count = 0

    async def fake_api(
        bridge: dict[str, Any],
        owner_id: str,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        nonlocal validation_count
        calls.append((method, path, json_body))
        if path == "/v1/providers/validate":
            validation_count += 1
            if validation_count == 1:
                return {
                    "valid": False,
                    "code": "AUTH_INVALID",
                    "message": "invalid",
                }
            return {"valid": True, "code": "OK", "message": "ok"}
        return None

    prompts: list[dict[str, Any]] = []

    async def event_call(payload: dict[str, Any]) -> dict[str, str]:
        prompts.append(payload)
        return {"value": "sk-new-persistent-key"}

    pipe._api = fake_api  # type: ignore[method-assign]
    provider = {
        "type": "openwebui",
        "base_url": "http://127.0.0.1:8080/api",
        "model": "e-infra.glm-5",
        "api_key_secret": "openwebui_api_key",
        "role_models": {},
    }
    asyncio.run(pipe._ensure_provider_ready({"url": "x", "token": "y"}, "owner", provider, event_call))

    assert prompts
    assert "několik dnů" in prompts[0]["data"]["message"]
    put = next(row for row in calls if row[0] == "PUT")
    assert put[1] == "/v1/secrets/openwebui_api_key"
    assert put[2] == {"value": "sk-new-persistent-key", "target": "stored_per_user"}
    assert validation_count == 2


def test_pipe_rejects_session_jwt_and_accepts_second_key() -> None:
    module = _load_pipe_module()
    pipe = module.Pipe()
    stored: list[str] = []

    async def fake_api(
        bridge: dict[str, Any],
        owner_id: str,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        if path == "/v1/providers/validate":
            return {"valid": bool(stored), "code": "OK" if stored else "MISSING_SECRET", "message": "missing"}
        if method == "PUT" and json_body:
            stored.append(str(json_body["value"]))
        return None

    values = iter(["eyJhbGciOi.test.signature", "sk-persistent"])

    async def event_call(_: dict[str, Any]) -> dict[str, str]:
        return {"value": next(values)}

    pipe._api = fake_api  # type: ignore[method-assign]
    provider = {
        "type": "openwebui",
        "base_url": "http://127.0.0.1:8080/api",
        "model": "e-infra.glm-5",
        "api_key_secret": "openwebui_api_key",
        "role_models": {},
    }
    asyncio.run(pipe._ensure_provider_ready({"url": "x", "token": "y"}, "owner", provider, event_call))
    assert stored == ["sk-persistent"]


def test_runner_classifies_worker_401_with_resume_instruction() -> None:
    from autogenbook_companion.runner import AutoGenBookRunner

    code, message = AutoGenBookRunner._classify_worker_failure(
        2,
        [
            "[REVIEWER] prompt1: using default",
            "Error: LLM2 reviewer call failed: Error code: 401 - session has expired or token is invalid",
        ],
        "openwebui",
        "23e18c2a-a871-4abe-bfb4-541fbeafebb4",
    )
    assert code == "OPENWEBUI_AUTH_INVALID"
    assert "pokračuj 23e18c2a-a871-4abe-bfb4-541fbeafebb4" in message


def _load_installer():
    path = ROOT / "installer" / "install.py"
    spec = importlib.util.spec_from_file_location("autogenbook_installer_data_test", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_installer_update_preserves_existing_data_without_copying(tmp_path: Path) -> None:
    installer = _load_installer()
    source = tmp_path / "source"
    target = tmp_path / "AutoGenBook OpenWebUI"
    source.mkdir()
    target.mkdir()
    (source / "main.py").write_text("new = True\n", encoding="utf-8")
    (source / "version.txt").write_text("0.2.3\n", encoding="utf-8")
    data = target / "data" / "projects" / "owner" / "job"
    data.mkdir(parents=True)
    marker = data / "large-output.marker"
    marker.write_text("must survive update", encoding="utf-8")
    (target / "version.txt").write_text("0.2.2\n", encoding="utf-8")

    installer.copy_payload(source, target)

    assert (target / "version.txt").read_text(encoding="utf-8").strip() == "0.2.3"
    assert (target / "data" / "projects" / "owner" / "job" / marker.name).read_text(encoding="utf-8") == "must survive update"
    assert not (target.with_name(target.name + ".previous") / "data").exists()


def test_job_scoped_openwebui_key_outranks_ambient_openrouter_key(monkeypatch: pytest.MonkeyPatch) -> None:
    import openrouter_llm

    monkeypatch.setenv("AUTOGENBOOK_PROVIDER_TYPE", "openwebui")
    monkeypatch.setenv("AUTOGENBOOK_CREDENTIAL_ISOLATION", "provider-aware-v1")
    monkeypatch.setenv("AUTOGENBOOK_LLM_API_KEY", "sk-correct-openwebui-key")
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-wrong-openrouter-key")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-wrong-openai-key")

    assert (
        openrouter_llm._selected_api_key("sk-explicit-but-not-job-key", "openwebui")
        == "sk-correct-openwebui-key"
    )


def test_job_scoped_openwebui_base_url_outranks_role_override(monkeypatch: pytest.MonkeyPatch) -> None:
    import openrouter_llm

    monkeypatch.setenv("AUTOGENBOOK_CREDENTIAL_ISOLATION", "provider-aware-v1")
    monkeypatch.setenv("AUTOGENBOOK_LLM_BASE_URL", "http://127.0.0.1:8080/api")
    assert (
        openrouter_llm._selected_base_url("https://ambient-role-override.example/v1")
        == "http://127.0.0.1:8080/api"
    )


def test_openrouter_llm_constructs_openwebui_client_with_isolated_job_key(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import openrouter_llm

    captured: dict[str, Any] = {}

    class FakeOpenAI:
        def __init__(self, *, api_key: str, base_url: str, default_headers: Any = None) -> None:
            captured.update(
                api_key=api_key,
                base_url=base_url,
                default_headers=default_headers,
            )

    monkeypatch.setattr(openrouter_llm, "OpenAI", FakeOpenAI)
    monkeypatch.setenv("AUTOGENBOOK_PROVIDER_TYPE", "openwebui")
    monkeypatch.setenv("AUTOGENBOOK_CREDENTIAL_ISOLATION", "provider-aware-v1")
    monkeypatch.setenv("AUTOGENBOOK_LLM_API_KEY", "sk-correct-openwebui-key")
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-wrong-openrouter-key")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-wrong-openai-key")
    monkeypatch.setenv("AUTOGENBOOK_LLM_BASE_URL", "http://127.0.0.1:8080/api")
    monkeypatch.setenv("AUTOGENBOOK_LLM_MODEL", "e-infra.glm-5")

    client = openrouter_llm.OpenRouterLLM(openrouter_llm.LLMConfig())
    assert client.base_url == "http://127.0.0.1:8080/api"
    assert captured["api_key"] == "sk-correct-openwebui-key"
    assert captured["base_url"] == "http://127.0.0.1:8080/api"


def test_runner_scrubs_inherited_provider_credentials_and_records_fingerprint(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from autogenbook_companion.config import Settings
    from autogenbook_companion.database import Database
    from autogenbook_companion.models import ProjectSpec
    from autogenbook_companion.runner import AutoGenBookRunner

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source)
    settings.ensure_layout()
    database = Database(settings.database_path)
    database.init()
    store = _store(tmp_path)
    store.set("owner", "openwebui_api_key", "sk-authoritative-job-key")

    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-ambient-wrong")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-ambient-wrong-openai")
    monkeypatch.setenv("OPENROUTER_BASE_URL", "https://wrong.example/v1")
    monkeypatch.setenv("OPENAI_BASE_URL", "https://wrong.example/v1")
    monkeypatch.setenv("AUTOGENBOOK_FORCE_MINI_MODEL", "1")

    runner = AutoGenBookRunner(settings, database, store)
    env, hidden = runner._build_env("owner", ProjectSpec(mode="book", brief="test", provider=_provider()))

    assert env["AUTOGENBOOK_LLM_API_KEY"] == "sk-authoritative-job-key"
    assert env["OPENAI_API_KEY"] == "sk-authoritative-job-key"
    assert "OPENROUTER_API_KEY" not in env
    assert "AUTOGENBOOK_FORCE_MINI_MODEL" not in env
    assert env["AUTOGENBOOK_LLM_BASE_URL"] == "http://127.0.0.1:8080/api"
    assert env["OPENAI_BASE_URL"] == "http://127.0.0.1:8080/api"
    assert env["AUTOGENBOOK_CREDENTIAL_ISOLATION"] == "provider-aware-v1"
    assert len(env["AUTOGENBOOK_LLM_KEY_FINGERPRINT"]) == 16
    assert env["AUTOGENBOOK_LLM_KEY_FINGERPRINT"] != "sk-authoritative-job-key"
    assert hidden == ["sk-authoritative-job-key"]


def test_pipe_updates_authoritative_txt_reference_instead_of_ignored_override() -> None:
    module = _load_pipe_module()
    pipe = module.Pipe()
    calls: list[tuple[str, str, dict[str, Any] | None]] = []
    validation_count = 0

    async def fake_api(
        bridge: dict[str, Any],
        owner_id: str,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        nonlocal validation_count
        calls.append((method, path, json_body))
        if path == "/v1/providers/validate":
            validation_count += 1
            return (
                {"valid": False, "code": "AUTH_INVALID", "message": "invalid"}
                if validation_count == 1
                else {"valid": True, "code": "OK", "message": "ok"}
            )
        if path.endswith("/status"):
            return {
                "exists": True,
                "source": "external_text_file",
                "reference_path": "C:/Secrets/openwebui-api-key.txt",
            }
        return None

    async def event_call(payload: dict[str, Any]) -> dict[str, str]:
        assert "atomicky zapsána" in payload["data"]["message"]
        return {"value": "sk-rotated-file-key"}

    pipe._api = fake_api  # type: ignore[method-assign]
    provider = {
        "type": "openwebui",
        "base_url": "http://127.0.0.1:8080/api",
        "model": "e-infra.glm-5",
        "api_key_secret": "openwebui_api_key",
        "role_models": {},
    }
    asyncio.run(pipe._ensure_provider_ready({"url": "x", "token": "y"}, "owner", provider, event_call))

    put = next(row for row in calls if row[0] == "PUT")
    assert put[2] == {
        "value": "sk-rotated-file-key",
        "target": "external_text_file",
    }
    assert validation_count == 2
