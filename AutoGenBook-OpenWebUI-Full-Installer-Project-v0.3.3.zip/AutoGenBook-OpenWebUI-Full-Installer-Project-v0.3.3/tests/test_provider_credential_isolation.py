from __future__ import annotations

import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "companion" / "src"))


def test_worker_preflight_uses_exact_job_scoped_key(monkeypatch: pytest.MonkeyPatch) -> None:
    from autogenbook_companion import worker_entry

    captured: dict[str, Any] = {}

    class FakeResponse:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *_: object) -> None:
            return None

        def read(self) -> bytes:
            return json.dumps({"data": [{"id": "e-infra.glm-5"}]}).encode("utf-8")

    class FakeOpener:
        def open(self, request, timeout: float):
            captured["authorization"] = request.get_header("Authorization")
            captured["url"] = request.full_url
            captured["timeout"] = timeout
            return FakeResponse()

    monkeypatch.setattr(worker_entry, "build_opener", lambda *_: FakeOpener())
    monkeypatch.setenv("AUTOGENBOOK_PROVIDER_TYPE", "openwebui")
    monkeypatch.setenv("AUTOGENBOOK_LLM_MODEL", "e-infra.glm-5")
    monkeypatch.setenv("AUTOGENBOOK_LLM_BASE_URL", "http://127.0.0.1:8080/api")
    monkeypatch.setenv("AUTOGENBOOK_LLM_API_KEY", "sk-exact-job-key")
    monkeypatch.setenv("AUTOGENBOOK_LLM_KEY_FINGERPRINT", "0123456789abcdef")
    monkeypatch.setenv("AUTOGENBOOK_LLM_SECRET_SOURCE", "external_text_file")
    monkeypatch.setenv("AUTOGENBOOK_CREDENTIAL_ISOLATION", "provider-aware-v1")
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-ambient-wrong-key")

    worker_entry._preflight_selected_provider()

    assert captured["authorization"] == "Bearer sk-exact-job-key"
    assert captured["url"] == "http://127.0.0.1:8080/api/models"
    assert os.environ["OPENROUTER_API_KEY"] == "sk-ambient-wrong-key"


def test_worker_preflight_real_loopback_transport_uses_exact_key(monkeypatch: pytest.MonkeyPatch) -> None:
    from autogenbook_companion import worker_entry

    captured: dict[str, str] = {}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - stdlib callback name
            captured["path"] = self.path
            captured["authorization"] = self.headers.get("Authorization", "")
            payload = json.dumps({"data": [{"id": "e-infra.glm-5"}]}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, *_: object) -> None:
            return None

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        monkeypatch.setenv("AUTOGENBOOK_PROVIDER_TYPE", "openwebui")
        monkeypatch.setenv("AUTOGENBOOK_LLM_MODEL", "e-infra.glm-5")
        monkeypatch.setenv(
            "AUTOGENBOOK_LLM_BASE_URL",
            f"http://127.0.0.1:{server.server_address[1]}/api",
        )
        monkeypatch.setenv("AUTOGENBOOK_LLM_API_KEY", "sk-real-loopback-job-key")
        monkeypatch.setenv("AUTOGENBOOK_LLM_KEY_FINGERPRINT", "1122334455667788")
        monkeypatch.setenv("AUTOGENBOOK_LLM_SECRET_SOURCE", "external_text_file")
        monkeypatch.setenv("AUTOGENBOOK_CREDENTIAL_ISOLATION", "provider-aware-v1")
        monkeypatch.setenv("OPENROUTER_API_KEY", "sk-ambient-must-not-be-used")

        worker_entry._preflight_selected_provider()
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    assert captured == {
        "path": "/api/models",
        "authorization": "Bearer sk-real-loopback-job-key",
    }


def test_worker_preflight_failure_stops_before_autogenbook_import(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from autogenbook_companion import worker_entry

    source = tmp_path / "source"
    source.mkdir()
    marker = tmp_path / "main-imported.marker"
    (source / "main.py").write_text(
        f"from pathlib import Path\nPath({str(marker)!r}).write_text('imported')\n"
        "def main(argv=None): return 0\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("AUTOGENBOOK_SOURCE_DIR", str(source))
    monkeypatch.setattr(
        worker_entry,
        "_preflight_selected_provider",
        lambda: (_ for _ in ()).throw(RuntimeError("PROVIDER_AUTH_INVALID: test")),
    )
    previous = Path.cwd()
    try:
        code = worker_entry.main([])
    finally:
        os.chdir(previous)

    assert code == 2
    assert not marker.exists()
