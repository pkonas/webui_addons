from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "companion" / "src"))


def load_pipe_module():
    path = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"
    spec = importlib.util.spec_from_file_location("autogenbook_pipe_kb1_test", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_settings(tmp_path: Path):
    from autogenbook_companion.config import Settings

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source, max_hash_bytes=1024)
    settings.ensure_layout()
    return settings


def reviewer_spec(*, allow_missing: bool = False) -> dict[str, Any]:
    return {
        "mode": "reviewer",
        "brief": "Vypracuj odborný posudek závěrečné práce.",
        "language": "cs",
        "outputs": {"formats": ["md", "zip"], "attach_primary_to_chat": True},
        "provider": {
            "type": "openai_compatible",
            "base_url": "http://localhost:1234/v1",
            "model": "e-infra.glm-5",
            "api_key_secret": "local",
            "role_models": {},
        },
        "options": {
            "reviewer_allow_missing_kb1": allow_missing,
            "reviewer_kb1_policy": "allow_without_kb1" if allow_missing else "ask_or_search",
        },
        "metadata": {},
    }


def test_reviewer_filename_role_recognizes_czech_regulations() -> None:
    module = load_pipe_module()
    infer = module.Pipe._infer_file_role
    assert infer("Smernice_hodnoceni_zaverecnych_praci.pdf", "reviewer") == "kb1"
    assert infer("Vyhláška_kritéria_posudku.pdf", "reviewer") == "kb1"
    assert infer("thesis_diplomova_prace.pdf", "reviewer") == "kb2"


def test_reviewer_context_requires_jurisdiction_institution_and_work_type() -> None:
    module = load_pipe_module()
    context, missing = module.Pipe._parse_reviewer_context(
        "HLEDAT: země=ČR; instituce=VUT; fakulta=FAST; typ práce=diplomová práce"
    )
    assert not missing
    assert context["jurisdiction"] == "ČR"
    assert context["institution"] == "VUT"
    assert context["faculty"] == "FAST"
    assert context["work_type"] == "diplomová práce"

    _context, missing = module.Pipe._parse_reviewer_context("HLEDAT: instituce=VUT")
    assert "země / jurisdikce" in missing
    assert "typ závěrečné práce" in missing


def test_missing_kb1_is_validation_error_and_text_import_fixes_it(tmp_path: Path) -> None:
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    with TestClient(app) as client:
        created = client.post("/v1/projects", headers=headers, json={"spec": reviewer_spec()})
        assert created.status_code == 201, created.text
        project_id = created.json()["id"]
        uploaded = client.post(
            f"/v1/projects/{project_id}/files?role=kb2",
            headers=headers,
            files={"file": ("thesis.txt", b"Obsah zaverecne prace", "text/plain")},
        )
        assert uploaded.status_code == 201, uploaded.text

        validation = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert validation.status_code == 200, validation.text
        issues = validation.json()["issues"]
        assert any(row["code"] == "MISSING_REVIEWER_KB1" and row["severity"] == "error" for row in issues)

        imported = client.post(
            f"/v1/projects/{project_id}/reviewer/kb1/import",
            headers=headers,
            json={
                "source_type": "text",
                "value": "Posuzuje se splnění cíle, metodika, kvalita výsledků, práce se zdroji a formální úroveň.",
                "filename": "explicitni_kriteria.md",
                "provenance": {"provided_by": "user"},
            },
        )
        assert imported.status_code == 201, imported.text
        assert imported.json()["role"] == "kb1"

        validation = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert validation.status_code == 200, validation.text
        assert not [row for row in validation.json()["issues"] if row["severity"] == "error"]


def test_private_url_is_rejected_for_kb1_import(tmp_path: Path) -> None:
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    with TestClient(app) as client:
        created = client.post("/v1/projects", headers=headers, json={"spec": reviewer_spec()})
        project_id = created.json()["id"]
        response = client.post(
            f"/v1/projects/{project_id}/reviewer/kb1/import",
            headers=headers,
            json={"source_type": "url", "value": "http://127.0.0.1/private.pdf"},
        )
        assert response.status_code == 400
        assert "Soukromé" in response.text or "lokální" in response.text


def test_explicit_waiver_is_warning_not_silent(tmp_path: Path) -> None:
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    with TestClient(app) as client:
        created = client.post(
            "/v1/projects", headers=headers, json={"spec": reviewer_spec(allow_missing=True)}
        )
        project_id = created.json()["id"]
        uploaded = client.post(
            f"/v1/projects/{project_id}/files?role=kb2",
            headers=headers,
            files={"file": ("thesis.txt", b"Obsah zaverecne prace", "text/plain")},
        )
        assert uploaded.status_code == 201
        validation = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert validation.status_code == 200
        issues = validation.json()["issues"]
        assert any(row["code"] == "REVIEWER_KB1_EXPLICITLY_WAIVED" for row in issues)
        assert not [row for row in issues if row["severity"] == "error"]


def test_pipe_explicit_url_flow_requires_user_source(monkeypatch: pytest.MonkeyPatch) -> None:
    module = load_pipe_module()
    pipe = module.Pipe()
    calls: list[tuple[str, str, dict[str, Any] | None]] = []

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        calls.append((method, path, json_body))
        if path.endswith("/reviewer/kb1/import"):
            return {"filename": "official_rules.pdf", "role": "kb1"}
        if method == "PATCH":
            return {"id": "project-1"}
        return {}

    async def event_call(payload):
        assert payload["type"] == "input"
        return "URL: https://example.edu/official_rules.pdf"

    monkeypatch.setattr(pipe, "_api", fake_api)
    spec = {
        "language": "cs",
        "options": {},
        "provider": {"type": "openwebui", "model": "e-infra.glm-5"},
    }
    valves = pipe.UserValves(REVIEWER_KB1_POLICY="require_source")
    result = __import__("asyncio").run(
        pipe._ensure_reviewer_kb1({}, "owner", "project-1", spec, valves, event_call)
    )
    assert result == [("official_rules.pdf", "kb1")]
    import_call = next(row for row in calls if row[1].endswith("/reviewer/kb1/import"))
    assert import_call[2]["source_type"] == "url"
    assert import_call[2]["value"].startswith("https://")


def test_runner_adds_missing_kb1_override_only_when_explicit(tmp_path: Path) -> None:
    from autogenbook_companion.config import Settings
    from autogenbook_companion.database import Database
    from autogenbook_companion.models import Mode, ProjectSpec, ProviderProfile
    from autogenbook_companion.runner import AutoGenBookRunner
    from autogenbook_companion.security import SecretStore

    source = tmp_path / "source"
    source.mkdir()
    (source / "main.py").write_text("def main(argv=None): return 0\n", encoding="utf-8")
    settings = Settings(home=tmp_path / "home", source_dir=source)
    settings.ensure_layout()
    database = Database(settings.database_path)
    database.init()
    runner = AutoGenBookRunner(settings, database, SecretStore(settings.secrets_dir))
    spec = ProjectSpec(
        mode=Mode.reviewer,
        brief="review",
        provider=ProviderProfile(type="openai_compatible", base_url="http://localhost:1/v1", model="m"),
        options={"reviewer_allow_missing_kb1": True},
    )
    roles = {name: [] for name in ("input", "structure", "kb", "kb1", "kb2")}
    job_root = tmp_path / "job"
    out_dir = job_root / "output"
    job_root.mkdir(parents=True)
    out_dir.mkdir(parents=True)
    command = runner._build_command(
        spec=spec, roles=roles, job_root=job_root, out_dir=out_dir, resume=False
    )
    assert "--reviewer-allow-missing-kb1" in command
    spec.options["reviewer_allow_missing_kb1"] = False
    command = runner._build_command(
        spec=spec, roles=roles, job_root=job_root, out_dir=out_dir, resume=False
    )
    assert "--reviewer-allow-missing-kb1" not in command

def test_discovery_requests_openwebui_web_search_and_verifies_candidates(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import asyncio
    import json
    from autogenbook_companion import service
    from autogenbook_companion.models import (
        ProviderProfile,
        ProviderValidationResponse,
        ReviewerContext,
        ReviewerKb1DiscoveryRequest,
    )
    from autogenbook_companion.security import SecretResolution

    captured: dict[str, Any] = {}

    class FakeResponse:
        status = 200
        headers = {}
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def read(self):
            content = {
                "choices": [
                    {
                        "message": {
                            "content": json.dumps(
                                {
                                    "candidates": [
                                        {
                                            "title": "Směrnice pro závěrečné práce",
                                            "url": "https://www.vut.cz/uredni-deska/smernice.pdf",
                                            "source_name": "VUT",
                                            "document_type": "směrnice",
                                            "reason": "Upravuje hodnocení a obhajobu.",
                                        }
                                    ]
                                },
                                ensure_ascii=False,
                            )
                        }
                    }
                ]
            }
            return json.dumps(content, ensure_ascii=False).encode("utf-8")

    class FakeOpener:
        def open(self, request, timeout=0):
            captured["url"] = request.full_url
            captured["body"] = json.loads(request.data.decode("utf-8"))
            captured["authorization"] = request.headers.get("Authorization")
            return FakeResponse()

    class FakeSecretStore:
        def resolve(self, owner_id, name):
            return SecretResolution(value="sk-valid-test", source="stored_per_user")

    async def fake_validate(provider, secret_store, owner_id, client=None):
        return ProviderValidationResponse(
            valid=True,
            code="OK",
            message="ok",
            provider_type="openwebui",
            base_url=provider.base_url,
            model=provider.model,
            auth_kind="openwebui_api_key",
        )

    monkeypatch.setattr(service, "validate_provider_profile", fake_validate)
    monkeypatch.setattr(service, "build_opener", lambda *args, **kwargs: FakeOpener())
    monkeypatch.setattr(
        service,
        "_probe_public_source",
        lambda url: (True, url, "Směrnice pro závěrečné práce"),
    )
    response = asyncio.run(
        service.discover_reviewer_kb1_sources(
            ReviewerKb1DiscoveryRequest(
                context=ReviewerContext(
                    jurisdiction="ČR",
                    institution="VUT",
                    faculty="FAST",
                    work_type="diplomová práce",
                ),
                max_candidates=3,
            ),
            ProviderProfile(
                type="openwebui",
                base_url="http://127.0.0.1:8080/api",
                model="e-infra.glm-5",
                api_key_secret="openwebui_api_key",
            ),
            FakeSecretStore(),
            "owner",
        )
    )
    assert response.code == "OK"
    assert response.candidates[0].verified_http is True
    assert captured["url"].endswith("/api/chat/completions")
    assert captured["body"]["features"]["web_search"] is True
    assert captured["authorization"] == "Bearer sk-valid-test"


def test_empty_kb1_file_remains_validation_error(tmp_path: Path) -> None:
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    with TestClient(app) as client:
        created = client.post("/v1/projects", headers=headers, json={"spec": reviewer_spec()})
        project_id = created.json()["id"]
        client.post(
            f"/v1/projects/{project_id}/files?role=kb2",
            headers=headers,
            files={"file": ("thesis.txt", b"reviewed content", "text/plain")},
        )
        empty = client.post(
            f"/v1/projects/{project_id}/files?role=kb1",
            headers=headers,
            files={"file": ("rules.txt", b"", "text/plain")},
        )
        assert empty.status_code == 201
        validation = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert any(
            issue["code"] == "EMPTY_REVIEWER_KB1" and issue["severity"] == "error"
            for issue in validation.json()["issues"]
        )



def test_resume_existing_reviewer_job_repairs_kb1_before_queue(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    calls: list[tuple[str, str, dict[str, Any] | None]] = []
    validation_count = 0

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        nonlocal validation_count
        calls.append((method, path, json_body))
        if method == "GET" and path == "/v1/jobs/job-resume-001":
            return {"id": "job-resume-001", "project_id": "project-resume-001", "status": "FAILED"}
        if method == "GET" and path == "/v1/projects/project-resume-001":
            return {
                "id": "project-resume-001",
                "spec": {
                    "mode": "reviewer",
                    "language": "cs",
                    "provider": {"type": "openwebui", "model": "e-infra.glm-5"},
                    "options": {"reviewer_kb1_policy": "require_source"},
                },
            }
        if method == "POST" and path.endswith("/validate"):
            validation_count += 1
            if validation_count == 1:
                return {
                    "issues": [
                        {
                            "severity": "error",
                            "code": "MISSING_REVIEWER_KB1",
                            "message": "KB1 is required",
                        }
                    ]
                }
            return {"issues": []}
        if method == "POST" and path.endswith("/reviewer/kb1/import"):
            return {"filename": "official_rules.pdf", "role": "kb1"}
        if method == "PATCH":
            return {"id": "project-resume-001"}
        if method == "POST" and path == "/v1/jobs/job-resume-001/resume":
            return {"id": "job-resume-001", "status": "QUEUED"}
        raise AssertionError((method, path, json_body))

    async def fake_provider_ready(*_args, **_kwargs):
        return None

    async def event_call(payload):
        assert payload["type"] == "input"
        return "URL: https://example.edu/official_rules.pdf"

    monkeypatch.setattr(pipe, "_api", fake_api)
    monkeypatch.setattr(pipe, "_ensure_provider_ready", fake_provider_ready)
    valves = pipe.UserValves(REVIEWER_KB1_POLICY="require_source")
    result = asyncio.run(
        pipe._job_command(
            "resume",
            "job-resume-001",
            {},
            "owner",
            {"id": "owner"},
            None,
            event_call,
            valves,
        )
    )
    assert "QUEUED" in result
    import_index = next(i for i, row in enumerate(calls) if row[1].endswith("/reviewer/kb1/import"))
    resume_index = next(i for i, row in enumerate(calls) if row[1] == "/v1/jobs/job-resume-001/resume")
    assert import_index < resume_index
    assert validation_count == 2


def test_resume_reviewer_without_interactive_kb1_does_not_requeue(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    resumed = False

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        nonlocal resumed
        if method == "GET" and path == "/v1/jobs/job-no-ui-001":
            return {"id": "job-no-ui-001", "project_id": "project-no-ui-001", "status": "FAILED"}
        if method == "GET" and path == "/v1/projects/project-no-ui-001":
            return {
                "id": "project-no-ui-001",
                "spec": {
                    "mode": "reviewer",
                    "provider": {"type": "openwebui", "model": "e-infra.glm-5"},
                    "options": {},
                },
            }
        if method == "POST" and path.endswith("/validate"):
            return {
                "issues": [
                    {
                        "severity": "error",
                        "code": "MISSING_REVIEWER_KB1",
                        "message": "KB1 is required",
                    }
                ]
            }
        if method == "POST" and path.endswith("/resume"):
            resumed = True
            return {"status": "QUEUED"}
        raise AssertionError((method, path, json_body))

    async def fake_provider_ready(*_args, **_kwargs):
        return None

    monkeypatch.setattr(pipe, "_api", fake_api)
    monkeypatch.setattr(pipe, "_ensure_provider_ready", fake_provider_ready)
    result = asyncio.run(
        pipe._job_command(
            "resume",
            "job-no-ui-001",
            {},
            "owner",
            {"id": "owner"},
            None,
            None,
            pipe.UserValves(REVIEWER_KB1_POLICY="require_source"),
        )
    )
    assert "nebyla obnovena" in result
    assert "KB1" in result
    assert resumed is False


def test_url_import_rejects_oauth_login_page(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from autogenbook_companion import service
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    login_html = b"""
    <html><head><title>Jednotne prihlaseni VUT</title></head>
    <body><h1>Jednotne prihlaseni VUT</h1><form>
    <label>Uzivatelske jmeno</label><input name='username'>
    <label>Heslo</label><input type='password' name='password'>
    <button>Prihlasit se</button></form></body></html>
    """

    monkeypatch.setattr(
        service,
        "_fetch_public_source",
        lambda _value: (
            login_html,
            "text/html",
            "https://id.vut.cz/auth/common/oauth2/authorize?client_id=x&redirect_uri=https%3A%2F%2Fwww.vut.cz",
            "Jednotne prihlaseni VUT",
        ),
    )
    with TestClient(app) as client:
        created = client.post("/v1/projects", headers=headers, json={"spec": reviewer_spec()})
        project_id = created.json()["id"]
        response = client.post(
            f"/v1/projects/{project_id}/reviewer/kb1/import",
            headers=headers,
            json={
                "source_type": "url",
                "value": "https://www.vut.cz/uredni-deska/smernice.pdf",
            },
        )
        assert response.status_code == 400
        assert "REVIEWER_KB1_AUTH_PAGE" in response.text
        files = client.get(f"/v1/projects/{project_id}/files", headers=headers)
        if files.status_code == 200:
            assert not [row for row in files.json() if row.get("role") == "kb1"]


def test_validation_rejects_attached_authorize_page(tmp_path: Path) -> None:
    from autogenbook_companion.service import create_app

    settings = make_settings(tmp_path)
    app = create_app(settings, start_workers=False)
    headers = {
        "Authorization": f"Bearer {settings.get_or_create_token()}",
        "X-AutoGenBook-User": "reviewer-user",
    }
    with TestClient(app) as client:
        created = client.post("/v1/projects", headers=headers, json={"spec": reviewer_spec()})
        project_id = created.json()["id"]
        assert client.post(
            f"/v1/projects/{project_id}/files?role=kb2",
            headers=headers,
            files={"file": ("thesis.txt", b"reviewed thesis content", "text/plain")},
        ).status_code == 201
        login = (
            "# Jednotné přihlášení VUT\n\n"
            "Zdroj: https://id.vut.cz/auth/common/oauth2/authorize?client_id=x&redirect_uri=y\n\n"
            "Přihlaste se uživatelským jménem a heslem. OAuth single sign-on."
        ).encode("utf-8")
        assert client.post(
            f"/v1/projects/{project_id}/files?role=kb1",
            headers=headers,
            files={"file": ("authorize.md", login, "text/markdown")},
        ).status_code == 201
        validation = client.post(f"/v1/projects/{project_id}/validate", headers=headers)
        assert validation.status_code == 200
        issues = validation.json()["issues"]
        assert any(
            row["code"] == "REVIEWER_KB1_AUTH_PAGE" and row["severity"] == "error"
            for row in issues
        )


def test_attached_diagnostic_archive_login_excerpt_is_rejected() -> None:
    from autogenbook.reviewer_kb1_quality import assess_text

    value = (
        "# Jednotné přihlášení VUT - Zdroj: "
        "https://id.vut.cz/auth/common/oauth2/authorize?redirect_uri=https%3A%2F%2Fwww.vut.cz"
    )
    report = assess_text(
        value,
        source_name="authorize.md",
        source_url="https://id.vut.cz/auth/common/oauth2/authorize?redirect_uri=x&client_id=y",
        source_kind="url",
    )
    assert report.valid is False
    assert report.code == "REVIEWER_KB1_AUTH_PAGE"


def test_reviewer_source_prompt_offers_interactive_file_upload() -> None:
    module = load_pipe_module()
    message = module.Pipe._reviewer_source_instruction(
        "ask_or_search", project_id="project-12345678"
    )
    assert "`SOUBOR`" in message
    assert "PDF, DOCX, PPTX, MD nebo TXT" in message
    assert "`KB1 project-12345678`" in message


def test_reviewer_file_picker_uses_same_origin_openwebui_upload() -> None:
    module = load_pipe_module()
    code = module.Pipe._reviewer_file_picker_code(
        max_files=5, max_bytes=250 * 1024 * 1024
    )
    assert 'input.type = "file"' in code
    assert 'input.multiple = true' in code
    assert 'input.accept = config.accept' in code
    assert 'fetch("/api/v1/files/?process=false"' in code
    assert 'credentials: "include"' in code
    assert '".pdf", ".docx", ".pptx", ".md", ".txt"' in code
    assert "finish({cancelled: false, files: uploaded})" in code
    assert "finish({cancelled: false, files: uploaded, token" not in code


def test_interactive_picker_uploads_selected_file_as_kb1(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    rules = tmp_path / "hodnotici_smernice.md"
    rules.write_text(
        "# Kritéria hodnocení\n\nHodnotí se splnění cíle, metodika, výsledky, literatura a formální úroveň.",
        encoding="utf-8",
    )
    event_types: list[str] = []
    uploads: list[tuple[str, str]] = []
    patches: list[dict[str, Any]] = []

    async def event_call(payload):
        event_types.append(payload["type"])
        if payload["type"] == "input":
            return "SOUBOR"
        assert payload["type"] == "execute"
        return {
            "result": {
                "cancelled": False,
                "files": [
                    {
                        "id": "openwebui-file-1",
                        "filename": rules.name,
                        "size": rules.stat().st_size,
                    }
                ],
            }
        }

    async def fake_resolve(entry, owner_id):
        assert entry["id"] == "openwebui-file-1"
        assert owner_id == "owner"
        return rules, rules.name

    async def fake_upload(_bridge, _owner, project_id, role, path, filename):
        assert project_id == "project-1"
        assert role == "kb1"
        assert path == rules
        uploads.append((filename, role))
        return {"filename": filename, "role": role}

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        assert method == "PATCH"
        assert path == "/v1/projects/project-1"
        patches.append(json_body)
        return {"id": "project-1", "spec": json_body["spec"]}

    monkeypatch.setattr(pipe, "_resolve_openwebui_file", fake_resolve)
    monkeypatch.setattr(pipe, "_upload_path", fake_upload)
    monkeypatch.setattr(pipe, "_api", fake_api)
    spec = {
        "mode": "reviewer",
        "language": "cs",
        "provider": {"type": "openwebui", "model": "e-infra.glm-5"},
        "options": {},
    }
    result = asyncio.run(
        pipe._ensure_reviewer_kb1(
            {},
            "owner",
            "project-1",
            spec,
            pipe.UserValves(REVIEWER_KB1_POLICY="require_source"),
            event_call,
        )
    )
    assert result == [(rules.name, "kb1")]
    assert event_types == ["input", "execute"]
    assert uploads == [(rules.name, "kb1")]
    assert patches[-1]["spec"]["options"]["reviewer_kb1_origin"] == "interactive_file_upload"


def test_kb1_followup_command_accepts_chat_attachment_and_starts_project(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    rules = tmp_path / "rubrika_posudku.txt"
    rules.write_text(
        "Hodnoticí rubrika: splnění cíle, správnost metodiky, odborná úroveň, výsledky, "
        "práce s literaturou, formální úroveň a připravenost k obhajobě.",
        encoding="utf-8",
    )
    calls: list[tuple[str, str, dict[str, Any] | None]] = []

    project = {
        "id": "project-followup-001",
        "spec": {
            "mode": "reviewer",
            "brief": "Posuď práci.",
            "language": "cs",
            "provider": {
                "type": "openwebui",
                "base_url": "http://127.0.0.1:8080/api",
                "model": "e-infra.glm-5",
                "api_key_secret": "openwebui_api_key",
            },
            "options": {"reviewer_kb1_policy": "require_source"},
        },
    }

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        calls.append((method, path, json_body))
        if method == "GET" and path == "/v1/projects/project-followup-001":
            return project
        if method == "PATCH" and path == "/v1/projects/project-followup-001":
            project["spec"] = json_body["spec"]
            return project
        if method == "POST" and path.endswith("/validate"):
            return {"valid": True, "issues": []}
        if method == "POST" and path == "/v1/jobs":
            return {"id": "job-followup-001", "status": "QUEUED"}
        raise AssertionError((method, path, json_body))

    async def fake_resolve(entry, owner_id):
        assert entry["id"] == "openwebui-file-followup"
        assert owner_id == "owner"
        return rules, rules.name

    async def fake_upload(_bridge, _owner, project_id, role, path, filename):
        assert (project_id, role, path, filename) == (
            "project-followup-001",
            "kb1",
            rules,
            rules.name,
        )
        return {"filename": filename, "role": role}

    async def fake_provider_ready(*_args, **_kwargs):
        return None

    monkeypatch.setattr(pipe, "_api", fake_api)
    monkeypatch.setattr(pipe, "_resolve_openwebui_file", fake_resolve)
    monkeypatch.setattr(pipe, "_upload_path", fake_upload)
    monkeypatch.setattr(pipe, "_ensure_provider_ready", fake_provider_ready)

    result = asyncio.run(
        pipe._kb1_attachment_command(
            "project-followup-001",
            {},
            "owner",
            [{"id": "openwebui-file-followup", "filename": rules.name}],
            None,
            None,
            pipe.UserValves(REVIEWER_KB1_POLICY="require_source"),
        )
    )
    assert "job-followup-001" in result
    assert "QUEUED" in result
    assert project["spec"]["options"]["reviewer_kb1_origin"] == "chat_attachment_followup"
    assert any(method == "POST" and path == "/v1/jobs" for method, path, _body in calls)


def test_kb1_followup_command_resumes_failed_reviewer_job(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    rules = tmp_path / "smernice_hodnoceni.md"
    rules.write_text(
        "Směrnice a kritéria hodnocení závěrečné práce: splnění cíle, metodika, "
        "odborná úroveň, výsledky, literatura, formální úroveň a obhajoba.",
        encoding="utf-8",
    )
    resumed = False

    async def fake_api(_bridge, _owner, method, path, *, json_body=None, timeout=30.0):
        nonlocal resumed
        if method == "GET" and path == "/v1/projects/job-reviewer-001":
            raise module.CompanionError("Companion API 404: Project not found")
        if method == "GET" and path == "/v1/jobs/job-reviewer-001":
            return {
                "id": "job-reviewer-001",
                "project_id": "project-reviewer-001",
                "status": "FAILED",
            }
        if method == "GET" and path == "/v1/projects/project-reviewer-001":
            return {
                "id": "project-reviewer-001",
                "spec": {
                    "mode": "reviewer",
                    "brief": "Posuď práci.",
                    "language": "cs",
                    "provider": {
                        "type": "openwebui",
                        "base_url": "http://127.0.0.1:8080/api",
                        "model": "e-infra.glm-5",
                        "api_key_secret": "openwebui_api_key",
                    },
                    "options": {"reviewer_kb1_policy": "require_source"},
                },
            }
        if method == "PATCH" and path == "/v1/projects/project-reviewer-001":
            return {"id": "project-reviewer-001", "spec": json_body["spec"]}
        if method == "POST" and path.endswith("/validate"):
            return {"valid": True, "issues": []}
        if method == "POST" and path == "/v1/jobs/job-reviewer-001/resume":
            resumed = True
            return {"id": "job-reviewer-001", "status": "QUEUED"}
        raise AssertionError((method, path, json_body))

    async def fake_resolve(_entry, _owner):
        return rules, rules.name

    async def fake_upload(*_args, **_kwargs):
        return {"filename": rules.name, "role": "kb1"}

    async def fake_provider_ready(*_args, **_kwargs):
        return None

    monkeypatch.setattr(pipe, "_api", fake_api)
    monkeypatch.setattr(pipe, "_resolve_openwebui_file", fake_resolve)
    monkeypatch.setattr(pipe, "_upload_path", fake_upload)
    monkeypatch.setattr(pipe, "_ensure_provider_ready", fake_provider_ready)
    result = asyncio.run(
        pipe._kb1_attachment_command(
            "job-reviewer-001",
            {},
            "owner",
            [{"id": "ow-file-1", "filename": rules.name}],
            None,
            None,
            pipe.UserValves(REVIEWER_KB1_POLICY="require_source"),
        )
    )
    assert resumed is True
    assert "zařazena k pokračování" in result
    assert "QUEUED" in result


def test_pipe_routes_kb1_command_with_attachments_before_job_handler(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import asyncio

    module = load_pipe_module()
    pipe = module.Pipe()
    called: dict[str, Any] = {}

    async def fake_companion():
        return {"url": "http://127.0.0.1:1", "token": "bridge"}

    async def fake_kb1(
        target_id, bridge, owner_id, files, event_emitter, event_call, user_valves
    ):
        called.update(
            target_id=target_id,
            bridge=bridge,
            owner_id=owner_id,
            files=files,
        )
        return "KB1 routed"

    async def fail_job_handler(*_args, **_kwargs):
        raise AssertionError("KB1 command must not be handled as a normal job command")

    monkeypatch.setattr(pipe, "_ensure_companion", fake_companion)
    monkeypatch.setattr(pipe, "_kb1_attachment_command", fake_kb1)
    monkeypatch.setattr(pipe, "_job_command", fail_job_handler)
    identifier = "631131cb-ee9d-4e09-ab1d-0c5fa9640f01"
    attachment = {"id": "file-1", "filename": "rules.pdf"}
    result = asyncio.run(
        pipe.pipe(
            {
                "model": "autogenbook.reviewer",
                "messages": [{"role": "user", "content": f"KB1 {identifier}"}],
            },
            __user__={"id": "owner"},
            __files__=[attachment],
        )
    )
    assert result == "KB1 routed"
    assert called["target_id"] == identifier
    assert called["owner_id"] == "owner"
    assert called["files"] == [attachment]
