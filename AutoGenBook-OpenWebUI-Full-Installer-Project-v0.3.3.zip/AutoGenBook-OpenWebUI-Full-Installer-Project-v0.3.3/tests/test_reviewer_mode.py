import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from autogenbook.pipelines import reviewer_pipeline


VALID_REVIEW = """| Hodnocená oblast | Známka 0–9 | Konkrétní důkazy z práce | Zdůvodnění a doporučení |
|---|---:|---|---|
| Popis tématu, problému a cílů práce | 7 | Úvod a formulace cíle vymezují řešený problém a zamýšlený výsledek. | Cíle jsou srozumitelné, ale jejich měřitelnost by měla být přesněji spojena s výsledky. |
| Analýza řešeného tématu | 6 | Teoretická část shrnuje literaturu, současný stav a zvolené metody. | Analýza je použitelná, avšak některé alternativní přístupy nejsou porovnány stejnými kritérii. |
| Návrhy řešení, výsledky a závěry | 7 | Praktická část popisuje návrh řešení, experimenty, výsledky a závěr. | Výsledky podporují hlavní závěr; doporučuji doplnit citlivostní analýzu a omezení. |
| Struktura a formální úroveň práce | 8 | Práce má logickou strukturu, odkazy na literaturu a oddělenou metodiku, výsledky a diskusi. | Formální úroveň je velmi dobrá, drobné nedostatky jsou pouze terminologické. |
| Původnost a samostatný přínos | 7 | Autor uvádí vlastní implementaci a porovnání navrženého postupu s výchozím řešením. | Původnost je doložena konkrétními kroky, ale hranice vůči převzatým částem má být popsána ještě přesněji. |
| Inovace práce | 6 | Inovační prvek spočívá v kombinaci metod a jejich ověření na konkrétních datech. | Jde o přiměřenou inovaci pro závěrečnou práci; zásadní metodologický průlom doložen není. |
| Přínos pro praxi a společnost | 7 | Závěr uvádí možné nasazení, omezení a další rozvoj. | Praktický přínos je věrohodný, ale měl by být podpořen pilotním ověřením s uživateli. |

Posudek hodnotí práci jako obsahově kvalitní a připravenou k obhajobě. Metodika odpovídá cíli, výsledky jsou interpretovány převážně správně a závěry nepřekračují doložené důkazy. Z hlediska pravidel KB1 je nutné ověřit úplnost povinných náležitostí, správnost odevzdání a zveřejnění; tam, kde předložené podklady neumožňují kontrolu, je tato skutečnost výslovně označena jako neověřitelná, nikoli jako porušení. Doporučení k obhajobě: vysvětlit volbu metrik, uvést nejvýznamnější omezení a přesně oddělit vlastní přínos od převzatých postupů. Otázky k obhajobě: Jak by se výsledky změnily při jiné volbě dat? Které omezení nejvíce ovlivňuje zobecnitelnost? Jak by bylo možné řešení ověřit v reálné praxi?
"""


class DummyConfig:
    model = "test-model"


class DummyLLM:
    def __init__(self, *args, **kwargs):
        self.calls = []
        self.config = DummyConfig()

    def chat(self, messages, allow_tools=False, model=None, max_tokens=None):
        self.calls.append(
            {
                "messages": messages,
                "allow_tools": allow_tools,
                "model": model,
                "max_tokens": max_tokens,
            }
        )
        system_text = messages[0].get("content", "") if messages else ""
        if "institution-rules analyst" in system_text:
            return "## Institution-specific KB1 addendum\n\n- Ověř povinné náležitosti [SRC:kb1]."
        return VALID_REVIEW

    def get_last_usage(self):
        return {}

    def get_total_tokens(self):
        return 0

    def get_total_cost_usd(self):
        return None


def _make_args(
    out_dir,
    kb1_dir=None,
    kb2_dir=None,
    *,
    allow_missing_kb1=False,
    profile="direct",
):
    return SimpleNamespace(
        out_dir=str(out_dir),
        kb1_dir=str(kb1_dir) if kb1_dir else None,
        kb2_dir=str(kb2_dir) if kb2_dir else None,
        rebuild_kb=False,
        no_pdf=True,
        no_tex=True,
        no_md=False,
        docx=False,
        language="cs",
        reviewer_profile=profile,
        reviewer_instructions=None,
        reviewer_direct_pdf=True,
        reviewer_allow_missing_kb1=allow_missing_kb1,
        reviewer_evidence_max_chars=60000,
        reviewer_kb1_context_max_chars=48000,
        reviewer_evidence_per_criterion=6,
        reviewer_max_output_tokens=32768,
        reviewer_quality_gate=True,
        reviewer_pdf_engine="auto",
        reviewer_llm1_model=None,
        reviewer_llm2_model=None,
        reviewer_llm1_base_url=None,
        reviewer_llm2_base_url=None,
    )


class ReviewerModeTests(unittest.TestCase):
    def test_missing_kb2_dir_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            code = reviewer_pipeline.run_reviewer(_make_args(Path(tmp) / "out"), None, None)
            self.assertEqual(code, 2)

    def test_empty_kb2_dir_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            kb2_dir = Path(tmp) / "kb2"
            kb2_dir.mkdir(parents=True, exist_ok=True)
            code = reviewer_pipeline.run_reviewer(
                _make_args(Path(tmp) / "out", kb2_dir=kb2_dir), None, None
            )
            self.assertEqual(code, 2)

    def test_missing_kb1_fails_with_actionable_diagnostic(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir = Path(tmp) / "kb2"
            kb2_dir.mkdir(parents=True, exist_ok=True)
            (kb2_dir / "thesis.txt").write_text("test", encoding="utf-8")
            with patch.object(reviewer_pipeline, "OpenRouterLLM") as llm_ctor:
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb2_dir=kb2_dir), None, None
                )
            self.assertEqual(code, 2)
            llm_ctor.assert_not_called()
            diagnostic = out_dir / "reviewer_kb1_diagnostic.json"
            self.assertTrue(diagnostic.exists())
            self.assertIn("REVIEWER_KB1_REQUIRED", diagnostic.read_text(encoding="utf-8"))
            self.assertFalse((out_dir / "review_final.md").exists())

    def test_explicit_missing_kb1_override_uses_canonical_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir = Path(tmp) / "kb2"
            kb2_dir.mkdir(parents=True, exist_ok=True)
            (kb2_dir / "thesis.txt").write_text("test", encoding="utf-8")
            dummy_instance = DummyLLM()
            with patch.object(reviewer_pipeline, "OpenRouterLLM", lambda *_a, **_k: dummy_instance):
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb2_dir=kb2_dir, allow_missing_kb1=True), None, None
                )
            self.assertEqual(code, 0)
            self.assertTrue((out_dir / "review_final.md").exists())
            self.assertFalse((out_dir / "reviewer_prompt1_generated.md").exists())
            diagnostic = (out_dir / "reviewer_kb1_diagnostic.json").read_text(encoding="utf-8")
            self.assertIn("REVIEWER_KB1_EXPLICITLY_WAIVED", diagnostic)

    def test_empty_kb1_is_not_treated_as_available(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir, kb1_dir = Path(tmp) / "kb2", Path(tmp) / "kb1"
            kb2_dir.mkdir(); kb1_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text("reviewed content", encoding="utf-8")
            (kb1_dir / "empty_rules.txt").write_text("   \n", encoding="utf-8")
            with patch.object(reviewer_pipeline, "OpenRouterLLM") as llm_ctor:
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir), None, None
                )
            self.assertEqual(code, 2)
            llm_ctor.assert_not_called()

    def test_authentication_page_is_rejected_before_any_llm_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir, kb1_dir = Path(tmp) / "kb2", Path(tmp) / "kb1"
            kb2_dir.mkdir(); kb1_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text("reviewed content", encoding="utf-8")
            (kb1_dir / "authorize.md").write_text(
                "# Jednotné přihlášení VUT\n\n"
                "https://id.vut.cz/auth/common/oauth2/authorize?client_id=x&redirect_uri=y\n\n"
                "Přihlaste se uživatelským jménem a heslem. OAuth single sign-on.",
                encoding="utf-8",
            )
            with patch.object(reviewer_pipeline, "OpenRouterLLM") as llm_ctor:
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir), None, None
                )
            self.assertEqual(code, 2)
            llm_ctor.assert_not_called()
            self.assertIn(
                "REVIEWER_KB1_AUTH_PAGE",
                (out_dir / "reviewer_kb1_quality.json").read_text(encoding="utf-8"),
            )

    def test_direct_profile_preserves_canonical_prompt_and_full_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir, kb1_dir = Path(tmp) / "kb2", Path(tmp) / "kb1"
            kb2_dir.mkdir(); kb1_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text(
                "Cíl práce. Analýza problému. Návrh řešení. Výsledky. Závěr. Původní přínos a inovace pro praxi.",
                encoding="utf-8",
            )
            (kb1_dir / "norms.txt").write_text(
                "Směrnice pro hodnocení závěrečných prací vyžaduje posouzení cíle, metodiky, odborné "
                "úrovně, výsledků, práce s literaturou, formálního zpracování, původnosti a obhajoby. "
                "Klasifikace musí být odůvodněna konkrétními kritérii.",
                encoding="utf-8",
            )
            dummy = DummyLLM()
            with patch.object(reviewer_pipeline, "OpenRouterLLM", lambda *_a, **_k: dummy):
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir, profile="direct"),
                    None,
                    None,
                )
            self.assertEqual(code, 0)
            self.assertEqual(len(dummy.calls), 1, "direct profile must not spend an LLM1 call")
            base_path = Path(reviewer_pipeline.__file__).resolve().parents[2] / "prompts" / "reviewer" / "prompt1_default.md"
            self.assertEqual(
                dummy.calls[0]["messages"][0]["content"].strip(),
                base_path.read_text(encoding="utf-8-sig").strip(),
            )
            user_prompt = dummy.calls[0]["messages"][1]["content"]
            self.assertIn("Piš celý výsledný posudek česky", user_prompt)
            self.assertIn("KB2 EVIDENCE PACK", user_prompt)
            self.assertTrue((out_dir / "reviewer_parity_manifest.json").exists())
            self.assertTrue((out_dir / "reviewer_quality_report.json").exists())

    def test_hybrid_profile_adds_kb1_without_replacing_canonical_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir, kb1_dir = Path(tmp) / "kb2", Path(tmp) / "kb1"
            kb2_dir.mkdir(); kb1_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text("Cíl, analýza, řešení, výsledky a přínos.", encoding="utf-8")
            (kb1_dir / "norms.txt").write_text(
                "Hodnoticí směrnice pro závěrečné práce vyžaduje posoudit splnění cíle, správnost metodiky, "
                "odbornou úroveň, kvalitu výsledků, práci s literaturou, formální zpracování, původnost a "
                "samostatnost řešení, inovační přínos, využitelnost v praxi a připravenost k obhajobě. "
                "Posudek vedoucího i oponenta musí obsahovat konkrétní odůvodnění klasifikace, upozornění na "
                "nedostatky, doporučení k obhajobě a otázky, které ověří porozumění autora zvolené metodě. "
                "Každé kritérium má být spojeno s doložitelnou částí práce; chybějící důkaz se označí jako "
                "neověřitelný a nesmí být nahrazen domněnkou.",
                encoding="utf-8",
            )
            dummy = DummyLLM()
            with patch.object(reviewer_pipeline, "OpenRouterLLM", lambda *_a, **_k: dummy):
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb1_dir=kb1_dir, kb2_dir=kb2_dir, profile="hybrid"),
                    None,
                    None,
                )
            self.assertEqual(code, 0)
            self.assertEqual(len(dummy.calls), 2)
            effective = (out_dir / "reviewer_prompt1_effective.md").read_text(encoding="utf-8")
            canonical = (
                Path(reviewer_pipeline.__file__).resolve().parents[2]
                / "prompts" / "reviewer" / "prompt1_default.md"
            ).read_text(encoding="utf-8-sig").strip()
            self.assertTrue(effective.startswith(canonical))
            self.assertIn("Institution-specific KB1 addendum", effective)

    def test_quality_gate_repairs_one_bad_draft(self):
        class RepairingLLM(DummyLLM):
            def chat(self, messages, allow_tools=False, model=None, max_tokens=None):
                self.calls.append({"messages": messages, "allow_tools": allow_tools, "max_tokens": max_tokens})
                return "Příliš krátké." if len(self.calls) == 1 else VALID_REVIEW

        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir = Path(tmp) / "kb2"
            kb2_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text("Cíl, analýza, výsledky, původnost, inovace a přínos.", encoding="utf-8")
            dummy = RepairingLLM()
            with patch.object(reviewer_pipeline, "OpenRouterLLM", lambda *_a, **_k: dummy):
                code = reviewer_pipeline.run_reviewer(
                    _make_args(out_dir, kb2_dir=kb2_dir, allow_missing_kb1=True), None, None
                )
            self.assertEqual(code, 0)
            self.assertEqual(len(dummy.calls), 2)
            report = (out_dir / "reviewer_quality_report.json").read_text(encoding="utf-8")
            self.assertIn('"repair_attempted": true', report)
            self.assertEqual((out_dir / "review_final.md").read_text(encoding="utf-8").strip(), VALID_REVIEW.strip())

    def test_requested_pdf_failure_makes_job_fail_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp) / "out"
            kb2_dir = Path(tmp) / "kb2"
            kb2_dir.mkdir()
            (kb2_dir / "thesis.txt").write_text("Cíl, analýza, výsledky, původnost, inovace a přínos.", encoding="utf-8")
            args = _make_args(out_dir, kb2_dir=kb2_dir, allow_missing_kb1=True)
            args.no_pdf = False
            dummy = DummyLLM()
            with (
                patch.object(reviewer_pipeline, "OpenRouterLLM", lambda *_a, **_k: dummy),
                patch.object(
                    reviewer_pipeline,
                    "_convert_with_pandoc",
                    return_value={
                        "markdown": {"success": True, "path": str(out_dir / "review_final.md")},
                        "pdf": {"success": False, "path": str(out_dir / "review_final.pdf"), "error": "engine failed"},
                    },
                ),
            ):
                code = reviewer_pipeline.run_reviewer(args, None, None)
            self.assertEqual(code, 2)
            self.assertTrue((out_dir / "review_final.md").exists())
            self.assertIn("engine failed", (out_dir / "reviewer_conversion_report.json").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
