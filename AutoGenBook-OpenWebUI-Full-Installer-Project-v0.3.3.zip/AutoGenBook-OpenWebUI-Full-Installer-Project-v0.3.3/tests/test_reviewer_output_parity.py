from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

from autogenbook.retrieval.types import RetrievalItem
from autogenbook.reviewer_parity import (
    DIRECT_REVIEW_CRITERIA,
    build_reviewer_evidence_pack,
    clean_user_instructions,
    ordered_full_context,
)
from autogenbook_companion.models import Mode, OutputOptions, ProjectSpec, ProviderProfile
from autogenbook_companion.runner import AutoGenBookRunner
from main import parse_args


ROOT = Path(__file__).resolve().parents[1]
PIPE_PATH = ROOT / "integrations" / "openwebui" / "autogenbook_pipe.py"


def load_pipe_module():
    spec = importlib.util.spec_from_file_location("parity_pipe", PIPE_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Chunk:
    def __init__(self, index: int) -> None:
        self.rid = f"chunk-{index:03d}"
        self.cite_key = f"SRC:chunk-{index:03d}"
        self.source_path = "thesis.pdf"
        self.loc = f"page {index + 1}; chunk {index}"
        self.text = (
            f"Část {index}. Cíl práce, analýza, metodika, návrh řešení, výsledky, závěr, "
            "původnost, inovace a praktický přínos. " * 3
        )


class FakeKB:
    def __init__(self, count: int) -> None:
        self.chunks = [Chunk(index) for index in range(count)]

    def _ensure_chunk_ids(self):
        return None


class FakeRetriever:
    def __init__(self, count: int = 40) -> None:
        self.local_kb = FakeKB(count)
        self._cursor = 0

    def retrieve(self, query, k=6, allow_web=False, diversify_sources=False):
        # Return different document regions for consecutive canonical queries.
        start = self._cursor % len(self.local_kb.chunks)
        self._cursor += max(1, k // 2)
        rows = []
        for offset in range(k):
            chunk = self.local_kb.chunks[(start + offset) % len(self.local_kb.chunks)]
            rows.append(
                RetrievalItem(
                    rid=chunk.rid,
                    kind="kb",
                    source="thesis.pdf",
                    loc=chunk.loc,
                    score=float(k - offset),
                    cite_key=chunk.cite_key,
                    text=chunk.text,
                    url=None,
                    title="thesis.pdf",
                )
            )
        return rows


def test_attachment_xml_does_not_turn_input_pdf_into_pdf_only_output():
    module = load_pipe_module()
    prompt = (
        '<attached_files><file type="file" name="thesis.pdf" content_type="application/pdf"/></attached_files>'
    )
    clean = module.Pipe._clean_prompt_text(prompt)
    assert clean == ""
    directives, brief = module.Pipe._parse_directives(prompt)
    assert directives == {}
    assert brief == ""
    defaults = module.Pipe._default_outputs("reviewer")
    assert module.Pipe._extract_outputs(clean, None, defaults) == ["md", "docx", "pdf", "zip"]


def test_clean_user_instructions_removes_only_openwebui_attachment_metadata():
    value = "Zpracuj česky.\n<attached_files><file name=\"input.pdf\"/></attached_files>\nDůraz na metodiku."
    assert clean_user_instructions(value) == "Zpracuj česky.\n\nDůraz na metodiku."


def test_evidence_pack_is_not_legacy_six_chunk_selection():
    pack = build_reviewer_evidence_pack(
        FakeRetriever(40),
        max_chars=60000,
        per_criterion=6,
        direct_pdf_requested=True,
    )
    assert pack.available_chunk_count == 40
    assert pack.selected_chunk_count > 6
    assert pack.selected_chunk_count >= 18
    for key, _label, _queries in DIRECT_REVIEW_CRITERIA:
        assert pack.criterion_ids[key], key
    assert "CRITERION_TO_EVIDENCE_INDEX" in pack.context


def test_ordered_kb1_context_uses_more_than_legacy_top_eight_when_budget_allows():
    context, ids, truncated = ordered_full_context(FakeKB(15), max_chars=100000)
    assert len(ids) == 15
    assert not truncated
    assert "chunk-014" in context


def test_companion_builds_reproducible_direct_cli_reviewer_command(tmp_path: Path):
    runner = object.__new__(AutoGenBookRunner)
    spec = ProjectSpec(
        mode=Mode.reviewer,
        brief=(
            '<attached_files><file name="thesis.pdf"/></attached_files>\n'
            "Zpracuj úplný posudek a důsledně zhodnoť metodiku."
        ),
        language="cs",
        outputs=OutputOptions(formats=["md", "docx", "pdf", "zip"]),
        provider=ProviderProfile(type="openwebui", base_url="http://127.0.0.1:8080/api"),
        options={},
    )
    job_root = tmp_path / "job"
    out_dir = job_root / "output"
    job_root.mkdir()
    command = runner._build_command(
        spec=spec,
        roles={"input": [], "structure": [], "kb": [], "kb1": [], "kb2": []},
        job_root=job_root,
        out_dir=out_dir,
        resume=False,
    )
    joined = " ".join(command)
    assert "--reviewer-profile direct" in joined
    assert "--reviewer-direct-pdf" in command
    assert "--language cs" in joined
    assert "--reviewer-llm1-model e-infra.glm-5" in joined
    assert "--reviewer-llm2-model e-infra.glm-5" in joined
    assert "--reviewer-quality-gate" not in command  # enabled by argparse default
    assert "--no-reviewer-quality-gate" not in command
    assert "--no-md" not in command
    assert "--docx" in command
    instructions = (job_root / "reviewer_instructions.txt").read_text(encoding="utf-8")
    assert "attached_files" not in instructions
    assert "metodiku" in instructions
    manifest = json.loads((job_root / "direct_cli_parity_request.json").read_text(encoding="utf-8"))
    assert manifest["command"] == command
    assert manifest["required_environment"]["AUTOGENBOOK_LLM_MODEL"] == "e-infra.glm-5"
    assert (out_dir / "direct_cli_parity_request.json").read_text(encoding="utf-8") == (
        job_root / "direct_cli_parity_request.json"
    ).read_text(encoding="utf-8")

    worker_marker = command.index("autogenbook_companion.worker_entry")
    parsed = parse_args(command[worker_marker + 1 :])
    assert parsed.mode == "reviewer"
    assert parsed.language == "cs"
    assert parsed.reviewer_profile == "direct"
    assert parsed.reviewer_direct_pdf is True
    assert parsed.reviewer_evidence_max_chars == 60000
    assert parsed.reviewer_max_output_tokens == 32768


def test_user_valves_default_to_parity_profile_and_canonical_model():
    module = load_pipe_module()
    valves = module.Pipe.UserValves()
    assert valves.LLM_MODEL == "e-infra.glm-5"
    assert valves.REVIEWER_PROFILE == "direct"
    assert valves.REVIEWER_DIRECT_PDF is True
    assert valves.REVIEWER_QUALITY_GATE is True
    assert valves.REVIEWER_EVIDENCE_MAX_CHARS >= 60000


def test_explicit_standalone_model_is_respected_without_job_environment(monkeypatch):
    import openrouter_llm

    captured = {}

    class FakeOpenAI:
        def __init__(self, *, api_key, base_url, default_headers=None):
            captured.update(api_key=api_key, base_url=base_url)

    for name in (
        "AUTOGENBOOK_FORCE_MODEL",
        "AUTOGENBOOK_LLM_MODEL",
        "OPENWEBUI_MODEL",
        "OPENAI_MODEL",
        "OPENROUTER_MODEL",
        "LLM_MODEL",
        "AUTOGENBOOK_PROVIDER_TYPE",
        "AUTOGENBOOK_CREDENTIAL_ISOLATION",
    ):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "local-test-key")
    monkeypatch.setattr(openrouter_llm, "OpenAI", FakeOpenAI)
    client = openrouter_llm.OpenRouterLLM(
        openrouter_llm.LLMConfig(model="e-infra.glm-5", base_url="http://127.0.0.1:9999/v1")
    )
    assert client.config.model == "e-infra.glm-5"
    assert captured["base_url"] == "http://127.0.0.1:9999/v1"
