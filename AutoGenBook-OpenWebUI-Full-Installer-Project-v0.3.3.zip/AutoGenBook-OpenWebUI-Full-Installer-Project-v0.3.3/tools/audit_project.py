from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from packaging.requirements import InvalidRequirement, Requirement


@dataclass
class Check:
    name: str
    status: str
    detail: str
    log: str | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_command(
    checks: list[Check],
    *,
    name: str,
    command: list[str],
    cwd: Path,
    output_dir: Path,
    env: dict[str, str],
) -> None:
    log_name = re.sub(r"[^a-z0-9]+", "-", name.casefold()).strip("-") + ".log"
    log_path = output_dir / log_name
    process = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        errors="replace",
        check=False,
    )
    log_path.write_text(process.stdout, encoding="utf-8")
    detail = f"exit={process.returncode}; command={' '.join(command)}"
    checks.append(Check(name, "pass" if process.returncode == 0 else "fail", detail, log_name))


def file_inventory(root: Path) -> list[dict[str, object]]:
    ignored = {".git", ".pytest_cache", ".ruff_cache", ".mypy_cache", "__pycache__", "dist", "output"}
    rows: list[dict[str, object]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in ignored for part in relative.parts) or path.suffix in {".pyc", ".pyo"}:
            continue
        rows.append(
            {
                "path": relative.as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return rows


def static_checks(root: Path, checks: list[Check]) -> None:
    expected_version = (root / "VERSION").read_text(encoding="utf-8").strip()
    audit_scope_path = f"docs/AUDIT_SCOPE_{expected_version}.md"
    required = (
        "README.md",
        "main.py",
        "openrouter_llm.py",
        "companion/pyproject.toml",
        "companion/src/autogenbook_companion/service.py",
        "companion/src/autogenbook_companion/runner.py",
        "companion/src/autogenbook_companion/artifacts.py",
        "autogenbook/reviewer_kb1_quality.py",
        "autogenbook/reviewer_parity.py",
        "companion/src/autogenbook_companion/progress.py",
        "companion/src/autogenbook_companion/key_file.py",
        "integrations/openwebui/autogenbook_pipe.py",
        "tools/build_openwebui_integration.py",
        "tools/unpack_openwebui_bundle.py",
        "build/package_full_installer_project.py",
        "integration/openwebui_bundle_manifest.json",
        "tests/test_openwebui_integration_v6.py",
        "tests/test_installer_startup.py",
        "tests/test_installer_api_key_file.py",
        "tests/test_installer_http_registration.py",
        "tests/test_openwebui_function_frontmatter.py",
        "tests/test_openwebui_persistent_auth.py",
        "tests/test_openwebui_persistent_artifacts.py",
        "tests/test_openwebui_authenticated_downloads.py",
        "tests/test_provider_credential_isolation.py",
        "tests/test_reviewer_mode.py",
        "tests/test_reviewer_output_parity.py",
        "tests/test_reviewer_kb1_workflow.py",
        "docs/REVIEWER_KB1_WORKFLOW.md",
        "docs/OUTPUT_PARITY.md",
        audit_scope_path,
        "docs/incidents/2026-08-20-reviewer-kb1-policy.md",
        "docs/incidents/2026-08-20-reviewer-kb1-sso-diagnostic-gap.md",
        "docs/incidents/2026-08-20-reviewer-kb1-interactive-file-upload.md",
        "docs/incidents/2026-08-20-openwebui-worker-credential-precedence.md",
        "docs/incidents/2026-08-20-openwebui-worker-credential-precedence.json",
        "docs/incidents/2026-08-27-expiring-companion-download-links.md",
        "docs/incidents/2026-08-28-openwebui-reviewer-output-degradation.md",
        "docs/incidents/2026-09-18-openwebui-output-download-contract.md",
        "docs/incidents/2026-09-18-openwebui-authenticated-download-broker.md",
        "docs/incidents/2026-09-18-openwebui-capability-download.md",
        "Configure-OpenWebUI-ApiKeyFile.cmd",
        "Clear-OpenWebUI-ApiKeyFile.cmd",
        "examples/openwebui-api-key.example.txt",
        "docs/incidents/2026-08-20-installer-http-400.md",
        "VERSION",
    )
    missing = [name for name in required if not (root / name).is_file()]
    checks.append(Check("Povinné projektové soubory", "fail" if missing else "pass", f"missing={missing}"))

    readme = (root / "README.md").read_text(encoding="utf-8-sig")
    sections = (
        "## Architektura",
        "## Instalace",
        "### Open WebUI API klíč z TXT souboru",
        "## Volba LLM modelu",
        "## Práce s dlouhotrvajícími úlohami",
        "## Výstupní soubory a velké downloady",
        "## Příklady použití",
        "## Reviewer: povinná KB1 a řízené dohledání",
        "## Bezpečnost a soukromí",
        "## Ekvivalence s přímým CLI AutoGenBooku",
        "## Build a reprodukovatelnost",
        "## Testování a audit",
        "## Známá omezení",
    )
    missing_sections = [section for section in sections if section not in readme]
    examples = sum(readme.count(token) for token in ("### Kniha", "### Odborný článek", "### Prezentace", "### Projektový návrh", "### Recenzní posudek", "### Scientist"))
    readme_ok = (
        not missing_sections
        and examples >= 6
        and "e-infra.glm-5" in readme
        and "--webui-api-key-file" in readme
        and "Invalid HTTP request received" in readme
        and "REVIEWER_KB1_REQUIRED" in readme
        and "HLEDAT:" in readme
        and "SOUBOR" in readme
        and "KB1 <ID_PROJEKTU_NEBO_ÚLOHY>" in readme
        and "Invalid companion token" in readme
        and "/api/autogenbook/download/PODEPSANÁ_CAPABILITY" in readme
        and '"detail":"Not authenticated"' in readme
        and "No content" in readme
        and "direct_cli_parity_request.json" in readme
        and "REVIEWER_OUTPUT_QUALITY_FAILED" in readme
        and "REVIEWER_EXPORT_FAILED" in readme
        and "REVIEWER_PROFILE=direct" in readme
    )
    checks.append(
        Check(
            "README pokrytí",
            "pass" if readme_ok else "fail",
            f"missing_sections={missing_sections}; recognized_examples={examples}; bytes={len(readme.encode('utf-8'))}",
        )
    )

    versions = {
        "pyproject": re.search(r'^version\s*=\s*"([^"]+)"', (root / "companion/pyproject.toml").read_text(encoding="utf-8"), re.MULTILINE),
        "version.py": re.search(r'__version__\s*=\s*"([^"]+)"', (root / "companion/src/autogenbook_companion/version.py").read_text(encoding="utf-8")),
        "pipe": re.search(r'^version:\s*([^\s]+)', (root / "integrations/openwebui/autogenbook_pipe.py").read_text(encoding="utf-8"), re.MULTILINE),
        "builder": re.search(r'COMPANION_VERSION\s*=\s*"([^"]+)"', (root / "build/build_release.py").read_text(encoding="utf-8")),
        "installer": re.search(r'INSTALLER_VERSION\s*=\s*"([^"]+)"', (root / "installer/install.py").read_text(encoding="utf-8")),
        "root": re.search(r'__version__\s*=\s*"([^"]+)"', (root / "__init__.py").read_text(encoding="utf-8")),
    }
    values = {name: match.group(1) if match else None for name, match in versions.items()}
    checks.append(Check("Konzistence verze", "pass" if set(values.values()) == {expected_version} else "fail", json.dumps({"expected": expected_version, **values}, ensure_ascii=False)))

    pipe = (root / "integrations/openwebui/autogenbook_pipe.py").read_text(encoding="utf-8")
    frontmatter: dict[str, str] = {}
    frontmatter_pattern = re.compile(r"^\s*([a-z_]+):\s*(.*)\s*$", re.IGNORECASE)
    pipe_lines = pipe.splitlines()
    if pipe_lines and pipe_lines[0].strip() == '"""':
        for line in pipe_lines[1:]:
            if '"""' in line:
                break
            match = frontmatter_pattern.match(line)
            if match:
                frontmatter[match.group(1).strip()] = match.group(2).strip()
    raw_requirements = frontmatter.get("requirements", "")
    requirement_tokens = [item.strip() for item in raw_requirements.split(",") if item.strip()]
    invalid_requirements: list[str] = []
    for token in requirement_tokens:
        try:
            Requirement(token)
        except InvalidRequirement:
            invalid_requirements.append(token)
    frontmatter_ok = not requirement_tokens and not invalid_requirements
    checks.append(
        Check(
            "Open WebUI frontmatter bez hostitelského pip installu",
            "pass" if frontmatter_ok else "fail",
            f"raw={raw_requirements!r}; tokens={requirement_tokens}; invalid={invalid_requirements}",
        )
    )
    runner = (root / "companion/src/autogenbook_companion/runner.py").read_text(encoding="utf-8")
    llm_client = (root / "openrouter_llm.py").read_text(encoding="utf-8")
    combo_tokens = (
        "default=DEFAULT_LLM_MODEL",
        '"input": {"type": "select", "options": "get_model_options"}',
        "def get_model_options",
        "FOREGROUND_WAIT_MINUTES",
    )
    missing_combo = [token for token in combo_tokens if token not in pipe]
    if "AUTOGENBOOK_FORCE_MODEL" not in runner or "AUTOGENBOOK_FORCE_MODEL" not in llm_client:
        missing_combo.append("AUTOGENBOOK_FORCE_MODEL propagation")
    checks.append(Check("Open WebUI modelový a long-job kontrakt", "pass" if not missing_combo else "fail", f"missing={missing_combo}"))

    service = (root / "companion/src/autogenbook_companion/service.py").read_text(encoding="utf-8")

    auth_tokens = (
        "/v1/providers/validate",
        "SESSION_TOKEN_NOT_ALLOWED",
        "AUTH_INVALID",
        "AUTH_FORBIDDEN",
        "/api/models",
        "/api/chat/completions",
    )
    missing_auth = [token for token in auth_tokens if token not in (pipe + service + runner + llm_client)]
    if "def _looks_like_session_token" not in pipe or "def _looks_like_session_token" not in service:
        missing_auth.append("session-token rejection")
    if "OPENWEBUI_AUTH_INVALID" not in runner or "pokračuj {job_id}" not in runner:
        missing_auth.append("actionable resume after 401")
    installer_source_for_auth = (root / "installer/install.py").read_text(encoding="utf-8")
    if 'preserved_data.replace(staged_data)' not in installer_source_for_auth:
        missing_auth.append("atomic preservation of data during update")
    checks.append(Check("Trvalá autentizace Open WebUI a obnova po 401", "pass" if not missing_auth else "fail", f"missing={missing_auth}"))

    worker_entry = (root / "companion/src/autogenbook_companion/worker_entry.py").read_text(encoding="utf-8")
    isolation_tests = (root / "tests/test_provider_credential_isolation.py").read_text(encoding="utf-8")
    isolation_tokens = {
        "runner": (
            "AUTOGENBOOK_CREDENTIAL_ISOLATION",
            "AUTOGENBOOK_LLM_KEY_FINGERPRINT",
            "AUTOGENBOOK_LLM_SECRET_SOURCE",
            '"OPENROUTER_API_KEY"',
            'env.pop(inherited_name, None)',
            '"AUTOGENBOOK_FORCE_MINI_MODEL"',
        ),
        "client": (
            "def _selected_api_key",
            "def _selected_base_url",
            "AUTOGENBOOK_LLM_API_KEY",
            "provider-aware",
        ),
        "worker": (
            "def _preflight_selected_provider",
            "PROVIDER_AUTH_INVALID",
            "PROVIDER_PREFLIGHT_UNREACHABLE",
            "ProxyHandler({})",
            "fingerprint=",
        ),
        "security": (
            "def secret_fingerprint",
            "def set_external",
            "os.replace(temporary, reference_path)",
        ),
        "service": (
            "credential_fingerprint=secret_fingerprint(secret)",
            "credential_source=secret_resolution.source",
            "build_opener(ProxyHandler({}))",
        ),
        "tests": (
            "test_worker_preflight_uses_exact_job_scoped_key",
            "test_worker_preflight_real_loopback_transport_uses_exact_key",
            "test_worker_preflight_failure_stops_before_autogenbook_import",
            "test_job_scoped_openwebui_key_outranks_ambient_openrouter_key",
            "test_job_scoped_openwebui_base_url_outranks_role_override",
            "test_runner_scrubs_inherited_provider_credentials_and_records_fingerprint",
            "test_pipe_updates_authoritative_txt_reference_instead_of_ignored_override",
        ),
    }
    isolation_sources = {
        "runner": runner,
        "client": llm_client,
        "worker": worker_entry,
        "security": (root / "companion/src/autogenbook_companion/security.py").read_text(encoding="utf-8"),
        "service": service,
        "tests": isolation_tests + (root / "tests/test_openwebui_persistent_auth.py").read_text(encoding="utf-8"),
    }
    missing_isolation = [
        f"{group}:{token}"
        for group, tokens in isolation_tokens.items()
        for token in tokens
        if token not in isolation_sources[group]
    ]
    checks.append(
        Check(
            "Providerově izolovaný worker a exact-key preflight",
            "pass" if not missing_isolation else "fail",
            f"missing={missing_isolation}",
        )
    )

    key_file_source = (root / "companion/src/autogenbook_companion/key_file.py").read_text(encoding="utf-8")
    security_source = (root / "companion/src/autogenbook_companion/security.py").read_text(encoding="utf-8")
    installer_key_tokens = (
        "--webui-api-key-file",
        "def normalize_direct_api_key",
        'priority="external_first"',
        "http.client.HTTPConnection",
        "def registration_preflight",
        "manual_import_required",
        "--require-function-registration",
    )
    key_file_tokens = (
        "def normalize_api_key_text",
        "reject_session_token",
        '"priority": normalized_priority',
    )
    security_key_tokens = (
        'priority == "external_first"',
        'reject_session_token=(name == "openwebui_api_key")',
    )
    missing_key_contract = [token for token in installer_key_tokens if token not in installer_source_for_auth]
    missing_key_contract.extend(token for token in key_file_tokens if token not in key_file_source)
    missing_key_contract.extend(token for token in security_key_tokens if token not in security_source)
    checks.append(
        Check(
            "TXT reference, normalizace přímého klíče a bezpečná registrace Function",
            "pass" if not missing_key_contract else "fail",
            f"missing={missing_key_contract}",
        )
    )

    reviewer_pipeline = (root / "autogenbook/pipelines/reviewer_pipeline.py").read_text(encoding="utf-8")
    reviewer_quality = (root / "autogenbook/reviewer_kb1_quality.py").read_text(encoding="utf-8")
    reviewer_tests = (root / "tests/test_reviewer_kb1_workflow.py").read_text(encoding="utf-8")
    reviewer_tokens = {
        "core": (
            "REVIEWER_KB1_REQUIRED",
            "REVIEWER_KB1_EXPLICITLY_WAIVED",
            "reviewer_kb1_diagnostic.json",
            "reviewer_kb1_quality.json",
            "reviewer_allow_missing_kb1",
            "_validated_kb1_directory",
        ),
        "quality": (
            "REVIEWER_KB1_AUTH_PAGE",
            "REVIEWER_KB1_ACCESS_GATE",
            "REVIEWER_KB1_TOO_SHORT",
            "REVIEWER_KB1_IRRELEVANT",
            "authentication_url_reasons",
            "assess_file",
        ),
        "service": (
            "MISSING_REVIEWER_KB1",
            "EMPTY_REVIEWER_KB1",
            "/reviewer/kb1/import",
            "/reviewer/kb1/discover",
            '"features": {"web_search": True}',
            "_validate_public_source_url",
            "assess_reviewer_kb1_file",
            "authentication_url_reasons",
            "ProxyHandler({})",
        ),
        "pipe": (
            "REVIEWER_KB1_POLICY",
            "_ensure_reviewer_kb1",
            "_reviewer_file_picker_code",
            "_pick_reviewer_kb1_files",
            "_kb1_attachment_command",
            'fetch("/api/v1/files/?process=false"',
            '"type": "execute"',
            "interactive_file_upload",
            "chat_attachment_followup",
            "HLEDAT:",
            "allow_without_kb1",
            "MISSING_REVIEWER_KB1",
            "EMPTY_REVIEWER_KB1",
            "REVIEWER_KB1_AUTH_PAGE",
            "REVIEWER_KB1_IRRELEVANT",
        ),
        "tests": (
            "test_missing_kb1_is_validation_error_and_text_import_fixes_it",
            "test_empty_kb1_file_remains_validation_error",
            "test_private_url_is_rejected_for_kb1_import",
            "test_discovery_requests_openwebui_web_search_and_verifies_candidates",
            "test_resume_existing_reviewer_job_repairs_kb1_before_queue",
            "test_url_import_rejects_oauth_login_page",
            "test_validation_rejects_attached_authorize_page",
            "test_attached_diagnostic_archive_login_excerpt_is_rejected",
            "test_reviewer_source_prompt_offers_interactive_file_upload",
            "test_reviewer_file_picker_uses_same_origin_openwebui_upload",
            "test_interactive_picker_uploads_selected_file_as_kb1",
            "test_kb1_followup_command_accepts_chat_attachment_and_starts_project",
            "test_kb1_followup_command_resumes_failed_reviewer_job",
            "test_pipe_routes_kb1_command_with_attachments_before_job_handler",
        ),
    }
    reviewer_sources = {
        "core": reviewer_pipeline,
        "quality": reviewer_quality,
        "service": service,
        "pipe": pipe,
        "tests": reviewer_tests,
    }
    missing_reviewer = [
        f"{group}:{token}"
        for group, tokens in reviewer_tokens.items()
        for token in tokens
        if token not in reviewer_sources[group]
    ]
    checks.append(
        Check(
            "Reviewer fail-closed KB1, interaktivní soubor, řízené dohledání a SSRF ochrana",
            "pass" if not missing_reviewer else "fail",
            f"missing={missing_reviewer}",
        )
    )

    reviewer_parity = (root / "autogenbook/reviewer_parity.py").read_text(encoding="utf-8")
    reviewer_parity_tests = (root / "tests/test_reviewer_output_parity.py").read_text(encoding="utf-8")
    main_source = (root / "main.py").read_text(encoding="utf-8")
    conversion_source = (root / "autogenbook/pipelines/proposal_pipeline.py").read_text(encoding="utf-8")
    architect_source = (root / "prompts/reviewer/architect_prompt.md").read_text(encoding="utf-8-sig")
    parity_tokens = {
        "parity": (
            'DEFAULT_REVIEWER_PROFILE = "direct"',
            "DIRECT_REVIEW_CRITERIA",
            "build_reviewer_evidence_pack",
            "ordered_full_context",
            "clean_user_instructions",
            "validate_review_output",
            "write_parity_manifest",
        ),
        "pipeline": (
            'profile in {"hybrid", "compliance"}',
            "canonical prompt preserved",
            "reviewer_evidence_manifest.json",
            "reviewer_parity_manifest.json",
            "reviewer_quality_report.json",
            "reviewer_conversion_report.json",
            "REVIEWER_OUTPUT_QUALITY_FAILED",
            "REVIEWER_EXPORT_FAILED",
        ),
        "pipe": (
            "REVIEWER_PROFILE",
            'default="direct"',
            "REVIEWER_DIRECT_PDF",
            "REVIEWER_QUALITY_GATE",
            "def _clean_prompt_text",
            "clean_prompt = self._clean_prompt_text(prompt)",
        ),
        "runner": (
            '"--reviewer-llm1-model"',
            '"--reviewer-llm2-model"',
            "direct_cli_parity_request.json",
            '"required_environment"',
            '"AUTOGENBOOK_LLM_MODEL"',
        ),
        "client": (
            "_selected_job_model(self.config.model)",
        ),
        "cli": (
            '"--reviewer-profile"',
            '"--reviewer-instructions"',
            '"--reviewer-quality-gate"',
            '"--reviewer-pdf-engine"',
        ),
        "conversion": (
            '("lualatex", "xelatex", "pdflatex")',
            "normalized unsupported symbols",
        ),
        "architect": (
            "institution-specific KB1 ADDENDUM",
            "must never replace",
        ),
        "tests": (
            "test_attachment_xml_does_not_turn_input_pdf_into_pdf_only_output",
            "test_evidence_pack_is_not_legacy_six_chunk_selection",
            "test_ordered_kb1_context_uses_more_than_legacy_top_eight_when_budget_allows",
            "test_companion_builds_reproducible_direct_cli_reviewer_command",
            "test_explicit_standalone_model_is_respected_without_job_environment",
            "test_requested_pdf_failure_makes_job_fail_closed",
        ),
    }
    parity_sources = {
        "parity": reviewer_parity,
        "pipeline": reviewer_pipeline,
        "pipe": pipe,
        "runner": runner,
        "client": llm_client,
        "cli": main_source,
        "conversion": conversion_source,
        "architect": architect_source,
        "tests": reviewer_parity_tests + (root / "tests/test_reviewer_mode.py").read_text(encoding="utf-8"),
    }
    missing_parity = [
        f"{group}:{token}"
        for group, tokens in parity_tokens.items()
        for token in tokens
        if token not in parity_sources[group]
    ]
    legacy_parity_patterns = {
        "legacy reviewer k=6": "retrieve(prompt2_text, k=6",
        "legacy prompt replacement task": "Generate ONLY the final system prompt for LLM2",
    }
    present_legacy = [
        label
        for label, token in legacy_parity_patterns.items()
        if token in reviewer_pipeline or token in architect_source
    ]
    checks.append(
        Check(
            "Reviewer output parity s přímým CLI, quality gate a fail-closed exporty",
            "pass" if not missing_parity and not present_legacy else "fail",
            f"missing={missing_parity}; legacy={present_legacy}",
        )
    )

    picker_requirements = (
        'input.type = "file"',
        'input.multiple = true',
        'credentials: "include"',
        'fetch("/api/v1/files/?process=false"',
        'finish({cancelled: false, files: uploaded})',
        '".pdf", ".docx", ".pptx", ".md", ".txt"',
    )
    missing_picker = [token for token in picker_requirements if token not in pipe]
    leaked_picker_secret = any(
        token in pipe
        for token in (
            "finish({cancelled: false, files: uploaded, token",
            "resolve({cancelled: false, files: uploaded, token",
        )
    )
    checks.append(
        Check(
            "KB1 file picker: same-origin upload bez návratu credentialu",
            "pass" if not missing_picker and not leaked_picker_secret else "fail",
            f"missing={missing_picker}; leaked_secret={leaked_picker_secret}",
        )
    )

    artifacts_source = (root / "companion/src/autogenbook_companion/artifacts.py").read_text(encoding="utf-8")
    runner_tests = (root / "companion/tests/test_runner.py").read_text(encoding="utf-8")
    diagnostic_tokens = {
        "artifacts": (
            "_stage_runtime_diagnostics",
            "worker.log",
            "job_status.json",
            "companion_version",
            "bundle_manifest.json",
        ),
        "runner": (
            "failure.json",
            "failure.md",
            "_write_failure_diagnostics",
            "job_root=job_root",
        ),
        "tests": (
            "test_failed_worker_bundle_contains_worker_log_and_failure_metadata",
            "_autogenbook_companion/diagnostics/worker.log",
            "_autogenbook_companion/failure.json",
        ),
    }
    diagnostic_sources = {"artifacts": artifacts_source, "runner": runner, "tests": runner_tests}
    missing_diagnostics = [
        f"{group}:{token}"
        for group, tokens in diagnostic_tokens.items()
        for token in tokens
        if token not in diagnostic_sources[group]
    ]
    checks.append(
        Check(
            "Úplný failure bundle s worker logem a stavem",
            "pass" if not missing_diagnostics else "fail",
            f"missing={missing_diagnostics}",
        )
    )

    persistent_artifact_tests = (
        root / "tests/test_openwebui_persistent_artifacts.py"
    ).read_text(encoding="utf-8")
    authenticated_download_tests = (
        root / "tests/test_openwebui_authenticated_downloads.py"
    ).read_text(encoding="utf-8")
    persistent_artifact_tokens = {
        "pipe": (
            "PERSIST_OUTPUTS_TO_OPENWEBUI",
            "PERSIST_OUTPUT_MAX_BYTES",
            "_persistent_output_url",
            "_stream_companion_artifact",
            "uuid.uuid5",
            '"download_url_kind": "openwebui_capability_v1"',
            '"type": "file"',
            '"status": "uploaded"',
            '"url": persistent_url',
            '"openwebui_registration_verified": True',
            'include_all=(command == "artifacts")',
            "_AGB_DOWNLOAD_PREFIX = \"/api/autogenbook\"",
            "_agb_make_capability",
            "_agb_read_capability",
            "_agb_download_capability",
            "_agb_preview_content",
            "WEBUI_SECRET_KEY",
            "capability-v0.3.3",
            'data = {**data, "status": "completed", "content": preview}',
            "dočasný Companion odkaz se nezveřejňuje",
        ),
        "service": (
            "get_or_create_download_signing_key",
            "Artifact download link expired",
            "status_code=410",
            "Invalid artifact download signature",
            'row["download_url_kind"] = "temporary"',
        ),
        "tests": (
            "test_large_output_is_streamed_to_durable_openwebui_file_and_is_idempotent",
            "test_output_command_uses_only_persistent_openwebui_links",
            "test_temporary_companion_link_is_not_exposed_when_native_registration_is_unavailable",
            'assert chat_file["type"] == "file"',
            'assert chat_file["url"] == row["persistent_url"]',
            "test_expired_signed_link_returns_410_instead_of_invalid_companion_token",
            "test_unexpired_signed_link_survives_companion_bearer_token_rotation",
            "test_capability_download_is_direct_and_requires_no_browser_auth",
            "test_capability_survives_function_reload_with_stable_webui_secret",
            "test_capability_supports_head_ranges_if_range_and_rejects_tampering",
            "test_legacy_v032_broker_paths_fail_with_actionable_410",
            "test_download_route_registration_is_idempotent_and_removes_v032_routes",
            'assert partial.status_code == 206',
            'assert invalid.status_code == 416',
        ),
    }
    persistent_sources = {
        "pipe": pipe,
        "service": service + (root / "companion/src/autogenbook_companion/config.py").read_text(encoding="utf-8"),
        "tests": persistent_artifact_tests + authenticated_download_tests,
    }
    missing_persistent_artifacts = [
        f"{group}:{token}"
        for group, tokens in persistent_artifact_tokens.items()
        for token in tokens
        if token not in persistent_sources[group]
    ]
    checks.append(
        Check(
            "Trvalé Open WebUI výstupy bez expiračního Companion odkazu",
            "pass" if not missing_persistent_artifacts else "fail",
            f"missing={missing_persistent_artifacts}",
        )
    )

    capability_tokens = (
        "_agb_download_secret",
        "WEBUI_SECRET_KEY",
        "_agb_make_capability",
        "_agb_read_capability",
        "_agb_download_capability",
        "Content-Disposition",
        "Accept-Ranges",
        "Content-Range",
        'request.headers.get("if-range")',
        "hmac.compare_digest",
        'owner_id != str(claims.get("oid") or "")',
        "claimed_hash",
        "claimed_size",
        "File not found.",
    )
    missing_capability = [token for token in capability_tokens if token not in pipe]
    checks.append(
        Check(
            "Trvalá podepsaná capability pro Open WebUI download",
            "pass" if not missing_capability else "fail",
            f"missing={missing_capability}",
        )
    )

    service_tokens = (
        '/v1/jobs/{job_id}/progress',
        "Accept-Ranges",
        "Content-Range",
        'request.headers.get("if-range")',
        "ETag",
        "status_code = 206",
        "status_code=416",
    )
    missing_service = [token for token in service_tokens if token not in service]
    checks.append(Check("Progress a obnovitelné downloady", "pass" if not missing_service else "fail", f"missing={missing_service}"))

    installer_source = (root / "installer/install.py").read_text(encoding="utf-8")
    installer_tokens = (
        "def resolve_source_dir",
        "def companion_python_paths",
        'env["PYTHONPATH"]',
        "def preflight_companion",
        "process exited before becoming healthy",
        "CREATE_NO_WINDOW",
    )
    missing_installer = [token for token in installer_tokens if token not in installer_source]
    prepare_runtime = (root / "build/prepare_runtime.py").read_text(encoding="utf-8")
    if "autogenbook-companion==0.1.0" in prepare_runtime:
        missing_installer.append("obsolete companion runtime pin")
    windows_workflow = (root / ".github/workflows/build-openwebui-windows-complete.yml").read_text(encoding="utf-8")
    for obsolete in ("patch_openwebui_build.py", "patch_complete_offline.py"):
        if obsolete in windows_workflow:
            missing_installer.append(f"obsolete workflow reference: {obsolete}")
    if "verify_installer_startup" not in (root / "tools/verify_offline_stage.py").read_text(encoding="utf-8"):
        missing_installer.append("offline installer startup gate")
    checks.append(Check("Instalátor a dependency-complete startup gate", "pass" if not missing_installer else "fail", f"missing={missing_installer}"))

    integration_sources = list((root / "companion").rglob("*.py")) + list((root / "integrations").rglob("*.py"))
    shell_true = []
    public_bind = []
    for path in integration_sources:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        if re.search(r"shell\s*=\s*True", text):
            shell_true.append(path.relative_to(root).as_posix())
        if re.search(r'default\s*=\s*["\']0\.0\.0\.0["\']', text):
            public_bind.append(path.relative_to(root).as_posix())
    security_ok = not shell_true and not public_bind
    checks.append(Check("Statická bezpečnost subprocess/loopback", "pass" if security_ok else "fail", f"shell_true={shell_true}; public_bind_defaults={public_bind}"))

    legacy = list((root / "tools").glob("apply_openwebui_llm_progress*.py")) + list((root / ".github/workflows").glob("apply-openwebui-llm-progress*.yml"))
    checks.append(Check("Odstranění historického patchovacího řetězce", "pass" if not legacy else "fail", f"legacy={[p.relative_to(root).as_posix() for p in legacy]}"))


def report_markdown(payload: dict[str, object]) -> str:
    lines = [
        f"# Audit AutoGenBook Open WebUI {payload['version']}",
        "",
        f"- Vygenerováno: `{payload['generated_at']}`",
        f"- Výsledek: **{str(payload['result']).upper()}**",
        f"- Python: `{payload['python']}`",
        f"- Kontrol: `{payload['check_count']}`",
        f"- Souborů v inventáři: `{payload['file_count']}`",
        "",
        "## Kontroly",
        "",
        "| Kontrola | Stav | Detail |",
        "|---|---:|---|",
    ]
    for row in payload["checks"]:  # type: ignore[index]
        status = "PASS" if row["status"] == "pass" else "FAIL"
        detail = str(row["detail"]).replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {row['name']} | **{status}** | {detail} |")
    lines.extend(
        (
            "",
            "## Rozsah auditu",
            "",
            "Audit ověřuje zdrojový kontrakt, deterministický integrační bundle, Python syntaxi, Open WebUI Pipe, pytest sadu zvolenou pro daný release gate, CLI start, trvalé Open WebUI výstupy, stabilní podepsané capability odkazy nezávislé na browserové autentizaci, vazbu na vlastníka/hash/velikost, HEAD/Range/If-Range streaming, opravu binárního náhledu, bezpečnost dlouhých úloh/downloadů, úplný failure bundle, fail-closed reviewer KB1 workflow a výstupní paritu s přímým CLI: zachování kanonických promptů, odstranění attachment metadata, criterion-aware evidence pack, explicitní model/jazyk, quality gate a fail-closed exporty.",
            "",
            "## Omezení auditu",
            "",
            "Audit negarantuje faktickou správnost dokumentů generovaných libovolným LLM ani aktuálnost automaticky dohledaného hodnoticího předpisu. Globální pip check zdrojového builderu byl přeskočen kvůli nesouvisejícímu konfliktu MoviePy/Pillow; autoritativní offline pip/toolchain gate provádí platformní dependency-complete workflow. Podepisování Windows instalátoru a notarizace macOS vyžadují certifikáty vlastníka projektu.",
            "",
        )
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit AutoGenBook Open WebUI source and integration contract.")
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-dir", type=Path, default=Path("audit"))
    parser.add_argument("--skip-pytest", action="store_true")
    parser.add_argument(
        "--pytest-target",
        action="append",
        default=[],
        help=(
            "Run pytest only for this path/node. Repeat the flag for a targeted release-regression suite. "
            "Without targets, the complete suite is run."
        ),
    )
    parser.add_argument(
        "--skip-pip-check",
        action="store_true",
        help=(
            "Skip pip check when auditing a source-only builder environment. "
            "Dependency-complete release workflows perform their own offline runtime gate."
        ),
    )
    args = parser.parse_args()

    root = args.project_root.resolve()
    output_dir = args.output_dir.resolve()
    project_version = (root / "VERSION").read_text(encoding="utf-8").strip()
    output_dir.mkdir(parents=True, exist_ok=True)
    checks: list[Check] = []
    static_checks(root, checks)

    env = dict(os.environ)
    source_pythonpath = os.pathsep.join((str(root), str(root / "companion" / "src")))
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = os.pathsep.join(
        [source_pythonpath, existing_pythonpath] if existing_pythonpath else [source_pythonpath]
    )
    env.update(
        {
            "PYTHONUTF8": "1",
            "PIP_NO_INDEX": "1",
            "PIP_DISABLE_PIP_VERSION_CHECK": "1",
            "HTTP_PROXY": "http://127.0.0.1:9",
            "HTTPS_PROXY": "http://127.0.0.1:9",
            "ALL_PROXY": "http://127.0.0.1:9",
            "NO_PROXY": "127.0.0.1,localhost,testclient",
        }
    )
    commands = [
        ("Deterministický Open WebUI bundle", [sys.executable, "tools/build_openwebui_integration.py", "verify"]),
        ("Python compileall", [sys.executable, "-m", "compileall", "-q", "autogenbook", "companion/src", "integrations", "installer", "build", "tools"]),
        ("Validace Open WebUI Pipe", [sys.executable, "build/validate_pipe.py", "integrations/openwebui/autogenbook_pipe.py"]),
        ("Start CLI a argparse kontrakt", [sys.executable, "main.py", "--help"]),
    ]
    if not args.skip_pip_check:
        commands.append(("Konzistence nainstalovaných balíků", [sys.executable, "-m", "pip", "check"]))
    else:
        checks.append(
            Check(
                "Konzistence nainstalovaných balíků",
                "pass",
                "skipped for source-only builder environment; dependency-complete release workflow owns the offline pip/toolchain gate",
            )
        )
    if not args.skip_pytest:
        pytest_command = [sys.executable, "-m", "pytest", "-c", os.devnull, "-q"]
        pytest_name = "Kompletní pytest sada"
        if args.pytest_target:
            pytest_command.extend(args.pytest_target)
            pytest_name = "Cílená pytest release-regresní sada"
        commands.append((pytest_name, pytest_command))
    for name, command in commands:
        run_command(checks, name=name, command=command, cwd=root, output_dir=output_dir, env=env)

    inventory = file_inventory(root)
    (output_dir / "project-files.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
    result = "pass" if all(check.status == "pass" for check in checks) else "fail"
    payload: dict[str, object] = {
        "schema_version": 1,
        "project": "AutoGenBook Open WebUI",
        "version": project_version,
        "generated_at": utc_now(),
        "result": result,
        "python": sys.version.replace("\n", " "),
        "python_executable": sys.executable,
        "check_count": len(checks),
        "file_count": len(inventory),
        "checks": [asdict(check) for check in checks],
    }
    (output_dir / "audit.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "AUDIT.md").write_text(report_markdown(payload), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if result == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
