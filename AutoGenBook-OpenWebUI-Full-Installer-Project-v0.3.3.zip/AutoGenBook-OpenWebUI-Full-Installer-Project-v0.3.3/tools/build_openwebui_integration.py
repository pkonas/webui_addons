from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import io
import json
import os
import re
import tarfile
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
INTEGRATION = ROOT / "integration"
UNPACKER = ROOT / "tools" / "unpack_openwebui_bundle.py"
MANIFEST = INTEGRATION / "openwebui_bundle_manifest.json"
PART_GLOB = "openwebui_bundle.part*.b64"
PART_SIZE = 9_000

INCLUDED_PATHS = (
    Path("build"),
    Path("companion"),
    Path("installer"),
    Path("integrations"),
    Path("docs/OPENWEBUI_INTEGRATION_CS.md"),
    Path("docs/ARCHITECTURE.md"),
    Path("docs/CONFIGURATION.md"),
    Path("docs/OPERATIONS.md"),
    Path("docs/SECURITY.md"),
    Path("docs/TROUBLESHOOTING.md"),
    Path("docs/USER_GUIDE.md"),
    Path("docs/REVIEWER_KB1_WORKFLOW.md"),
    Path("docs/OUTPUT_PARITY.md"),
    Path("docs/AUDIT_SCOPE_0.3.3.md"),
    Path("docs/openwebui-llm-model-and-long-jobs.md"),
    Path("docs/incidents/2026-08-20-reviewer-kb1-policy.md"),
    Path("docs/incidents/2026-08-20-reviewer-kb1-sso-diagnostic-gap.md"),
    Path("docs/incidents/2026-08-20-reviewer-kb1-interactive-file-upload.md"),
    Path("docs/incidents/2026-08-20-openwebui-worker-credential-precedence.md"),
    Path("docs/incidents/2026-08-20-openwebui-worker-credential-precedence.json"),
    Path("docs/incidents/2026-08-27-expiring-companion-download-links.md"),
    Path("docs/incidents/2026-08-28-openwebui-reviewer-output-degradation.md"),
    Path("docs/incidents/2026-09-18-openwebui-output-download-contract.md"),
    Path("docs/incidents/2026-09-18-openwebui-authenticated-download-broker.md"),
    Path("docs/incidents/2026-09-18-openwebui-capability-download.md"),
    Path("main.py"),
    Path("autogenbook/pipelines/reviewer_pipeline.py"),
    Path("autogenbook/pipelines/proposal_pipeline.py"),
    Path("autogenbook/reviewer_kb1_quality.py"),
    Path("autogenbook/reviewer_parity.py"),
    Path("prompts/reviewer/architect_prompt.md"),
    Path("prompts/reviewer/prompt1_default.md"),
    Path("prompts/reviewer/prompt2.md"),
    Path("openrouter_llm.py"),
    Path("Configure-OpenWebUI-ApiKeyFile.cmd"),
    Path("Clear-OpenWebUI-ApiKeyFile.cmd"),
    Path("examples/openwebui-api-key.example.txt"),
    Path("VERSION"),
    Path("tests/test_openwebui_persistent_auth.py"),
    Path("tests/test_provider_credential_isolation.py"),
    Path("tests/test_openwebui_integration_v6.py"),
    Path("tests/test_openwebui_persistent_artifacts.py"),
    Path("tests/test_openwebui_authenticated_downloads.py"),
    Path("tests/test_installer_startup.py"),
    Path("tests/test_installer_api_key_file.py"),
    Path("tests/test_installer_http_registration.py"),
    Path("tests/test_reviewer_mode.py"),
    Path("tests/test_reviewer_output_parity.py"),
    Path("tests/test_reviewer_kb1_workflow.py"),
    Path("docs/incidents/2026-08-20-installer-http-400.md"),
    Path("tests/test_openwebui_function_frontmatter.py"),
)

IGNORED_PARTS = {
    ".git",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    "__pycache__",
    "dist",
    "output",
    "build-output",
}


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ignored(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in IGNORED_PARTS for part in relative.parts):
        return True
    return path.suffix.casefold() in {".pyc", ".pyo"}


def files_to_bundle() -> list[Path]:
    rows: dict[str, Path] = {}
    for relative in INCLUDED_PATHS:
        path = ROOT / relative
        if not path.exists():
            raise RuntimeError(f"Required integration input is missing: {relative}")
        candidates: Iterable[Path]
        if path.is_dir():
            candidates = path.rglob("*")
        else:
            candidates = (path,)
        for candidate in candidates:
            if candidate.is_file() and not ignored(candidate):
                rows[candidate.relative_to(ROOT).as_posix()] = candidate
    return [rows[name] for name in sorted(rows)]


def deterministic_payload(files: list[Path]) -> bytes:
    raw = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for path in files:
                relative = path.relative_to(ROOT).as_posix()
                payload = path.read_bytes()
                info = tarfile.TarInfo(relative)
                info.size = len(payload)
                info.mode = 0o755 if os.access(path, os.X_OK) else 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(payload))
    return raw.getvalue()


def update_unpacker_hash(digest: str) -> None:
    source = UNPACKER.read_text(encoding="utf-8-sig")
    source, count = re.subn(
        r'EXPECTED_SHA256\s*=\s*"[0-9a-fA-F]{64}"',
        f'EXPECTED_SHA256 = "{digest}"',
        source,
        count=1,
    )
    if count != 1:
        raise RuntimeError("EXPECTED_SHA256 was not found in the bundle unpacker")
    UNPACKER.write_text(source, encoding="utf-8")


def write_parts(payload: bytes) -> list[Path]:
    INTEGRATION.mkdir(parents=True, exist_ok=True)
    for path in INTEGRATION.glob(PART_GLOB):
        path.unlink()
    encoded = base64.b64encode(payload).decode("ascii")
    parts: list[Path] = []
    for index, start in enumerate(range(0, len(encoded), PART_SIZE), start=1):
        path = INTEGRATION / f"openwebui_bundle.part{index:03d}.b64"
        path.write_text(encoded[start : start + PART_SIZE] + "\n", encoding="ascii")
        parts.append(path)
    return parts


def reconstruct() -> bytes:
    parts = sorted(INTEGRATION.glob(PART_GLOB))
    if not parts:
        raise RuntimeError("Integration bundle parts are missing")
    encoded = "".join(path.read_text(encoding="ascii").strip() for path in parts)
    return base64.b64decode(encoded, validate=True)


def inspect_payload(payload: bytes) -> list[str]:
    names: list[str] = []
    root = ROOT.resolve()
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
        for member in archive.getmembers():
            if member.issym() or member.islnk():
                raise RuntimeError(f"Links are forbidden in the integration bundle: {member.name}")
            target = (ROOT / member.name).resolve()
            try:
                target.relative_to(root)
            except ValueError as exc:
                raise RuntimeError(f"Unsafe integration bundle member: {member.name}") from exc
            if member.isfile():
                names.append(member.name)
    return sorted(names)


def build() -> dict[str, object]:
    files = files_to_bundle()
    payload_a = deterministic_payload(files)
    payload_b = deterministic_payload(files)
    if payload_a != payload_b:
        raise RuntimeError("Integration bundle is not deterministic")
    digest = sha256_bytes(payload_a)
    names = inspect_payload(payload_a)
    expected_names = [path.relative_to(ROOT).as_posix() for path in files]
    if names != expected_names:
        raise RuntimeError("Integration bundle member inventory differs from source inventory")
    parts = write_parts(payload_a)
    update_unpacker_hash(digest)
    reconstructed = reconstruct()
    if reconstructed != payload_a:
        raise RuntimeError("Reconstructed base64 bundle differs from generated payload")
    rows = [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in files
    ]
    manifest: dict[str, object] = {
        "format_version": 1,
        "project_version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "payload_sha256": digest,
        "payload_size": len(payload_a),
        "part_count": len(parts),
        "part_size_base64_chars": PART_SIZE,
        "file_count": len(files),
        "files": rows,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def verify() -> dict[str, object]:
    if not MANIFEST.exists():
        raise RuntimeError("Integration bundle manifest is missing")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    payload = reconstruct()
    digest = sha256_bytes(payload)
    if digest != manifest.get("payload_sha256"):
        raise RuntimeError(f"Bundle hash mismatch: {digest}")
    names = inspect_payload(payload)
    expected = [str(row["path"]) for row in manifest.get("files", [])]
    if names != expected:
        raise RuntimeError("Bundle members differ from the manifest")
    declared = re.search(
        r'EXPECTED_SHA256\s*=\s*"([0-9a-fA-F]{64})"',
        UNPACKER.read_text(encoding="utf-8-sig"),
    )
    if not declared or declared.group(1).lower() != digest:
        raise RuntimeError("Bundle unpacker does not declare the current bundle hash")
    source_files = files_to_bundle()
    current_payload = deterministic_payload(source_files)
    if current_payload != payload:
        raise RuntimeError("Committed integration bundle is stale relative to the source tree")
    return {
        "verified": True,
        "payload_sha256": digest,
        "payload_size": len(payload),
        "part_count": len(list(INTEGRATION.glob(PART_GLOB))),
        "file_count": len(names),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build or verify the deterministic Open WebUI integration bundle.")
    parser.add_argument("command", choices=("build", "verify", "list"))
    args = parser.parse_args()
    if args.command == "build":
        result = build()
    elif args.command == "verify":
        result = verify()
    else:
        result = {"files": [path.relative_to(ROOT).as_posix() for path in files_to_bundle()]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
